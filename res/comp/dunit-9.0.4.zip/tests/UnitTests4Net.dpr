program UnitTests4Net;

{%DotNetAssemblyCompiler '$(SystemRoot)\microsoft.net\framework\v1.1.4322\System.Drawing.dll'}

uses
  Forms,
  SysUtils,
  Variants,
  TestFramework in '..\src\TestFramework.pas',
  TestExtensions in '..\src\TestExtensions.pas',
  NGUITestRunner in '..\src\NGUITestRunner.pas' {GUITestRunner},
  TextTestRunner in '..\src\TextTestRunner.pas',
  UnitTestExtensions in 'UnitTestExtensions.pas',
  UnitTestFramework in 'UnitTestFramework.pas';

[STAThread]
begin
  TGUITestRunner.RunRegisteredTests();
//  System.Console.WriteLine('Dunit.Net');
//  TTextTestListener.RunRegisteredTests();
//  ReadLn;
end.
