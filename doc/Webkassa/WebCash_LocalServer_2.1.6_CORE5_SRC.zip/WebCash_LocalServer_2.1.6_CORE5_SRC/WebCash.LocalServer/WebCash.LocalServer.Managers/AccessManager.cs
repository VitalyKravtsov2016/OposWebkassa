using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Serilog;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;

namespace WebCash.LocalServer.Managers
{
	public class AccessManager
	{
		[CompilerGenerated]
		private sealed class _E001
		{
			public string _E000;

			public string _E001;
		}

		[CompilerGenerated]
		private sealed class _E002
		{
			public string _E000;

			public string _E001;
		}

		private readonly MainDbContext m__E000;

		public AccessManager(MainDbContext db)
		{
			this.m__E000 = db;
		}

		public async Task RemoveAccessToCashboxAsync(string cashboxUniqueNumber, string authorizedRequestToken)
		{
			UserToCashbox userToCashbox = await _E000(cashboxUniqueNumber, authorizedRequestToken);
			if (userToCashbox != null)
			{
				Log.Information(_E01E._E000("\ue83b\ue819\ue819\ue81f\ue809\ue809\ue85a\ue80e\ue815\ue85a\ue801\ue819\ue81b\ue809\ue812\ue818\ue815\ue802\ue82f\ue814\ue813\ue80b\ue80f\ue81f\ue834\ue80f\ue817\ue818\ue81f\ue808\ue807\ue85a\ue813\ue809\ue85a\ue808\ue81f\ue817\ue815\ue80c\ue81f\ue81e\ue85a\ue81c\ue815\ue808\ue85a\ue801\ue80e\ue815\ue811\ue81f\ue814\ue807", 59408), cashboxUniqueNumber, authorizedRequestToken);
				this.m__E000.Remove(userToCashbox);
				await this.m__E000.SaveChangesAsync();
			}
		}

		private Task<UserToCashbox> _E000(string _E03C, string _E03D)
		{
			_E001 obj = new _E001();
			obj._E000 = _E03D;
			obj._E001 = _E03C;
			DbSet<UserToCashbox> source = this.m__E000.Set<UserToCashbox>();
			ParameterExpression parameterExpression = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uf3cb", 62242));
			return source.SingleOrDefaultAsync(Expression.Lambda<Func<UserToCashbox, bool>>(Expression.AndAlso(Expression.OrElse(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)))), Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression }));
		}

		public async Task<bool> AddAccessToCashboxAsync(string cashboxUniqueNumber, string authorizedRequestToken)
		{
			_E002 obj = new _E002();
			obj._E000 = cashboxUniqueNumber;
			obj._E001 = authorizedRequestToken;
			if (await _E000(obj._E000, obj._E001) != null)
			{
				return false;
			}
			Log.Information(_E01E._E000("\uf5ab\uf589\uf589\uf58f\uf599\uf599\uf5ca\uf59e\uf585\uf5ca\uf591\uf589\uf58b\uf599\uf582\uf588\uf585\uf592\uf5bf\uf584\uf583\uf59b\uf59f\uf58f\uf5a4\uf59f\uf587\uf588\uf58f\uf598\uf597\uf5ca\uf59d\uf58b\uf599\uf5ca\uf58b\uf58e\uf58e\uf58f\uf58e\uf5ca\uf58c\uf585\uf598\uf5ca\uf591\uf59e\uf585\uf581\uf58f\uf584\uf597", 62848), obj._E000, obj._E001);
			DbSet<Cashbox> cashboxes = this.m__E000.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			IQueryable<Cashbox> source = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			Task<long> task = source.Select(Expression.Lambda<Func<Cashbox, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			DbSet<User> users = this.m__E000.Users;
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			IQueryable<User> source2 = users.Where(Expression.Lambda<Func<User, bool>>(Expression.OrElse(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			Task<long> task2 = source2.Select(Expression.Lambda<Func<User, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			MainDbContext mainDbContext = this.m__E000;
			UserToCashbox userToCashbox = new UserToCashbox();
			UserToCashbox userToCashbox2 = userToCashbox;
			userToCashbox2.CashboxId = await task;
			UserToCashbox userToCashbox3 = userToCashbox;
			userToCashbox3.UserId = await task2;
			await mainDbContext.AddAsync(userToCashbox);
			await this.m__E000.SaveChangesAsync();
			return true;
		}

		public async Task<bool> HasAccessToCashboxAsync(string cashboxUniqueNumber, string authorizedRequestToken)
		{
			return await _E000(cashboxUniqueNumber, authorizedRequestToken) != null;
		}
	}
}
