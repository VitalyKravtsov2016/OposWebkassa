using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Serilog;
using Serilog.Events;
using WebCash.Constants.Enums;
using WebCash.ServiceContracts;

namespace WebCash.LocalServer.Controllers
{
	public class ApiController : ControllerBase
	{
		protected ApiResult CollectModelErrors()
		{
			ApiResult apiResult = new ApiResult();
			foreach (KeyValuePair<string, ModelStateEntry> item in base.ModelState.Where<KeyValuePair<string, ModelStateEntry>>((KeyValuePair<string, ModelStateEntry> _E0BF) => _E0BF.Value.Errors.Any()))
			{
				apiResult.AddError(ApiErrorCode.ValidationError, string.Format(_E01E._E000("\ueee5\ueec4\ueec1\ueecf\ueac0\ueada\uea81\ueaca\uea87\ueac0\ueada\uea81\ueacb\uea87", 60144), item.Key, string.Join(_E01E._E000("\uea42\uea59", 59992), from _E0C1 in item.Value.Errors.SelectMany((ModelError _E0C0) => new string[2]
					{
						_E0C0.ErrorMessage,
						(_E0C0.Exception != null) ? _E0C0.Exception.Message : null
					})
					where _E0C1 != null
					select _E0C1)));
			}
			return apiResult;
		}

		protected void LogRequestBody()
		{
			if (!Log.IsEnabled(LogEventLevel.Verbose) || !base.Request.ContentLength.HasValue)
			{
				return;
			}
			try
			{
				byte[] array = new byte[base.Request.ContentLength.Value];
				base.Request.Body.Position = 0L;
				base.Request.Body.Read(array, 0, array.Length);
				string @string = Encoding.UTF8.GetString(array);
				Log.Verbose(_E01E._E000("\uf08c\uf085\uf092\uf086\uf082\uf092\uf084\uf083\uf08a", 61542), @string);
			}
			catch (Exception)
			{
			}
		}
	}
}
