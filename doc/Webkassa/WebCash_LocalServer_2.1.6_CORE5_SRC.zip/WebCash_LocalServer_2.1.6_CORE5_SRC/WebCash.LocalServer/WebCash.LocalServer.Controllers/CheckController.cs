using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebCash.LocalServer.Abstractions;
using WebCash.LocalServer.DAL;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Controllers
{
	[Route("api/[controller]")]
	[Route("api/v1/[controller]")]
	[Route("api/v2/[controller]")]
	public class CheckController : ApiController
	{
		private readonly IMediator _E000;

		public CheckController(IMediator mediator)
		{
			this._E000 = mediator;
		}

		[HttpPost]
		[ProducesResponseType(typeof(ApiResult<CheckOperationResponse>), 200)]
		public async Task<ApiResult> Post([FromBody] CheckOperationRequest request, [FromServices] MainDbContext db)
		{
			LogRequestBody();
			if (!base.ModelState.IsValid)
			{
				return CollectModelErrors();
			}
			return await this._E000.GetResponse(new _E01C(db), request);
		}
	}
}
