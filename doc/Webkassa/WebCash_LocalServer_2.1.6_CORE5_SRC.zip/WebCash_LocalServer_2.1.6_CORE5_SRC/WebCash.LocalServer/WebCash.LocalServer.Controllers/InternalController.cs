using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebCash.Constants.Enums;
using WebCash.LocalServer.Abstractions;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.LocalServer.Descriptions;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Controllers
{
	[Route("/api/[controller]/[action]")]
	[Route("/api/v1/[controller]/[action]")]
	[Route("/api/v2/[controller]/[action]")]
	public class InternalController : ApiController
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public string _E000;
		}

		[HttpGet]
		[ProducesResponseType(typeof(ApiResult<VersionResponse>), 200)]
		public ApiResult Version()
		{
			string version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			return new ApiResult<VersionResponse>(new VersionResponse
			{
				Version = version
			});
		}

		[HttpGet("{cashboxUniqueNumber}")]
		[ProducesResponseType(typeof(ApiResult<OfflineSwitchResponse>), 200)]
		public async Task<ApiResult> OfflineModeStartedAt(string cashboxUniqueNumber, [FromServices] MainDbContext db)
		{
			_E000 obj = new _E000();
			obj._E000 = cashboxUniqueNumber;
			DbSet<CashboxState> cashboxStates = db.CashboxStates;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			_E000<DateTime?> obj2 = await source.Select(Expression.Lambda<Func<CashboxState, _E000<DateTime?>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E000<DateTime?>).TypeHandle), new Expression[1] { Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)) }, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E000<DateTime?>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleOrDefaultAsync();
			if (obj2 == null)
			{
				return ApiResult.Error(ApiErrorCode.CashboxNotFound, _E01E._E000("\uf6fb\uf6d1\uf6a0\uf6a0\uf6d1\uf2c1\uf6dc\uf6d4\uf2c1\uf6dc\uf6d1\uf6d8\uf6d5\uf6d4\uf6dc\uf6d1\uf2c1\uf6dc\uf6d1\uf2c1\uf6da\uf6df\uf6db\uf6d1\uf6da\uf6ad\uf6dc\uf6df\uf6dd\uf2c1\uf6dd\uf6df\uf6d5\uf6a2\uf6da\uf6d4\uf2cf\uf2c1\uf6fc\uf6d4\uf6df\uf6d0\uf6a4\uf6df\uf6d5\uf6d9\uf6dd\uf6df\uf2c1\uf6d3\uf6aa\uf6de\uf6df\uf6da\uf6dc\uf6d9\uf6a3\uf6ad\uf2c1\uf6d1\uf6d3\uf6a3\uf6df\uf6a1\uf6d9\uf6d6\uf6df\uf6d3\uf6d1\uf6dc\uf6dc\uf6a2\uf6af\uf2c1\uf6df\uf6de\uf6d4\uf6a1\uf6d1\uf6a7\uf6d9\uf6af", 62113));
			}
			return new ApiResult<OfflineSwitchResponse>(new OfflineSwitchResponse
			{
				OfflineModeStartedAt = obj2._E001
			});
		}

		[HttpPost]
		[ProducesResponseType(typeof(ApiResult<CashboxShortStateResponse>), 200)]
		public async Task<ApiResult> CashboxState([FromServices] IMediator mediator, [FromBody] CashboxRequest request, [FromServices] MainDbContext db)
		{
			LogRequestBody();
			if (!base.ModelState.IsValid)
			{
				return CollectModelErrors();
			}
			return await mediator.GetResponse(new CashboxStateDescription(db), request);
		}
	}
}
