using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Serilog;
using Serilog.Context;

namespace WebCash.LocalServer.Middleware
{
	public class RequestIdLoggingMiddleware
	{
		private readonly RequestDelegate _E000;

		public RequestIdLoggingMiddleware(RequestDelegate next)
		{
			this._E000 = next;
		}

		public async Task Invoke(HttpContext context)
		{
			using (LogContext.PushProperty(_E01E._E000("\uf5a9\uf59e\uf58a\uf58e\uf59e\uf588\uf58f\uf5b2\uf59f", 62867), context.TraceIdentifier))
			{
				Log.Information(_E01E._E000("\ue683\ue6b4\ue6a0\ue6a4\ue6b4\ue6a2\ue6a5\ue6f1\ue6aa\ue6bc\ue6b4\ue6a5\ue6b9\ue6be\ue6b5\ue6ac\ue6f1\ue6a5\ue6be\ue6f1\ue6aa\ue6a4\ue6a3\ue6bd\ue6ac\ue6aa\ue6a0\ue6a4\ue6b4\ue6a3\ue6a8\ue682\ue6a5\ue6a3\ue6b8\ue6bf\ue6b6\ue6ac", 59089), context.Request.Method, context.Request.Path, context.Request.QueryString);
				await this._E000(context);
				Log.Information(_E01E._E000("\ue2ab\ue29c\ue28a\ue289\ue296\ue297\ue28a\ue29c\ue2d9\ue28d\ue296\ue2d9\ue282\ue28c\ue28b\ue295\ue284\ue2d9\ue28a\ue28d\ue298\ue28d\ue28c\ue28a\ue2d9\ue290\ue28a\ue2d9\ue282\ue28a\ue28d\ue298\ue28d\ue28c\ue28a\ue284", 58072), context.Request.Path, context.Response.StatusCode);
			}
		}
	}
}
