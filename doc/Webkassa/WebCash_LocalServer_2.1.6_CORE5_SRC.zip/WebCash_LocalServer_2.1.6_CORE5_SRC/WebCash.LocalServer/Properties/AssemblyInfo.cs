using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.Extensions.Configuration.UserSecrets;

[assembly: UserSecretsId("4a94a3ae-3007-4ca3-8c4e-02038eafcf18")]
[assembly: AssemblyCompany("Esepshi Development")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCopyright("© 2018 Esepshi Development")]
[assembly: AssemblyDescription("Локальный модуль Webkassa для интеграции по API")]
[assembly: AssemblyFileVersion("2.1.6.0")]
[assembly: AssemblyInformationalVersion("2.1.6.0")]
[assembly: AssemblyProduct("WebCash.LocalServer")]
[assembly: AssemblyTitle("WebCash.LocalServer")]
[assembly: ApplicationPart("Swashbuckle.AspNetCore.SwaggerGen")]
[assembly: SuppressIldasm]
[assembly: AssemblyVersion("2.1.6.0")]
