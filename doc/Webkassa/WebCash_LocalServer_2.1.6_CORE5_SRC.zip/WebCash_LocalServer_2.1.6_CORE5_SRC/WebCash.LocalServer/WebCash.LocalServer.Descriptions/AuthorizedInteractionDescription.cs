using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Serilog;
using WebCash.LocalServer.Abstractions;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;

namespace WebCash.LocalServer.Descriptions
{
	public abstract class AuthorizedInteractionDescription<TRequest, TResponse> : IDisposable, IServerInteractionDescription<TRequest, TResponse> where TRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private sealed class _E002
		{
			public string _E000;
		}

		[CompilerGenerated]
		private sealed class _E004
		{
			public string _E000;
		}

		[CompilerGenerated]
		private sealed class _E006
		{
			public string _E000;
		}

		[CompilerGenerated]
		private sealed class _E008<_E007>
		{
			public RequestType _E000;

			public Cashbox _E001;
		}

		[CompilerGenerated]
		private sealed class _E00A
		{
			public long _E000;

			public string _E001;

			public RequestType _E002;
		}

		[CompilerGenerated]
		private readonly MainDbContext m__E000;

		protected TimeSpan AllowedOfflinePeriod => TimeSpan.FromHours(72.0);

		public abstract string Url { get; }

		protected MainDbContext Db
		{
			[CompilerGenerated]
			get
			{
				return this._E000;
			}
		}

		public abstract ApiResult ConvertBeforeReply(TResponse response);

		public abstract Task<TResponse> CreateOfflineResponseAsync(TRequest request);

		public abstract string GetCashboxUniqueNumber(TRequest request);

		public abstract void PrepareRequestBeforeSend(TRequest request);

		public abstract Task SaveToOfflineStoreAsync(TRequest request, TResponse response);

		public abstract Task UpdateLocalStorageAsync(TRequest request, TResponse response);

		public abstract Task<TResponse> ValidateAsync(TRequest request);

		public AuthorizedInteractionDescription(MainDbContext db)
		{
			this._E000 = db;
		}

		public void Dispose()
		{
			Db.Dispose();
		}

		public virtual async Task<bool> MustBeRegisterOffline(TRequest request)
		{
			return await _E000(GetCashboxUniqueNumber(request));
		}

		public virtual async Task<bool> HandleError(TRequest request, TResponse response)
		{
			return false;
		}

		private async Task<bool> _E000(string _E094)
		{
			_E002 obj = new _E002();
			obj._E000 = _E094;
			DbSet<OfflineRequest> offlineRequests = Db.OfflineRequests;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
			return await offlineRequests.AnyAsync(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E002).TypeHandle))), new ParameterExpression[1] { parameterExpression }));
		}

		private async Task<bool> _E001(string _E095)
		{
			_E004 obj = new _E004();
			obj._E000 = _E095;
			if (string.IsNullOrEmpty(obj._E000))
			{
				return false;
			}
			DbSet<User> users = Db.Users;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			IQueryable<User> source = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E004).TypeHandle))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			return await source.Select(Expression.Lambda<Func<User, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).AnyAsync();
		}

		private async Task<bool> _E002(string _E096)
		{
			_E006 obj = new _E006();
			obj._E000 = _E096;
			if (string.IsNullOrEmpty(obj._E000))
			{
				return false;
			}
			DbSet<User> users = Db.Users;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			return await users.Where(Expression.Lambda<Func<User, bool>>(Expression.OrElse(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E006).TypeHandle))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E006).TypeHandle)))), new ParameterExpression[1] { parameterExpression })).AnyAsync();
		}

		protected bool OfflinePeriodMoreThanThreshold(DateTime? offlineModeStarTime)
		{
			if (!offlineModeStarTime.HasValue)
			{
				return false;
			}
			return DateTime.Now - offlineModeStarTime.Value > AllowedOfflinePeriod;
		}

		protected async Task SaveLastOperationAsync<T>(TRequest request, T response, Cashbox cashbox, RequestType requestType, string externalId)
		{
			_E008<T> obj = new _E008<T>();
			obj._E000 = requestType;
			obj._E001 = cashbox;
			try
			{
				DbSet<OperationData> lastOperations = Db.LastOperations;
				ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
				OperationData operationData = await lastOperations.SingleOrDefaultAsync(Expression.Lambda<Func<OperationData, bool>>(Expression.AndAlso(Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Convert(Expression.Field(Expression.Constant(obj, typeof(_E008<T>)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E008<T>).TypeHandle)), typeof(int))), Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E008<T>)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E008<T>).TypeHandle)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression }));
				if (operationData == null)
				{
					operationData = new OperationData
					{
						Cashbox = obj._E001
					};
					await Db.LastOperations.AddAsync(operationData);
				}
				operationData.Date = DateTime.Now;
				operationData.Type = obj._E000;
				operationData.Request = JsonConvert.SerializeObject(request);
				operationData.Response = JsonConvert.SerializeObject(response);
				operationData.ExternalId = externalId;
				await Db.SaveChangesAsync();
			}
			catch (Exception exception)
			{
				Log.Error(exception, _E01E._E000("\ueabe\uea9c\uea93\ueada\uea89\ueadd\uea8e\uea9c\uea8b\uea98\ueadd\uea91\uea9c\uea8e\uea89\ueadd\uea92\uea8d\uea98\uea8f\uea9c\uea89\uea94\uea92\uea93", 60133));
			}
		}

		protected async Task<OperationData> FindLastOperationAsync(long cashboxId, RequestType requestType, string externalId)
		{
			_E00A obj = new _E00A();
			obj._E000 = cashboxId;
			obj._E001 = externalId;
			obj._E002 = requestType;
			DbSet<OperationData> lastOperations = Db.LastOperations;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
			return await lastOperations.SingleOrDefaultAsync(Expression.Lambda<Func<OperationData, bool>>(Expression.AndAlso(Expression.AndAlso(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E00A)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E00A).TypeHandle))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E00A)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E00A).TypeHandle)))), Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Convert(Expression.Field(Expression.Constant(obj, typeof(_E00A)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E00A).TypeHandle)), typeof(int)))), new ParameterExpression[1] { parameterExpression }));
		}

		public virtual bool NeedPing()
		{
			return true;
		}
	}
}
