using System;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.LocalServer.Managers;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Descriptions
{
	public class CashboxStateDescription : AuthorizedInteractionDescription<CashboxRequest, ApiResult<CashboxShortStateResponse>>
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public CashboxRequest _E000;
		}

		public override string Url => _E01E._E000("\uefd6\uef98\uef89\uef90\uefd6\uef9a\uef98\uef8a\uef91\uef9b\uef96\uef81\uefd6\uef95\uef96\uef9a\uef98\uef95\uefb4\uef96\uef9d\uef8c\uef95\uef9c\uefaa\uef8d\uef98\uef8d\uef9c", 61432);

		public CashboxStateDescription(MainDbContext db)
			: base(db)
		{
		}

		public override void PrepareRequestBeforeSend(CashboxRequest request)
		{
		}

		public override Task SaveToOfflineStoreAsync(CashboxRequest request, ApiResult<CashboxShortStateResponse> response)
		{
			return Task.CompletedTask;
		}

		public override Task UpdateLocalStorageAsync(CashboxRequest request, ApiResult<CashboxShortStateResponse> response)
		{
			return Task.CompletedTask;
		}

		public override Task<ApiResult<CashboxShortStateResponse>> ValidateAsync(CashboxRequest request)
		{
			return Task.FromResult(new ApiResult<CashboxShortStateResponse>());
		}

		public override ApiResult ConvertBeforeReply(ApiResult<CashboxShortStateResponse> response)
		{
			return response;
		}

		public override async Task<ApiResult<CashboxShortStateResponse>> CreateOfflineResponseAsync(CashboxRequest request)
		{
			_E000 obj = new _E000();
			obj._E000 = request;
			DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			_E002<double> obj2 = await source.Select(Expression.Lambda<Func<CashboxState, _E002<double>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E002<double>).TypeHandle), new Expression[1] { Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)) }, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E002<double>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			return new ApiResult<CashboxShortStateResponse>(new CashboxShortStateResponse
			{
				SumInCashbox = obj2._E001
			});
		}

		public override string GetCashboxUniqueNumber(CashboxRequest request)
		{
			return request.CashboxUniqueNumber;
		}

		public override async Task<bool> MustBeRegisterOffline(CashboxRequest request)
		{
			AccessManager accessManager = new AccessManager(base.Db);
			bool flag = await base.MustBeRegisterOffline(request);
			if (!flag)
			{
				flag = await accessManager.HasAccessToCashboxAsync(request.CashboxUniqueNumber, request.Token);
			}
			return flag;
		}

		public override bool NeedPing()
		{
			return false;
		}

		[CompilerGenerated]
		[DebuggerHidden]
		private Task<bool> _E000(CashboxRequest _E097)
		{
			return base.MustBeRegisterOffline(_E097);
		}
	}
}
