using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using WebCash.Constants.Enums;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.LocalServer.Descriptions.Base;
using WebCash.Resources;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Descriptions
{
	public class ZReportDescription : BaseReportDescription<ZReportRequest>
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public ZReportRequest _E000;
		}

		[CompilerGenerated]
		private sealed class _E002
		{
			public ZReportRequest _E000;

			public Cashbox _E001;

			public CashboxState _E002;
		}

		[CompilerGenerated]
		private sealed class _E004
		{
			public ZReportRequest _E000;
		}

		[CompilerGenerated]
		private sealed class _E006
		{
			public ZReportRequest _E000;

			public Cashbox _E001;
		}

		[CompilerGenerated]
		private sealed class _E008
		{
			public ZReportRequest _E000;
		}

		[CompilerGenerated]
		private sealed class _E009
		{
			public Cashbox _E000;
		}

		[CompilerGenerated]
		private bool m__E000;

		public override string Url => _E01E._E000("\uef54\uef1a\uef0b\uef12\uef54\uef01\uef09\uef1e\uef0b\uef14\uef09\uef0f", 61275);

		public bool AutoCloseRequestAfterSpecifiedTime
		{
			[CompilerGenerated]
			get
			{
				return this.m__E000;
			}
			[CompilerGenerated]
			set
			{
				this.m__E000 = value;
			}
		}

		public ZReportDescription(MainDbContext db)
			: base(db)
		{
		}

		public override async Task<ApiResult<ZXReportResponse>> ValidateAsync(ZReportRequest request)
		{
			_E000 obj = new _E000();
			obj._E000 = request;
			DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			_E005<DateTime?, DateTime?, DateTime?> obj2 = await source.Select(Expression.Lambda<Func<CashboxState, _E005<DateTime?, DateTime?, DateTime?>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E005<DateTime?, DateTime?, DateTime?>).TypeHandle), new Expression[3]
			{
				Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
				Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
				Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))
			}, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E005<DateTime?, DateTime?, DateTime?>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E005<DateTime?, DateTime?, DateTime?>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E005<DateTime?, DateTime?, DateTime?>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			if (OfflinePeriodMoreThanThreshold(obj2._E005))
			{
				return new ApiResult<ZXReportResponse>(ApiErrorCode.OfflineModeMoreThan72Hours, CommonResource.OfflineModeDurationMore72Hours);
			}
			if (!obj2._E003.HasValue)
			{
				return new ApiResult<ZXReportResponse>(ApiErrorCode.ShiftNotFound, _E01E._E000("\ue300\ue328\ue73d\ue320\ue32d\ue324\ue329\ue328\ue320\ue32d\ue73d\ue323\ue35f\ue327\ue35d\ue356\ue35f\ue32d\ue352\ue73d\ue35c\ue321\ue328\ue320\ue32d", 59157));
			}
			if (obj2._E004.HasValue)
			{
				return new ApiResult<ZXReportResponse>(ApiErrorCode.ShiftAlreadyClosed, ValidationResource.ShiftAlreadyClose);
			}
			return new ApiResult<ZXReportResponse>();
		}

		public override async Task<ApiResult<ZXReportResponse>> CreateOfflineResponseAsync(ZReportRequest request)
		{
			_E002 obj = new _E002();
			obj._E000 = request;
			StateCanBeUpdated = false;
			DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			obj._E002 = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			DbSet<OperationSummary> operationSummaries = base.Db.OperationSummaries;
			parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
			IQueryable<OperationSummary> source = operationSummaries.Where(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
			Dictionary<OperationTypeEnum, OperationSummary> dictionary = await source.Include(Expression.Lambda<Func<OperationSummary, ICollection<PaymentSummary>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).ToDictionaryAsync((OperationSummary _E0B9) => _E0B9.Type, (OperationSummary _E0BA) => _E0BA);
			DbSet<User> users = base.Db.Users;
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			IQueryable<User> source2 = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			Task<int> task = source2.Select(Expression.Lambda<Func<User, int>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			DateTime now = DateTime.Now;
			ZXReportResponse zXReportResponse = new ZXReportResponse
			{
				CashboxIN = obj._E001.IdentityNumber,
				CashboxRN = obj._E001.RegistrationNumber,
				CashboxSN = obj._E001.UniqueNumber,
				CashboxOfflineMode = true,
				OfflineMode = true,
				ShiftNumber = obj._E002.ShiftNumber,
				StartNonNullable = new NonNullableApiModel
				{
					Sell = (decimal)obj._E002.NNStartSell,
					Buy = (decimal)obj._E002.NNStartBuy,
					ReturnBuy = (decimal)obj._E002.NNStartReturnBuy,
					ReturnSell = (decimal)obj._E002.NNStartReturnSell
				},
				SumInCashbox = (obj._E001.AutoWithdrawal ? 0m : ((decimal)obj._E002.SumInCashbox))
			};
			ZXReportResponse zXReportResponse2 = zXReportResponse;
			zXReportResponse2.CashierCode = await task;
			zXReportResponse.CloseOn = obj._E002.ShiftClosedOn ?? obj._E000.OfflineDate ?? now;
			zXReportResponse.ControlSum = Math.Abs(obj._E000.ExternalCheckNumber.GetHashCode());
			zXReportResponse.DocumentCount = obj._E002.DocumentsCount + 1;
			zXReportResponse.PutMoneySum = (decimal)obj._E002.CashDeposits;
			zXReportResponse.TakeMoneySum = (decimal)obj._E002.CashWithdrawals + (decimal)(obj._E001.AutoWithdrawal ? obj._E002.SumInCashbox : 0.0);
			zXReportResponse.ReportOn = obj._E000.OfflineDate ?? now;
			zXReportResponse.StartOfflineMode = obj._E002.OfflineModeStart ?? now;
			zXReportResponse.StartOn = obj._E002.ShiftOpened.Value;
			zXReportResponse.ExternalReportId = obj._E000.ExternalCheckNumber;
			zXReportResponse.Sell = GenerateOperationSummary(dictionary[OperationTypeEnum.Sell]);
			zXReportResponse.Buy = GenerateOperationSummary(dictionary[OperationTypeEnum.Buy]);
			zXReportResponse.ReturnBuy = GenerateOperationSummary(dictionary[OperationTypeEnum.ReturnBuy]);
			zXReportResponse.ReturnSell = GenerateOperationSummary(dictionary[OperationTypeEnum.ReturnSell]);
			zXReportResponse.TaxPayerName = obj._E001.OrganizationFullName;
			zXReportResponse.TaxPayerIN = obj._E001.OrganizationXin;
			zXReportResponse.TaxPayerVAT = obj._E001.OrganizationIsVatPayer;
			zXReportResponse.TaxPayerVATNumber = obj._E001.OrganizationVatNumber;
			zXReportResponse.TaxPayerVATSeria = obj._E001.OrganizationVatSeria;
			zXReportResponse.ReportNumber = obj._E002.DocumentsCount + 1;
			zXReportResponse.Ofd = new OfdInformation(obj._E001.OfdName, obj._E001.OfdHost, obj._E001.OfdCode);
			ZXReportResponse zXReportResponse3 = zXReportResponse;
			zXReportResponse3.EndNonNullable = new NonNullableApiModel
			{
				Sell = zXReportResponse3.StartNonNullable.Sell + (decimal)dictionary[OperationTypeEnum.Sell].Sum,
				Buy = zXReportResponse3.StartNonNullable.Buy + (decimal)dictionary[OperationTypeEnum.Buy].Sum,
				ReturnBuy = zXReportResponse3.StartNonNullable.ReturnBuy + (decimal)dictionary[OperationTypeEnum.ReturnBuy].Sum,
				ReturnSell = zXReportResponse3.StartNonNullable.ReturnSell + (decimal)dictionary[OperationTypeEnum.ReturnSell].Sum
			};
			return new ApiResult<ZXReportResponse>(zXReportResponse3);
		}

		public override async Task SaveToOfflineStoreAsync(ZReportRequest request, ApiResult<ZXReportResponse> response)
		{
			_E004 obj = new _E004();
			obj._E000 = request;
			string content = JsonConvert.SerializeObject(new OfflineXzReportRequest
			{
				CashboxUniqueNumber = obj._E000.CashboxUniqueNumber,
				ExternalCheckNumber = obj._E000.ExternalCheckNumber,
				Token = obj._E000.Token,
				OfflineDate = response.Data.ReportOn,
				AsImage = false,
				ReportType = ReportTypeEnum.ReportZ
			});
			DbSet<OfflineRequest> offlineRequests = base.Db.OfflineRequests;
			OfflineRequest offlineRequest = new OfflineRequest();
			OfflineRequest offlineRequest2 = offlineRequest;
			DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			offlineRequest2.Cashbox = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			offlineRequest.ExternalId = obj._E000.ExternalCheckNumber;
			offlineRequest.Type = RequestType.XZReport;
			offlineRequest.Content = content;
			await offlineRequests.AddAsync(offlineRequest);
			await base.Db.SaveChangesAsync();
		}

		public override async Task UpdateLocalStorageAsync(ZReportRequest request, ApiResult<ZXReportResponse> response)
		{
			_E006 obj = new _E006();
			obj._E000 = request;
			DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			DbSet<Cashbox> cashboxes2 = base.Db.Cashboxes;
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			IQueryable<Cashbox> source = cashboxes2.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			bool flag = await source.Select(Expression.Lambda<Func<Cashbox, bool>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			cashboxState.ShiftClosedOn = response.Data.CloseOn;
			cashboxState.DocumentsCount = (int)response.Data.ReportNumber;
			cashboxState.OfflineModeStart = response.Data.StartOfflineMode;
			if (response.Data.Ofd != null)
			{
				obj._E001.OfdName = response.Data.Ofd.Name;
				obj._E001.OfdHost = response.Data.Ofd.Host;
				obj._E001.OfdCode = response.Data.Ofd.Code;
			}
			obj._E001.IdentityNumber = response.Data.CashboxIN;
			obj._E001.OrganizationIsVatPayer = response.Data.TaxPayerVAT;
			obj._E001.OrganizationVatNumber = response.Data.TaxPayerVATNumber;
			obj._E001.OrganizationVatSeria = response.Data.TaxPayerVATSeria;
			if (flag)
			{
				cashboxState.CashWithdrawals += cashboxState.SumInCashbox;
				cashboxState.SumInCashbox = 0.0;
			}
			UpdateStateFromResponse(cashboxState, response.Data);
			await base.Db.SaveChangesAsync();
			await SaveLastOperationAsync(obj._E000, response, obj._E001, RequestType.XZReport, obj._E000.ExternalCheckNumber);
		}

		public override async Task<bool> HandleError(ZReportRequest request, ApiResult<ZXReportResponse> response)
		{
			_E008 obj = new _E008();
			obj._E000 = request;
			if (response.HasError(ApiErrorCode.ShiftAlreadyClosed))
			{
				_E009 obj2 = new _E009();
				ApiResult<ZXReportResponse> apiResult = await CreateOfflineResponseAsync(obj._E000);
				if (apiResult.HasError())
				{
					return false;
				}
				ZXReportResponse data = apiResult.Data;
				data.DocumentCount--;
				data.ReportNumber--;
				DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
				ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
				IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
				parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
				_E000<DateTime?> obj3 = await source.Select(Expression.Lambda<Func<CashboxState, _E000<DateTime?>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E000<DateTime?>).TypeHandle), new Expression[1] { Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)) }, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E000<DateTime?>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
				data.OfflineMode = obj3._E001.HasValue;
				data.CashboxOfflineMode = obj3._E001.HasValue;
				data.StartOfflineMode = obj3._E001;
				data.ReportOn = data.CloseOn.Value;
				DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
				parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
				obj2._E000 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
				DbSet<CashboxState> cashboxStates2 = base.Db.CashboxStates;
				parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
				if (!(await cashboxStates2.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj2, typeof(_E009)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }))).ShiftClosedOn.HasValue)
				{
					await UpdateLocalStorageAsync(obj._E000, apiResult);
				}
				response.Data = data;
				return true;
			}
			return await base.HandleError(obj._E000, response);
		}

		public override async Task<bool> MustBeRegisterOffline(ZReportRequest request)
		{
			return await base.MustBeRegisterOffline(request) || AutoCloseRequestAfterSpecifiedTime;
		}

		[CompilerGenerated]
		[DebuggerHidden]
		private Task<bool> _E000(ZReportRequest _E0B6, ApiResult<ZXReportResponse> _E0B7)
		{
			return base.HandleError(_E0B6, _E0B7);
		}

		[CompilerGenerated]
		[DebuggerHidden]
		private Task<bool> _E001(ZReportRequest _E0B8)
		{
			return base.MustBeRegisterOffline(_E0B8);
		}
	}
}
