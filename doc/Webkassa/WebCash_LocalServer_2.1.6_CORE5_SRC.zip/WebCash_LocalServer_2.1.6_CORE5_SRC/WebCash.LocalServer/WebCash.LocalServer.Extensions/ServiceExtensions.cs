using System;
using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace WebCash.LocalServer.Extensions
{
	public static class ServiceExtensions
	{
		private static JsonSerializerSettings m__E000;

		private static void _E000()
		{
			ServiceExtensions.m__E000 = new JsonSerializerSettings
			{
				NullValueHandling = NullValueHandling.Ignore,
				DateFormatString = _E01E._E000("\ue69b\ue69b\ue6d1\ue6b2\ue6b2\ue6d1\ue686\ue686\ue686\ue686\ue6df\ue6b7\ue6b7\ue6c5\ue692\ue692\ue6c5\ue68c\ue68c", 59033),
				Culture = new CultureInfo(_E01E._E000("\uf3eb\uf3e0\uf383\uf3db\uf3dd", 62218)),
				ContractResolver = new DefaultContractResolver
				{
					NamingStrategy = new DefaultNamingStrategy()
				}
			};
		}

		public static IMvcCoreBuilder ConfigureLookingAtNET(this IServiceCollection services)
		{
			_E000();
			return services.AddMvcCore(delegate(MvcOptions _E091)
			{
				_E091.EnableEndpointRouting = false;
			}).AddNewtonsoftJson(delegate(MvcNewtonsoftJsonOptions _E092)
			{
				_E092.SerializerSettings.NullValueHandling = ServiceExtensions.m__E000.NullValueHandling;
				_E092.SerializerSettings.DateFormatString = ServiceExtensions.m__E000.DateFormatString;
				_E092.SerializerSettings.Culture = ServiceExtensions.m__E000.Culture;
				_E092.SerializerSettings.ContractResolver = ServiceExtensions.m__E000.ContractResolver;
			});
		}

		public static IHostApplicationLifetime GetApplicationLifetimeService(this IServiceProvider services)
		{
			return services.GetRequiredService<IHostApplicationLifetime>();
		}
	}
}
