using WebCash.LocalServer.DAL.Entities;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Extensions
{
	public static class DbExtensions
	{
		public static CashboxInfo ToCashboxInfo(this Cashbox cashbox)
		{
			return new CashboxInfo(cashbox.UniqueNumber, cashbox.RegistrationNumber, cashbox.IdentityNumber.ToString(), cashbox.Address, new OfdInformation(cashbox.OfdName, cashbox.OfdHost, cashbox.OfdCode));
		}
	}
}
