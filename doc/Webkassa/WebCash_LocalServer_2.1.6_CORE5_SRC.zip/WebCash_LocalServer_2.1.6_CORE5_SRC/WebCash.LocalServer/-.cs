using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerGen;
using WebCash.Constants;
using WebCash.Constants.Enums;
using WebCash.LocalServer.Abstractions;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.LocalServer.Descriptions;
using WebCash.LocalServer.Descriptions.Base;
using WebCash.LocalServer.Extensions;
using WebCash.LocalServer.Infrastructure;
using WebCash.LocalServer.Managers;
using WebCash.Resources;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

[CompilerGenerated]
internal sealed class _E000<_E000>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E000 m__E000;

	public _E000 _E001 => this._E000;

	[DebuggerHidden]
	public _E000(_E000 _E000)
	{
		this._E000 = _E000;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E000<_E000> obj = value as _E000<_E000>;
		if (this != obj)
		{
			if (obj != null)
			{
				return EqualityComparer<_E000>.Default.Equals(this._E000, obj._E000);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return 852431796 * -1521134295 + EqualityComparer<_E000>.Default.GetHashCode(this._E000);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\uf888\uf888\uf8d3\uf8bc\uf895\uf895\uf89f\uf89a\uf89d\uf896\uf8be\uf89c\uf897\uf896\uf8a0\uf887\uf892\uf881\uf887\uf8d3\uf8ce\uf8d3\uf888\uf8c3\uf88e\uf8d3\uf88e\uf88e", 63602);
		object[] array = new object[1];
		_E000 val = this._E000;
		array[0] = ((val != null) ? val.ToString() : null);
		return string.Format(null, format, array);
	}
}
[CompilerGenerated]
internal sealed class _E001<_E001, _E002, _E003>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E001 _E000;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E002 m__E001;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E003 _E002;

	public _E001 _E003 => _E000;

	public _E002 _E004 => this._E001;

	public _E003 _E005 => this._E002;

	[DebuggerHidden]
	public _E001(_E001 _E001, _E002 _E002, _E003 _E003)
	{
		_E000 = _E001;
		this._E001 = _E002;
		this._E002 = _E003;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E001<_E001, _E002, _E003> obj = value as _E001<_E001, _E002, _E003>;
		if (this != obj)
		{
			if (obj != null && EqualityComparer<_E001>.Default.Equals(_E000, obj._E000) && EqualityComparer<_E002>.Default.Equals(this._E001, obj._E001))
			{
				return EqualityComparer<_E003>.Default.Equals(this._E002, obj._E002);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return ((-159550938 * -1521134295 + EqualityComparer<_E001>.Default.GetHashCode(_E000)) * -1521134295 + EqualityComparer<_E002>.Default.GetHashCode(this._E001)) * -1521134295 + EqualityComparer<_E003>.Default.GetHashCode(this._E002);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\uf481\uf481\uf4da\uf4b3\uf49e\uf4da\uf4c7\uf4da\uf481\uf4ca\uf487\uf4d6\uf4da\uf4b9\uf48f\uf488\uf488\uf49f\uf494\uf48e\uf4ae\uf495\uf491\uf49f\uf494\uf4da\uf4c7\uf4da\uf481\uf4cb\uf487\uf4d6\uf4da\uf4a8\uf49f\uf49b\uf496\uf4ae\uf495\uf491\uf49f\uf494\uf4da\uf4c7\uf4da\uf481\uf4c8\uf487\uf4da\uf487\uf487", 62704);
		object[] array = new object[3];
		_E001 val = _E000;
		array[0] = ((val != null) ? val.ToString() : null);
		_E002 val2 = this._E001;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		_E003 val3 = this._E002;
		array[2] = ((val3 != null) ? val3.ToString() : null);
		return string.Format(null, format, array);
	}
}
[CompilerGenerated]
internal sealed class _E002<_E004>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E004 _E000;

	public _E004 _E001 => _E000;

	[DebuggerHidden]
	public _E002(_E004 _E004)
	{
		_E000 = _E004;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E002<_E004> obj = value as _E002<_E004>;
		if (this != obj)
		{
			if (obj != null)
			{
				return EqualityComparer<_E004>.Default.Equals(_E000, obj._E000);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return 1226204948 * -1521134295 + EqualityComparer<_E004>.Default.GetHashCode(_E000);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\ue1a8\ue1a8\ue1f3\ue180\ue1a6\ue1be\ue19a\ue1bd\ue190\ue1b2\ue1a0\ue1bb\ue1b1\ue1bc\ue1ab\ue1f3\ue1ee\ue1f3\ue1a8\ue1e3\ue1ae\ue1f3\ue1ae\ue1ae", 57666);
		object[] array = new object[1];
		_E004 val = _E000;
		array[0] = ((val != null) ? val.ToString() : null);
		return string.Format(null, format, array);
	}
}
[CompilerGenerated]
internal sealed class _E003<_E004, _E000>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E004 _E000;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E000 _E001;

	public _E004 _E002 => this._E000;

	public _E000 _E003 => _E001;

	[DebuggerHidden]
	public _E003(_E004 _E005, _E000 _E006)
	{
		this._E000 = _E005;
		_E001 = _E006;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E003<_E004, _E000> obj = value as _E003<_E004, _E000>;
		if (this != obj)
		{
			if (obj != null && EqualityComparer<_E004>.Default.Equals(this._E000, obj._E000))
			{
				return EqualityComparer<_E000>.Default.Equals(_E001, obj._E001);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (1967340008 * -1521134295 + EqualityComparer<_E004>.Default.GetHashCode(this._E000)) * -1521134295 + EqualityComparer<_E000>.Default.GetHashCode(_E001);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\ue181\ue181\ue1da\ue1a9\ue18f\ue197\ue1b3\ue194\ue1b9\ue19b\ue189\ue192\ue198\ue195\ue182\ue1da\ue1c7\ue1da\ue181\ue1ca\ue187\ue1d6\ue1da\ue1b5\ue19c\ue19c\ue196\ue193\ue194\ue19f\ue1b7\ue195\ue19e\ue19f\ue1a9\ue18e\ue19b\ue188\ue18e\ue1da\ue1c7\ue1da\ue181\ue1cb\ue187\ue1da\ue187\ue187", 57744);
		object[] array = new object[2];
		_E004 val = this._E000;
		array[0] = ((val != null) ? val.ToString() : null);
		_E000 val2 = _E001;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		return string.Format(null, format, array);
	}
}
[CompilerGenerated]
internal sealed class _E004<_E005, _E000>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E005 _E000;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E000 _E001;

	public _E005 _E002 => this._E000;

	public _E000 _E003 => _E001;

	[DebuggerHidden]
	public _E004(_E005 _E007, _E000 _E008)
	{
		this._E000 = _E007;
		_E001 = _E008;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E004<_E005, _E000> obj = value as _E004<_E005, _E000>;
		if (this != obj)
		{
			if (obj != null && EqualityComparer<_E005>.Default.Equals(this._E000, obj._E000))
			{
				return EqualityComparer<_E000>.Default.Equals(_E001, obj._E001);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (-894754815 * -1521134295 + EqualityComparer<_E005>.Default.GetHashCode(this._E000)) * -1521134295 + EqualityComparer<_E000>.Default.GetHashCode(_E001);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\uea84\uea84\ueadf\ueaac\uea97\uea96\uea99\uea8b\ueab0\uea8f\uea9a\uea91\uea9a\uea9b\ueadf\ueac2\ueadf\uea84\ueacf\uea82\uead3\ueadf\ueab0\uea99\uea99\uea93\uea96\uea91\uea9a\ueab2\uea90\uea9b\uea9a\ueaac\uea8b\uea9e\uea8d\uea8b\ueadf\ueac2\ueadf\uea84\ueace\uea82\ueadf\uea82\uea82", 60157);
		object[] array = new object[2];
		_E005 val = this._E000;
		array[0] = ((val != null) ? val.ToString() : null);
		_E000 val2 = _E001;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		return string.Format(null, format, array);
	}
}
[CompilerGenerated]
internal sealed class _E005<_E005, _E006, _E000>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E005 _E000;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E006 _E001;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E000 _E002;

	public _E005 _E003 => this._E000;

	public _E006 _E004 => _E001;

	public _E000 _E005 => _E002;

	[DebuggerHidden]
	public _E005(_E005 _E009, _E006 _E00A, _E000 _E00B)
	{
		this._E000 = _E009;
		_E001 = _E00A;
		_E002 = _E00B;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E005<_E005, _E006, _E000> obj = value as _E005<_E005, _E006, _E000>;
		if (this != obj)
		{
			if (obj != null && EqualityComparer<_E005>.Default.Equals(this._E000, obj._E000) && EqualityComparer<_E006>.Default.Equals(_E001, obj._E001))
			{
				return EqualityComparer<_E000>.Default.Equals(_E002, obj._E002);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return ((562077262 * -1521134295 + EqualityComparer<_E005>.Default.GetHashCode(this._E000)) * -1521134295 + EqualityComparer<_E006>.Default.GetHashCode(_E001)) * -1521134295 + EqualityComparer<_E000>.Default.GetHashCode(_E002);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E01E._E000("\ue08c\ue08c\ue0d7\ue0a4\ue09f\ue09e\ue091\ue083\ue0b8\ue087\ue092\ue099\ue092\ue093\ue0d7\ue0ca\ue0d7\ue08c\ue0c7\ue08a\ue0db\ue0d7\ue0a4\ue09f\ue09e\ue091\ue083\ue0b4\ue09b\ue098\ue084\ue092\ue093\ue0b8\ue099\ue0d7\ue0ca\ue0d7\ue08c\ue0c6\ue08a\ue0db\ue0d7\ue0b8\ue091\ue091\ue09b\ue09e\ue099\ue092\ue0ba\ue098\ue093\ue092\ue0a4\ue083\ue096\ue085\ue083\ue0d7\ue0ca\ue0d7\ue08c\ue0c5\ue08a\ue0d7\ue08a\ue08a", 57446);
		object[] array = new object[3];
		_E005 val = this._E000;
		array[0] = ((val != null) ? val.ToString() : null);
		_E006 val2 = _E001;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		_E000 val3 = _E002;
		array[2] = ((val3 != null) ? val3.ToString() : null);
		return string.Format(null, format, array);
	}
}
internal class _E006 : _E00A
{
	private new class _E000
	{
		[CompilerGenerated]
		private long _E000;

		[CompilerGenerated]
		private DateTime? _E001;

		[CompilerGenerated]
		private DateTime? _E002;

		public long _E003
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public DateTime? _E004
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public DateTime? _E005
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}

	[CompilerGenerated]
	private new sealed class _E002
	{
		public long _E000;
	}

	[CompilerGenerated]
	private new sealed class _E004
	{
		public long _E000;
	}

	private new readonly TimeSpan m__E000;

	private new readonly IMediator m__E001;

	public override string _E003 => _E01E._E000("\ue4fc\ue4c8\ue4c9\ue4d2\ue4de\ue4d1\ue4d2\ue4ce\ue4d8\ue49d\ue4ce\ue4d5\ue4d4\ue4db\ue4c9\ue49d\ue4c9\ue4d4\ue4d0\ue4d8\ue4cf", 58556);

	internal _E006(TimeSpan _E00C, IMediator _E00D)
		: base(TimeSpan.FromMinutes(1.0))
	{
		base._E001 = true;
		this.m__E000 = _E00C;
		this.m__E001 = _E00D;
	}

	protected override async Task _E006()
	{
		_E000[] array;
		using (MainDbContext mainDbContext = Provider.GetContext())
		{
			DbSet<CashboxState> cashboxStates = mainDbContext.CashboxStates;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			array = cashboxStates.Select(Expression.Lambda<Func<CashboxState, _E000>>(Expression.MemberInit(Expression.New(typeof(_E000)), Expression.Bind((MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/), Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Bind((MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/), Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Bind((MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/), Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression })).ToArray();
		}
		_E000[] array2 = array;
		foreach (_E000 obj in array2)
		{
			if (obj._E005.HasValue)
			{
				Log.Information(_E01E._E000("\uf692\uf6a9\uf6a8\uf6a7\uf6b5\uf6e1\uf6a0\uf6ad\uf6b3\uf6a4\uf6a0\uf6a5\uf6b8\uf6e1\uf6a2\uf6ad\uf6ae\uf6b2\uf6a4\uf6a5", 63169));
				continue;
			}
			if (!obj._E004.HasValue)
			{
				Log.Information(_E01E._E000("\ue02a\ue011\ue010\ue01f\ue00d\ue059\ue017\ue016\ue00d\ue059\ue016\ue009\ue01c\ue017\ue01c\ue01d", 57384));
				continue;
			}
			DateTime value = obj._E004.Value;
			DateTime now = DateTime.Now;
			DateTime dateTime = _E001(value);
			if (value.Date == now.Date)
			{
				TimeSpan timeSpan = TimeSpan.FromMinutes(1.0);
				TimeSpan timeSpan2 = this.m__E000 - now.TimeOfDay;
				if (timeSpan2 > timeSpan)
				{
					Log.Warning(_E01E._E000("\ue6fd\ue6c5\ue6c7\ue6de\ue68e\ue6d9\ue6c1\ue6dc\ue6c5\ue68e\ue6cc\ue6cb\ue6cd\ue6cf\ue6db\ue6dd\ue6cb\ue68e\ue6c1\ue6c8\ue68e\ue6d5\ue6ca\ue6c7\ue6c8\ue6c8\ue6d3\ue68e\ue6c9\ue6dc\ue6cb\ue6cf\ue6da\ue6cb\ue6dc\ue68e\ue6da\ue6c6\ue6cf\ue6c0\ue68e\ue69f\ue68e\ue6c3\ue6c7\ue6c0", 58922), timeSpan2);
				}
				else
				{
					await _E002(obj._E003, dateTime);
				}
			}
			else if (value.Date < now.Date)
			{
				await _E002(obj._E003, dateTime);
			}
		}
		_E000();
	}

	private new void _E000()
	{
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromDays(1.0);
		TimeSpan timeSpan2 = this.m__E000 - now.TimeOfDay;
		if (timeSpan2 < TimeSpan.Zero)
		{
			timeSpan2 = timeSpan2.Add(timeSpan);
		}
		Log.Information(_E01E._E000("\uef2e\uef13\uef17\uef1f\uef08\uef5a\uef19\uef15\uef08\uef08\uef1f\uef19\uef0e\uef13\uef15\uef14\uef40\uef5a\uef14\uef1f\uef02\uef0e\uef5a\uef1c\uef13\uef08\uef1f\uef5a\uef0d\uef13\uef16\uef16\uef5a\uef18\uef1f\uef5a\uef1b\uef1c\uef0e\uef1f\uef08\uef5a\uef01\uef14\uef1f\uef02\uef0e\uef3c\uef13\uef08\uef1f\uef07", 61232), timeSpan2);
		_E000(timeSpan2, timeSpan);
	}

	private new DateTime _E001(DateTime _E00E)
	{
		DateTime dateTime = _E00E.Date.Add(this.m__E000);
		if (dateTime < _E00E)
		{
			return dateTime.AddDays(1.0);
		}
		return dateTime;
	}

	private new async Task _E002(long _E00F, DateTime _E010)
	{
		_E002 obj = new _E002();
		obj._E000 = _E00F;
		string propertyValue;
		string value;
		using (MainDbContext mainDbContext = Provider.GetContext())
		{
			DbSet<Cashbox> cashboxes = mainDbContext.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			IQueryable<Cashbox> source = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			propertyValue = await source.Select(Expression.Lambda<Func<Cashbox, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			value = await _E003(mainDbContext, obj._E000);
		}
		if (string.IsNullOrEmpty(value))
		{
			Log.Warning(_E01E._E000("\uefba\uef8e\uef8f\uef94\uef98\uef97\uef94\uef88\uef9e\uefdb\uef88\uef93\uef92\uef9d\uef8f\uefdb\uef9f\uef94\uef9e\uef88\uef95\uefdc\uef8f\uefdb\uef9d\uef92\uef89\uef9e\uef9f\uefdb\uef9d\uef94\uef89\uefdb\uef80\uef98\uef9a\uef88\uef93\uef99\uef94\uef83\uef86\uefdb\uef99\uef9e\uef98\uef9a\uef8e\uef88\uef9e\uefdb\uef98\uef9a\uef95\uefdc\uef8f\uefdb\uef9d\uef92\uef95\uef9f\uefdb\uef8d\uef9a\uef97\uef92\uef9f\uefdb\uef8f\uef94\uef90\uef9e\uef95", 61363), propertyValue);
			return;
		}
		Log.Information(_E01E._E000("\ue7aa\ue79e\ue79f\ue784\ue788\ue787\ue784\ue798\ue78e\ue7cb\ue798\ue783\ue782\ue78d\ue79f\ue7cb\ue78d\ue782\ue799\ue78e\ue78f\ue7cb\ue78d\ue784\ue799\ue7cb\ue790\ue788\ue78a\ue798\ue783\ue789\ue784\ue793\ue796", 59267), propertyValue);
		using MainDbContext mainDbContext = Provider.GetContext();
		DbSet<Cashbox> cashboxes2 = mainDbContext.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source2 = cashboxes2.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		propertyValue = await source2.Select(Expression.Lambda<Func<Cashbox, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		value = await _E003(mainDbContext, obj._E000);
		ZReportDescription description = new ZReportDescription(mainDbContext)
		{
			AutoCloseRequestAfterSpecifiedTime = (DateTime.Now - _E010 > TimeSpan.FromMinutes(1.0))
		};
		ZReportRequest request = new ZReportRequest
		{
			CashboxUniqueNumber = propertyValue,
			OfflineDate = _E010,
			Token = value
		};
		ApiResult apiResult = await this.m__E001.GetResponse(description, request);
		if (apiResult.HasError())
		{
			ErrorItem errorItem = apiResult.Errors.First();
			Log.Warning(_E01E._E000("\ue53a\ue50e\ue50f\ue514\ue518\ue517\ue514\ue508\ue51e\ue55b\ue508\ue513\ue512\ue51d\ue50f\ue55b\ue515\ue514\ue50f\ue55b\ue51e\ue503\ue51e\ue518\ue50e\ue50f\ue51e\ue51f\ue55b\ue519\ue51e\ue518\ue51a\ue50e\ue508\ue51e\ue55b\ue514\ue51d\ue55b\ue51e\ue509\ue509\ue514\ue509\ue541\ue55b\ue500\ue518\ue514\ue51f\ue51e\ue506\ue557\ue55b\ue500\ue50f\ue51e\ue503\ue50f\ue506", 58715), errorItem.Code, errorItem.Text);
		}
	}

	private new async Task<string> _E003(MainDbContext _E011, long _E012)
	{
		_E004 obj = new _E004();
		obj._E000 = _E012;
		DbSet<OperationData> lastOperations = _E011.LastOperations;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		IQueryable<OperationData> source = lastOperations.Where(Expression.Lambda<Func<OperationData, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		OperationData operationData = await source.OrderByDescending(Expression.Lambda<Func<OperationData, DateTime>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).FirstOrDefaultAsync();
		if (operationData != null)
		{
			AuthorizedRequest authorizedRequest = JsonConvert.DeserializeObject<AuthorizedRequest>(operationData.Request);
			return authorizedRequest.Token;
		}
		DbSet<Cashbox> cashboxes = _E011.Cashboxes;
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source2 = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<UserToCashbox> source3 = source2.SelectMany(Expression.Lambda<Func<Cashbox, IEnumerable<UserToCashbox>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uf3cb", 62242));
		IOrderedQueryable<UserToCashbox> source4 = source3.OrderByDescending(Expression.Lambda<Func<UserToCashbox, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uf3cb", 62242));
		return source4.Select(Expression.Lambda<Func<UserToCashbox, string>>(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).FirstOrDefault();
	}
}
internal class _E008 : _E00A
{
	[CompilerGenerated]
	private new sealed class _E001
	{
		public string _E000;
	}

	[CompilerGenerated]
	private new sealed class _E003
	{
		public string _E000;
	}

	[CompilerGenerated]
	private new sealed class _E004
	{
		public string _E000;

		public AuthorizedRequest _E001;
	}

	[CompilerGenerated]
	private new sealed class _E006
	{
		public CashboxState _E000;
	}

	[CompilerGenerated]
	private sealed class _E008
	{
		public PaymentSummary _E000;

		internal bool _E000(PaymentsByTypeApiModel _E02D)
		{
			return _E02D.Type == this._E000.Type;
		}
	}

	private new readonly _E015 m__E002;

	private new readonly IOptions<AppConfig> m__E003;

	private new readonly int m__E004 = 50;

	public override string _E003 => _E01E._E000("\ue330\ue319\ue319\ue313\ue316\ue311\ue31a\ue35f\ue30d\ue31a\ue30e\ue30a\ue31a\ue30c\ue30b\ue30c\ue35f\ue30c\ue306\ue311\ue31c\ue317\ue30d\ue310\ue311\ue316\ue305\ue31a\ue30d", 58169);

	public _E008(_E015 _E013, IOptions<AppConfig> _E014)
		: base(TimeSpan.FromMinutes(1.0))
	{
		base._E001 = true;
		this.m__E002 = _E013;
		this.m__E003 = _E014;
		this.m__E002._E007(TimeSpan.FromSeconds(_E014.Value.OfflineOperationsRequestTimeout));
	}

	protected override async Task _E006()
	{
		using MainDbContext mainDbContext = Provider.GetContext();
		DbSet<OfflineRequest> offlineRequests = mainDbContext.OfflineRequests;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		IIncludableQueryable<OfflineRequest, Cashbox> source = offlineRequests.Include(Expression.Lambda<Func<OfflineRequest, Cashbox>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source2 = source.Select(Expression.Lambda<Func<OfflineRequest, Cashbox>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<IGrouping<string, Cashbox>> source3 = source2.GroupBy(Expression.Lambda<Func<Cashbox, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(IGrouping<string, Cashbox>), _E01E._E000("\uf3cb", 62242));
		string[] array = source3.Select(Expression.Lambda<Func<IGrouping<string, Cashbox>, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(IGrouping<string, Cashbox>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).ToArray();
		string[] array2 = array;
		foreach (string text in array2)
		{
			using (await _E017._E002(text))
			{
				await _E000(mainDbContext, text);
			}
		}
	}

	private new async Task _E000(MainDbContext _E015, string _E016)
	{
		_E001 obj = new _E001();
		obj._E000 = _E016;
		while (true)
		{
			OfflineRequest[] array = _E002(_E015, obj._E000);
			if (array.Length == 0)
			{
				break;
			}
			Log.Information(_E01E._E000("\uebac\ueb8b\ueb9e\ueb8d\ueb8b\uebdf\ueb8f\ueb8d\ueb90\ueb9c\ueb9a\ueb8c\ueb8c\ueb96\ueb91\ueb98\uebdf\ueb8f\ueb9e\ueb9c\ueb94\ueb9e\ueb98\ueb9a\uebdf\uebd7\ueb84\ueb9c\ueb90\ueb8a\ueb91\ueb8b\ueb82\uebdf\ueb8d\ueb9a\ueb8e\ueb8a\ueb9a\ueb8c\ueb8b\ueb8c\uebd6\uebdf\ueb99\ueb90\ueb8d\uebdf\ueb84\ueb9c\ueb9e\ueb8c\ueb97\ueb9d\ueb90\ueb87\ueb82", 60221), array.Length, obj._E000);
			string text = await _E003(_E015, obj._E000);
			if (string.IsNullOrEmpty(text))
			{
				break;
			}
			OfflinePackage offlinePackage = _E001(obj._E000, text, array);
			ApiResult<OfflinePackageResponse> apiResult = await this.m__E002._E002<ApiResult<OfflinePackageResponse>>(_E01E._E000("\ued9b\uedd5\uedc4\ueddd\ued9b\ueddb\uedd2\uedd2\uedd8\ueddd\uedda\uedd1\uedfb\uedc4\uedd1\uedc6\uedd5\uedc0\ueddd\ueddb\uedda", 60724), offlinePackage, _E015);
			if (apiResult == null)
			{
				Log.Information(_E01E._E000("\uecc3\uecf2\uecf0\uecf8\uecf2\uecf4\uecf6\uecb3\uece4\uecf2\uece0\uecfd\uecb4\uece7\uecb3\uece0\uecf6\uecfd\uece7\uecb3\uecf5\uecfc\uece1\uecb3\uece8\uecf0\uecf2\uece0\uecfb\uecf1\uecfc\ueceb\uecee", 60562), obj._E000);
				break;
			}
			if (apiResult.HasError())
			{
				Log.Warning(_E01E._E000("\uef4f\uef7e\uef7c\uef74\uef7e\uef78\uef7a\uef3f\uef6c\uef7a\uef71\uef6b\uef3f\uef7d\uef6a\uef6b\uef3f\uef68\uef7e\uef6c\uef71\uef38\uef6b\uef3f\uef6f\uef6d\uef70\uef7c\uef7a\uef6c\uef6c\uef7a\uef7b\uef3f\uef7d\uef66\uef3f\uef6c\uef7a\uef6d\uef69\uef7a\uef6d\uef3f\uef79\uef70\uef6d\uef3f\uef64\uef7c\uef7e\uef6c\uef77\uef7d\uef70\uef67\uef62\uef25\uef3f\uef64\uef7a\uef6d\uef6d\uef70\uef6d\uef6c\uef62", 61207), obj._E000, string.Join(Environment.NewLine, apiResult.Errors));
				break;
			}
			Log.Information(_E01E._E000("\uefae\uef9f\uef9d\uef95\uef9f\uef99\uef9b\uefde\uef89\uef9f\uef8d\uefde\uef8d\uef8b\uef9d\uef9d\uef9b\uef8d\uef8d\uef98\uef8b\uef92\uef92\uef87\uefde\uef8e\uef8c\uef91\uef9d\uef9b\uef8d\uef8d\uef9b\uef9a\uefde\uef9c\uef87\uefde\uef8d\uef9b\uef8c\uef88\uef9b\uef8c\uefde\uef98\uef91\uef8c\uefde\uef85\uef9d\uef9f\uef8d\uef96\uef9c\uef91\uef86\uef83", 61422), obj._E000);
			if (apiResult.Data.IsSuccess)
			{
				using (await _E017._E000(obj._E000))
				{
					_E015.OfflineRequests.RemoveRange(array);
					DbSet<CashboxState> cashboxStates = _E015.CashboxStates;
					ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
					(await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }))).OfflineModeStart = apiResult.Data.StartOfflineMode;
					await _E015.SaveChangesAsync();
					DbSet<OfflineRequest> offlineRequests = _E015.OfflineRequests;
					parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
					int propertyValue = await offlineRequests.CountAsync(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
					Log.Information(_E01E._E000("\ue202\ue21a\ue216\ue20c\ue217\ue20d\ue204\ue259\ue216\ue21f\ue21f\ue215\ue210\ue217\ue21c\ue259\ue20b\ue21c\ue208\ue20c\ue21c\ue20a\ue20d\ue20a\ue259\ue215\ue21c\ue21f\ue20d\ue259\ue21f\ue216\ue20b\ue259\ue202\ue21a\ue218\ue20a\ue211\ue21b\ue216\ue201\ue204", 57880), propertyValue, obj._E000);
				}
			}
		}
	}

	private new OfflinePackage _E001(string _E017, string _E018, OfflineRequest[] _E019)
	{
		return new OfflinePackage
		{
			CashboxUniqueNumber = _E017,
			Token = _E018,
			ProductVersion = _E01E._E000("\uf4bb\uf498\uf494\uf496\uf49b\uf4a4\uf492\uf485\uf481\uf492\uf485\uf4d7", 62534) + Assembly.GetExecutingAssembly().GetName().Version,
			Checks = (from _E024 in _E019
				where _E024.Type == RequestType.Check
				select _E024 into _E025
				select JsonConvert.DeserializeObject<OfflineCheckOperationRequest>(_E025.Content)).ToArray(),
			MoneyOperations = (from _E026 in _E019
				where _E026.Type == RequestType.MoneyOperation
				select _E026 into _E027
				select JsonConvert.DeserializeObject<OfflineMoneyOperationRequest>(_E027.Content)).ToArray(),
			XzReports = (from _E028 in _E019
				where _E028.Type == RequestType.XZReport
				select _E028 into _E029
				select JsonConvert.DeserializeObject<OfflineXzReportRequest>(_E029.Content)).ToArray()
		};
	}

	private new OfflineRequest[] _E002(MainDbContext _E01A, string _E01B)
	{
		_E003 obj = new _E003();
		obj._E000 = _E01B;
		DbSet<OfflineRequest> offlineRequests = _E01A.OfflineRequests;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		IIncludableQueryable<OfflineRequest, Cashbox> source = offlineRequests.Include(Expression.Lambda<Func<OfflineRequest, Cashbox>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		OfflineRequest[] source2 = source.Where(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E003)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).ToArray();
		return source2.OrderBy((OfflineRequest _E02A) => _E02A.Created).Take(this.m__E004).ToArray();
	}

	private new async Task<string> _E003(MainDbContext _E01C, string _E01D)
	{
		_E004 obj = new _E004();
		obj._E000 = _E01D;
		DbSet<OfflineRequest> offlineRequests = _E01C.OfflineRequests;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		IIncludableQueryable<OfflineRequest, Cashbox> source = offlineRequests.Include(Expression.Lambda<Func<OfflineRequest, Cashbox>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		obj._E001 = JsonConvert.DeserializeObject<AuthorizedRequest>((await source.Where(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).ToListAsync()).Last().Content);
		DbSet<User> users = _E01C.Users;
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		User user = await users.SingleOrDefaultAsync(Expression.Lambda<Func<User, bool>>(Expression.OrElse(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression }));
		if (user == null)
		{
			Log.Error(_E01E._E000("\ueb3d\ueb11\ueb0b\ueb12\ueb1a\ueb10\ueb59\ueb0a\ueb5e\ueb18\ueb17\ueb10\ueb1a\ueb5e\ueb0b\ueb0d\ueb1b\ueb0c\ueb5e\ueb09\ueb17\ueb0a\ueb16\ueb5e\ueb05\ueb0a\ueb11\ueb15\ueb1b\ueb10\ueb03\ueb5e\ueb1c\ueb07\ueb5e\ueb11\ueb18\ueb18\ueb12\ueb17\ueb10\ueb1b\ueb5e\ueb0c\ueb1b\ueb0f\ueb0b\ueb1b\ueb0d\ueb0a\ueb0d", 60254), obj._E001.Token);
			DbSet<User> users2 = _E01C.Users;
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			MethodInfo method = (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/);
			Expression[] obj2 = new Expression[2]
			{
				Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
				null
			};
			ParameterExpression parameterExpression2 = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\ue198", 57779));
			obj2[1] = Expression.Lambda<Func<UserToCashbox, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression2, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression2 });
			user = await users2.FirstOrDefaultAsync(Expression.Lambda<Func<User, bool>>(Expression.Call(null, method, obj2), new ParameterExpression[1] { parameterExpression }));
			if (user != null)
			{
				Log.Information(_E01E._E000("\ue82c\ue80a\ue81c\ue80b\ue859\ue802\ue80c\ue80a\ue81c\ue80b\ue837\ue818\ue814\ue81c\ue804\ue859\ue80e\ue818\ue80a\ue859\ue81f\ue816\ue80c\ue817\ue81d\ue859\ue81f\ue816\ue80b\ue859\ue81a\ue818\ue80a\ue811\ue81b\ue816\ue801\ue859\ue802\ue81a\ue818\ue80a\ue811\ue81b\ue816\ue801\ue82c\ue817\ue810\ue808\ue80c\ue81c\ue837\ue80c\ue814\ue81b\ue81c\ue80b\ue804", 59480), user.UserName, obj._E000);
				return user.CurrentToken;
			}
			return null;
		}
		return user.CurrentToken;
	}

	private new async Task _E004(MainDbContext _E01E, CashboxState _E01F, CashboxMobileStateResponse _E020)
	{
		_E006 obj = new _E006();
		obj._E000 = _E01F;
		List<ValidationResult> list = new List<ValidationResult>();
		WebCash.ServiceContracts.Validator validator = new WebCash.ServiceContracts.Validator(list);
		validator.Equal(obj._E000.CashDeposits, (double)_E020.DepositMoneyInShift, global::_E01E._E000("\ue79c\ue7fe\ue781\ue781\ue78d\ue39d\ue78f\ue780\ue788\ue7fc\ue788\ue780\ue785\ue784\ue39d\ue78a\ue78d\ue39d\ue7fc\ue781\ue788\ue780\ue7fe", 58277));
		validator.Equal(obj._E000.CashWithdrawals, (double)_E020.WithdrawalMoneyInShift, global::_E01E._E000("\uf4ce\uf4ac\uf4d3\uf4d3\uf4df\uf0cf\uf4d7\uf4d8\uf4a5\uf4a0\uf4ad\uf4d7\uf4d6\uf0cf\uf4d8\uf4df\uf0cf\uf4ae\uf4d3\uf4da\uf4d2\uf4ac", 61613));
		validator.Equal(obj._E000.DocumentsCount, _E020.ShiftLastDocumentNumber, global::_E01E._E000("\uf3f1\uf3d5\uf3d0\uf3d3\uf3ac\uf3de\uf3aa\uf3a9\uf3d9\uf3d5\uf7cb\uf3df\uf3d5\uf3d1\uf3a8\uf3d7\uf3de\uf3d6\uf3a9\uf3d5\uf3d9\uf7cb\uf3dc\uf3db\uf7cb\uf3aa\uf3d7\uf3de\uf3d6\uf3a8", 63267));
		validator.Equal(obj._E000.SumInCashbox, (double)_E020.SumInCashbox, global::_E01E._E000("\uf5df\uf5bd\uf5c2\uf5c2\uf5ce\uf1de\uf5c3\uf5ce\uf5c5\uf5c6\uf5b9\uf5c3\uf5c0\uf5bf\uf5bc\uf5c6\uf1de\uf5cc\uf1de\uf5c4\uf5ce\uf5bf\uf5bf\uf5cb", 61786));
		validator.Equal(obj._E000.ShiftNumber, _E020.ShiftNumber, global::_E01E._E000("\ue8f0\ue8d3\ue8d1\ue8d8\ue8ad\ueccd\ue8ac\ue8d1\ue8d8\ue8d0\ue8a6", 60524));
		validator.Equal(obj._E000.ShiftOpened, _E020.ShiftOpened, global::_E01E._E000("\ue1e3\ue1c7\ue1b5\ue1c7\ue5d7\ue1c9\ue1b5\ue1cd\ue1b7\ue1bc\ue1b5\ue1cf\ue1b8\ue5d7\ue1b6\ue1cb\ue1c2\ue1ca\ue1bc", 58694), new _E013());
		validator.Equal(obj._E000.ShiftClosedOn, _E020.ShiftClosedOn, global::_E01E._E000("\ue36f\ue34b\ue339\ue34b\ue75b\ue34c\ue34b\ue341\ue33b\ue330\ue339\ue343\ue334\ue75b\ue33a\ue347\ue34e\ue346\ue330", 59259), new _E013());
		validator.Equal(obj._E000.NNStartBuy, (double)_E020.StartShiftNonNullable.Buy, global::_E01E._E000("\uf6c9\uf6e1\uf6ea\uf6e5\uf6e9\uf2fa\uf2f4\uf6e9\uf6e4\uf693\uf2fa\uf2f4\uf695\uf6e8\uf6e1\uf6e9\uf69f\uf2fa\uf2f4\uf6cb\uf6ea\uf6ee\uf697\uf6eb\uf6ee\uf6ec", 62036));
		validator.Equal(obj._E000.NNStartSell, (double)_E020.StartShiftNonNullable.Sell, global::_E01E._E000("\uf3f2\uf3da\uf3d1\uf3de\uf3d2\uf7c1\uf7cf\uf3d2\uf3df\uf3a8\uf7c1\uf7cf\uf3ae\uf3d3\uf3da\uf3d2\uf3a4\uf7c1\uf7cf\uf3f0\uf3af\uf3d1\uf3db\uf3df\uf3d9\uf3d7", 63469));
		validator.Equal(obj._E000.NNStartReturnBuy, (double)_E020.StartShiftNonNullable.ReturnBuy, global::_E01E._E000("\ue080\ue0a8\ue0a3\ue0ac\ue0a0\ue4b3\ue4bd\ue0a0\ue0ad\ue0da\ue4b3\ue4bd\ue0dc\ue0a1\ue0a8\ue0a0\ue0d6\ue4b3\ue4bd\ue08f\ue0a3\ue0aa\ue0af\ue0dd\ue0ad\ue0df\ue0d6\ue4bd\ue0a2\ue0a3\ue0a7\ue0de\ue0a2\ue0a3\ue0a7", 58501));
		validator.Equal(obj._E000.NNStartReturnSell, (double)_E020.StartShiftNonNullable.ReturnSell, global::_E01E._E000("\ue4f2\ue4da\ue4d1\ue4de\ue4d2\ue0c1\ue0cf\ue4d2\ue4df\ue4a8\ue0c1\ue0cf\ue4ae\ue4d3\ue4da\ue4d2\ue4a4\ue0c1\ue0cf\ue4fd\ue4d1\ue4d8\ue4dd\ue4af\ue4df\ue4ad\ue4a4\ue0cf\ue4d0\ue4af\ue4d1\ue4db\ue4df\ue4d9", 57389));
		DbSet<OperationSummary> operationSummaries = _E01E.OperationSummaries;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationSummary), global::_E01E._E000("\uf3cb", 62242));
		IQueryable<OperationSummary> source = operationSummaries.Where(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationSummary), global::_E01E._E000("\uf3cb", 62242));
		Dictionary<OperationTypeEnum, OperationSummary> dictionary = await source.Include(Expression.Lambda<Func<OperationSummary, ICollection<PaymentSummary>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).ToDictionaryAsync((OperationSummary _E02B) => _E02B.Type, (OperationSummary _E02C) => _E02C);
		validator.Equal(obj._E000.NNStartBuy + dictionary[OperationTypeEnum.Buy].Sum, (double)_E020.CurrentNonNullable.Buy, global::_E01E._E000("\ue1f6\ue1de\ue1d5\ue1da\ue1d6\ue5c5\ue5cb\ue1d1\ue1d5\ue1d6\ue1de\ue1ad\ue5c5\ue5cb\ue1aa\ue1d7\ue1de\ue1d6\ue1a0\ue5c5\ue5cb\ue1f4\ue1d5\ue1d1\ue1a8\ue1d4\ue1d1\ue1d3", 58859));
		validator.Equal(obj._E000.NNStartSell + dictionary[OperationTypeEnum.Sell].Sum, (double)_E020.CurrentNonNullable.Sell, global::_E01E._E000("\uf7f6\uf7de\uf7d5\uf7da\uf7d6\uf3c5\uf3cb\uf7d1\uf7d5\uf7d6\uf7de\uf7ad\uf3c5\uf3cb\uf7aa\uf7d7\uf7de\uf7d6\uf7a0\uf3c5\uf3cb\uf7f4\uf7ab\uf7d5\uf7df\uf7db\uf7dd\uf7d3", 62379));
		validator.Equal(obj._E000.NNStartReturnBuy + dictionary[OperationTypeEnum.ReturnBuy].Sum, (double)_E020.CurrentNonNullable.ReturnBuy, global::_E01E._E000("\uf0f2\uf0da\uf0d1\uf0de\uf0d2\uf4c1\uf4cf\uf0d5\uf0d1\uf0d2\uf0da\uf0a9\uf4c1\uf4cf\uf0ae\uf0d3\uf0da\uf0d2\uf0a4\uf4c1\uf4cf\uf0fd\uf0d1\uf0d8\uf0dd\uf0af\uf0df\uf0ad\uf0a4\uf4cf\uf0d0\uf0d1\uf0d5\uf0ac\uf0d0\uf0d1\uf0d5", 62573));
		validator.Equal(obj._E000.NNStartReturnSell + dictionary[OperationTypeEnum.ReturnSell].Sum, (double)_E020.CurrentNonNullable.ReturnSell, global::_E01E._E000("\ue6f6\ue6de\ue6d5\ue6da\ue6d6\ue2c5\ue2cb\ue6d1\ue6d5\ue6d6\ue6de\ue6ad\ue2c5\ue2cb\ue6aa\ue6d7\ue6de\ue6d6\ue6a0\ue2c5\ue2cb\ue6f9\ue6d5\ue6dc\ue6d9\ue6ab\ue6db\ue6a9\ue6a0\ue2cb\ue6d4\ue6ab\ue6d5\ue6df\ue6db\ue6dd", 58059));
		validator.Equal(dictionary[OperationTypeEnum.Buy].Count, _E020.Buy?.Count ?? 0, global::_E01E._E000("\ue2e5\ue2c1\ue2c4\ue2c7\ue2b8\ue2ca\ue2be\ue2bd\ue2cd\ue2c1\ue6df\ue2c0\ue2c1\ue2c5\ue2bc\ue2c0\ue2c1\ue2c5\ue6df\ue2cd\ue6df\ue2be\ue2c3\ue2ca\ue2c2\ue2ca", 59055));
		validator.Equal(dictionary[OperationTypeEnum.Sell].Count, _E020.Sell?.Count ?? 0, global::_E01E._E000("\uf3ed\uf3c9\uf3cc\uf3cf\uf3b0\uf3c2\uf3b6\uf3b5\uf3c5\uf3c9\uf7d7\uf3c8\uf3b7\uf3c9\uf3c3\uf3c7\uf3c1\uf7d7\uf3c5\uf7d7\uf3b6\uf3cb\uf3c2\uf3ca\uf3c2", 63478));
		validator.Equal(dictionary[OperationTypeEnum.ReturnBuy].Count, _E020.ReturnBuy?.Count ?? 0, global::_E01E._E000("\ue461\ue445\ue440\ue443\ue43c\ue44e\ue43a\ue439\ue449\ue445\ue05b\ue449\ue445\ue44c\ue449\ue43b\ue44b\ue439\ue445\ue449\ue05b\ue444\ue445\ue441\ue438\ue444\ue445\ue441\ue05b\ue449\ue05b\ue43a\ue447\ue44e\ue446\ue44e", 57371));
		validator.Equal(dictionary[OperationTypeEnum.ReturnSell].Count, _E020.ReturnSell?.Count ?? 0, global::_E01E._E000("ﱤﱀﱅﱆﰹﱋﰿﰼﱌﱀ\uf85eﱌﱀﱉﱌﰾﱎﰼﱀﱌ\uf85eﱁﰾﱀﱊﱎﱈ\uf85eﱌ\uf85eﰿﱂﱋﱃﱋ", 63566));
		_E005(new WebCash.ServiceContracts.Validator(list, global::_E01E._E000("\ue7e1\ue7c0\ue7c4\ue7bd\ue7c1\ue7c4\ue7c6\ue3de", 58362)), dictionary[OperationTypeEnum.Buy].PaymentsSummary, _E020.Buy);
		_E005(new WebCash.ServiceContracts.Validator(list, global::_E01E._E000("\ue8c2\ue89d\ue8e3\ue8e9\ue8ed\ue8eb\ue8e5\uecfd", 60629)), dictionary[OperationTypeEnum.Sell].PaymentsSummary, _E020.Sell);
		_E005(new WebCash.ServiceContracts.Validator(list, global::_E01E._E000("\ued6d\ued41\ued48\ued4d\ued3f\ued4f\ued3d\ued34\ue95f\ued40\ued41\ued45\ued3c\ued40\ued41\ued45\ue95f", 59767)), dictionary[OperationTypeEnum.ReturnBuy].PaymentsSummary, _E020.ReturnBuy);
		_E005(new WebCash.ServiceContracts.Validator(list, global::_E01E._E000("\uedbc\ued90\ued99\ued9c\uedee\ued9e\uedec\uede5\ue98e\ued91\uedee\ued90\ued9a\ued9e\ued98\ue98e", 59786)), dictionary[OperationTypeEnum.ReturnSell].PaymentsSummary, _E020.ReturnSell);
		if (list.Any())
		{
			Log.Error(global::_E01E._E000("\ue6e5\ue6b3\ue6c3\ue6ca\ue6c1\ue6cb\ue2db\ue6ba\ue6c3\ue6c6\ue6be\ue6bb\ue6c5\ue6c6\ue6c3\ue6cc\ue6cb\ue6bd\ue6c3\ue6c3\ue2db\ue6cf\ue6cb\ue6c6\ue6c6\ue6b0\ue6be\ue2db\ue280\ue29e\ue289\ue289\ue294\ue289\ue288\ue286", 58075), list);
		}
		else
		{
			Log.Information(global::_E01E._E000("\ueaf4\uee8f\uee8a\ueef2\ueef7\uee89\uee8a\uee8f\uee80\uee87\ueef1\uee8f\uee8f\uea97\uee83\uee87\uee8a\uee8a\ueefc\ueef2\uea97\ueef4\ueef6\uee88\uee82\ueeff\uee8a\uee89\uea97\uee80\uee87\uee85\uee82\ueef7\ueeff\uee82\uee8a\uee87", 59958));
		}
	}

	private void _E005(WebCash.ServiceContracts.Validator _E021, ICollection<PaymentSummary> _E022, OperationTypeSummaryApiModel _E023)
	{
		PaymentsByTypeApiModel[] source = ((_E023 != null) ? _E023.PaymentsByTypesApiModel : new PaymentsByTypeApiModel[0]);
		foreach (PaymentSummary current in _E022)
		{
			PaymentsByTypeApiModel paymentsByTypeApiModel = source.SingleOrDefault((PaymentsByTypeApiModel _E02D) => _E02D.Type == current.Type);
			double expected = 0.0;
			if (paymentsByTypeApiModel != null)
			{
				expected = (double)paymentsByTypeApiModel.Sum;
			}
			_E021.Equal(current.Sum, expected, _E01E._E000("\ue1fc\ue19e\ue1e1\ue1e1\ue1ed\ue5fd\ue1e3\ue1e2\ue1e6\ue1ed\ue19f\ue196\ue5fd", 58716) + current.Type.GetDisplayName());
		}
	}
}
internal class _E009 : _E00A
{
	private new readonly _E012 _E005;

	public override string _E003 => _E01E._E000("\ueeb0\uee8d\uee98\uee9e\uee91\uee96\uee85\uee9e\uee8b\uee96\uee90\uee91\ueedf\uee96\uee91\uee99\uee90\ueedf\uee8c\uee86\uee91\uee9c\uee97\uee8d\uee90\uee91\uee96\uee85\uee9e\uee8b\uee96\uee90\uee91\ueedf\uee8b\uee96\uee92\uee9a\uee8d", 61175);

	public _E009(_E012 _E02E)
		: base(TimeSpan.FromDays(1.0))
	{
		base._E001 = true;
		_E005 = _E02E;
	}

	protected override async Task _E006()
	{
		long[] array;
		using (MainDbContext mainDbContext = Provider.GetContext())
		{
			DbSet<Cashbox> cashboxes = mainDbContext.Cashboxes;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			array = await cashboxes.Select(Expression.Lambda<Func<Cashbox, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).ToArrayAsync();
		}
		long[] array2 = array;
		foreach (long num in array2)
		{
			await _E005._E006(num);
			await _E005._E007(num);
		}
	}
}
internal abstract class _E00A : _E00B, IDisposable
{
	[CompilerGenerated]
	private TimeSpan m__E006;

	private readonly Timer _E007;

	[CompilerGenerated]
	private bool _E008;

	[CompilerGenerated]
	private bool _E009;

	[CompilerGenerated]
	private bool m__E00A;

	public TimeSpan _E000
	{
		[CompilerGenerated]
		get
		{
			return this.m__E006;
		}
		[CompilerGenerated]
		private set
		{
			this.m__E006 = value;
		}
	}

	public bool _E001
	{
		[CompilerGenerated]
		get
		{
			return _E008;
		}
		[CompilerGenerated]
		set
		{
			_E008 = value;
		}
	}

	public bool _E002
	{
		[CompilerGenerated]
		get
		{
			return _E009;
		}
		[CompilerGenerated]
		private set
		{
			_E009 = value;
		}
	}

	public bool _E004
	{
		[CompilerGenerated]
		get
		{
			return m__E00A;
		}
		[CompilerGenerated]
		private set
		{
			m__E00A = value;
		}
	}

	public abstract string _E003 { get; }

	protected _E00A(TimeSpan _E02F)
	{
		this._E000 = _E02F;
		_E007 = new Timer(async delegate
		{
			if (!this._E001 || !_E002)
			{
				Log.Information(_E01E._E000("\uf110\uf13f\uf102\uf106\uf10e\uf119\uf125\uf10a\uf106\uf10e\uf116\uf14b\uf10d\uf102\uf119\uf10e\uf10f", 61739), this._E003);
				using (await _E017._E001(GetType().Name))
				{
					_E002 = true;
					await _E006();
					_E002 = false;
				}
			}
		});
	}

	protected abstract Task _E006();

	public void _E003()
	{
		_E004(this._E000);
		Log.Information(_E01E._E000("\uf3cc\uf3e3\uf3de\uf3da\uf3d2\uf3c5\uf3f9\uf3d6\uf3da\uf3d2\uf3ca\uf397\uf3c4\uf3c3\uf3d6\uf3c5\uf3c3\uf3d2\uf3d3", 62230), this._E003);
	}

	public void _E004(TimeSpan _E0C8)
	{
		this._E000 = _E0C8;
		_E007.Change(TimeSpan.Zero, _E0C8);
		this._E004 = true;
	}

	public void _E000(TimeSpan _E030, TimeSpan _E031)
	{
		this._E000 = _E031;
		_E007.Change(_E030, _E031);
		Log.Information(string.Format(_E01E._E000("\uf3f1\uf3da\uf3c7\uf3cb\uf39f\uf3d9\uf3d6\uf3cd\uf3da\uf39f\uf3c8\uf3d6\uf3d3\uf3d3\uf39f\uf3dd\uf3da\uf39f\uf3de\uf3d9\uf3cb\uf3da\uf3cd\uf39f\uf3c4\uf38f\uf3c2", 62391), _E030));
		this._E004 = true;
	}

	public void _E005()
	{
		if (this._E004)
		{
			_E007.Dispose();
			Log.Information(_E01E._E000("\ue79f\ue7b0\ue78d\ue789\ue781\ue796\ue7aa\ue785\ue789\ue781\ue799\ue7c4\ue797\ue790\ue78b\ue794\ue794\ue781\ue780", 59236), this._E003);
			this._E004 = false;
		}
	}

	public void Dispose()
	{
		_E005();
	}

	[CompilerGenerated]
	private async void _E001(object _E032)
	{
		if (!this._E001 || !_E002)
		{
			Log.Information(_E01E._E000("\uf110\uf13f\uf102\uf106\uf10e\uf119\uf125\uf10a\uf106\uf10e\uf116\uf14b\uf10d\uf102\uf119\uf10e\uf10f", 61739), this._E003);
			using (await _E017._E001(GetType().Name))
			{
				_E002 = true;
				await _E006();
				_E002 = false;
			}
		}
	}
}
internal interface _E00B
{
	bool _E004 { get; }

	void _E003();

	void _E004(TimeSpan _E0C9);

	void _E005();
}
internal class _E00C : _E00E
{
	private readonly string m__E000;

	public _E00C(string _E033)
	{
		this.m__E000 = _E033;
	}

	public string _E000(string _E0CA)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(this.m__E000);
		using Aes aes = Aes.Create();
		using ICryptoTransform transform = aes.CreateEncryptor(bytes, aes.IV);
		using MemoryStream memoryStream = new MemoryStream();
		using (CryptoStream stream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
		{
			using StreamWriter streamWriter = new StreamWriter(stream);
			streamWriter.Write(_E0CA);
		}
		byte[] iV = aes.IV;
		byte[] array = memoryStream.ToArray();
		byte[] array2 = new byte[iV.Length + array.Length];
		Buffer.BlockCopy(iV, 0, array2, 0, iV.Length);
		Buffer.BlockCopy(array, 0, array2, iV.Length, array.Length);
		return Convert.ToBase64String(array2);
	}

	public string _E001(string _E0CC)
	{
		byte[] src = Convert.FromBase64String(_E0CC);
		byte[] array = new byte[16];
		byte[] array2 = new byte[16];
		Buffer.BlockCopy(src, 0, array, 0, array.Length);
		Buffer.BlockCopy(src, array.Length, array2, 0, array.Length);
		byte[] bytes = Encoding.UTF8.GetBytes(this.m__E000);
		using Aes aes = Aes.Create();
		using ICryptoTransform transform = aes.CreateDecryptor(bytes, array);
		using MemoryStream stream = new MemoryStream(array2);
		using CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Read);
		using StreamReader streamReader = new StreamReader(stream2);
		return streamReader.ReadToEnd();
	}
}
internal class _E00D : ISchemaFilter
{
	private readonly string m__E000;

	public _E00D(IOptions<AppConfig> _E034, _E00E _E035)
	{
		try
		{
			this.m__E000 = _E035._E001(_E034.Value.AppId);
		}
		catch (Exception)
		{
			this.m__E000 = _E01E._E000("\uf4bf\uf49e\uf49d\uf49a\uf48e\uf497\uf48f", 62651);
			Log.Warning(_E01E._E000("\uf384\uf3bf\uf3ba\uf3bf\uf3be\uf3a6\uf3bf\uf3f1\uf390\uf3a1\uf3a1\uf398\uf3b5\uf3f1\uf3b8\uf3bf\uf3f1\uf3b2\uf3be\uf3bf\uf3bf\uf3b4\uf3b2\uf3a5\uf3b8\uf3be\uf3bf\uf3f1\uf3a2\uf3a5\uf3a3\uf3b8\uf3bf\uf3b6\uf3ff\uf3f1\uf395\uf3b4\uf3b7\uf3b0\uf3a4\uf3bd\uf3a5\uf3f1\uf3a6\uf3b8\uf3bd\uf3bd\uf3f1\uf3b3\uf3b4\uf3f1\uf3a4\uf3a2\uf3b4\uf3b5", 62417));
		}
	}

	public void Apply(OpenApiSchema model, SchemaFilterContext context)
	{
		PropertyInfo[] properties = context.Type.GetProperties();
		PropertyInfo[] array = properties;
		foreach (PropertyInfo propertyInfo in array)
		{
			IEnumerable<ShowForAppIdAttribute> source = propertyInfo.GetCustomAttributes(typeof(ShowForAppIdAttribute), inherit: true).OfType<ShowForAppIdAttribute>();
			if (source.Any())
			{
				if (!source.Any((ShowForAppIdAttribute _E036) => _E036.AppIdentificators.Contains(this.m__E000)))
				{
					model.Properties.Remove(propertyInfo.Name);
				}
				continue;
			}
			IEnumerable<HideForAppIdAttribute> source2 = propertyInfo.GetCustomAttributes(typeof(HideForAppIdAttribute), inherit: true).OfType<HideForAppIdAttribute>();
			if (source2.Any() && source2.Any((HideForAppIdAttribute _E037) => _E037.AppIdentificators.Contains(this.m__E000)))
			{
				model.Properties.Remove(propertyInfo.Name);
			}
		}
	}

	[CompilerGenerated]
	private bool _E000(ShowForAppIdAttribute _E036)
	{
		return _E036.AppIdentificators.Contains(this.m__E000);
	}

	[CompilerGenerated]
	private bool _E001(HideForAppIdAttribute _E037)
	{
		return _E037.AppIdentificators.Contains(this.m__E000);
	}
}
internal interface _E00E
{
	string _E000(string _E0CB);

	string _E001(string _E0CD);
}
internal class _E00F : IHostedService, IDisposable
{
	private readonly List<_E00B> m__E000;

	private static readonly object _E001 = new object();

	public _E00F(IEnumerable<_E00B> _E038)
	{
		this.m__E000 = new List<_E00B>(_E038);
	}

	public Task StartAsync(CancellationToken cancellationToken)
	{
		lock (_E001)
		{
			foreach (_E00B item in this.m__E000.Where((_E00B _E03A) => !_E03A._E004))
			{
				item._E003();
			}
		}
		return Task.CompletedTask;
	}

	public Task StopAsync(CancellationToken cancellationToken)
	{
		Dispose();
		return Task.CompletedTask;
	}

	public void Dispose()
	{
		lock (_E001)
		{
			foreach (_E00B item in this.m__E000.Where((_E00B _E03B) => _E03B._E004))
			{
				item._E005();
			}
			this.m__E000.Clear();
		}
	}

	public void _E000(_E00B _E039)
	{
		lock (_E001)
		{
			this.m__E000.Add(_E039);
			_E039._E003();
		}
	}
}
internal class _E010 : _E015
{
	[CompilerGenerated]
	private sealed class _E001
	{
		public AuthorizedRequest _E000;
	}

	private readonly _E014 m__E000;

	public _E010(_E014 _E03E)
	{
		this.m__E000 = _E03E;
	}

	public async Task<_E007> _E002<_E007>(string _E0CE, object _E0CF, MainDbContext _E0D0) where _E007 : class
	{
		AuthorizedRequest authorizedRequest = _E0CF as AuthorizedRequest;
		string text = null;
		if (authorizedRequest != null)
		{
			text = authorizedRequest.Token;
			await _E000(authorizedRequest, _E0D0);
		}
		_E007 val = await this.m__E000._E002<_E007>(_E0CE, _E0CF, _E0D0);
		if (val == null)
		{
			if (!string.IsNullOrEmpty(text))
			{
				authorizedRequest.Token = text;
			}
			return null;
		}
		if (authorizedRequest == null)
		{
			return val;
		}
		if (!(val is ApiResult apiResult))
		{
			return val;
		}
		if (!apiResult.HasError())
		{
			return val;
		}
		if (!apiResult.HasError() || !apiResult.HasError(ApiErrorCode.TokenExpired))
		{
			return val;
		}
		_E011 obj = new _E011(this.m__E000, _E0D0);
		string text2 = await obj._E000(authorizedRequest.Token);
		await _E0D0.SaveChangesAsync();
		if (string.IsNullOrEmpty(text2))
		{
			return val;
		}
		authorizedRequest.Token = text2;
		return await this.m__E000._E002<_E007>(_E0CE, authorizedRequest, _E0D0);
	}

	private async Task _E000(AuthorizedRequest _E03F, MainDbContext _E040)
	{
		_E001 obj = new _E001();
		obj._E000 = _E03F;
		DbSet<User> users = _E040.Users;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		IQueryable<User> source = users.Where(Expression.Lambda<Func<User, bool>>(Expression.OrElse(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		string text = await source.Select(Expression.Lambda<Func<User, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleOrDefaultAsync();
		if (!string.IsNullOrEmpty(text))
		{
			obj._E000.Token = text;
		}
	}

	public void _E007(TimeSpan _E0D7)
	{
		this.m__E000._E007(_E0D7);
	}

	public Task<HttpResponseMessage> _E008(HttpRequestMessage _E0DA)
	{
		return this.m__E000._E008(_E0DA);
	}
}
internal class _E011
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public string _E000;
	}

	private readonly _E015 m__E000;

	private readonly MainDbContext _E001;

	public _E011(_E015 _E041, MainDbContext _E042)
	{
		this.m__E000 = _E041;
		this._E001 = _E042;
	}

	internal async Task<string> _E000(string _E043)
	{
		_E000 obj = new _E000();
		obj._E000 = _E043;
		Log.Information(_E01E._E000("\uf5ab\uf58d\uf586\uf5df\uf58d\uf59a\uf59e\uf58a\uf58b\uf597\uf590\uf58d\uf596\uf585\uf59a\uf5df\uf58a\uf58c\uf59a\uf58d\uf5df\uf588\uf596\uf58b\uf597\uf5df\uf584\uf58b\uf590\uf594\uf59a\uf591\uf582", 62967), obj._E000);
		using (await _E017._E001(obj._E000))
		{
			DbSet<User> users = this._E001.Users;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			User user = await users.SingleOrDefaultAsync(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			if (user == null)
			{
				Log.Error(_E01E._E000("\uf13f\uf119\uf10f\uf118\uf14a\uf11d\uf103\uf11e\uf102\uf14a\uf111\uf11e\uf105\uf101\uf10f\uf104\uf117\uf14a\uf104\uf105\uf11e\uf14a\uf10c\uf105\uf11f\uf104\uf10e", 61696), obj._E000);
				return null;
			}
			_E01A obj2 = new _E01A(this._E001);
			ApiResult<TokenResponse> apiResult = await this.m__E000._E002<ApiResult<TokenResponse>>(obj2.Url, new AuthCredentialsRequest
			{
				Login = user.UserName,
				Password = user.Password
			}, this._E001);
			if (apiResult == null)
			{
				Log.Warning(_E01E._E000("\ue738\ue70f\ue719\ue71a\ue705\ue704\ue719\ue70f\ue74a\ue70c\ue705\ue718\ue74a\ue70b\ue71f\ue71e\ue702\ue705\ue718\ue703\ue710\ue70b\ue71e\ue703\ue705\ue704\ue74a\ue704\ue705\ue71e\ue74a\ue718\ue70f\ue709\ue70f\ue703\ue71c\ue70f\ue70e", 59168));
				return null;
			}
			if (apiResult.HasError())
			{
				if (apiResult.HasError(ApiErrorCode.WrongCredentials))
				{
					Log.Warning(_E01E._E000("\uf27d\uf25f\uf250\uf219\uf24a\uf21e\uf25f\uf24b\uf24a\uf256\uf251\uf24c\uf257\uf244\uf25b\uf21e\uf249\uf257\uf24a\uf256\uf21e\uf25d\uf24b\uf24c\uf24c\uf25b\uf250\uf24a\uf21e\uf25d\uf24c\uf25b\uf25a\uf25b\uf250\uf24a\uf257\uf25f\uf252\uf24d", 61966));
					this._E001.Remove(user);
				}
				return null;
			}
			Log.Information(_E01E._E000("\ueb2f\ueb18\ueb1c\ueb08\ueb09\ueb15\ueb12\ueb0f\ueb14\ueb07\ueb18\ueb5d\ueb1e\ueb12\ueb10\ueb0d\ueb11\ueb18\ueb09\ueb18\ueb19\ueb5d\ueb0a\ueb14\ueb09\ueb15\ueb5d\ueb06\ueb09\ueb12\ueb16\ueb18\ueb13\ueb00", 60261), obj._E000);
			user.RealToken = apiResult.Data.Token;
			this._E001.Update(user);
			return user.RealToken;
		}
	}
}
internal class _E012
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public string _E000;

		public string _E001;
	}

	[CompilerGenerated]
	private sealed class _E004
	{
		public string _E000;
	}

	[CompilerGenerated]
	private sealed class _E006
	{
		public PaymentTypeEnum _E000;

		internal bool _E000(PaymentsByTypeApiModel _E055)
		{
			return _E055.Type == this._E000;
		}
	}

	[CompilerGenerated]
	private sealed class _E009
	{
		public long _E000;
	}

	private readonly _E015 m__E000;

	private readonly MainDbContext m__E001;

	public _E012(_E015 _E044, MainDbContext _E045, IOptions<AppConfig> _E046)
	{
		this.m__E000 = _E044;
		this.m__E000._E007(TimeSpan.FromSeconds(_E046.Value.DefaultRequestTimeout));
		this.m__E001 = _E045;
	}

	public async Task<ApiResult<bool>> _E000(string _E047, string _E048)
	{
		_E000 obj = new _E000();
		obj._E000 = _E048;
		obj._E001 = _E047;
		try
		{
			DbSet<User> users = this.m__E001.Users;
			ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			IQueryable<User> source = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
			if (!(await source.Select(Expression.Lambda<Func<User, long?>>(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(long?)), new ParameterExpression[1] { parameterExpression })).FirstOrDefaultAsync()).HasValue)
			{
				return new ApiResult<bool>(ApiErrorCode.TokenExpired, _E01E._E000("\uf5d2\uf5fa\uf5f7\uf5f8\uf5fd\uf5fa\uf58e\uf58d\uf5f2\uf584\uf5f6\uf1ef\uf5ff\uf5fd\uf58d\uf5f1\uf58f\uf5f7\uf5f8\uf5ff\uf589\uf5f7\uf5f1\uf5f2\uf5f2\uf584\uf5f6\uf1ef\uf58d\uf5f1\uf5f5\uf5fa\uf5f2\uf1e1\uf1ef\uf5d2\uf5fa\uf5f1\uf5fe\uf58a\uf5f1\uf5fb\uf5f7\uf5f3\uf5ff\uf1ef\uf5f0\uf5f1\uf5fd\uf58d\uf5f1\uf58f\uf5f2\uf5ff\uf580\uf1ef\uf5ff\uf5fd\uf58d\uf5f1\uf58f\uf5f7\uf5f8\uf5ff\uf589\uf5f7\uf580", 61709));
			}
			DbSet<Cashbox> cashboxes = this.m__E001.Cashboxes;
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			IQueryable<Cashbox> source2 = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			if ((await source2.Select(Expression.Lambda<Func<Cashbox, long?>>(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(long?)), new ParameterExpression[1] { parameterExpression })).SingleOrDefaultAsync()).HasValue)
			{
				return new ApiResult<bool>(data: true);
			}
			ApiResult<CashboxMobileStateResponse> apiResult = await _E002(obj._E001, obj._E000);
			if (apiResult == null)
			{
				return new ApiResult<bool>(ApiErrorCode.UnknownError, _E01E._E000("\ueac9\ueae6\uea92\ueefd\ueae2\ueae3\ueae6\uea9e\uea9a\ueae8\ueae0\ueae5\uea92\ueefd\ueae2\ueae8\uea9d\ueaef\ueae5\uea9a\ueae0\ueae3\ueae4\ueefd\ueae5\ueae0\uea99\ueae3\uea9d\ueae1\ueaed\uea9b\ueae5\ueae5\ueefd\ueae3\ueefd\ueae7\ueaed\uea9c\uea9c\ueae8\ueefd\ueae0\ueae8\ueae3\ueaec\uea98\ueae3\ueae9\ueae5\ueae1\ueae3\ueefd\uea9c\ueae3\ueae8\ueae9\ueae5\ueae0\ueae8\ueae0\ueae5\ueae8\ueefd\uea9c\ueefd\uea9c\ueae8\uea9d\ueaef\ueae8\uea9d\ueae3\ueae1", 61141));
			}
			if (apiResult.HasError())
			{
				return new ApiResult<bool>
				{
					Errors = apiResult.Errors
				};
			}
			ApiResult<OrganizationInfoForPrintResponse> apiResult2 = await _E001(obj._E000);
			if (apiResult2 == null)
			{
				return new ApiResult<bool>(ApiErrorCode.UnknownError, _E01E._E000("\ueac9\ueae6\uea92\ueefd\ueae2\ueae3\ueae6\uea9e\uea9a\ueae8\ueae0\ueae5\uea92\ueefd\ueae2\ueae8\uea9d\ueaef\ueae5\uea9a\ueae0\ueae3\ueae4\ueefd\ueae5\ueae0\uea99\ueae3\uea9d\ueae1\ueaed\uea9b\ueae5\ueae5\ueefd\ueae3\ueefd\ueae7\ueaed\uea9c\uea9c\ueae8\ueefd\ueae0\ueae8\ueae3\ueaec\uea98\ueae3\ueae9\ueae5\ueae1\ueae3\ueefd\uea9c\ueae3\ueae8\ueae9\ueae5\ueae0\ueae8\ueae0\ueae5\ueae8\ueefd\uea9c\ueefd\uea9c\ueae8\uea9d\ueaef\ueae8\uea9d\ueae3\ueae1", 61141));
			}
			if (apiResult2.HasError())
			{
				return new ApiResult<bool>
				{
					Errors = apiResult2.Errors
				};
			}
			if (apiResult.Data.OfflineSupportMode == OfflineSupportMode.Disabled)
			{
				return new ApiResult<bool>(ApiErrorCode.OfflineChecksNotSupported, _E01E._E000("\uf4e5\uf4cf\uf4be\uf4be\uf4cf\uf0df\uf4cb\uf4c1\uf4c4\uf4c9\uf4c2\uf4cf\uf0df\uf4c0\uf4c1\uf4cb\uf4cb\uf4ca\uf4bf\uf4c9\uf4c7\uf4cd\uf4cf\uf4bd\uf4b3\uf0df\uf4bf\uf4ca\uf4c9\uf4c7\uf4c3\uf0df\uf4c0\uf4c1\uf4cb\uf4c5\uf4c4\uf4b1\uf4b8\uf4ca\uf4c2\uf4c7\uf4b0\uf0df\uf4c5\uf0df\uf4bc\uf4b8\uf4ca\uf4bd\uf4c2\uf4c1\uf4c6\uf0df\uf4be\uf4c7\uf4be\uf4bd\uf4ca\uf4c3\uf4ca", 61609));
			}
			CashboxMobileStateResponse data = apiResult.Data;
			Cashbox cashbox = new Cashbox
			{
				UniqueNumber = obj._E001,
				IdentityNumber = data.CashboxIdentityNumber,
				RegistrationNumber = data.CasboxRegistrationNumber,
				RoundType = data.RoundType.GetValueOrDefault(),
				Name = data.CashboxName,
				AutoWithdrawal = data.AutoWithDrawal,
				Address = data.Address,
				OfdName = data.Ofd?.Name,
				OfdHost = data.Ofd?.Host,
				OfdProtocolVersion = data.OfdProtocolVersion,
				OfflineSupportMode = data.OfflineSupportMode,
				OrganizationXin = apiResult2.Data.TaxPayerXin,
				OrganizationFullName = apiResult2.Data.TaxPayerName,
				OrganizationVatNumber = apiResult2.Data.TaxPayerVatNumber,
				OrganizationVatSeria = apiResult2.Data.TaxPayerVatSeria,
				OrganizationIsVatPayer = apiResult2.Data.VatPayer,
				AllowedTaxValues = apiResult2.Data.TaxPercents.Select((TaxPercent _E053) => _E053.Value).ToArray()
			};
			CashboxState cashboxState = new CashboxState
			{
				CashDeposits = (double)data.DepositMoneyInShift,
				CashWithdrawals = (double)data.WithdrawalMoneyInShift,
				DocumentsCount = (int)data.ShiftLastDocumentNumber,
				OfflineModeStart = data.StartOfflineMode,
				ShiftOpened = data.ShiftOpened,
				ShiftClosedOn = data.ShiftClosedOn,
				ShiftNumber = data.ShiftNumber,
				Cashbox = cashbox,
				SumInCashbox = (double)data.SumInCashbox
			};
			if (data.StartShiftNonNullable != null)
			{
				cashboxState.NNStartSell = (double)data.StartShiftNonNullable.Sell;
				cashboxState.NNStartBuy = (double)data.StartShiftNonNullable.Buy;
				cashboxState.NNStartReturnBuy = (double)data.StartShiftNonNullable.ReturnBuy;
				cashboxState.NNStartReturnSell = (double)data.StartShiftNonNullable.ReturnSell;
			}
			cashboxState.OperationsSummary.Add(_E005(OperationTypeEnum.Sell, data.Sell, (double)data.CurrentNonNullable.Sell - cashboxState.NNStartSell));
			cashboxState.OperationsSummary.Add(_E005(OperationTypeEnum.Buy, data.Buy, (double)data.CurrentNonNullable.Buy - cashboxState.NNStartBuy));
			cashboxState.OperationsSummary.Add(_E005(OperationTypeEnum.ReturnBuy, data.ReturnBuy, (double)data.CurrentNonNullable.ReturnBuy - cashboxState.NNStartReturnBuy));
			cashboxState.OperationsSummary.Add(_E005(OperationTypeEnum.ReturnSell, data.ReturnSell, (double)data.CurrentNonNullable.ReturnSell - cashboxState.NNStartReturnSell));
			this.m__E001.Add(cashbox);
			this.m__E001.Add(cashboxState);
			await this.m__E001.SaveChangesAsync();
			AccessManager accessManager = new AccessManager(this.m__E001);
			if (await accessManager.AddAccessToCashboxAsync(obj._E001, obj._E000))
			{
				await this.m__E001.SaveChangesAsync();
			}
			return new ApiResult<bool>(data: true);
		}
		catch (Exception exception)
		{
			Log.Error(exception, _E01E._E000("\uf590\uf588\uf58a\uf598\uf583\uf589\uf584\uf593\uf5be\uf585\uf582\uf59a\uf59e\uf58e\uf5a5\uf59e\uf586\uf589\uf58e\uf599\uf596\uf5cb\uf582\uf585\uf582\uf59f\uf582\uf58a\uf587\uf582\uf591\uf58a\uf59f\uf582\uf584\uf585\uf5cb\uf58e\uf593\uf588\uf58e\uf59b\uf59f\uf582\uf584\uf585", 62883), obj._E001);
			return new ApiResult<bool>(ApiErrorCode.UnknownError, _E01E._E000("\ue063\ue04b\ue040\ue04f\ue03b\ue040\ue04a\ue046\ue042\ue040\ue45e\ue03f\ue040\ue04b\ue04a\ue046\ue043\ue046\ue03c\ue032\ue03f\ue031\ue45e\ue03f\ue45e\ue040\ue03f\ue043\ue040\ue04c\ue043\ue035\ue042\ue45e\ue03f\ue04b\ue03e\ue04c\ue04b\ue03e\ue040\ue042\ue45e\ue04a\ue045\ue031\ue45e\ue041\ue040\ue045\ue03d\ue039\ue04b\ue043\ue046\ue031\ue45e\ue046\ue043\ue03a\ue040\ue03e\ue042\ue04e\ue038\ue046\ue046\ue45e\ue041\ue040\ue45e\ue044\ue04e\ue03f\ue03f\ue04b\ue444\ue45e", 58446) + obj._E001);
		}
	}

	private Task<ApiResult<OrganizationInfoForPrintResponse>> _E001(string _E049)
	{
		return this.m__E000._E002<ApiResult<OrganizationInfoForPrintResponse>>(_E01E._E000("\uf556\uf518\uf509\uf510\uf556\uf536\uf50b\uf51e\uf518\uf517\uf510\uf503\uf518\uf50d\uf510\uf516\uf517\uf556\uf529\uf50b\uf510\uf517\uf50d\uf536\uf50b\uf51e\uf518\uf517\uf510\uf503\uf518\uf50d\uf510\uf516\uf517\uf530\uf517\uf51f\uf516", 62840), new OrganizationInfoRequest
		{
			Token = _E049
		}, this.m__E001);
	}

	internal async Task<ApiResult<CashboxMobileStateResponse>> _E002(string _E04A, string _E04B)
	{
		return await this.m__E000._E002<ApiResult<CashboxMobileStateResponse>>(_E01E._E000("\uecd1\uec9f\uec8e\uec97\uecd1\uec9d\uec9f\uec8d\uec96\uec9c\uec91\uec86\uecd1\uec92\uec91\uec9d\uec9f\uec92\uecad\uec9b\uec8c\uec88\uec9b\uec8c\uecbd\uec8b\uec8c\uec8c\uec9b\uec90\uec8a\uecad\uec8a\uec9f\uec8a\uec9b", 60506), new MobileCashboxRequest
		{
			CashboxUniqueNumber = _E04A,
			Token = _E04B,
			Platform = Environment.OSVersion.Platform.ToString() + _E01E._E000("\uf6ff", 63071) + Environment.OSVersion.Version,
			PlatformSerialNumber = null,
			ProductVersion = _E01E._E000("\uf4bb\uf498\uf494\uf496\uf49b\uf4a4\uf492\uf485\uf481\uf492\uf485\uf4d7", 62534) + Assembly.GetExecutingAssembly().GetName().Version
		}, this.m__E001);
	}

	internal async Task<bool> _E003()
	{
		try
		{
			(await this.m__E000._E008(new HttpRequestMessage
			{
				Method = HttpMethod.Get,
				RequestUri = new Uri(_E01E._E000("\uf2d1\uf29f\uf28e\uf297\uf2d1\uf28e\uf297\uf290\uf299", 62042), UriKind.Relative)
			})).EnsureSuccessStatusCode();
			return true;
		}
		catch (Exception exception)
		{
			Log.Error(exception, _E01E._E000("\ueeaa\uee93\uee94\uee9d\ueeda\uee9c\uee9b\uee93\uee96\uee9f\uee9e", 61104));
			return false;
		}
	}

	internal async Task<bool> _E004(string _E04C)
	{
		_E004 obj = new _E004();
		obj._E000 = _E04C;
		DbSet<OfflineRequest> offlineRequests = this.m__E001.OfflineRequests;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		return await offlineRequests.AnyAsync(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
	}

	private OperationSummary _E005(OperationTypeEnum _E04D, OperationTypeSummaryApiModel _E04E, double _E04F)
	{
		OperationSummary operationSummary = new OperationSummary
		{
			Type = _E04D,
			Sum = _E04F
		};
		if (_E04E != null)
		{
			operationSummary.Count = _E04E.Count;
			operationSummary.Tax = (double)_E04E.VAT;
			operationSummary.Change = (double)_E04E.Change;
			operationSummary.Taken = (double)_E04E.Taken;
			operationSummary.Discounts = (double)_E04E.Discount;
			operationSummary.Markups = (double)_E04E.Markup;
		}
		foreach (PaymentTypeEnum paymentTypeEnum in Enum.GetValues(typeof(PaymentTypeEnum)))
		{
			PaymentSummary paymentSummary = new PaymentSummary
			{
				Type = paymentTypeEnum
			};
			if (_E04E != null)
			{
				PaymentsByTypeApiModel paymentsByTypeApiModel = _E04E.PaymentsByTypesApiModel.SingleOrDefault((PaymentsByTypeApiModel _E055) => _E055.Type == paymentTypeEnum);
				if (paymentsByTypeApiModel != null)
				{
					paymentSummary.Sum = (double)paymentsByTypeApiModel.Sum;
				}
			}
			operationSummary.PaymentsSummary.Add(paymentSummary);
		}
		return operationSummary;
	}

	public async Task _E006(long _E050)
	{
		string text = await _E008(_E050);
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		ApiResult<OrganizationInfoForPrintResponse> apiResult = await _E001(text);
		if (apiResult != null && !apiResult.HasError())
		{
			Cashbox cashbox = await this.m__E001.Cashboxes.FindAsync(_E050);
			cashbox.OrganizationVatNumber = apiResult.Data.TaxPayerVatNumber;
			cashbox.OrganizationVatSeria = apiResult.Data.TaxPayerVatSeria;
			cashbox.OrganizationIsVatPayer = apiResult.Data.VatPayer;
			cashbox.AllowedTaxValues = apiResult.Data.TaxPercents.Select((TaxPercent _E054) => _E054.Value).ToArray();
			await this.m__E001.SaveChangesAsync();
		}
	}

	public async Task _E007(long _E051)
	{
		string text = await _E008(_E051);
		if (!string.IsNullOrEmpty(text))
		{
			Cashbox cashbox = await this.m__E001.Cashboxes.FindAsync(_E051);
			ApiResult<CashboxMobileStateResponse> apiResult = await _E002(cashbox.UniqueNumber, text);
			if (apiResult != null && !apiResult.HasError())
			{
				CashboxMobileStateResponse data = apiResult.Data;
				cashbox.IdentityNumber = data.CashboxIdentityNumber;
				cashbox.RegistrationNumber = data.CasboxRegistrationNumber;
				cashbox.RoundType = data.RoundType.GetValueOrDefault();
				cashbox.Name = data.CashboxName;
				cashbox.AutoWithdrawal = data.AutoWithDrawal;
				cashbox.Address = data.Address;
				cashbox.OfdName = data.Ofd?.Name;
				cashbox.OfdHost = data.Ofd?.Host;
				cashbox.OfdCode = data.Ofd?.Code ?? OfdEnum.KazakhTelecom;
				cashbox.OfflineSupportMode = data.OfflineSupportMode;
				cashbox.OfdProtocolVersion = data.OfdProtocolVersion;
				await this.m__E001.SaveChangesAsync();
			}
		}
	}

	private async Task<string> _E008(long _E052)
	{
		_E009 obj = new _E009();
		obj._E000 = _E052;
		DbSet<OperationData> lastOperations = this.m__E001.LastOperations;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		IQueryable<OperationData> source = lastOperations.Where(Expression.Lambda<Func<OperationData, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E009)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		OperationData operationData = await source.OrderByDescending(Expression.Lambda<Func<OperationData, DateTime>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).FirstOrDefaultAsync();
		if (operationData != null)
		{
			AuthorizedRequest authorizedRequest = JsonConvert.DeserializeObject<AuthorizedRequest>(operationData.Request);
			return authorizedRequest.Token;
		}
		DbSet<Cashbox> cashboxes = this.m__E001.Cashboxes;
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source2 = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E009)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<UserToCashbox> source3 = source2.SelectMany(Expression.Lambda<Func<Cashbox, IEnumerable<UserToCashbox>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uf3cb", 62242));
		IOrderedQueryable<UserToCashbox> source4 = source3.OrderByDescending(Expression.Lambda<Func<UserToCashbox, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uf3cb", 62242));
		return source4.Select(Expression.Lambda<Func<UserToCashbox, string>>(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).FirstOrDefault();
	}
}
internal class _E013 : IEqualityComparer<DateTime?>
{
	public bool Equals(DateTime? x, DateTime? y)
	{
		if (x.HasValue == y.HasValue)
		{
			if (!x.HasValue)
			{
				return true;
			}
			return Math.Abs(Math.Abs((x.Value - y.Value).TotalMilliseconds)) < 1000.0;
		}
		return false;
	}

	public int GetHashCode(DateTime? obj)
	{
		if (!obj.HasValue)
		{
			return -1;
		}
		return _E000(obj.Value).GetHashCode();
	}

	private DateTime _E000(DateTime _E056)
	{
		return _E056.AddMilliseconds(-_E056.Millisecond);
	}
}
internal class _E014 : _E015
{
	private readonly JsonSerializerSettings m__E000;

	private readonly IHttpContextAccessor m__E001;

	private readonly HttpClient m__E002;

	private TimeSpan _E003;

	public _E014(IHttpContextAccessor _E057, HttpClient _E058)
	{
		this.m__E001 = _E057;
		this.m__E002 = _E058;
		_E000();
		_E003 = TimeSpan.FromSeconds(5.0);
		this.m__E000 = new JsonSerializerSettings
		{
			NullValueHandling = NullValueHandling.Ignore,
			Culture = new CultureInfo(_E01E._E000("\uf3eb\uf3e0\uf383\uf3db\uf3dd", 62218)),
			DateFormatString = _E01E._E000("\ue81f\ue81f\ue855\ue836\ue836\ue855\ue802\ue802\ue802\ue802\ue85b\ue833\ue833\ue841\ue816\ue816\ue841\ue808\ue808\ue855\ue83d\ue83d\ue83d", 59483),
			Formatting = Formatting.None
		};
	}

	public async Task<_E007> _E002<_E007>(string _E0D1, object _E0D2, MainDbContext _E0D3) where _E007 : class
	{
		string text = JsonConvert.SerializeObject(_E0D2, this.m__E000);
		Stopwatch stopwatch = new Stopwatch();
		Log.Debug(_E01E._E000("\uf290\uf29e\uf299\uf282\uf296\uf2cb\uf2d6\uf2d5\uf2cb\uf290\uf28f\uf28a\uf29f\uf28a\uf296", 62091), _E0D1, text);
		try
		{
			stopwatch.Start();
			Task<HttpResponseMessage> task = this.m__E002.PostAsync(_E0D1, new StringContent(text, Encoding.UTF8, _E01E._E000("\ue29a\ue28b\ue28b\ue297\ue292\ue298\ue29a\ue28f\ue292\ue294\ue295\ue2d4\ue291\ue288\ue294\ue295", 58011)));
			Task task2 = Task.Delay(_E003);
			await Task.WhenAny(task, task2);
			if (task.IsCompletedSuccessfully)
			{
				HttpResponseMessage httpResponseMessage = await task;
				if (!httpResponseMessage.IsSuccessStatusCode)
				{
					return null;
				}
				string text2 = await httpResponseMessage.Content.ReadAsStringAsync();
				stopwatch.Stop();
				Log.Debug(_E01E._E000("\uefa4\uefaa\uefad\uefb6\uefa2\uefff\uefe3\uefe2\uefff\uefa4\uefad\uefba\uefac\uefaf\uefb0\uefb1\uefac\uefba\uefa2\ueff3\uefff\uefa4\uefab\uefb6\uefb2\uefba\uefa2\uefb2\uefac", 61213), _E0D1, text2, stopwatch.ElapsedMilliseconds);
				return JsonConvert.DeserializeObject<_E007>(text2, this.m__E000);
			}
			Log.Warning(_E01E._E000("\uf7f6\uf7f8\uf7ff\uf7e4\uf7f0\uf7ad\uf7f9\uf7e4\uf7e0\uf7e8\uf7e2\uf7f8\uf7f9\uf7e8\uf7e9", 63244), _E0D1);
			return null;
		}
		catch (HttpRequestException exception)
		{
			Log.Warning(exception, _E01E._E000("\uf3a4\uf3aa\uf3ad\uf3b6\uf3a2\uf3ff\uf3b9\uf3be\uf3b6\uf3b3\uf3ba\uf3bb", 62351), _E0D1);
			return null;
		}
		catch (TaskCanceledException)
		{
			Log.Warning(_E01E._E000("\uf7f6\uf7f8\uf7ff\uf7e4\uf7f0\uf7ad\uf7f9\uf7e4\uf7e0\uf7e8\uf7e2\uf7f8\uf7f9\uf7e8\uf7e9", 63244), _E0D1);
			return null;
		}
		catch (OperationCanceledException)
		{
			Log.Warning(_E01E._E000("\uf695\uf69b\uf69c\uf687\uf693\uf6ce\uf69a\uf687\uf683\uf68b\uf681\uf69b\uf69a\uf68b\uf68a\uf6ce\uf68a\uf69b\uf69c\uf687\uf680\uf689\uf6ce\uf69c\uf68b\uf68d\uf68b\uf687\uf698\uf68b\uf6ce\uf69c\uf68b\uf69d\uf69e\uf681\uf680\uf69d\uf68b", 63210), _E0D1);
			return null;
		}
		catch (Exception exception2)
		{
			Log.Error(exception2, _E01E._E000("\uef10\uef01\uef01\uef1d\uef18\uef12\uef10\uef05\uef18\uef1e\uef1f\uef51\uef01\uef03\uef1e\uef13\uef1d\uef14\uef1c\uef51\uef06\uef18\uef05\uef19\uef51\uef03\uef14\uef00\uef04\uef14\uef02\uef05\uef51\uef05\uef1e\uef51\uef0a\uef04\uef03\uef18\uef0c", 61297), _E0D1);
			return null;
		}
	}

	public void _E007(TimeSpan _E0D8)
	{
		_E003 = _E0D8;
		this.m__E002.Timeout = _E0D8;
	}

	private void _E000()
	{
		this.m__E002.DefaultRequestHeaders.Add(_E01E._E000("\uee2e\uee08\uee1e\uee09\uee56\uee3a\uee1c\uee1e\uee15\uee0f\uee56\uee2d\uee1e\uee09\uee08\uee12\uee14\uee15", 61019), _E01E._E000("\uf4bb\uf498\uf494\uf496\uf49b\uf4a4\uf492\uf485\uf481\uf492\uf485\uf4d7", 62534) + Assembly.GetExecutingAssembly().GetName().Version);
		if (this.m__E001.HttpContext != null && this.m__E001.HttpContext.Request.Headers.ContainsKey(_E01E._E000("\ued8b\uedfe\ued92\ued83\ued9a\uedfe\ued98\ued96\ued8a", 60754)))
		{
			string value = this.m__E001.HttpContext.Request.Headers[_E01E._E000("\ued8b\uedfe\ued92\ued83\ued9a\uedfe\ued98\ued96\ued8a", 60754)].ToString();
			this.m__E002.DefaultRequestHeaders.Add(_E01E._E000("\ued8b\uedfe\ued92\ued83\ued9a\uedfe\ued98\ued96\ued8a", 60754), value);
		}
	}

	private bool _E001(HttpRequestMessage _E059, X509Certificate2 _E05A, X509Chain _E05B, SslPolicyErrors _E05C)
	{
		if (_E05C == SslPolicyErrors.None)
		{
			return true;
		}
		Log.Warning(_E01E._E000("\uefc0\uefc0\uefdf\uefb3\uefe5\ueff2\uefff\ueffa\ueff7\ueff2\uefe7\ueffa\ueffc\ueffd\uefb3\ueff6\uefe1\uefe1\ueffc\uefe1\uefa9\uefb3\uefe8\ueff6\uefe1\uefe1\ueffc\uefe1\uefee", 61186), _E05C);
		X509ChainStatus[] chainStatus = _E05B.ChainStatus;
		for (int i = 0; i < chainStatus.Length; i++)
		{
			X509ChainStatus x509ChainStatus = chainStatus[i];
			if (x509ChainStatus.Status != 0)
			{
				Log.Warning(_E01E._E000("\ue2a8\ue283\ue28a\ue282\ue285\ue2cb\ue298\ue29f\ue28a\ue29f\ue29e\ue298\ue2d1\ue2cb\ue290\ue28e\ue299\ue299\ue284\ue299\ue296\ue2cb\ue2c6\ue2cb\ue290\ue282\ue285\ue28d\ue284\ue296", 57891), x509ChainStatus.Status, x509ChainStatus.StatusInformation);
			}
		}
		return false;
	}

	public async Task<HttpResponseMessage> _E008(HttpRequestMessage _E0DB)
	{
		return await this.m__E002.SendAsync(_E0DB);
	}
}
internal interface _E015
{
	Task<_E007> _E002<_E007>(string _E0D4, object _E0D5, MainDbContext _E0D6) where _E007 : class;

	void _E007(TimeSpan _E0D9);

	Task<HttpResponseMessage> _E008(HttpRequestMessage _E0DC);
}
internal class _E016 : IDisposable, IMediator
{
	[CompilerGenerated]
	private sealed class _E002
	{
		public string _E000;
	}

	[CompilerGenerated]
	private sealed class _E004
	{
		public string _E000;
	}

	private readonly _E015 m__E000;

	private readonly MainDbContext m__E001;

	private readonly _E012 m__E002;

	public _E016(_E015 _E05D, MainDbContext _E05E, _E012 _E05F, IOptions<AppConfig> _E060)
	{
		this.m__E000 = _E05D;
		this.m__E000._E007(TimeSpan.FromSeconds(_E060.Value.FiscalizationRequestTimeout));
		this.m__E001 = _E05E;
		this.m__E002 = _E05F;
	}

	public async Task<ApiResult> GetResponse<TRequest, TResponse>(IServerInteractionDescription<TRequest, TResponse> description, TRequest request) where TResponse : ApiResult
	{
		TResponse val = null;
		string cashboxUniqueNumber = description.GetCashboxUniqueNumber(request);
		AuthorizedRequest authorizedRequest = request as AuthorizedRequest;
		using (await _E017._E001(_E000(cashboxUniqueNumber, authorizedRequest)))
		{
			if (!string.IsNullOrEmpty(cashboxUniqueNumber) && authorizedRequest != null)
			{
				if (authorizedRequest != null)
				{
					ApiResult<bool> apiResult = await this.m__E002._E000(cashboxUniqueNumber, authorizedRequest.Token);
					if (apiResult.HasError())
					{
						return new ApiResult<TResponse>
						{
							Errors = apiResult.Errors
						};
					}
				}
				if (await _E003(cashboxUniqueNumber) == OfflineSupportMode.Special && description.NeedPing())
				{
					bool flag = await this.m__E002._E004(cashboxUniqueNumber);
					if (!flag)
					{
						flag = !(await this.m__E002._E003());
					}
					if (flag)
					{
						return ApiResult.Error(ApiErrorCode.ValidationError, _E01E._E000("\ue1c1\ue1e0\ue1ea\ue19f\ue1ef\ue199\ue1e7\ue190\ue5ff\ue1e2\ue1ea\ue1eb\ue1e1\ue19e\ue19d\ue19c\ue1e0\ue1e2\ue1ef\ue5ff\ue1e0\ue19f\ue1e7\ue5ff\ue1e1\ue19d\ue19e\ue19c\ue19d\ue19e\ue19d\ue1ed\ue1e7\ue1e7\ue5ff\ue19e\ue1ed\ue190\ue1e8\ue1e7\ue5ff\ue19e\ue5ff\ue19e\ue1ea\ue19f\ue1ed\ue1ea\ue19f\ue1e1\ue1e3", 58839));
					}
				}
			}
			if (!(await _E002(cashboxUniqueNumber)))
			{
				return ApiResult.Error(ApiErrorCode.ValidationError, _E01E._E000("\uf6f6\uf6de\uf6d9\uf6de\uf6ab\uf6d6\uf6db\uf6a4\uf2cb\uf6a9\uf6de\uf6d1\uf6a8\uf6a2\uf6db\uf6a4\uf2cb\uf6df\uf6db\uf6a9\uf6db", 62147));
			}
			description.PrepareRequestBeforeSend(request);
			if (!(await description.MustBeRegisterOffline(request)))
			{
				val = await _E001<TRequest, TResponse>(request, description.Url);
			}
			if (authorizedRequest != null)
			{
				AccessManager accessManager = new AccessManager(this.m__E001);
				string token = authorizedRequest.Token;
				if (val != null)
				{
					if (!val.HasError())
					{
						await accessManager.AddAccessToCashboxAsync(cashboxUniqueNumber, token);
					}
					else if (val.HasError(ApiErrorCode.CashAccessDenied))
					{
						await accessManager.RemoveAccessToCashboxAsync(cashboxUniqueNumber, token);
					}
				}
				else if (!(await accessManager.HasAccessToCashboxAsync(cashboxUniqueNumber, token)))
				{
					return ApiResult.Error(ApiErrorCode.CashAccessDenied, _E01E._E000("\uf6ea\uf6c2\uf6b5\uf2d7\uf6cf\uf6ca\uf6b3\uf6c9\uf6b7\uf6cb\uf6c7\uf6b1\uf6cf\uf6cf\uf2d7\uf6c9\uf2d7\uf6c3\uf6c9\uf6b6\uf6b5\uf6b4\uf6c8\uf6ca\uf6c9\uf6b6\uf6b5\uf6cf\uf2d7\uf6ba\uf6b5\uf6c9\uf6ce\uf2d7\uf6cd\uf6c7\uf6b6\uf6b6\uf6bc\uf2d7\uf6b5\uf6c2\uf6cd\uf6b4\uf6be\uf6c2\uf6cb\uf6b4\uf2d7\uf6c8\uf6c9\uf6cc\uf6bb\uf6c0\uf6c9\uf6c5\uf6c7\uf6b5\uf6c2\uf6cc\uf6b9\uf2d9\uf2d7\uf6ea\uf6c2\uf6c9\uf6c6\uf6b2\uf6c9\uf6c3\uf6cf\uf6cb\uf6c9\uf2d7\uf6c5\uf6bc\uf6c8\uf6c9\uf6cc\uf6ca\uf6cf\uf6b5\uf6bb\uf2d7\uf6b6\uf6c9\uf6c2\uf6c3\uf6cf\uf6ca\uf6c2\uf6ca\uf6cf\uf6c2\uf2d7\uf6b6\uf2d7\uf6c9\uf6b6\uf6ca\uf6c9\uf6c5\uf6ca\uf6bc\uf6cb\uf2d7\uf6b6\uf6c2\uf6b7\uf6c5\uf6c2\uf6b7\uf6c9\uf6cb", 62150));
				}
			}
			if (val == null || val.HasError(ApiErrorCode.UnknownError))
			{
				val = await description.ValidateAsync(request);
				if (!val.HasError())
				{
					val = await description.CreateOfflineResponseAsync(request);
					await description.SaveToOfflineStoreAsync(request, val);
				}
			}
			if (val.HasError())
			{
				await description.HandleError(request, val);
				return val;
			}
			await description.UpdateLocalStorageAsync(request, val);
			return description.ConvertBeforeReply(val);
		}
	}

	private string _E000(string _E061, AuthorizedRequest _E062)
	{
		if (!string.IsNullOrEmpty(_E061))
		{
			return _E061;
		}
		if (_E062 != null)
		{
			return _E062.Token;
		}
		return _E01E._E000("\ue19e\ue195\ue196\ue19b\ue198\ue195", 57784);
	}

	private async Task<_E009> _E001<_E008, _E009>(_E008 _E063, string _E064) where _E009 : ApiResult
	{
		_E009 val = await this.m__E000._E002<_E009>(_E064, _E063, this.m__E001);
		if (val == null)
		{
			Log.Information(_E01E._E000("\ue830\ue811\ue813\ue816\ue811\ue81a\ue85f\ue80d\ue81a\ue80c\ue80f\ue810\ue811\ue80c\ue81a\ue85f\ue811\ue810\ue80b\ue85f\ue81e\ue809\ue81e\ue816\ue813\ue81e\ue81d\ue813\ue81a", 59465));
		}
		return val;
	}

	private async Task<bool> _E002(string _E065)
	{
		_E002 obj = new _E002();
		obj._E000 = _E065;
		DbSet<OperationData> lastOperations = this.m__E001.LastOperations;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		IQueryable<OperationData> source = lastOperations.Where(Expression.Lambda<Func<OperationData, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\uf3cb", 62242));
		IOrderedQueryable<OperationData> source2 = source.OrderByDescending(Expression.Lambda<Func<OperationData, DateTime>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationData), _E01E._E000("\ue990", 59864));
		DateTime? dateTime = await source2.Select(Expression.Lambda<Func<OperationData, DateTime?>>(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(DateTime?)), new ParameterExpression[1] { parameterExpression })).FirstOrDefaultAsync();
		if (dateTime.HasValue && dateTime.Value > DateTime.Now)
		{
			return false;
		}
		return true;
	}

	private async Task<OfflineSupportMode> _E003(string _E066)
	{
		_E004 obj = new _E004();
		obj._E000 = _E066;
		DbSet<Cashbox> cashboxes = this.m__E001.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		return await source.Select(Expression.Lambda<Func<Cashbox, OfflineSupportMode>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).FirstOrDefaultAsync();
	}

	public void Dispose()
	{
		this.m__E001.Dispose();
	}
}
internal class _E017
{
	internal class _E000 : IDisposable
	{
		private readonly SemaphoreSlim m__E000;

		public _E000(SemaphoreSlim _E06A)
		{
			m__E000 = _E06A;
		}

		public void Dispose()
		{
			m__E000.Release();
		}
	}

	private static readonly ConcurrentDictionary<string, SemaphoreSlim> m__E000 = new ConcurrentDictionary<string, SemaphoreSlim>();

	public static async Task<IDisposable> _E000(string _E067)
	{
		return await _E001(_E067);
	}

	public static async Task<IDisposable> _E001(string _E068)
	{
		SemaphoreSlim orAdd = _E017.m__E000.GetOrAdd(_E068, new SemaphoreSlim(1));
		await orAdd.WaitAsync();
		return new _E000(orAdd);
	}

	public static async Task<IDisposable> _E002(string _E069)
	{
		return await _E001(_E069 + _E01E._E000("\uf389\uf3f6\uf3cb\uf3da\uf3c7\uf3f5\uf3c1\uf3dc\uf3de\uf3fc\uf3d5\uf3d5\uf3df\uf3da\uf3dd\uf3d6", 62242));
	}
}
internal class _E018
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public long _E000;

		public CashboxState _E001;
	}

	[CompilerGenerated]
	private sealed class _E001
	{
		public OperationSummary _E000;
	}

	private readonly MainDbContext m__E000;

	public _E018(MainDbContext _E06B)
	{
		this.m__E000 = _E06B;
	}

	public async Task _E000(long _E06C, DateTime _E06D)
	{
		_E000 obj = new _E000();
		obj._E000 = _E06C;
		DbSet<CashboxState> cashboxStates = this.m__E000.CashboxStates;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (!obj._E001.ShiftClosedOn.HasValue && obj._E001.ShiftOpened.HasValue)
		{
			return;
		}
		obj._E001.ShiftOpened = _E06D;
		obj._E001.ShiftClosedOn = null;
		obj._E001.ShiftNumber++;
		obj._E001.CashDeposits = 0.0;
		obj._E001.CashWithdrawals = 0.0;
		obj._E001.DocumentsCount = 0;
		DbSet<OperationSummary> operationSummaries = this.m__E000.OperationSummaries;
		parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
		OperationSummary[] array = await operationSummaries.Where(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).ToArrayAsync();
		for (int i = 0; i < array.Length; i++)
		{
			_E001 obj2 = new _E001();
			obj2._E000 = array[i];
			switch (obj2._E000.Type)
			{
			case OperationTypeEnum.Sell:
				obj._E001.NNStartSell += obj2._E000.Sum;
				break;
			case OperationTypeEnum.Buy:
				obj._E001.NNStartBuy += obj2._E000.Sum;
				break;
			case OperationTypeEnum.ReturnSell:
				obj._E001.NNStartReturnSell += obj2._E000.Sum;
				break;
			case OperationTypeEnum.ReturnBuy:
				obj._E001.NNStartReturnBuy += obj2._E000.Sum;
				break;
			}
			obj2._E000.Change = 0.0;
			obj2._E000.Count = 0;
			obj2._E000.Taken = 0.0;
			obj2._E000.Sum = 0.0;
			obj2._E000.Tax = 0.0;
			obj2._E000.Discounts = 0.0;
			obj2._E000.Markups = 0.0;
			DbSet<PaymentSummary> paymentSummaries = this.m__E000.PaymentSummaries;
			parameterExpression = Expression.Parameter(typeof(PaymentSummary), _E01E._E000("\uf3cb", 62242));
			foreach (PaymentSummary item in paymentSummaries.Where(Expression.Lambda<Func<PaymentSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj2, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })))
			{
				item.Sum = 0.0;
			}
		}
		await this.m__E000.SaveChangesAsync();
	}
}
internal static class _E019
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public Assembly[] _E000;

		internal void _E000(ApplicationPartManager _E077)
		{
			Assembly[] array = this._E000;
			foreach (Assembly assembly in array)
			{
				_E077.ApplicationParts.Add(new AssemblyPart(assembly));
			}
		}
	}

	private const string m__E000 = "plugins";

	private static List<IPluginDescription> m__E001 = new List<IPluginDescription>();

	internal static void _E000(this IServiceCollection _E071, IConfiguration _E072)
	{
		string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		string path = Path.Combine(directoryName, _E01E._E000("\ue78e\ue792\ue78b\ue799\ue797\ue790\ue78d", 59342));
		DirectoryInfo directoryInfo = new DirectoryInfo(path);
		if (directoryInfo.Exists)
		{
			_E002(directoryInfo, _E071, _E072);
			DirectoryInfo[] directories = directoryInfo.GetDirectories();
			foreach (DirectoryInfo directoryInfo2 in directories)
			{
				_E002(directoryInfo2, _E071, _E072);
			}
		}
	}

	internal static void _E001(this IApplicationBuilder _E073)
	{
		foreach (IPluginDescription item in _E019.m__E001)
		{
			item.Validate(_E073.ApplicationServices);
		}
	}

	private static void _E002(DirectoryInfo _E074, IServiceCollection _E075, IConfiguration _E076)
	{
		Assembly[] array = (from _E078 in _E074.GetFiles(_E01E._E000("\uec7b\uec7f\uec35\uec3d\uec3d", 60497))
			select Assembly.LoadFile(_E078.FullName)).ToArray();
		if (!array.Any())
		{
			return;
		}
		Assembly[] array2 = array;
		foreach (Assembly assembly in array2)
		{
			IEnumerable<Type> enumerable = from _E079 in assembly.GetExportedTypes()
				where _E079.IsAssignableTo(typeof(IPluginDescription))
				select _E079;
			foreach (Type item in enumerable)
			{
				IPluginDescription pluginDescription = (IPluginDescription)Activator.CreateInstance(item);
				Console.WriteLine(_E01E._E000("\ue02d\ue011\ue008\ue01a\ue014\ue013\ue05d\ue01b\ue012\ue008\ue013\ue019\ue047\ue05d", 57461) + item.Name);
				pluginDescription.ConfigureServices(_E075, _E076);
				_E019.m__E001.Add(pluginDescription);
			}
		}
		_E075.AddControllersWithViews().ConfigureApplicationPartManager(delegate(ApplicationPartManager _E077)
		{
			Assembly[] array3 = array;
			foreach (Assembly assembly2 in array3)
			{
				_E077.ApplicationParts.Add(new AssemblyPart(assembly2));
			}
		});
	}
}
internal class _E01A : IServerInteractionDescription<AuthCredentialsRequest, ApiResult<TokenWithEmployeeInfoResponse>>
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public AuthCredentialsRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E003
	{
		public AuthCredentialsRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E005
	{
		public AuthCredentialsRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E007
	{
		public AuthCredentialsRequest _E000;

		public _E001<long, string, string> _E001;
	}

	[CompilerGenerated]
	private readonly MainDbContext m__E000;

	private bool _E001;

	public MainDbContext _E002
	{
		[CompilerGenerated]
		get
		{
			return this.m__E000;
		}
	}

	public string Url => _E01E._E000("\ue991\ue9df\ue9ce\ue9d7\ue991\ue9ff\ue9cb\ue9ca\ue9d6\ue9d1\ue9cc\ue9d7\ue9c4\ue9db\ue991\ue9e9\ue9d7\ue9ca\ue9d6\ue9fb\ue9d3\ue9ce\ue9d2\ue9d1\ue9c7\ue9db\ue9db\ue9f7\ue9d0\ue9d8\ue9d1", 59790);

	public _E01A(MainDbContext _E093)
	{
		this.m__E000 = _E093;
	}

	public void PrepareRequestBeforeSend(AuthCredentialsRequest request)
	{
	}

	public string GetCashboxUniqueNumber(AuthCredentialsRequest request)
	{
		return null;
	}

	public async Task<ApiResult<TokenWithEmployeeInfoResponse>> ValidateAsync(AuthCredentialsRequest request)
	{
		_E000 obj = new _E000();
		obj._E000 = request;
		DbSet<User> users = this._E002.Users;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		if (!(await users.AnyAsync(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }))))
		{
			return new ApiResult<TokenWithEmployeeInfoResponse>(ApiErrorCode.NotAuthorized, _E01E._E000("\ue38e\ue3a6\ue3ab\ue3a4\ue3a1\ue3a6\ue3d2\ue3d1\ue3ae\ue3d8\ue3aa\ue7b3\ue3ac\ue3ad\ue3a8\ue3df\ue3a4\ue3ad\ue3a1\ue3a3\ue3d1\ue3a6\ue3a8\ue3df\ue7bd\ue7b3\ue38e\ue3a6\ue3ad\ue3a2\ue3d6\ue3ad\ue3a7\ue3ab\ue3af\ue3ad\ue7b3\ue3d0\ue3d2\ue3d1\ue3a3\ue3ae\ue3ad\ue3a1\ue3ab\ue3d1\ue3df\ue7b3\ue3d2\ue3a1\ue3dc\ue3a4\ue3df\ue7b3\ue3d2\ue7b3\ue3ad\ue3d2\ue3ae\ue3ad\ue3a1\ue3ae\ue3d8\ue3af\ue7b3\ue3d2\ue3a6\ue3d3\ue3a1\ue3a6\ue3d3\ue3ad\ue3af", 59154));
		}
		return new ApiResult<TokenWithEmployeeInfoResponse>();
	}

	public async Task SaveToOfflineStoreAsync(AuthCredentialsRequest request, ApiResult<TokenWithEmployeeInfoResponse> response)
	{
		this._E001 = true;
	}

	public async Task<ApiResult<TokenWithEmployeeInfoResponse>> CreateOfflineResponseAsync(AuthCredentialsRequest request)
	{
		_E003 obj = new _E003();
		obj._E000 = request;
		DbSet<User> users = this._E002.Users;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		User user = await users.SingleOrDefaultAsync(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E003)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (user == null)
		{
			return new ApiResult<TokenWithEmployeeInfoResponse>
			{
				Errors = new List<ErrorItem>
				{
					new ErrorItem(ApiErrorCode.UnknownError, _E01E._E000("\uf663\uf64b\uf640\uf64f\uf63b\uf640\uf64a\uf646\uf642\uf640\uf25e\uf63b\uf640\uf63c\uf631\uf25e\uf64f\uf635\uf25e\uf63e\uf64e\uf649\uf25e\uf63d\uf63f\uf641\uf64b\uf636\uf643\uf640\uf25e\uf64e\uf64c\uf63c\uf640\uf63e\uf646\uf649\uf640\uf64c\uf64e\uf63c\uf632\uf63f\uf631\uf25e\uf643\uf64e\uf25e\uf63f\uf64b\uf63e\uf64c\uf64b\uf63e\uf64b", 62062))
				}
			};
		}
		if (user.Password != obj._E000.Password)
		{
			return new ApiResult<TokenWithEmployeeInfoResponse>(ApiErrorCode.WrongCredentials, _E01E._E000("\uefaa\uef82\uef85\uef82\ueff7\uef8a\ueffc\uef8e\ueb97\uef8c\uef89\uef84\uef8f\uef8a\ueb97\uef8f\uebeb\uef8f\uef8c\uef8f\ueb97\uef88\uef87\ueff7\uef89\uef8c\ueffb", 60326));
		}
		string value = user.RealToken;
		if (string.IsNullOrEmpty(value))
		{
			value = user.CurrentToken;
		}
		return new ApiResult<TokenWithEmployeeInfoResponse>(new TokenWithEmployeeInfoResponse(value)
		{
			FullName = user.FullName,
			Code = user.Code
		});
	}

	public async Task UpdateLocalStorageAsync(AuthCredentialsRequest request, ApiResult<TokenWithEmployeeInfoResponse> response)
	{
		_E005 obj = new _E005();
		obj._E000 = request;
		DbSet<User> users = this._E002.Users;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		User user = await users.SingleOrDefaultAsync(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E005)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (user == null)
		{
			user = new User
			{
				UserName = obj._E000.Login
			};
			await this._E002.Users.AddAsync(user);
		}
		if (this._E001)
		{
			user.RealToken = string.Empty;
		}
		else
		{
			user.RealToken = response.Data.Token;
		}
		user.CurrentToken = response.Data.Token;
		user.Password = obj._E000.Password;
		user.FullName = response.Data.FullName;
		user.Code = response.Data.Code;
		await this._E002.SaveChangesAsync();
	}

	public ApiResult ConvertBeforeReply(ApiResult<TokenWithEmployeeInfoResponse> response)
	{
		if (!response.HasError())
		{
			return new ApiResult<TokenResponse>(new TokenResponse(response.Data.Token));
		}
		return response;
	}

	public async Task<bool> MustBeRegisterOffline(AuthCredentialsRequest request)
	{
		_E007 obj = new _E007();
		obj._E000 = request;
		DbSet<User> users = this._E002.Users;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		IQueryable<User> source = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E007)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await source.Select(Expression.Lambda<Func<User, _E001<long, string, string>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E001<long, string, string>).TypeHandle), new Expression[3]
		{
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))
		}, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E001<long, string, string>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E001<long, string, string>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E001<long, string, string>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleOrDefaultAsync();
		if (obj._E001 == null)
		{
			return false;
		}
		if (obj._E001._E004 != obj._E001._E005)
		{
			return true;
		}
		DbSet<OfflineRequest> offlineRequests = this._E002.OfflineRequests;
		parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
		MethodInfo method = (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/);
		Expression[] obj2 = new Expression[2]
		{
			Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
			null
		};
		ParameterExpression parameterExpression2 = Expression.Parameter(typeof(UserToCashbox), _E01E._E000("\uebe1", 60180));
		obj2[1] = Expression.Lambda<Func<UserToCashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression2, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E007)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E001<long, string, string>).TypeHandle))), new ParameterExpression[1] { parameterExpression2 });
		if (await offlineRequests.AnyAsync(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.Call(null, method, obj2), new ParameterExpression[1] { parameterExpression })))
		{
			return true;
		}
		return false;
	}

	public async Task<bool> HandleError(AuthCredentialsRequest request, ApiResult<TokenWithEmployeeInfoResponse> response)
	{
		return false;
	}

	public bool NeedPing()
	{
		return false;
	}
}
internal class _E01B : AuthorizedInteractionDescription<MoneyOperationRequest, ApiResult<MoneyOperationResponse>>
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public MoneyOperationRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E001
	{
		public Cashbox _E000;

		public _E000 _E001;
	}

	[CompilerGenerated]
	private sealed class _E003
	{
		public MoneyOperationRequest _E000;

		public Cashbox _E001;
	}

	[CompilerGenerated]
	private sealed class _E005
	{
		public MoneyOperationRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E007
	{
		public MoneyOperationRequest _E000;
	}

	public override string Url => _E01E._E000("\ue356\ue318\ue309\ue310\ue356\ue314\ue316\ue317\ue31c\ue300\ue316\ue309\ue31c\ue30b\ue318\ue30d\ue310\ue316\ue317", 58168);

	public _E01B(MainDbContext _E098)
		: base(_E098)
	{
	}

	public override void PrepareRequestBeforeSend(MoneyOperationRequest request)
	{
		request.ExternalCheckNumber = (string.IsNullOrEmpty(request.ExternalCheckNumber) ? Guid.NewGuid().ToString() : request.ExternalCheckNumber);
		request.OfflineDate = request.OfflineDate ?? DateTime.Now;
	}

	public override string GetCashboxUniqueNumber(MoneyOperationRequest request)
	{
		return request.CashboxUniqueNumber;
	}

	public override async Task<ApiResult<MoneyOperationResponse>> ValidateAsync(MoneyOperationRequest request)
	{
		_E000 obj = new _E000();
		obj._E000 = request;
		if (obj._E000.Sum < 0m)
		{
			return new ApiResult<MoneyOperationResponse>(ApiErrorCode.ValidationError, CommonResource.TheAmountMustBeGreaterThanZero);
		}
		DateTime now = DateTime.Now;
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (!cashboxState.ShiftClosedOn.HasValue && cashboxState.ShiftOpened.HasValue && now - cashboxState.ShiftOpened.Value > TimeSpan.FromDays(1.0))
		{
			return new ApiResult<MoneyOperationResponse>(ApiErrorCode.ShiftOpenedMoreThan24Hours, CommonResource.DurationOfShiftMoreThan24HoursCloseShift);
		}
		if (OfflinePeriodMoreThanThreshold(cashboxState.OfflineModeStart))
		{
			return new ApiResult<MoneyOperationResponse>(ApiErrorCode.OfflineModeMoreThan72Hours, CommonResource.OfflineModeDurationMore72Hours);
		}
		if (obj._E000.OperationType == MoneyPlacementTypeEnum.WithDrawal)
		{
			DbSet<CashboxState> cashboxStates2 = base.Db.CashboxStates;
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			IQueryable<CashboxState> source = cashboxStates2.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
			double num = await source.Select(Expression.Lambda<Func<CashboxState, double>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
			if (num < (double)obj._E000.Sum)
			{
				return new ApiResult<MoneyOperationResponse>(ApiErrorCode.NotEnoughMoney, string.Format(ValidationResource.NotEnoughCashInCashbox, num));
			}
		}
		if (!string.IsNullOrEmpty(obj._E000.ExternalCheckNumber))
		{
			_E001 obj2 = new _E001();
			obj2._E001 = obj;
			DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
			parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
			obj2._E000 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Field(Expression.Constant(obj2, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
			DbSet<OfflineRequest> offlineRequests = base.Db.OfflineRequests;
			parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
			OfflineRequest offlineRequest = offlineRequests.SingleOrDefault(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.AndAlso(Expression.AndAlso(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj2, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Field(Expression.Constant(obj2, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(1, typeof(int)))), new ParameterExpression[1] { parameterExpression }));
			if (offlineRequest != null)
			{
				OfflineMoneyOperationRequest offlineMoneyOperationRequest = JsonConvert.DeserializeObject<OfflineMoneyOperationRequest>(offlineRequest.Content);
				ApiResult<MoneyOperationResponse> apiResult = new ApiResult<MoneyOperationResponse>(new MoneyOperationResponse
				{
					Cashbox = obj2._E000.ToCashboxInfo(),
					DateTime = offlineMoneyOperationRequest.OfflineDate.Value,
					OfflineMode = true,
					CashboxOfflineMode = true,
					Sum = offlineMoneyOperationRequest.Sum
				});
				apiResult.AddError(ApiErrorCode.DuplicateExternalCode, string.Format(_E01E._E000("\uece4\uecc5\ueccf\uecba\uecca\uecbc\uecc2\uecb5\ue8da\ue8d8\ue881\ue8cb\ue887\ue8d8\ue8da\uecbb\ue8da\uecc8\uecc7\ueccf\uecb2\uecc7\uecc2\uecc6\ue8da\uecc7\uecc4\uecc6\ueccf\uecba\uecc4\uecc6\ue8da\ue881\ue8ca\ue887\ue8da\uecb9\ueccc\ueccf\ue8da\uecc5\uecba\uecc2\uecbb\uecb9\uecb8\uecbb\uecb8\uecc8\uecb9\ueccf\uecb8\ue8da\uecc8\ue8da\uecbb\uecc2\uecbb\uecb8\ueccf\uecc6\ueccf", 59536), obj2._E001._E000.ExternalCheckNumber, obj2._E001._E000.OperationType.GetDisplayName()));
				return apiResult;
			}
		}
		return new ApiResult<MoneyOperationResponse>();
	}

	public override async Task<ApiResult<MoneyOperationResponse>> CreateOfflineResponseAsync(MoneyOperationRequest request)
	{
		_E003 obj = new _E003();
		obj._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E003)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E003)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		_E003<double, DateTime?> obj2 = await source.Select(Expression.Lambda<Func<CashboxState, _E003<double, DateTime?>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E003<double, DateTime?>).TypeHandle), new Expression[2]
		{
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))
		}, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E003<double, DateTime?>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E003<double, DateTime?>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		double num = obj2._E002;
		switch (obj._E000.OperationType)
		{
		case MoneyPlacementTypeEnum.Deposit:
			num += (double)obj._E000.Sum;
			break;
		case MoneyPlacementTypeEnum.WithDrawal:
			num -= (double)obj._E000.Sum;
			break;
		}
		DateTime now = DateTime.Now;
		_E018 obj3 = new _E018(base.Db);
		await obj3._E000(obj._E001.Id, now);
		return new ApiResult<MoneyOperationResponse>(new MoneyOperationResponse
		{
			Cashbox = obj._E001.ToCashboxInfo(),
			DateTime = (obj._E000.OfflineDate ?? now),
			Sum = (decimal)num,
			CashboxOfflineMode = true,
			OfflineMode = true,
			StartOfflineMode = (obj2._E003 ?? now)
		});
	}

	public override async Task SaveToOfflineStoreAsync(MoneyOperationRequest request, ApiResult<MoneyOperationResponse> response)
	{
		_E005 obj = new _E005();
		obj._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		IQueryable<Cashbox> source = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E005)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		long num = await source.Select(Expression.Lambda<Func<Cashbox, long>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		OfflineMoneyOperationRequest value = new OfflineMoneyOperationRequest
		{
			CashboxUniqueNumber = obj._E000.CashboxUniqueNumber,
			OperationType = obj._E000.OperationType,
			Token = obj._E000.Token,
			ExternalCheckNumber = obj._E000.ExternalCheckNumber,
			OfflineDate = response.Data.DateTime,
			Sum = obj._E000.Sum
		};
		string content = JsonConvert.SerializeObject(value);
		await base.Db.AddAsync(new OfflineRequest
		{
			Type = RequestType.MoneyOperation,
			Content = content,
			ExternalId = obj._E000.ExternalCheckNumber,
			Cashbox = base.Db.Cashboxes.Find(num)
		});
		await base.Db.SaveChangesAsync();
	}

	public override async Task UpdateLocalStorageAsync(MoneyOperationRequest request, ApiResult<MoneyOperationResponse> response)
	{
		_E007 obj = new _E007();
		obj._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		Cashbox cashbox = await cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E007)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		cashbox.Address = response.Data.Cashbox.Address;
		if (response.Data.Cashbox.Ofd != null)
		{
			cashbox.OfdName = response.Data.Cashbox.Ofd.Name;
			cashbox.OfdHost = response.Data.Cashbox.Ofd.Host;
			cashbox.OfdCode = response.Data.Cashbox.Ofd.Code;
		}
		cashbox.IdentityNumber = long.Parse(response.Data.Cashbox.IdentityNumber);
		_E018 obj2 = new _E018(base.Db);
		await obj2._E000(cashbox.Id, response.Data.DateTime);
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E007)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		cashboxState.SumInCashbox = (double)response.Data.Sum;
		cashboxState.OfflineModeStart = response.Data.StartOfflineMode;
		switch (obj._E000.OperationType)
		{
		case MoneyPlacementTypeEnum.Deposit:
			cashboxState.CashDeposits += (double)obj._E000.Sum;
			break;
		case MoneyPlacementTypeEnum.WithDrawal:
			cashboxState.CashWithdrawals += (double)obj._E000.Sum;
			break;
		}
		await base.Db.SaveChangesAsync();
		await SaveLastOperationAsync(obj._E000, response, cashbox, RequestType.MoneyOperation, obj._E000.ExternalCheckNumber);
	}

	public override ApiResult ConvertBeforeReply(ApiResult<MoneyOperationResponse> response)
	{
		return response;
	}
}
internal class _E01C : AuthorizedInteractionDescription<CheckOperationRequest, ApiResult<CheckOperationResponse>>
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public CheckOperationRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E001
	{
		public CheckOperationRequest _E000;

		public Cashbox _E001;
	}

	[CompilerGenerated]
	private sealed class _E002
	{
		public IRounder _E000;

		internal decimal _E000(CheckItemApiModel _E09C)
		{
			return _E09C.CalculateSum(this._E000);
		}
	}

	[CompilerGenerated]
	private sealed class _E004
	{
		public CheckOperationRequest _E000;

		public IRounder _E001;

		internal decimal _E000(CheckItemApiModel _E0AF)
		{
			return _E0AF.CalculateSum(this._E001);
		}

		internal decimal _E001(ModifierApiModel _E0B0)
		{
			return this._E001.RoundItem(_E0B0.AffectedSum);
		}
	}

	[CompilerGenerated]
	private sealed class _E006
	{
		public CheckOperationRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E008
	{
		public CheckOperationRequest _E000;

		public Cashbox _E001;

		public IRounder _E002;

		public CashboxState _E003;

		public OperationSummary _E004;

		public PaymentTypeEnum[] _E005;

		internal decimal _E000(CheckItemApiModel _E0B1)
		{
			return _E0B1.CalculateSum(_E002);
		}
	}

	[CompilerGenerated]
	private sealed class _E009
	{
		public PaymentTypeInfoApiModel _E000;

		internal bool _E000(PaymentSummary _E0B2)
		{
			return _E0B2.Type == this._E000.PaymentType;
		}
	}

	public override string Url => _E01E._E000("\uf744\uf70a\uf71b\uf702\uf744\uf708\uf703\uf70e\uf708\uf700", 63307);

	public _E01C(MainDbContext _E099)
		: base(_E099)
	{
	}

	public override void PrepareRequestBeforeSend(CheckOperationRequest request)
	{
		_E000 obj = new _E000();
		obj._E000 = request;
		obj._E000.ExternalCheckNumber = (string.IsNullOrEmpty(obj._E000.ExternalCheckNumber) ? Guid.NewGuid().ToString() : obj._E000.ExternalCheckNumber);
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		long identityNumber = cashboxes.Single(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).IdentityNumber;
		obj._E000.OfflineDate = obj._E000.OfflineDate ?? DateTime.Now;
		obj._E000.OfflineNumber = TicketConstants.GenerateOfflineNumber(identityNumber, obj._E000.OfflineDate.Value);
	}

	public override string GetCashboxUniqueNumber(CheckOperationRequest request)
	{
		return request.CashboxUniqueNumber;
	}

	public override async Task<ApiResult<CheckOperationResponse>> ValidateAsync(CheckOperationRequest request)
	{
		_E001 obj = new _E001();
		obj._E000 = request;
		IEnumerable<ValidationResult> source = obj._E000.Validate(new ValidationContext(obj._E000));
		if (source.Any())
		{
			ValidationResult validationResult = source.First();
			return new ApiResult<CheckOperationResponse>(ApiErrorCode.ValidationError, validationResult.ErrorMessage);
		}
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (!cashboxState.ShiftClosedOn.HasValue && cashboxState.ShiftOpened.HasValue && DateTime.Now - cashboxState.ShiftOpened.Value > TimeSpan.FromDays(1.0))
		{
			return new ApiResult<CheckOperationResponse>(ApiErrorCode.ShiftOpenedMoreThan24Hours, CommonResource.DurationOfShiftMoreThan24HoursCloseShift);
		}
		if (OfflinePeriodMoreThanThreshold(cashboxState.OfflineModeStart))
		{
			return new ApiResult<CheckOperationResponse>(ApiErrorCode.OfflineModeMoreThan72Hours, CommonResource.OfflineModeDurationMore72Hours);
		}
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		if (obj._E001.OfdProtocolVersion == OfdProtocolVersion.Version202 && obj._E000.Payments.Any((PaymentTypeInfoApiModel _E09D) => _E09D.PaymentType == PaymentTypeEnum.PAYMENT_TARE || _E09D.PaymentType == PaymentTypeEnum.PAYMENT_CREDIT))
		{
			return new ApiResult<CheckOperationResponse>(ApiErrorCode.ValidationError, _E01E._E000("\ue5dd\ue5c7\ue5c0\ue5b4\ue1df\ue5c0\ue5c4\ue5cf\ue5bd\ue5ca\ue5c9\ue5ca\ue5c6\ue1df\ue1d8\ue5e5\ue5bf\ue5ca\ue5cb\ue5c7\ue5bd\ue1d8\ue1df\ue5c7\ue1df\ue1d8\ue5dd\ue5cf\ue5bf\ue5cf\ue1d8\ue1df\ue5c2\ue5ca\ue5cb\ue5c1\ue5be\ue5bd\ue5bc\ue5c0\ue5c2\ue5b4\ue1df\ue5c0\ue5bf\ue5c7\ue1df\ue5c7\ue5be\ue5c0\ue5c1\ue5c4\ue5b3\ue5c8\ue5c1\ue5cd\ue5cf\ue5c2\ue5c7\ue5c7\ue1df\ue5c0\ue5bf\ue5c1\ue5bd\ue5c1\ue5c5\ue5c1\ue5c4\ue5cf\ue1df\ue1cd\ue1d1\ue1cf\ue1d1\ue1cd", 57785));
		}
		if (obj._E001.OfdProtocolVersion < OfdProtocolVersion.Version202 && obj._E000.Payments.Any((PaymentTypeInfoApiModel _E09E) => _E09E.PaymentType == PaymentTypeEnum.PAYMENT_MOBILE))
		{
			return new ApiResult<CheckOperationResponse>(ApiErrorCode.ValidationError, _E01E._E000("\ue1c8\ue1d2\ue1d5\ue5ca\ue1d5\ue1d1\ue1da\ue1a8\ue1df\ue1dc\ue1da\ue5ca\ue5cd\ue1f6\ue1d4\ue1db\ue1d2\ue1d1\ue1a6\ue1d7\ue1a1\ue1df\ue5cd\ue5ca\ue1d7\ue1df\ue1de\ue1d4\ue1ab\ue1a8\ue1a9\ue1d5\ue1d7\ue1a1\ue5ca\ue1d5\ue1aa\ue1d2\ue5ca\ue1d2\ue1ab\ue1d5\ue1d4\ue1d1\ue1a6\ue1dd\ue1d4\ue1d8\ue1da\ue1d7\ue1d2\ue1d2\ue5ca\ue1d5\ue1aa\ue1d4\ue1a8\ue1d4\ue1d0\ue1d4\ue1d1\ue1da\ue5ca\ue1d7\ue1d2\ue1dc\ue1df\ue5ca\ue5d8\ue5c4\ue5da\ue5c4\ue5d8", 58784));
		}
		CheckItemApiModel[] positions = obj._E000.Positions;
		foreach (CheckItemApiModel checkItemApiModel in positions)
		{
			if (checkItemApiModel.TaxPercent.HasValue && !obj._E001.AllowedTaxValues.Contains(checkItemApiModel.TaxPercent.Value))
			{
				return new ApiResult<CheckOperationResponse>(ApiErrorCode.ValidationError, string.Format(_E01E._E000("\uebf4\uebd5\uebdc\uebd3\uebad\uebd3\ueba4\uefcb\uefcc\uef90\uefdb\uef96\uefcc\uefcb\uebaa\uebd5\uebdf\uebde\uebab\uebdd\uebd3\ueba9\uefcb\uebd6\uebde\uebd4\uebd5\uebdf\uebdf\uebde\uebab\uebdd\uebd3\uebd9\uebdb\uebde\uebd7\uebd5\uebde\uefcb\uebd9\uebdb\ueba3\uebde\uebd2\uefcb\uebd5\uebab\uebd8\uebdb\uebd6\uebd3\uebdc\uebdb\uebad\uebd3\uebde\uebd2\uefcb\uebdc\uebd6\uebdb\uebac\uebde\uebd6\uebd3\uebde\uefcb\uebd6\uebdb\uebd0\uebd5\uebd8\uebd5\uebd9\uebd5\uebd2\uefcb\uebaa\ueba9\uebdb\uebd9\uebd1\uebd3\uefd1\uefcb\uef90\uefda\uef96\uefce", 61251), checkItemApiModel.PositionName, checkItemApiModel.TaxPercent.Value));
			}
		}
		foreach (ModifierApiModel ticketModifier in obj._E000.TicketModifiers)
		{
			if (ticketModifier.TaxPercent.HasValue && !obj._E001.AllowedTaxValues.Contains(ticketModifier.TaxPercent.Value))
			{
				return new ApiResult<CheckOperationResponse>(ApiErrorCode.ValidationError, string.Format(_E01E._E000("\ue9c3\ue9e1\ue9eb\ue9e7\ue99b\ue9e7\ue9e5\ue9ef\ue99d\ue9e1\ue99f\uedff\uedf8\ueda4\uedef\ueda2\uedf8\uedff\ue99e\ue9e1\ue9eb\ue9ea\ue99f\ue9e9\ue9e7\ue99d\uedff\ue9e2\ue9ea\ue9e0\ue9e1\ue9eb\ue9eb\ue9ea\ue99f\ue9e9\ue9e7\ue9ed\ue9ef\ue9ea\ue9e3\ue9e1\ue9ea\uedff\ue9ed\ue9ef\ue997\ue9ea\ue9e6\uedff\ue9e1\ue99f\ue9ec\ue9ef\ue9e2\ue9e7\ue9e8\ue9ef\ue999\ue9e7\ue9ea\ue9e6\uedff\ue9e8\ue9e2\ue9ef\ue998\ue9ea\ue9e2\ue9e7\ue9ea\uedff\ue9e2\ue9ef\ue9e4\ue9e1\ue9ec\ue9e1\ue9ed\ue9e1\ue9e6\uedff\ue99e\ue99d\ue9ef\ue9ed\ue9e5\ue9e7\uede5\uedff\ueda4\uedee\ueda2\uedfa", 60879), ticketModifier.Text, ticketModifier.TaxPercent.Value));
			}
		}
		if (!string.IsNullOrEmpty(obj._E000.ExternalCheckNumber))
		{
			DbSet<OfflineRequest> offlineRequests = base.Db.OfflineRequests;
			parameterExpression = Expression.Parameter(typeof(OfflineRequest), _E01E._E000("\uf3cb", 62242));
			OfflineRequest offlineRequest = await offlineRequests.SingleOrDefaultAsync(Expression.Lambda<Func<OfflineRequest, bool>>(Expression.AndAlso(Expression.AndAlso(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E001)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)))), Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(0, typeof(int)))), new ParameterExpression[1] { parameterExpression }));
			OperationData operationData = await FindLastOperationAsync(obj._E001.Id, RequestType.Check, obj._E000.ExternalCheckNumber);
			if (offlineRequest != null && operationData == null)
			{
				OfflineCheckOperationRequest offlineCheckOperationRequest = JsonConvert.DeserializeObject<OfflineCheckOperationRequest>(offlineRequest.Content);
				IRounder rounder = RoundersFactory.GetRounder(obj._E000.RoundType);
				List<decimal> list = (from _E09F in offlineCheckOperationRequest.Positions
					where !_E09F.IsStorno
					select _E09F into _E09C
					select _E09C.CalculateSum(rounder)).ToList();
				list.AddRange(offlineCheckOperationRequest.TicketModifiers.Select((ModifierApiModel _E0A0) => _E0A0.AffectedSum));
				list.Add(rounder.RoundItem(-offlineCheckOperationRequest.Discount));
				list.Add(rounder.RoundItem(offlineCheckOperationRequest.Markup));
				decimal ticketSum = rounder.RoundTotal(list);
				ApiResult<CheckOperationResponse> apiResult = new ApiResult<CheckOperationResponse>(new CheckOperationResponse
				{
					Cashbox = obj._E001.ToCashboxInfo(),
					DateTime = offlineCheckOperationRequest.OfflineDate.Value,
					OfflineMode = true,
					CashboxOfflineMode = true,
					CheckNumber = offlineCheckOperationRequest.OfflineNumber,
					TicketUrl = TicketConstants.GenerateTicketUrl(obj._E001.RegistrationNumber, offlineCheckOperationRequest.OfflineNumber, ticketSum, offlineCheckOperationRequest.OfflineDate.Value, obj._E001.OfdHost, obj._E001.OfdCode),
					TicketPrintUrl = TicketConstants.GenerateTicketUrl(obj._E001.UniqueNumber, offlineCheckOperationRequest.ExternalCheckNumber, cashboxState.ShiftNumber)
				});
				apiResult.AddError(ApiErrorCode.DuplicateExternalCode, string.Format(_E01E._E000("\uf328\uf33a\uf335\uf72f\uf34e\uf72f\uf33d\uf332\uf33a\uf347\uf332\uf337\uf333\uf72f\uf332\uf331\uf333\uf33a\uf34f\uf331\uf333\uf72f\uf774\uf73f\uf772\uf72f\uf34c\uf339\uf33a\uf72f\uf330\uf34f\uf337\uf34e\uf34c\uf34d\uf34e\uf34d\uf33d\uf34c\uf33a\uf34d\uf72f\uf33d\uf72f\uf34e\uf337\uf34e\uf34d\uf33a\uf333\uf33a\uf735\uf72f\uf774\uf73e\uf772", 63239), obj._E000.ExternalCheckNumber, offlineCheckOperationRequest.OfflineNumber));
				return apiResult;
			}
			if (operationData != null)
			{
				ApiResult<CheckOperationResponse> apiResult2 = JsonConvert.DeserializeObject<ApiResult<CheckOperationResponse>>(operationData.Response);
				if (apiResult2.Data == null)
				{
					return apiResult2;
				}
				CheckOperationResponse data = apiResult2.Data;
				ApiResult<CheckOperationResponse> apiResult3 = new ApiResult<CheckOperationResponse>(new CheckOperationResponse
				{
					Cashbox = obj._E001.ToCashboxInfo(),
					DateTime = data.DateTime,
					OfflineMode = true,
					CashboxOfflineMode = true,
					CheckNumber = data.CheckNumber,
					ShiftNumber = data.ShiftNumber,
					CheckOrderNumber = data.CheckOrderNumber,
					EmployeeName = data.EmployeeName,
					StartOfflineMode = data.StartOfflineMode,
					TicketUrl = data.TicketUrl,
					TicketPrintUrl = data.TicketPrintUrl
				});
				apiResult3.AddError(ApiErrorCode.DuplicateExternalCode, string.Format(_E01E._E000("\uf328\uf33a\uf335\uf72f\uf34e\uf72f\uf33d\uf332\uf33a\uf347\uf332\uf337\uf333\uf72f\uf332\uf331\uf333\uf33a\uf34f\uf331\uf333\uf72f\uf774\uf73f\uf772\uf72f\uf34c\uf339\uf33a\uf72f\uf330\uf34f\uf337\uf34e\uf34c\uf34d\uf34e\uf34d\uf33d\uf34c\uf33a\uf34d\uf72f\uf33d\uf72f\uf34e\uf337\uf34e\uf34d\uf33a\uf333\uf33a\uf735\uf72f\uf774\uf73e\uf772", 63239), obj._E000.ExternalCheckNumber, data.CheckNumber));
				return apiResult3;
			}
		}
		if (obj._E000.OperationType == OperationTypeEnum.Buy || obj._E000.OperationType == OperationTypeEnum.ReturnSell)
		{
			double sumInCashbox = cashboxState.SumInCashbox;
			double num = (double)obj._E000.Payments.Where((PaymentTypeInfoApiModel _E0A1) => _E0A1.PaymentType == PaymentTypeEnum.PAYMENT_CASH).Sum((PaymentTypeInfoApiModel _E0A2) => _E0A2.Sum);
			if (sumInCashbox < num)
			{
				return new ApiResult<CheckOperationResponse>(ApiErrorCode.NotEnoughMoney, string.Format(_E01E._E000("\ue72c\ue31e\ue704\ue70e\ue77f\ue77f\ue70b\ue31e\ue703\ue70b\ue70a\ue700\ue77f\ue77c\ue70e\ue77c\ue700\ue779\ue703\ue700\ue31e\ue703\ue70e\ue705\ue706\ue779\ue703\ue700\ue77f\ue77c\ue706\ue31e\ue70a\ue705\ue771\ue31e\ue701\ue77e\ue700\ue70c\ue70b\ue70a\ue70b\ue703\ue706\ue771\ue31e\ue700\ue701\ue70b\ue77e\ue70e\ue778\ue706\ue706\ue31e\ue316\ue72c\ue31e\ue704\ue70e\ue77f\ue77f\ue70b\ue304\ue31e\ue345\ue30e\ue304\ue350\ue343\ue317", 58142), sumInCashbox));
			}
		}
		return new ApiResult<CheckOperationResponse>();
	}

	public override async Task<ApiResult<CheckOperationResponse>> CreateOfflineResponseAsync(CheckOperationRequest request)
	{
		_E004 CS_0024_003C_003E8__locals0 = new _E004();
		CS_0024_003C_003E8__locals0._E000 = request;
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DateTime now = DateTime.Now;
		EntityEntry<CashboxState> entityEntry = base.Db.Entry(cashboxState);
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		await entityEntry.Reference(Expression.Lambda<Func<CashboxState, Cashbox>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).LoadAsync();
		Cashbox cashbox = cashboxState.Cashbox;
		_E018 obj = new _E018(base.Db);
		await obj._E000(cashbox.Id, now);
		DbSet<User> users = base.Db.Users;
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		IQueryable<User> source = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		Task<string> task = source.Select(Expression.Lambda<Func<User, string>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		CS_0024_003C_003E8__locals0._E001 = RoundersFactory.GetRounder(CS_0024_003C_003E8__locals0._E000.RoundType);
		decimal ticketSum = CS_0024_003C_003E8__locals0._E000.Positions.Where((CheckItemApiModel _E0A3) => !_E0A3.IsStorno).Sum((CheckItemApiModel _E0AF) => _E0AF.CalculateSum(CS_0024_003C_003E8__locals0._E001)) + CS_0024_003C_003E8__locals0._E000.TicketModifiers.Sum((ModifierApiModel _E0B0) => CS_0024_003C_003E8__locals0._E001.RoundItem(_E0B0.AffectedSum));
		CheckOperationResponse checkOperationResponse = new CheckOperationResponse
		{
			Cashbox = cashbox.ToCashboxInfo(),
			DateTime = (CS_0024_003C_003E8__locals0._E000.OfflineDate ?? now),
			ShiftNumber = cashboxState.ShiftNumber,
			OfflineMode = true,
			CashboxOfflineMode = true,
			CheckNumber = CS_0024_003C_003E8__locals0._E000.OfflineNumber,
			CheckOrderNumber = cashboxState.DocumentsCount + 1,
			StartOfflineMode = (cashboxState.OfflineModeStart ?? now)
		};
		CheckOperationResponse checkOperationResponse2 = checkOperationResponse;
		checkOperationResponse2.EmployeeName = await task;
		checkOperationResponse.TicketUrl = TicketConstants.GenerateTicketUrl(cashbox.RegistrationNumber, CS_0024_003C_003E8__locals0._E000.OfflineNumber, ticketSum, CS_0024_003C_003E8__locals0._E000.OfflineDate ?? now, cashbox.OfdHost, cashbox.OfdCode);
		checkOperationResponse.TicketPrintUrl = TicketConstants.GenerateTicketUrl(cashbox.UniqueNumber, CS_0024_003C_003E8__locals0._E000.ExternalCheckNumber, cashboxState.ShiftNumber);
		return new ApiResult<CheckOperationResponse>(checkOperationResponse);
	}

	public override async Task SaveToOfflineStoreAsync(CheckOperationRequest request, ApiResult<CheckOperationResponse> response)
	{
		_E006 obj = new _E006();
		obj._E000 = request;
		OfflineCheckOperationRequest value = new OfflineCheckOperationRequest
		{
			Positions = obj._E000.Positions,
			CashboxUniqueNumber = obj._E000.CashboxUniqueNumber,
			Change = obj._E000.Change,
			OperationType = obj._E000.OperationType,
			Payments = obj._E000.Payments,
			Token = obj._E000.Token,
			RoundType = obj._E000.RoundType,
			CustomerEmail = obj._E000.CustomerEmail,
			Discount = obj._E000.Discount,
			ExternalCheckNumber = obj._E000.ExternalCheckNumber,
			LotteryInfo = obj._E000.LotteryInfo,
			Markup = obj._E000.Markup,
			OfflineDate = response.Data.DateTime,
			OfflineNumber = response.Data.CheckNumber,
			CustomerPhone = obj._E000.CustomerPhone,
			CustomerXin = obj._E000.CustomerXin,
			ExtendedModule = obj._E000.ExtendedModule,
			TaxValues = obj._E000.TaxValues,
			TicketModifiers = obj._E000.TicketModifiers,
			CardPaymentDetails = obj._E000.CardPaymentDetails,
			ExternalOrderNumber = obj._E000.ExternalOrderNumber
		};
		string content = JsonConvert.SerializeObject(value);
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		Task<Cashbox> task = cashboxes.Where(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		MainDbContext db = base.Db;
		OfflineRequest offlineRequest = new OfflineRequest
		{
			Type = RequestType.Check,
			Content = content,
			ExternalId = obj._E000.ExternalCheckNumber
		};
		OfflineRequest offlineRequest2 = offlineRequest;
		offlineRequest2.Cashbox = await task;
		await db.AddAsync(offlineRequest);
		await base.Db.SaveChangesAsync();
	}

	public override async Task UpdateLocalStorageAsync(CheckOperationRequest request, ApiResult<CheckOperationResponse> response)
	{
		_E008 CS_0024_003C_003E8__locals0 = new _E008();
		CS_0024_003C_003E8__locals0._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		CS_0024_003C_003E8__locals0._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		CS_0024_003C_003E8__locals0._E001.Address = response.Data.Cashbox.Address;
		if (response.Data.Cashbox.Ofd != null)
		{
			CS_0024_003C_003E8__locals0._E001.OfdName = response.Data.Cashbox.Ofd.Name;
			CS_0024_003C_003E8__locals0._E001.OfdHost = response.Data.Cashbox.Ofd.Host;
			CS_0024_003C_003E8__locals0._E001.OfdCode = response.Data.Cashbox.Ofd.Code;
		}
		CS_0024_003C_003E8__locals0._E001.IdentityNumber = long.Parse(response.Data.Cashbox.IdentityNumber);
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CS_0024_003C_003E8__locals0._E003 = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		_E018 obj = new _E018(base.Db);
		await obj._E000(CS_0024_003C_003E8__locals0._E001.Id, response.Data.DateTime);
		CheckItemApiModel[] source = CS_0024_003C_003E8__locals0._E000.Positions.Where((CheckItemApiModel _E0A4) => !_E0A4.IsStorno).ToArray();
		CS_0024_003C_003E8__locals0._E002 = RoundersFactory.GetRounder(CS_0024_003C_003E8__locals0._E000.RoundType);
		double num = (double)(source.Sum((CheckItemApiModel _E0B1) => _E0B1.CalculateSum(CS_0024_003C_003E8__locals0._E002)) - CS_0024_003C_003E8__locals0._E002.RoundItem(CS_0024_003C_003E8__locals0._E000.Discount) + CS_0024_003C_003E8__locals0._E002.RoundItem(CS_0024_003C_003E8__locals0._E000.Markup));
		CS_0024_003C_003E8__locals0._E003.DocumentsCount++;
		CS_0024_003C_003E8__locals0._E003.OfflineModeStart = response.Data.StartOfflineMode;
		DbSet<OperationSummary> operationSummaries = base.Db.OperationSummaries;
		parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
		CS_0024_003C_003E8__locals0._E004 = await operationSummaries.SingleAsync(Expression.Lambda<Func<OperationSummary, bool>>(Expression.AndAlso(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Convert(Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)))), new ParameterExpression[1] { parameterExpression }));
		double num2 = (CS_0024_003C_003E8__locals0._E000.Change.HasValue ? ((double)CS_0024_003C_003E8__locals0._E000.Change.Value) : ((double)CS_0024_003C_003E8__locals0._E000.Payments.Sum((PaymentTypeInfoApiModel _E0A5) => _E0A5.Sum) - num));
		CS_0024_003C_003E8__locals0._E004.Change += num2;
		CS_0024_003C_003E8__locals0._E004.Sum += num;
		CS_0024_003C_003E8__locals0._E004.Count++;
		CS_0024_003C_003E8__locals0._E004.Taken += num + num2;
		if (CS_0024_003C_003E8__locals0._E004.Type == OperationTypeEnum.Sell || CS_0024_003C_003E8__locals0._E004.Type == OperationTypeEnum.ReturnSell)
		{
			CS_0024_003C_003E8__locals0._E004.Tax += ((num > 0.0) ? ((double)source.Sum((CheckItemApiModel _E0A6) => _E0A6.Tax)) : 0.0);
			if (source.Any((CheckItemApiModel _E0A7) => _E0A7.TaxType == 100) || CS_0024_003C_003E8__locals0._E001.OrganizationIsVatPayer)
			{
				double num3 = 0.12;
				CS_0024_003C_003E8__locals0._E004.Tax -= _E000((double)CS_0024_003C_003E8__locals0._E000.Discount, num3);
				CS_0024_003C_003E8__locals0._E004.Tax += _E000((double)CS_0024_003C_003E8__locals0._E000.Markup, num3);
			}
		}
		CS_0024_003C_003E8__locals0._E004.Discounts += (double)(CS_0024_003C_003E8__locals0._E000.Discount + source.Where((CheckItemApiModel _E0A8) => !_E0A8.DiscountDeleted).Sum((CheckItemApiModel _E0A9) => _E0A9.Discount));
		CS_0024_003C_003E8__locals0._E004.Markups += (double)(CS_0024_003C_003E8__locals0._E000.Markup + source.Where((CheckItemApiModel _E0AA) => !_E0AA.MarkupDeleted).Sum((CheckItemApiModel _E0AB) => _E0AB.Markup));
		CS_0024_003C_003E8__locals0._E005 = CS_0024_003C_003E8__locals0._E000.Payments.Select((PaymentTypeInfoApiModel _E0AC) => _E0AC.PaymentType).ToArray();
		DbSet<PaymentSummary> paymentSummaries = base.Db.PaymentSummaries;
		parameterExpression = Expression.Parameter(typeof(PaymentSummary), _E01E._E000("\uf3cb", 62242));
		PaymentSummary[] source2 = await paymentSummaries.Where(Expression.Lambda<Func<PaymentSummary, bool>>(Expression.AndAlso(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), Expression.Call(null, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/), new Expression[2]
		{
			Expression.Field(Expression.Constant(CS_0024_003C_003E8__locals0, typeof(_E008)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)),
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))
		})), new ParameterExpression[1] { parameterExpression })).ToArrayAsync();
		PaymentTypeInfoApiModel[] payments = CS_0024_003C_003E8__locals0._E000.Payments;
		foreach (PaymentTypeInfoApiModel paymentTypeInfoApiModel in payments)
		{
			PaymentSummary paymentSummary = source2.SingleOrDefault((PaymentSummary _E0B2) => _E0B2.Type == paymentTypeInfoApiModel.PaymentType);
			if (paymentSummary == null)
			{
				paymentSummary = new PaymentSummary
				{
					Type = paymentTypeInfoApiModel.PaymentType
				};
				base.Db.PaymentSummaries.Add(paymentSummary);
			}
			double num4 = (double)paymentTypeInfoApiModel.Sum - ((paymentTypeInfoApiModel.PaymentType == PaymentTypeEnum.PAYMENT_CASH) ? num2 : 0.0);
			paymentSummary.Sum += num4;
		}
		int num5 = 1;
		switch (CS_0024_003C_003E8__locals0._E000.OperationType)
		{
		case OperationTypeEnum.Buy:
		case OperationTypeEnum.ReturnSell:
			num5 = -1;
			break;
		}
		CS_0024_003C_003E8__locals0._E003.SumInCashbox += ((double)CS_0024_003C_003E8__locals0._E000.Payments.Where((PaymentTypeInfoApiModel _E0AD) => _E0AD.PaymentType == PaymentTypeEnum.PAYMENT_CASH).Sum((PaymentTypeInfoApiModel _E0AE) => _E0AE.Sum) - num2) * (double)num5;
		await base.Db.SaveChangesAsync();
		await SaveLastOperationAsync(CS_0024_003C_003E8__locals0._E000, response, CS_0024_003C_003E8__locals0._E001, RequestType.Check, CS_0024_003C_003E8__locals0._E000.ExternalCheckNumber);
	}

	private double _E000(double _E09A, double _E09B)
	{
		if (_E09B > 1.0)
		{
			throw new ArgumentOutOfRangeException(_E01E._E000("\ue683\ue696\ue681\ue690\ue696\ue69d\ue687\ue6a5\ue692\ue69f\ue686\ue696", 59106), _E01E._E000("\ue2c0\ue2ea\ue2ef\ue2e2\ue2e1\ue2e9\ue6f4\ue2e5\ue29f\ue296\ue298\ue6f4\ue2e9\ue2e1\ue6f4\ue2e5\ue2ea\ue2ef\ue298\ue29c\ue2e1\ue6f4\ue6e5", 59092));
		}
		return Math.Round(_E09A * _E09B / (1.0 + _E09B), 2, MidpointRounding.AwayFromZero);
	}

	public override ApiResult ConvertBeforeReply(ApiResult<CheckOperationResponse> response)
	{
		return response;
	}
}
internal class _E01D : BaseReportDescription<XReportRequest>
{
	[CompilerGenerated]
	private sealed class _E000
	{
		public XReportRequest _E000;

		public Cashbox _E001;
	}

	[CompilerGenerated]
	private sealed class _E002
	{
		public XReportRequest _E000;

		public Cashbox _E001;

		public CashboxState _E002;
	}

	[CompilerGenerated]
	private sealed class _E004
	{
		public XReportRequest _E000;
	}

	[CompilerGenerated]
	private sealed class _E006
	{
		public XReportRequest _E000;

		public Cashbox _E001;
	}

	public override string Url => _E01E._E000("\ue282\ue2cc\ue2dd\ue2c4\ue282\ue2d5\ue2df\ue2c8\ue2dd\ue2c2\ue2df\ue2d9", 57900);

	public _E01D(MainDbContext _E0B3)
		: base(_E0B3)
	{
	}

	public override async Task<ApiResult<ZXReportResponse>> ValidateAsync(XReportRequest request)
	{
		_E000 obj = new _E000();
		obj._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		IQueryable<CashboxState> source = cashboxStates.Where(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		_E004<DateTime?, DateTime?> obj2 = await source.Select(Expression.Lambda<Func<CashboxState, _E004<DateTime?, DateTime?>>>(Expression.New((ConstructorInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E004<DateTime?, DateTime?>).TypeHandle), new Expression[2]
		{
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)),
			Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))
		}, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E004<DateTime?, DateTime?>).TypeHandle), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E004<DateTime?, DateTime?>).TypeHandle)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		if (OfflinePeriodMoreThanThreshold(obj2._E003))
		{
			return new ApiResult<ZXReportResponse>(ApiErrorCode.OfflineModeMoreThan72Hours, CommonResource.OfflineModeDurationMore72Hours);
		}
		if (!obj2._E002.HasValue)
		{
			return new ApiResult<ZXReportResponse>(ApiErrorCode.ShiftNotFound, _E01E._E000("\ue300\ue328\ue73d\ue320\ue32d\ue324\ue329\ue328\ue320\ue32d\ue73d\ue323\ue35f\ue327\ue35d\ue356\ue35f\ue32d\ue352\ue73d\ue35c\ue321\ue328\ue320\ue32d", 59157));
		}
		return new ApiResult<ZXReportResponse>();
	}

	public override async Task<ApiResult<ZXReportResponse>> CreateOfflineResponseAsync(XReportRequest request)
	{
		_E002 obj = new _E002();
		obj._E000 = request;
		StateCanBeUpdated = false;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		obj._E002 = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DbSet<OperationSummary> operationSummaries = base.Db.OperationSummaries;
		parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
		IQueryable<OperationSummary> source = operationSummaries.Where(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
		Dictionary<OperationTypeEnum, OperationSummary> dictionary = await source.Include(Expression.Lambda<Func<OperationSummary, ICollection<PaymentSummary>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).ToDictionaryAsync((OperationSummary _E0B4) => _E0B4.Type, (OperationSummary _E0B5) => _E0B5);
		DateTime now = DateTime.Now;
		DbSet<User> users = base.Db.Users;
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		IQueryable<User> source2 = users.Where(Expression.Lambda<Func<User, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E002)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		parameterExpression = Expression.Parameter(typeof(User), _E01E._E000("\uf3cb", 62242));
		Task<int> task = source2.Select(Expression.Lambda<Func<User, int>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression })).SingleAsync();
		ZXReportResponse zXReportResponse = new ZXReportResponse
		{
			CashboxIN = obj._E001.IdentityNumber,
			CashboxRN = obj._E001.RegistrationNumber,
			CashboxSN = obj._E001.UniqueNumber,
			CashboxOfflineMode = true,
			OfflineMode = true,
			ShiftNumber = obj._E002.ShiftNumber,
			SumInCashbox = (decimal)obj._E002.SumInCashbox
		};
		ZXReportResponse zXReportResponse2 = zXReportResponse;
		zXReportResponse2.CashierCode = await task;
		zXReportResponse.CloseOn = obj._E002.ShiftClosedOn;
		zXReportResponse.ControlSum = Math.Abs(obj._E000.ExternalCheckNumber.GetHashCode());
		zXReportResponse.DocumentCount = (obj._E002.ShiftClosedOn.HasValue ? obj._E002.DocumentsCount : (obj._E002.DocumentsCount + 1));
		zXReportResponse.ReportOn = obj._E000.OfflineDate ?? now;
		zXReportResponse.StartOfflineMode = obj._E002.OfflineModeStart ?? now;
		zXReportResponse.StartOn = obj._E002.ShiftOpened.Value;
		zXReportResponse.ExternalReportId = obj._E000.ExternalCheckNumber;
		zXReportResponse.TaxPayerName = obj._E001.OrganizationFullName;
		zXReportResponse.TaxPayerIN = obj._E001.OrganizationXin;
		zXReportResponse.TaxPayerVAT = obj._E001.OrganizationIsVatPayer;
		zXReportResponse.TaxPayerVATNumber = obj._E001.OrganizationVatNumber;
		zXReportResponse.TaxPayerVATSeria = obj._E001.OrganizationVatSeria;
		zXReportResponse.ReportNumber = (obj._E002.ShiftClosedOn.HasValue ? obj._E002.DocumentsCount : (obj._E002.DocumentsCount + 1));
		zXReportResponse.Ofd = new OfdInformation(obj._E001.OfdName, obj._E001.OfdHost, obj._E001.OfdCode);
		ZXReportResponse zXReportResponse3 = zXReportResponse;
		zXReportResponse3.EndNonNullable = new NonNullableApiModel
		{
			Sell = (decimal)(obj._E002.NNStartSell + dictionary[OperationTypeEnum.Sell].Sum),
			Buy = (decimal)(obj._E002.NNStartBuy + dictionary[OperationTypeEnum.Buy].Sum),
			ReturnBuy = (decimal)(obj._E002.NNStartReturnBuy + dictionary[OperationTypeEnum.ReturnBuy].Sum),
			ReturnSell = (decimal)(obj._E002.NNStartReturnSell + dictionary[OperationTypeEnum.ReturnSell].Sum)
		};
		if (obj._E002.ShiftClosedOn.HasValue)
		{
			zXReportResponse3.StartNonNullable = zXReportResponse3.EndNonNullable;
			OperationTypeSummaryApiModel operationTypeSummaryApiModel2 = (zXReportResponse3.ReturnBuy = new OperationTypeSummaryApiModel
			{
				PaymentsByTypesApiModel = new PaymentsByTypeApiModel[0]
			});
			OperationTypeSummaryApiModel operationTypeSummaryApiModel4 = (zXReportResponse3.ReturnSell = operationTypeSummaryApiModel2);
			OperationTypeSummaryApiModel sell = (zXReportResponse3.Buy = operationTypeSummaryApiModel4);
			zXReportResponse3.Sell = sell;
		}
		else
		{
			zXReportResponse3.TakeMoneySum = (decimal)obj._E002.CashWithdrawals;
			zXReportResponse3.PutMoneySum = (decimal)obj._E002.CashDeposits;
			zXReportResponse3.ReturnSell = GenerateOperationSummary(dictionary[OperationTypeEnum.ReturnSell]);
			zXReportResponse3.ReturnBuy = GenerateOperationSummary(dictionary[OperationTypeEnum.ReturnBuy]);
			zXReportResponse3.Buy = GenerateOperationSummary(dictionary[OperationTypeEnum.Buy]);
			zXReportResponse3.Sell = GenerateOperationSummary(dictionary[OperationTypeEnum.Sell]);
			zXReportResponse3.StartNonNullable = new NonNullableApiModel
			{
				Sell = (decimal)obj._E002.NNStartSell,
				Buy = (decimal)obj._E002.NNStartBuy,
				ReturnBuy = (decimal)obj._E002.NNStartReturnBuy,
				ReturnSell = (decimal)obj._E002.NNStartReturnSell
			};
		}
		return new ApiResult<ZXReportResponse>(zXReportResponse3);
	}

	public override async Task SaveToOfflineStoreAsync(XReportRequest request, ApiResult<ZXReportResponse> response)
	{
		_E004 obj = new _E004();
		obj._E000 = request;
		string content = JsonConvert.SerializeObject(new OfflineXzReportRequest
		{
			CashboxUniqueNumber = obj._E000.CashboxUniqueNumber,
			ExternalCheckNumber = obj._E000.ExternalCheckNumber,
			Token = obj._E000.Token,
			OfflineDate = response.Data.ReportOn,
			AsImage = false,
			ReportType = ReportTypeEnum.ReportX
		});
		DbSet<OfflineRequest> offlineRequests = base.Db.OfflineRequests;
		OfflineRequest offlineRequest = new OfflineRequest();
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		offlineRequest.Cashbox = cashboxes.Single(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E004)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		offlineRequest.ExternalId = obj._E000.ExternalCheckNumber;
		offlineRequest.Type = RequestType.XZReport;
		offlineRequest.Content = content;
		await offlineRequests.AddAsync(offlineRequest);
		await base.Db.SaveChangesAsync();
	}

	public override async Task UpdateLocalStorageAsync(XReportRequest request, ApiResult<ZXReportResponse> response)
	{
		_E006 obj = new _E006();
		obj._E000 = request;
		DbSet<Cashbox> cashboxes = base.Db.Cashboxes;
		ParameterExpression parameterExpression = Expression.Parameter(typeof(Cashbox), _E01E._E000("\uf3cb", 62242));
		obj._E001 = await cashboxes.SingleAsync(Expression.Lambda<Func<Cashbox, bool>>(Expression.Equal(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		DbSet<CashboxState> cashboxStates = base.Db.CashboxStates;
		parameterExpression = Expression.Parameter(typeof(CashboxState), _E01E._E000("\uf3cb", 62242));
		CashboxState cashboxState = await cashboxStates.SingleAsync(Expression.Lambda<Func<CashboxState, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E006)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
		cashboxState.DocumentsCount = (int)response.Data.ReportNumber;
		cashboxState.OfflineModeStart = response.Data.StartOfflineMode;
		if (response.Data.Ofd != null)
		{
			obj._E001.OfdName = response.Data.Ofd.Name;
			obj._E001.OfdHost = response.Data.Ofd.Host;
			obj._E001.OfdCode = response.Data.Ofd.Code;
		}
		obj._E001.IdentityNumber = response.Data.CashboxIN;
		obj._E001.OrganizationIsVatPayer = response.Data.TaxPayerVAT;
		obj._E001.OrganizationVatNumber = response.Data.TaxPayerVATNumber;
		obj._E001.OrganizationVatSeria = response.Data.TaxPayerVATSeria;
		UpdateStateFromResponse(cashboxState, response.Data);
		await base.Db.SaveChangesAsync();
		await SaveLastOperationAsync(obj._E000, response, obj._E001, RequestType.XZReport, obj._E000.ExternalCheckNumber);
	}
}
internal sealed class _E01E
{
	private delegate string _E000();

	private sealed class _E001
	{
		private static readonly _E000 m__E001;

		public static readonly _E001 _E004;

		private byte[] _E005;

		static _E001()
		{
			m__E001 = _E01E._E001;
			_E004 = new _E001();
		}

		private _E001()
		{
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(m__E001());
			if (((manifestResourceStream == null) ? (-(~-475893330) + 660039182 - 184145852) : ((-589996347 ^ -589996347) >> 1)) == 0)
			{
				_E005 = new byte[-(~((162187974 << 2) + -323771528)) - 324980353];
				manifestResourceStream.Read(_E005, (0x110E5995 ^ 0x110E5995) << 6, _E005.Length);
			}
		}

		public string _E000(string _E0C6, int _E0C7)
		{
			int num = _E0C6.Length;
			char[] array = _E0C6.ToCharArray();
			while ((num -= (-((~-408402793 >> 3) - -472371602) ^ -41397137) + -491086701) >= -(-(-(-918493264 ^ -604550212) ^ -18618528) + 127272909) + -202747079)
			{
				array[num] = (char)(array[num] ^ (_E005[_E0C7 & (--429101878 - 429101863)] | _E0C7));
			}
			return new string(array);
		}
	}

	public static string _E000(string _E0C2, int _E0C3)
	{
		return _E01E._E001._E004._E000(_E0C2, _E0C3);
	}

	public static string _E001()
	{
		char[] array = "ôôóî".ToCharArray();
		int num = array.Length;
		while (--num >= (-220192751 ^ -220192751))
		{
			array[num] = (char)(array[num] ^ -(~(-(-(~(-780038857)) ^ -610374801)) - 169863044 >> 1));
		}
		return new string(array);
	}
}
