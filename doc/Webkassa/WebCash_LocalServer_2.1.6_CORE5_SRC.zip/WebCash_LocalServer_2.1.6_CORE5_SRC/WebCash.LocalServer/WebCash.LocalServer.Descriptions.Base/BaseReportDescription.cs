using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using WebCash.Constants.Enums;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.DAL.Entities;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Descriptions.Base
{
	public abstract class BaseReportDescription<TReportRequest> : AuthorizedInteractionDescription<TReportRequest, ApiResult<ZXReportResponse>> where TReportRequest : BaseReportRequest
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public CashboxState _E000;
		}

		[CompilerGenerated]
		private sealed class _E001
		{
			public PaymentTypeEnum _E000;

			internal bool _E000(PaymentSummary _E0BD)
			{
				return _E0BD.Type == this._E000;
			}

			internal bool _E001(PaymentsByTypeApiModel _E0BE)
			{
				return _E0BE.Type == this._E000;
			}
		}

		protected bool StateCanBeUpdated;

		public BaseReportDescription(MainDbContext db)
			: base(db)
		{
			StateCanBeUpdated = true;
		}

		public override void PrepareRequestBeforeSend(TReportRequest request)
		{
			request.ExternalCheckNumber = (string.IsNullOrEmpty(request.ExternalCheckNumber) ? Guid.NewGuid().ToString() : request.ExternalCheckNumber);
			request.OfflineDate = request.OfflineDate ?? DateTime.Now;
		}

		public override string GetCashboxUniqueNumber(TReportRequest request)
		{
			return request.CashboxUniqueNumber;
		}

		protected void UpdateStateFromResponse(CashboxState state, ZXReportResponse response)
		{
			_E000 obj = new _E000();
			obj._E000 = state;
			if (StateCanBeUpdated)
			{
				obj._E000.ShiftNumber = response.ShiftNumber;
				obj._E000.NNStartSell = (double)response.StartNonNullable.Sell;
				obj._E000.NNStartBuy = (double)response.StartNonNullable.Buy;
				obj._E000.NNStartReturnBuy = (double)response.StartNonNullable.ReturnBuy;
				obj._E000.NNStartReturnSell = (double)response.StartNonNullable.ReturnSell;
				obj._E000.SumInCashbox = (double)response.SumInCashbox;
				obj._E000.CashDeposits = (double)response.PutMoneySum;
				obj._E000.CashWithdrawals = (double)response.TakeMoneySum;
				obj._E000.ShiftOpened = response.StartOn;
				DbSet<OperationSummary> operationSummaries = base.Db.OperationSummaries;
				ParameterExpression parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				IQueryable<OperationSummary> source = operationSummaries.Where(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Property(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), Expression.Property(Expression.Field(Expression.Constant(obj, typeof(_E000)), FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/, typeof(_E000).TypeHandle)), (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/))), new ParameterExpression[1] { parameterExpression }));
				parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				IIncludableQueryable<OperationSummary, ICollection<PaymentSummary>> source2 = source.Include(Expression.Lambda<Func<OperationSummary, ICollection<PaymentSummary>>>(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), new ParameterExpression[1] { parameterExpression }));
				parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				UpdateOperations(source2.Single(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(2, typeof(int))), new ParameterExpression[1] { parameterExpression })), response.Sell);
				parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				UpdateOperations(source2.Single(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(0, typeof(int))), new ParameterExpression[1] { parameterExpression })), response.Buy);
				parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				UpdateOperations(source2.Single(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(1, typeof(int))), new ParameterExpression[1] { parameterExpression })), response.ReturnBuy);
				parameterExpression = Expression.Parameter(typeof(OperationSummary), _E01E._E000("\uf3cb", 62242));
				UpdateOperations(source2.Single(Expression.Lambda<Func<OperationSummary, bool>>(Expression.Equal(Expression.Convert(Expression.Property(parameterExpression, (MethodInfo)MethodBase.GetMethodFromHandle((RuntimeMethodHandle)/*OpCode not supported: LdMemberToken*/)), typeof(int)), Expression.Constant(3, typeof(int))), new ParameterExpression[1] { parameterExpression })), response.ReturnSell);
			}
		}

		protected void UpdateOperations(OperationSummary localData, OperationTypeSummaryApiModel remoteData)
		{
			if (remoteData == null)
			{
				remoteData = new OperationTypeSummaryApiModel();
			}
			localData.Change = (double)remoteData.Change;
			localData.Count = remoteData.Count;
			localData.Discounts = (double)remoteData.Discount;
			localData.Markups = (double)remoteData.Markup;
			localData.Sum = (double)remoteData.Amount();
			localData.Taken = (double)remoteData.Taken;
			localData.Tax = (double)remoteData.VAT;
			foreach (PaymentTypeEnum paymentTypeEnum in Enum.GetValues(typeof(PaymentTypeEnum)))
			{
				PaymentSummary paymentSummary = localData.PaymentsSummary.SingleOrDefault((PaymentSummary _E0BD) => _E0BD.Type == paymentTypeEnum);
				if (paymentSummary == null)
				{
					paymentSummary = new PaymentSummary
					{
						Type = paymentTypeEnum
					};
					localData.PaymentsSummary.Add(paymentSummary);
				}
				PaymentsByTypeApiModel paymentsByTypeApiModel = remoteData.PaymentsByTypesApiModel.SingleOrDefault((PaymentsByTypeApiModel _E0BE) => _E0BE.Type == paymentTypeEnum);
				paymentSummary.Sum = ((paymentsByTypeApiModel == null) ? 0.0 : ((double)paymentsByTypeApiModel.Sum));
			}
		}

		protected OperationTypeSummaryApiModel GenerateOperationSummary(OperationSummary summary)
		{
			if (summary.Count == 0)
			{
				OperationTypeSummaryApiModel operationTypeSummaryApiModel = new OperationTypeSummaryApiModel();
				operationTypeSummaryApiModel.PaymentsByTypesApiModel = new PaymentsByTypeApiModel[0];
				return operationTypeSummaryApiModel;
			}
			return new OperationTypeSummaryApiModel
			{
				Change = (decimal)summary.Change,
				Count = summary.Count,
				Taken = (decimal)summary.Taken,
				VAT = (decimal)summary.Tax,
				Markup = (decimal)summary.Markups,
				Discount = (decimal)summary.Discounts,
				PaymentsByTypesApiModel = (from _E0BB in summary.PaymentsSummary
					where _E0BB.Sum > 0.0
					select _E0BB into _E0BC
					select new PaymentsByTypeApiModel
					{
						Type = _E0BC.Type,
						Sum = (decimal)_E0BC.Sum
					}).ToArray()
			};
		}

		public override ApiResult ConvertBeforeReply(ApiResult<ZXReportResponse> response)
		{
			return response;
		}
	}
}
