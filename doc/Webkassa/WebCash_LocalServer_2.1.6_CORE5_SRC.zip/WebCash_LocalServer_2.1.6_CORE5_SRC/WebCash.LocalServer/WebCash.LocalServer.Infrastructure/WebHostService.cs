using System.Reflection;
using System.Runtime.CompilerServices;
using DasMulli.Win32.ServiceUtils;
using Microsoft.Extensions.Hosting;
using WebCash.LocalServer.Extensions;

namespace WebCash.LocalServer.Infrastructure
{
	public class WebHostService : IWin32Service
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public WebHostService _E000;

			public ServiceStoppedCallback _E001;

			internal void _E000()
			{
				if (!this._E000._E001)
				{
					_E001();
				}
			}
		}

		private readonly IHost m__E000;

		private bool _E001;

		[CompilerGenerated]
		private readonly string _E002;

		public string ServiceName
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
		}

		public WebHostService(IHost host, string serviceName = null)
		{
			if (serviceName == null)
			{
				serviceName = Assembly.GetEntryAssembly().GetName().Name;
			}
			_E002 = serviceName;
			this.m__E000 = host;
		}

		public void Start(string[] startupArguments, ServiceStoppedCallback serviceStoppedCallback)
		{
			this.m__E000.Services.GetApplicationLifetimeService().ApplicationStopped.Register(delegate
			{
				if (!_E001)
				{
					serviceStoppedCallback();
				}
			});
			this.m__E000.Start();
		}

		public void Stop()
		{
			_E001 = true;
			this.m__E000.Dispose();
		}
	}
}
