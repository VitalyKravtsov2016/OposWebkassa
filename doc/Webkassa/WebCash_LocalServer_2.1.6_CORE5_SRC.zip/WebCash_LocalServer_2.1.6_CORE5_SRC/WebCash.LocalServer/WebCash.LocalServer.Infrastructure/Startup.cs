using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerGen;
using Swashbuckle.AspNetCore.SwaggerUI;
using WebCash.LocalServer.Abstractions;
using WebCash.LocalServer.DAL;
using WebCash.LocalServer.Descriptions;
using WebCash.LocalServer.Extensions;
using WebCash.LocalServer.Middleware;
using WebCash.ServiceContracts;
using WebCash.ServiceContracts.Request;
using WebCash.ServiceContracts.Response;

namespace WebCash.LocalServer.Infrastructure
{
	public class Startup
	{
		[CompilerGenerated]
		private readonly IConfiguration m__E000;

		[CompilerGenerated]
		private IHostEnvironment m__E001;

		public IConfiguration Configuration
		{
			[CompilerGenerated]
			get
			{
				return this.m__E000;
			}
		}

		protected IHostEnvironment Hosting
		{
			[CompilerGenerated]
			get
			{
				return this.m__E001;
			}
			[CompilerGenerated]
			private set
			{
				this.m__E001 = value;
			}
		}

		public Startup(IConfiguration configuration, IHostEnvironment hosting)
		{
			this.m__E000 = configuration;
			Hosting = hosting;
		}

		public void ConfigureServices(IServiceCollection services)
		{
			services.ConfigureLookingAtNET().AddDataAnnotations().AddDataAnnotationsLocalization()
				.AddApiExplorer();
			services.AddSwaggerGen(delegate(SwaggerGenOptions _E085)
			{
				_E085.SchemaFilter<_E00D>(Array.Empty<object>());
				_E085.MapType<DateTime>(() => new OpenApiSchema
				{
					Example = new OpenApiString(DateTime.Now.ToString(_E01E._E000("\ue69b\ue69b\ue6d1\ue6b2\ue6b2\ue6d1\ue686\ue686\ue686\ue686\ue6df\ue6b7\ue6b7\ue6c5\ue692\ue692\ue6c5\ue68c\ue68c", 59033)))
				});
				_E085.MapType<DateTime?>(() => new OpenApiSchema
				{
					Example = new OpenApiString(DateTime.Now.ToString(_E01E._E000("\ue69b\ue69b\ue6d1\ue6b2\ue6b2\ue6d1\ue686\ue686\ue686\ue686\ue6df\ue6b7\ue6b7\ue6c5\ue692\ue692\ue6c5\ue68c\ue68c", 59033)))
				});
				_E085.SwaggerDoc(_E01E._E000("\ue7a9\ue7ee", 59215), new OpenApiInfo
				{
					Title = _E01E._E000("\uea4a\uea78\uea7f\uea76\uea7c\uea6e\uea6e\uea7c\uea3d\uea71\uea72\uea7e\uea7c\uea71\uea3d\uea6e\uea78\uea6f\uea6b\uea78\uea6f\uea3d\uea5c\uea4d\uea54", 59925),
					Version = _E01E._E000("\ue7a9\ue7ee", 59215),
					Description = _E01E._E000("\ue7e0\ue7c5\ue7c1\ue7cb\ue7c0\ue7b7\ue7c6\ue7b0\ue7c2\ue3db\ue7c7\ue7c5\ue7cf\ue7b8\ue7c0\ue7b7\ue3db\ue7bf\ue7c3\ue7ba\ue7c1\ue7cb\ue7c0\ue7c3\ue7cc\ue7cb\ue7bd\ue7c3\ue7c3\ue3db\ue7cf\ue7c0\ue7b4\ue3db\ue3ac\ue39e\ue399\ue390\ue39a\ue388\ue388\ue39a", 58291),
					Contact = new OpenApiContact
					{
						Url = new Uri(_E01E._E000("\uf083\uf09f\uf09f\uf09b\uf098\uf0d1\uf0c4\uf0c4\uf09c\uf08e\uf089\uf080\uf08a\uf098\uf098\uf08a\uf0c5\uf080\uf091", 61571))
					}
				});
				_E085.CustomSchemaIds((Type _E086) => _E086.FullName);
			});
			services.AddOptions();
			services.Configure<AppConfig>(Configuration.GetSection(_E01E._E000("\uedba\ued8b\ued8b", 60755)));
			services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
			services.AddTransient<_E014>();
			services.AddTransient<_E012>();
			services.AddTransient<_E015, _E010>();
			services.AddScoped<IMediator, _E016>();
			services.AddScoped((IServiceProvider _E087) => Provider.GetContext());
			services.AddSingleton((Func<IServiceProvider, _E00E>)((IServiceProvider _E088) => new _E00C(_E01E._E000("\ue7c9\ue79b\ue79d\ue7cc\ue7cb\ue7ce\ue79e\ue7ce\ue7cc\ue79a\ue79c\ue79c\ue7c8\ue7cb\ue7cf\ue7cc\ue79b\ue7c6\ue7cd\ue79a\ue7ca\ue7c6\ue79d\ue79a", 59305))));
			services.AddSingleton(Configuration);
			services.AddSingleton<_E00F>();
			services.AddSingleton((Func<IServiceProvider, IHostedService>)((IServiceProvider _E089) => _E089.GetRequiredService<_E00F>()));
			services.AddSingleton<_E00B, _E008>();
			services.AddSingleton<_E00B, _E009>();
			services.AddScoped<IServerInteractionDescription<CheckOperationRequest, ApiResult<CheckOperationResponse>>, _E01C>();
			services.AddScoped<IServerInteractionDescription<MoneyOperationRequest, ApiResult<MoneyOperationResponse>>, _E01B>();
			services.AddScoped<IServerInteractionDescription<XReportRequest, ApiResult<ZXReportResponse>>, _E01D>();
			services.AddScoped<IServerInteractionDescription<ZReportRequest, ApiResult<ZXReportResponse>>, ZReportDescription>();
			services.AddScoped<IServerInteractionDescription<AuthCredentialsRequest, ApiResult<TokenWithEmployeeInfoResponse>>, _E01A>();
			services.AddSingleton(delegate(IServiceProvider _E08A)
			{
				IOptions<AppConfig> service2 = _E08A.GetService<IOptions<AppConfig>>();
				_E015 requiredService2 = _E08A.GetRequiredService<_E015>();
				MainDbContext context2 = Provider.GetContext();
				_E012 obj = new _E012(requiredService2, context2, service2);
				return new global::_E006(service2.Value.AutoCloseShiftTime.Value, new _E016(requiredService2, context2, obj, service2));
			});
			services.AddTransient(delegate(IServiceProvider _E08B)
			{
				IOptions<AppConfig> service = _E08B.GetService<IOptions<AppConfig>>();
				_E015 requiredService = _E08B.GetRequiredService<_E015>();
				MainDbContext context = Provider.GetContext();
				return new _E012(requiredService, context, service);
			});
			services.AddHttpClient<_E014>(delegate(IServiceProvider _E08C, HttpClient _E08D)
			{
				AppConfig value2 = _E08C.GetService<IOptions<AppConfig>>().Value;
				_E08D.Timeout = TimeSpan.FromSeconds(15.0);
				_E08D.BaseAddress = new Uri(value2.Host);
			}).ConfigurePrimaryHttpMessageHandler(delegate(IServiceProvider _E08E)
			{
				AppConfig value = _E08E.GetService<IOptions<AppConfig>>().Value;
				HttpClientHandler httpClientHandler = new HttpClientHandler
				{
					AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate)
				};
				if (value.DisableSystemProxy)
				{
					httpClientHandler.Proxy = null;
					httpClientHandler.UseProxy = false;
				}
				return httpClientHandler;
			});
			services._E000(Configuration);
		}

		public void Configure(IApplicationBuilder app)
		{
			app._E001();
			if (Hosting.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
				app.UseSwagger();
				app.UseSwaggerUI(delegate(SwaggerUIOptions _E08F)
				{
					_E08F.SwaggerEndpoint(_E01E._E000("\ue6d1\ue68d\ue689\ue69f\ue699\ue699\ue69b\ue68c\ue6d1\ue688\ue6cf\ue6d1\ue68d\ue689\ue69f\ue699\ue699\ue69b\ue68c\ue6d0\ue694\ue68d\ue691\ue690", 59102), _E01E._E000("\uea4a\uea78\uea7f\uea76\uea7c\uea6e\uea6e\uea7c\uea3d\uea71\uea72\uea7e\uea7c\uea71\uea3d\uea6e\uea78\uea6f\uea6b\uea78\uea6f\uea3d\uea5c\uea4d\uea54", 59925));
				});
			}
			IOptions<AppConfig> service = app.ApplicationServices.GetService<IOptions<AppConfig>>();
			app.UseMiddleware<RequestIdLoggingMiddleware>(Array.Empty<object>()).UseMvc().UseStatusCodePages(new StatusCodePagesOptions
			{
				HandleAsync = _E000
			});
			if (service.Value.AutoCloseShiftTime.HasValue)
			{
				Log.Information(string.Format(_E01E._E000("\ue73e\ue70a\ue70b\ue710\ue71c\ue713\ue710\ue70c\ue71a\ue75f\ue70c\ue717\ue716\ue719\ue70b\ue75f\ue71a\ue711\ue71e\ue71d\ue713\ue71a\ue71b\ue745\ue75f\ue704\ue74f\ue702", 59161), service.Value.AutoCloseShiftTime.Value));
				app.ApplicationServices.GetService<_E00F>()._E000(app.ApplicationServices.GetRequiredService<global::_E006>());
			}
			else
			{
				Log.Information(_E01E._E000("\ue6be\ue68a\ue68b\ue690\ue69c\ue693\ue690\ue68c\ue69a\ue6df\ue68c\ue697\ue696\ue699\ue68b\ue6df\ue69b\ue696\ue68c\ue69e\ue69d\ue693\ue69a\ue69b", 58927));
			}
		}

		private async Task _E000(StatusCodeContext _E083)
		{
			if (_E083.HttpContext.Response.StatusCode == 404)
			{
				if (_E083.HttpContext.Request.Method != HttpMethod.Post.Method)
				{
					await _E083.Next(_E083.HttpContext);
					return;
				}
				HttpRequestMessage httpRequestMessage = _E001(_E083.HttpContext.Request);
				_E015 service = _E083.HttpContext.RequestServices.GetService<_E015>();
				try
				{
					HttpResponseMessage httpResponseMessage = await service._E008(httpRequestMessage);
					string text = await httpResponseMessage.Content.ReadAsStringAsync();
					foreach (KeyValuePair<string, IEnumerable<string>> header in httpResponseMessage.Headers)
					{
						if (!(header.Key == _E01E._E000("\uf787\uf7a1\uf7b2\uf7bd\uf7a0\uf7b5\uf7b6\uf7a1\uf7fe\uf796\uf7bd\uf7b0\uf7bc\uf7b7\uf7ba\uf7bd\uf7b4", 63426)))
						{
							_E083.HttpContext.Response.Headers[header.Key] = new StringValues(header.Value.ToArray());
						}
					}
					_E083.HttpContext.Response.ContentType = httpResponseMessage.Content.Headers.ContentType.ToString();
					_E083.HttpContext.Response.ContentLength = httpResponseMessage.Content.Headers.ContentLength;
					_E083.HttpContext.Response.StatusCode = (int)httpResponseMessage.StatusCode;
					await _E083.HttpContext.Response.WriteAsync(text);
					return;
				}
				catch (TaskCanceledException exception)
				{
					_E083.HttpContext.Response.StatusCode = 408;
					Log.Warning(exception, _E01E._E000("\uecbf\uec92\uec89\uec9e\uec98\uec8f\uecdb\uec94\uec95\uec97\uec92\uec95\uec9e\uecdb\uec89\uec9e\uec8a\uec8e\uec9e\uec88\uec8f\uecdb\uec8f\uec92\uec96\uec9e\uec94\uec8e\uec8f\uec9e\uec9f", 60635));
				}
				catch (Exception exception2)
				{
					_E083.HttpContext.Abort();
					Log.Error(exception2, _E01E._E000("\ue12e\ue103\ue118\ue10f\ue109\ue11e\ue14a\ue105\ue104\ue106\ue103\ue104\ue10f\ue14a\ue118\ue10f\ue11b\ue11f\ue10f\ue119\ue11e\ue14a\ue10f\ue118\ue118\ue105\ue118", 57600));
				}
			}
			await _E083.Next(_E083.HttpContext);
		}

		private HttpRequestMessage _E001(HttpRequest _E084)
		{
			HttpRequestMessage httpRequestMessage = new HttpRequestMessage(new HttpMethod(_E084.Method), _E084.Path)
			{
				Content = new StreamContent(_E084.Body)
			};
			httpRequestMessage.Content.Headers.ContentLength = _E084.ContentLength;
			MediaTypeHeaderValue mediaTypeHeaderValue = MediaTypeHeaderValue.Parse(_E084.ContentType);
			string mediaType = mediaTypeHeaderValue.MediaType;
			string charSet = mediaTypeHeaderValue.CharSet;
			httpRequestMessage.Content.Headers.ContentType = new MediaTypeHeaderValue(mediaType)
			{
				CharSet = charSet
			};
			KeyValuePair<string, StringValues>[] array = _E084.Headers.Where<KeyValuePair<string, StringValues>>((KeyValuePair<string, StringValues> _E090) => _E090.Key != _E01E._E000("\uefb1\uef96\uef8a\uef8d", 61368)).ToArray();
			KeyValuePair<string, StringValues>[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				KeyValuePair<string, StringValues> keyValuePair = array2[i];
				string[] array3 = keyValuePair.Value.ToArray();
				if (httpRequestMessage.Headers.TryGetValues(keyValuePair.Key, out IEnumerable<string> values))
				{
					array3 = array3.Except(values).ToArray();
				}
				if (array3.Length != 0)
				{
					httpRequestMessage.Headers.TryAddWithoutValidation(keyValuePair.Key, array3);
				}
			}
			return httpRequestMessage;
		}
	}
}
