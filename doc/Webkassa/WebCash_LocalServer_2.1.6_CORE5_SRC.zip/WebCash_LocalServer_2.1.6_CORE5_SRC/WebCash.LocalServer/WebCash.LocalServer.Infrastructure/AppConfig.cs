using System;
using System.Runtime.CompilerServices;

namespace WebCash.LocalServer.Infrastructure
{
	public class AppConfig
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private int _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private TimeSpan? _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private bool _E005;

		[CompilerGenerated]
		private int _E006;

		[CompilerGenerated]
		private int _E007;

		[CompilerGenerated]
		private int _E008;

		[CompilerGenerated]
		private bool _E009;

		public string Host
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public int Port
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string AppId
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public TimeSpan? AutoCloseShiftTime
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public string DbFolder
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public bool DisableSystemProxy
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public int FiscalizationRequestTimeout
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public int OfflineOperationsRequestTimeout
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public int DefaultRequestTimeout
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public bool LocalNetwork
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}
	}
}
