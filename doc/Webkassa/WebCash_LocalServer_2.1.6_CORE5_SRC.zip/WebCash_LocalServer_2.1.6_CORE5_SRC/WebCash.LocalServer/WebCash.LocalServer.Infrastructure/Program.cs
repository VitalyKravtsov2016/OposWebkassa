using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using DasMulli.Win32.ServiceUtils;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;
using WebCash.LocalServer.DAL;

namespace WebCash.LocalServer.Infrastructure
{
	public class Program
	{
		private const string m__E000 = "--run-as-service";

		private const string m__E001 = "--working-directory";

		private const string m__E002 = "--register-service";

		private const string m__E003 = "--preserve-working-directory";

		private const string _E004 = "--unregister-service";

		private const string _E005 = "WebkassaLocalServer";

		private const string _E006 = "Webkassa LocalServer";

		private const string _E007 = "Локальный модуль Webkassa.LocalServer";

		public static HostFacade BuildWebHost(string[] args)
		{
			return new HostFacade(Host.CreateDefaultBuilder(args).ConfigureWebHostDefaults(delegate(IWebHostBuilder _E07C)
			{
				_E07C.ConfigureAppConfiguration(delegate
				{
				}).ConfigureWebHost();
			}).Build());
		}

		public static int Main(string[] args)
		{
			try
			{
				AppDomain.CurrentDomain.UnhandledException += delegate(object _E07F, UnhandledExceptionEventArgs _E080)
				{
					Log.Fatal(_E01E._E000("\uedaa\ued91\ued97\ued9e\ued91\ued9b\ued93\ued9a\ued9b\ueddf\ued9a\ued87\ued9c\ued9a\ued8f\ued8b\ued96\ued90\ued91\uedc5\ueddf\ued84\uedcf\ued82", 60783), _E080.ExceptionObject);
				};
				if (args.Contains(_E01E._E000("\uf8d0\uf8d0\uf88f\uf888\uf893\uf8d0\uf89c\uf88e\uf8d0\uf88e\uf898\uf88f\uf88b\uf894\uf89e\uf898", 63733)))
				{
					args = args.Where((string _E081) => _E081 != _E01E._E000("\uf8d0\uf8d0\uf88f\uf888\uf893\uf8d0\uf89c\uf88e\uf8d0\uf88e\uf898\uf88f\uf88b\uf894\uf89e\uf898", 63733)).ToArray();
					Directory.SetCurrentDirectory(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location));
					HostFacade hostFacade = BuildWebHost(args);
					_E003(hostFacade);
					hostFacade.RunAsService();
				}
				else if (args.Contains(_E01E._E000("\ue993\ue993\ue9cc\ue9db\ue9d9\ue9d7\ue9cd\ue9ca\ue9db\ue9cc\ue993\ue9cd\ue9db\ue9cc\ue9c8\ue9d7\ue9dd\ue9db", 59802)))
				{
					_E000();
				}
				else if (args.Contains(_E01E._E000("\ue9d3\ue9d3\ue98b\ue990\ue98c\ue99b\ue999\ue997\ue98d\ue98a\ue99b\ue98c\ue9d3\ue98d\ue99b\ue98c\ue988\ue997\ue99d\ue99b", 59770)))
				{
					_E001();
				}
				else
				{
					HostFacade hostFacade2 = BuildWebHost(args);
					_E003(hostFacade2);
					hostFacade2.Run();
				}
				return 0;
			}
			catch (Exception ex)
			{
				Log.Fatal(ex, _E01E._E000("\ueeac\uee9a\uee8d\uee89\uee96\uee9c\uee9a\ueedf\uee8c\uee8b\uee90\uee8f\uee8f\uee9a\uee9b", 60989));
				return ex.HResult;
			}
			finally
			{
				Log.CloseAndFlush();
			}
		}

		private static void _E000()
		{
			string[] commandLineArgs = Environment.GetCommandLineArgs();
			IEnumerable<string> enumerable = commandLineArgs.Where((string _E082) => _E082 != _E01E._E000("\ue993\ue993\ue9cc\ue9db\ue9d9\ue9d7\ue9cd\ue9ca\ue9db\ue9cc\ue993\ue9cd\ue9db\ue9cc\ue9c8\ue9d7\ue9dd\ue9db", 59802) && _E082 != _E01E._E000("\uf054\uf054\uf009\uf00b\uf01c\uf00a\uf01c\uf00b\uf00f\uf01c\uf054\uf00e\uf016\uf00b\uf012\uf010\uf017\uf01e\uf054\uf01d\uf010\uf00b\uf01c\uf01a\uf00d\uf016\uf00b\uf000", 61496)).Select(_E002).Append(_E01E._E000("\uf8d0\uf8d0\uf88f\uf888\uf893\uf8d0\uf89c\uf88e\uf8d0\uf88e\uf898\uf88f\uf88b\uf894\uf89e\uf898", 63733));
			string fileName = Process.GetCurrentProcess().MainModule.FileName;
			if (!fileName.EndsWith(_E01E._E000("\ue49d\ue496\ue48d\ue497\ue49c\ue48d\ue4d7\ue49c\ue481\ue49c", 58616), StringComparison.OrdinalIgnoreCase))
			{
				enumerable = enumerable.Skip(1);
			}
			if (commandLineArgs.Contains(_E01E._E000("\uf054\uf054\uf009\uf00b\uf01c\uf00a\uf01c\uf00b\uf00f\uf01c\uf054\uf00e\uf016\uf00b\uf012\uf010\uf017\uf01e\uf054\uf01d\uf010\uf00b\uf01c\uf01a\uf00d\uf016\uf00b\uf000", 61496)))
			{
				enumerable = enumerable.Append(_E01E._E000("\ue654\ue654\ue60e\ue616\ue60b\ue612\ue610\ue617\ue61e\ue654\ue61d\ue610\ue60b\ue61c\ue61a\ue60d\ue616\ue60b\ue600", 58904)).Append(_E002(Directory.GetCurrentDirectory()));
			}
			string binaryPath = fileName + _E01E._E000("\uf6ff", 63071) + string.Join(_E01E._E000("\uf6ff", 63071), enumerable);
			ServiceDefinition serviceDefinition = new ServiceDefinitionBuilder(_E01E._E000("\uf798\uf7aa\uf7ad\uf7a4\uf7ae\uf7bc\uf7bc\uf7ae\uf783\uf7a0\uf7ac\uf7ae\uf7a3\uf79c\uf7aa\uf7bd\uf7b9\uf7aa\uf7bd", 63245)).WithDisplayName(_E01E._E000("\uece0\uecd2\uecd5\uecdc\uecd6\uecc4\uecc4\uecd6\uec97\uecfb\uecd8\uecd4\uecd6\uecdb\uece4\uecd2\uecc5\uecc1\uecd2\uecc5", 60422)).WithDescription(_E01E._E000("\uea61\uea44\uea40\uea4a\uea41\uea36\uea47\uea31\uea43\uee5a\uea46\uea44\uea4e\uea39\uea41\uea36\uee5a\uee2d\uee1f\uee18\uee11\uee1b\uee09\uee09\uee1b\uee54\uee36\uee15\uee19\uee1b\uee16\uee29\uee1f\uee08\uee0c\uee1f\uee08", 60976)).WithBinaryPath(binaryPath)
				.WithCredentials(Win32ServiceCredentials.LocalSystem)
				.WithAutoStart(autoStart: true)
				.Build();
			new Win32ServiceManager().CreateOrUpdateService(serviceDefinition, startImmediately: true);
			Console.WriteLine(_E01E._E000("\uf428\uf40e\uf418\uf418\uf41e\uf408\uf408\uf41d\uf40e\uf417\uf417\uf402\uf45b\uf409\uf41e\uf41c\uf412\uf408\uf40f\uf41e\uf409\uf41e\uf41f\uf45b\uf41a\uf415\uf41f\uf45b\uf408\uf40f\uf41a\uf409\uf40f\uf41e\uf41f\uf45b\uf408\uf41e\uf409\uf40d\uf412\uf418\uf41e\uf45b\uf459\uf42c\uf41e\uf419\uf410\uf41a\uf408\uf408\uf41a\uf45b\uf437\uf414\uf418\uf41a\uf417\uf428\uf41e\uf409\uf40d\uf41e\uf409\uf459\uf45b\uf453\uf459\uf060\uf045\uf041\uf04b\uf040\uf037\uf046\uf030\uf042\uf45b\uf047\uf045\uf04f\uf038\uf040\uf037\uf45b\uf42c\uf41e\uf419\uf410\uf41a\uf408\uf408\uf41a\uf455\uf437\uf414\uf418\uf41a\uf417\uf428\uf41e\uf409\uf40d\uf41e\uf409\uf459\uf452", 62555));
		}

		private static void _E001()
		{
			new Win32ServiceManager().DeleteService(_E01E._E000("\uf798\uf7aa\uf7ad\uf7a4\uf7ae\uf7bc\uf7bc\uf7ae\uf783\uf7a0\uf7ac\uf7ae\uf7a3\uf79c\uf7aa\uf7bd\uf7b9\uf7aa\uf7bd", 63245));
			Console.WriteLine(_E01E._E000("\ue1ac\ue18a\ue19c\ue19c\ue19a\ue18c\ue18c\ue199\ue18a\ue193\ue193\ue186\ue1df\ue18a\ue191\ue18d\ue19a\ue198\ue196\ue18c\ue18b\ue19a\ue18d\ue19a\ue19b\ue1df\ue18c\ue19a\ue18d\ue189\ue196\ue19c\ue19a\ue1df\ue1dd\ue1a8\ue19a\ue19d\ue194\ue19e\ue18c\ue18c\ue19e\ue1df\ue1b3\ue190\ue19c\ue19e\ue193\ue1ac\ue19a\ue18d\ue189\ue19a\ue18d\ue1dd\ue1df\ue1d7\ue1dd\ue5e4\ue5c1\ue5c5\ue5cf\ue5c4\ue5b3\ue5c2\ue5b4\ue5c6\ue1df\ue5c3\ue5c1\ue5cb\ue5bc\ue5c4\ue5b3\ue1df\ue1a8\ue19a\ue19d\ue194\ue19e\ue18c\ue18c\ue19e\ue1d1\ue1b3\ue190\ue19c\ue19e\ue193\ue1ac\ue19a\ue18d\ue189\ue19a\ue18d\ue1dd\ue1d6", 57833));
		}

		private static string _E002(string _E07A)
		{
			_E07A = Regex.Replace(_E07A, _E01E._E000("\ue7d9\ue7ad\ue7ad\ue7db\ue7d8\ue7d3", 59377), _E01E._E000("\uea5e\uea4b\uea5e\uea4b\uea26\uea58", 59952));
			_E07A = _E01E._E000("\uef96", 61236) + Regex.Replace(_E07A, _E01E._E000("\uf3f7\uf383\uf383\uf3f4\uf3f6\uf3fb", 62287), _E01E._E000("\uec89\uec9c\uec89\uec9c", 60460)) + _E01E._E000("\uef96", 61236);
			return _E07A;
		}

		private static void _E003(HostFacade _E07B)
		{
			using IServiceScope serviceScope = _E07B.Services.CreateScope();
			IServiceProvider serviceProvider = serviceScope.ServiceProvider;
			IOptions<AppConfig> requiredService = serviceProvider.GetRequiredService<IOptions<AppConfig>>();
			IWebHostEnvironment hostingEnvironment = serviceProvider.GetHostingEnvironment();
			string password = _E01E._E000("\ue84f\ue81d\ue81b\ue84a\ue84d\ue848\ue818\ue848\ue84a\ue81c\ue81a\ue81a\ue84e\ue84d\ue849\ue84a\ue81d\ue840\ue84b\ue81c\ue84c\ue840\ue81b\ue81c\ue81b\ue849\ue84c\ue84a\ue81c\ue818\ue84a\ue81b", 59496);
			Provider.Setup(password, string.IsNullOrEmpty(requiredService.Value.DbFolder) ? hostingEnvironment.ContentRootPath : requiredService.Value.DbFolder);
			using MainDbContext mainDbContext = serviceProvider.GetRequiredService<MainDbContext>();
			mainDbContext.Database.Migrate();
		}
	}
}
