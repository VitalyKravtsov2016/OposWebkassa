using System;
using System.Net;
using System.Reflection;
using DasMulli.Win32.ServiceUtils;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Serilog;

namespace WebCash.LocalServer.Infrastructure
{
	public static class WebHostExtensions
	{
		public static void RunAsService(this IHost host, string serviceName = null)
		{
			new Win32ServiceHost(new WebHostService(host, serviceName)).Run();
		}

		public static IWebHostEnvironment GetHostingEnvironment(this IServiceProvider services)
		{
			return services.GetRequiredService<IWebHostEnvironment>();
		}

		public static IWebHostBuilder ConfigureWebHost(this IWebHostBuilder webBuilder)
		{
			return webBuilder.UseStartup<Startup>().UseContentRoot(AppContext.BaseDirectory).UseSerilog(_E000)
				.UseKestrel(delegate(KestrelServerOptions _E070)
				{
					Version version = Assembly.GetExecutingAssembly().GetName().Version;
					IOptions<AppConfig> service = _E070.ApplicationServices.GetService<IOptions<AppConfig>>();
					IPAddress iPAddress = ((_E070.ApplicationServices.GetHostingEnvironment().IsDevelopment() || service.Value.LocalNetwork) ? IPAddress.Any : IPAddress.Loopback);
					_E070.Listen(iPAddress, service.Value.Port);
					Log.Information(_E01E._E000("\ue92e\ue91c\ue91b\ue912\ue918\ue90a\ue90a\ue918\ue959\ue911\ue916\ue90a\ue90d\ue943\ue959\ue902\ue911\ue916\ue90a\ue90d\ue904", 59752), service.Value.Host);
					Log.Information(string.Format(_E01E._E000("\ued26\ued03\ued19\ued1e\ued0f\ued04\ued03\ued04\ued0d\ued4a\ued03\ued04\ued09\ued05\ued07\ued07\ued03\ued04\ued0d\ued4a\ued18\ued0f\ued1b\ued1f\ued0f\ued19\ued1e\ued19\ued4a\ued05\ued04\ued50\ued4a\ued11\ued5a\ued17\ued50\ued11\ued5b\ued17", 60736), iPAddress, service.Value.Port));
					if (service.Value.DisableSystemProxy)
					{
						Log.Information(_E01E._E000("\uf6ae\uf684\uf68e\uf689\uf698\uf690\uf6dd\uf68d\uf68f\uf692\uf685\uf684\uf6dd\uf699\uf694\uf68e\uf69c\uf69f\uf691\uf698\uf699", 63221));
					}
					Log.Information(_E01E._E000("\uf7a5\uf796\uf781\uf780\uf79a\uf79c\uf79d\uf7c9\uf7d3\uf788\uf785\uf796\uf781\uf780\uf79a\uf79c\uf79d\uf78e", 63458), version);
				});
		}

		private static void _E000(WebHostBuilderContext _E06E, LoggerConfiguration _E06F)
		{
			_E06F.Enrich.FromLogContext().ReadFrom.Configuration(_E06E.Configuration);
		}
	}
}
