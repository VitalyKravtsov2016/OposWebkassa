using System;
using Microsoft.Extensions.Hosting;

namespace WebCash.LocalServer.Infrastructure
{
	public class HostFacade
	{
		private readonly IHost _E000;

		public IServiceProvider Services => _E000.Services;

		public HostFacade(IHost host)
		{
			_E000 = host;
		}

		public void Run()
		{
			_E000.Run();
		}

		public void RunAsService()
		{
			_E000.RunAsService();
		}
	}
}
