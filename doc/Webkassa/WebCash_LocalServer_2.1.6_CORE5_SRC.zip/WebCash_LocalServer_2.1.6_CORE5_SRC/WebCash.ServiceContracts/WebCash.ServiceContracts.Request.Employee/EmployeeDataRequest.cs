using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.Employee
{
	public class EmployeeDataRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E084;

		[CompilerGenerated]
		private long? _E085;

		public string UserName
		{
			[CompilerGenerated]
			get
			{
				return _E084;
			}
			[CompilerGenerated]
			set
			{
				_E084 = value;
			}
		}

		public long? EmployeeId
		{
			[CompilerGenerated]
			get
			{
				return _E085;
			}
			[CompilerGenerated]
			set
			{
				_E085 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.Programming };
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return new List<ValidationResult>();
		}
	}
}
