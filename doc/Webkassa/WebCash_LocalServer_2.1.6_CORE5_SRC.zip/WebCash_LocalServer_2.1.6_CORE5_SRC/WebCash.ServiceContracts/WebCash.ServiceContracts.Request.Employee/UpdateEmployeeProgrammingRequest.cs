using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.Employee
{
	public class UpdateEmployeeProgrammingRequest : EmployeeDataRequest
	{
		[CompilerGenerated]
		private string _E050;

		[CompilerGenerated]
		private decimal _E086;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private bool _E087;

		[CompilerGenerated]
		private PermissionEnum[] _E088;

		[CompilerGenerated]
		private string[] _E01C;

		[CompilerGenerated]
		private bool _E089;

		public string FullName
		{
			[CompilerGenerated]
			get
			{
				return _E050;
			}
			[CompilerGenerated]
			set
			{
				_E050 = value;
			}
		}

		public decimal MaximalCheckSum
		{
			[CompilerGenerated]
			get
			{
				return _E086;
			}
			[CompilerGenerated]
			set
			{
				_E086 = value;
			}
		}

		public string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public bool AutoPrintOnCreateCheck
		{
			[CompilerGenerated]
			get
			{
				return _E087;
			}
			[CompilerGenerated]
			set
			{
				_E087 = value;
			}
		}

		public PermissionEnum[] Permissions
		{
			[CompilerGenerated]
			get
			{
				return _E088;
			}
			[CompilerGenerated]
			set
			{
				_E088 = value;
			}
		}

		public string[] UniqueNumbers
		{
			[CompilerGenerated]
			get
			{
				return _E01C;
			}
			[CompilerGenerated]
			set
			{
				_E01C = value;
			}
		}

		public bool IsContactPerson
		{
			[CompilerGenerated]
			get
			{
				return _E089;
			}
			[CompilerGenerated]
			set
			{
				_E089 = value;
			}
		}
	}
}
