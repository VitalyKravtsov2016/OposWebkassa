using System;
using System.ComponentModel.DataAnnotations;

namespace WebCash.ServiceContracts.Attributes
{
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
	public class ArrayLengthAttribute : ValidationAttribute
	{
		private uint _E000;

		public ArrayLengthAttribute(uint minLength)
		{
			_E000 = minLength;
		}

		public override bool IsValid(object value)
		{
			if (value != null)
			{
				try
				{
					object[] array = (object[])value;
					if (array.Length != 0 && array.Length >= _E000)
					{
						return true;
					}
				}
				catch (Exception)
				{
				}
			}
			return false;
		}
	}
}
