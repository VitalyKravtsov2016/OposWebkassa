using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.Alpha
{
	public class OrganizationRegistrationAlphaRequest
	{
		[CompilerGenerated]
		private AlphaOrganizationInfo _E000;

		[CompilerGenerated]
		private AlphaEmployeeInfo _E001;

		[Required]
		public AlphaOrganizationInfo Organization
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		public AlphaEmployeeInfo Employee
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
