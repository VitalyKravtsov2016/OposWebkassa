using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.Alpha
{
	public class AlphaActivationRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private AlphaActivationCode[] _E001;

		[Xin]
		[Required]
		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		public AlphaActivationCode[] Items
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
