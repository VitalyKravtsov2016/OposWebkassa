using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.Alpha
{
	public class AlphaEmployeeInfo : BaseEmployeeInfo
	{
		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E000;

		[DisplayName("Полное имя")]
		[Required]
		[StringLength(255, MinimumLength = 1, ErrorMessage = "Длина имени кассира должна быть не менее 1 и не более 255 символов")]
		public override string FullName
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[DisplayName("Номер телефона")]
		[RegularExpression("\\+77\\d{9}", ErrorMessage = "Номер телефона должен соответствовать формату +77XXXXXXXXX")]
		[Required]
		[StringLength(12, MinimumLength = 12, ErrorMessage = "Номер телефона должен содержать 12 знаков")]
		public override string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public AlphaEmployeeInfo()
		{
			base.Password = _E006._E000("\uf7b9\uf798\uf783\uf7d7\uf799\uf782\uf79b\uf79b\uf7d7\uf787\uf796\uf784\uf784\uf780\uf798\uf785\uf793\uf7d7\uf783\uf798\uf7d7\uf787\uf796\uf784\uf784\uf7d7\uf781\uf796\uf79b\uf79e\uf793\uf796\uf783\uf79e\uf798\uf799\uf7d7\uf7c6\uf7c5\uf7c4", 63328);
		}
	}
}
