namespace WebCash.ServiceContracts.Request.Alpha
{
	public class AlphaOrganizationInfo : OrganizationInfo
	{
		public AlphaOrganizationInfo()
		{
			base.IsLegal = false;
		}
	}
}
