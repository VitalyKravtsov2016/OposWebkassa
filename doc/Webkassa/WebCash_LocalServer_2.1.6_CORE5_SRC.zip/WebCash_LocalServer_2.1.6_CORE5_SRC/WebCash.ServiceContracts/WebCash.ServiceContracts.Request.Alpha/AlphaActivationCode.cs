using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.Alpha
{
	public class AlphaActivationCode
	{
		[CompilerGenerated]
		private string _E000;

		public string ActivationCode
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}
	}
}
