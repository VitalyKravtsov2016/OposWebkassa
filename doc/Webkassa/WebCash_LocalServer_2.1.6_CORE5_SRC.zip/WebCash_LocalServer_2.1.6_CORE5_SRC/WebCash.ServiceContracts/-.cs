using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using WebCash.ServiceContracts;

[CompilerGenerated]
internal sealed class _E000<_E000, _E001>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E000 m__E000;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _E001 _E001;

	public _E000 _E002 => this._E000;

	public _E001 _E003 => this._E001;

	[DebuggerHidden]
	public _E000(_E000 _E000, _E001 _E001)
	{
		this._E000 = _E000;
		this._E001 = _E001;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_E000<_E000, _E001> obj = value as _E000<_E000, _E001>;
		if (this != obj)
		{
			if (obj != null && EqualityComparer<_E000>.Default.Equals(this._E000, obj._E000))
			{
				return EqualityComparer<_E001>.Default.Equals(this._E001, obj._E001);
			}
			return false;
		}
		return true;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (2041950968 * -1521134295 + EqualityComparer<_E000>.Default.GetHashCode(this._E000)) * -1521134295 + EqualityComparer<_E001>.Default.GetHashCode(this._E001);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		string format = _E006._E000("\uf684\uf684\uf6df\uf6ac\uf68a\uf692\uf6df\uf6c2\uf6df\uf684\uf6cf\uf682\uf6d3\uf6df\uf6ab\uf69e\uf687\uf6df\uf6c2\uf6df\uf684\uf6ce\uf682\uf6df\uf682\uf682", 63167);
		object[] array = new object[2];
		_E000 val = this._E000;
		array[0] = ((val != null) ? val.ToString() : null);
		_E001 val2 = this._E001;
		array[1] = ((val2 != null) ? val2.ToString() : null);
		return string.Format(null, format, array);
	}
}
internal class _E002 : IRounder
{
	public decimal RoundTotal(IEnumerable<decimal> items)
	{
		return items.Sum((decimal _E004) => RoundItem(_E004));
	}

	public decimal RoundItem(decimal item)
	{
		return Math.Round(item, 0, MidpointRounding.AwayFromZero);
	}

	[CompilerGenerated]
	private decimal _E000(decimal _E004)
	{
		return RoundItem(_E004);
	}
}
internal class _E003 : IRounder
{
	public decimal RoundTotal(IEnumerable<decimal> items)
	{
		return Math.Round(items.Sum(), 0, MidpointRounding.AwayFromZero);
	}

	public decimal RoundItem(decimal item)
	{
		return Math.Round(item, 0, MidpointRounding.AwayFromZero);
	}
}
internal class _E004 : IRounder
{
	public decimal RoundTotal(IEnumerable<decimal> items)
	{
		return Math.Round(items.Sum(), 2, MidpointRounding.AwayFromZero);
	}

	public decimal RoundItem(decimal item)
	{
		return Math.Round(item, 2, MidpointRounding.AwayFromZero);
	}
}
[CompilerGenerated]
internal sealed class _E005
{
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 12)]
	private struct _E000
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	private struct _E001
	{
	}

	internal static readonly _E001 _E000/* Not supported: data(0A 00 00 00 0C 00 00 00 16 00 00 00 0B 00 00 00) */;

	internal static readonly _E000 _E001/* Not supported: data(07 00 00 00 16 00 00 00 1C 00 00 00) */;
}
internal sealed class _E006
{
	private delegate string _E000();

	private sealed class _E001
	{
		private static readonly _E000 m__E001;

		public static readonly _E001 _E004;

		private byte[] _E005;

		static _E001()
		{
			m__E001 = _E006._E001;
			_E004 = new _E001();
		}

		private _E001()
		{
			Stream manifestResourceStream = typeof(_E001).GetTypeInfo().Assembly.GetManifestResourceStream(m__E001());
			if (((manifestResourceStream == null) ? (~(-(~(-98190065 ^ 0x5DA42F2)))) : (-654613853 - -654613853)) == 0)
			{
				_E005 = new byte[(-227684130 ^ -227684098) >> 1];
				manifestResourceStream.Read(_E005, -(~(-(--488318645 - 442497771) - 311405287 + 700108335) + 342882175), _E005.Length);
			}
		}

		public string _E000(string _E021, int _E022)
		{
			int num = _E021.Length;
			char[] array = _E021.ToCharArray();
			while ((num -= ~(-((-(-67029241 - 375158356) + 6750009 - 22304243) ^ 0x196DE891))) >= (0x12AEED54 ^ 0x27BE5318) - 223636867 + -666652873)
			{
				array[num] = (char)(array[num] ^ (_E005[_E022 & (-(-100448580 << 2) + 98085001 - 499878361 >> 6)] | _E022));
			}
			return new string(array);
		}
	}

	public static string _E000(string _E01D, int _E01E)
	{
		return _E006._E001._E004._E000(_E01D, _E01E);
	}

	public static string _E001()
	{
		char[] array = "\u00046\r\u0015\u0005".ToCharArray();
		int num = array.Length;
		while ((num -= ~(--675852229) - -587977172 + 87875059) >= -(~(-1)))
		{
			array[num] = (char)(array[num] ^ ~((-36817079 - -92300279) ^ -55483198));
		}
		return new string(array);
	}
}
