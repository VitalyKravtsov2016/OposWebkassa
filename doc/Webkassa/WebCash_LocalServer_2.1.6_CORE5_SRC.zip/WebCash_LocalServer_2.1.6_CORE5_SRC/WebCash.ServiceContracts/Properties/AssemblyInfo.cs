using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Webkassa")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("\r\n      ServiceContracts библиотека Data Contract'ов API для внутренних модулей\r\n    ")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("WebCash.ServiceContracts")]
[assembly: AssemblyTitle("WebCash.ServiceContracts")]
[assembly: AssemblyVersion("1.0.0.0")]
