using System.Collections.Generic;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class SectionSummary
	{
		[CompilerGenerated]
		private byte _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private Dictionary<OperationTypeEnum, CountAmountModel> _E002;

		public byte Code
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public Dictionary<OperationTypeEnum, CountAmountModel> Operations
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public SectionSummary()
		{
			Operations = new Dictionary<OperationTypeEnum, CountAmountModel>();
		}
	}
}
