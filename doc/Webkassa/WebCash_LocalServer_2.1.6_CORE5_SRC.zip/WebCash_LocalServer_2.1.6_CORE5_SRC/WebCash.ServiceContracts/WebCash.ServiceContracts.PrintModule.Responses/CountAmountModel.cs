using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public struct CountAmountModel
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private long _E001;

		public decimal Amount
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public long Count
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
