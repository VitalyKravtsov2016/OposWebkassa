using System.Collections.Generic;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class ModificatorSummary
	{
		[CompilerGenerated]
		private ModifierTypeEnum _E000;

		[CompilerGenerated]
		private Dictionary<OperationTypeEnum, CountAmountModel> _E001;

		public ModifierTypeEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public Dictionary<OperationTypeEnum, CountAmountModel> Operations
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public ModificatorSummary()
		{
			Operations = new Dictionary<OperationTypeEnum, CountAmountModel>(4);
		}
	}
}
