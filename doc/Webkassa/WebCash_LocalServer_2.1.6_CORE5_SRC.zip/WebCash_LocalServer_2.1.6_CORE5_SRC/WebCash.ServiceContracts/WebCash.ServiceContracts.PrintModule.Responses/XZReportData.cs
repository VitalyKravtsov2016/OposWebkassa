using System.Collections.Generic;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.ServiceContracts.Response;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class XZReportData : ZXReportResponse
	{
		[CompilerGenerated]
		private SectionSummary[] _E01E;

		[CompilerGenerated]
		private TaxSummary[] _E01F;

		[CompilerGenerated]
		private Dictionary<MoneyPlacementTypeEnum, MoneyPlacementSummary> _E020;

		[CompilerGenerated]
		private decimal _E021;

		[CompilerGenerated]
		private ReportTypeEnum _E022;

		[CompilerGenerated]
		private ModificatorSummary[] _E023;

		public SectionSummary[] Sections
		{
			[CompilerGenerated]
			get
			{
				return _E01E;
			}
			[CompilerGenerated]
			set
			{
				_E01E = value;
			}
		}

		public TaxSummary[] Taxes
		{
			[CompilerGenerated]
			get
			{
				return _E01F;
			}
			[CompilerGenerated]
			set
			{
				_E01F = value;
			}
		}

		public Dictionary<MoneyPlacementTypeEnum, MoneyPlacementSummary> MoneyPlacementOperations
		{
			[CompilerGenerated]
			get
			{
				return _E020;
			}
			[CompilerGenerated]
			set
			{
				_E020 = value;
			}
		}

		public decimal Revenue
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		public ReportTypeEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _E022;
			}
			[CompilerGenerated]
			set
			{
				_E022 = value;
			}
		}

		public ModificatorSummary[] Modificators
		{
			[CompilerGenerated]
			get
			{
				return _E023;
			}
			[CompilerGenerated]
			set
			{
				_E023 = value;
			}
		}

		public XZReportData()
		{
			MoneyPlacementOperations = new Dictionary<MoneyPlacementTypeEnum, MoneyPlacementSummary>();
			Modificators = new ModificatorSummary[0];
		}
	}
}
