using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class CashboxInitializationResponse
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private CurrentStateInfo _E004;

		[CompilerGenerated]
		private long _E005;

		[CompilerGenerated]
		private bool _E006;

		[CompilerGenerated]
		private string _E007;

		[CompilerGenerated]
		private string _E008;

		[CompilerGenerated]
		private string _E009;

		[CompilerGenerated]
		private bool _E00A;

		[CompilerGenerated]
		private bool _E00B;

		[CompilerGenerated]
		private bool _E00C;

		[CompilerGenerated]
		private bool _E00D;

		[CompilerGenerated]
		private byte[] _E00E;

		[CompilerGenerated]
		private string _E00F;

		[CompilerGenerated]
		private string _E010;

		[CompilerGenerated]
		private string _E011;

		[CompilerGenerated]
		private string _E012;

		[CompilerGenerated]
		private OfdEnum _E013;

		[CompilerGenerated]
		private OfdProtocolVersion _E014;

		[CompilerGenerated]
		private QrGenerationMode _E015;

		[CompilerGenerated]
		private TimeSpan? _E016;

		[CompilerGenerated]
		private byte[] _E017;

		[CompilerGenerated]
		private IEnumerable<SectionModel> _E018;

		[CompilerGenerated]
		private OfflineSupportMode _E019;

		[CompilerGenerated]
		private int? _E01A;

		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string RegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string Organization
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public CurrentStateInfo CurrentState
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public long IdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public bool AutowithdrawalOnCloseShift
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public string OfdAdTexts
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public string VatNumber
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public string VatSeria
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public bool OfflineAllowed
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public bool PrintDostykQR
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public bool PrintTicketQR
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public bool PrintWithoutVatTicketView
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public byte[] Logo
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		public string AdTexts
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		public string OfdName
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		public string OfdHost
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		public OfdEnum OfdCode
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		public OfdProtocolVersion OfdProtocolVersion
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public QrGenerationMode QrGenerationMode
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public TimeSpan? ForcedUpdateTime
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public byte[] AllowedValValues
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}

		public IEnumerable<SectionModel> Sections
		{
			[CompilerGenerated]
			get
			{
				return _E018;
			}
			[CompilerGenerated]
			set
			{
				_E018 = value;
			}
		}

		public OfflineSupportMode OfflineSupportMode
		{
			[CompilerGenerated]
			get
			{
				return _E019;
			}
			[CompilerGenerated]
			set
			{
				_E019 = value;
			}
		}

		public int? DefaultUnitCode
		{
			[CompilerGenerated]
			get
			{
				return _E01A;
			}
			[CompilerGenerated]
			set
			{
				_E01A = value;
			}
		}
	}
}
