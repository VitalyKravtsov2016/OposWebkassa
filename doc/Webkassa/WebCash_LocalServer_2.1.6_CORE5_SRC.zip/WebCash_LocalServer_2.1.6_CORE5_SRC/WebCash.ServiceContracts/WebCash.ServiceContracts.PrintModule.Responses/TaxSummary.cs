using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class TaxSummary
	{
		[CompilerGenerated]
		private TaxTypeEnum _E000;

		[CompilerGenerated]
		private OperationTypeEnum _E001;

		[CompilerGenerated]
		private decimal _E002;

		[CompilerGenerated]
		private decimal _E003;

		[CompilerGenerated]
		private byte? _E004;

		public TaxTypeEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public OperationTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public decimal Turnover
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public decimal Amount
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public byte? Percent
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}
	}
}
