using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class MoneyPlacementSummary
	{
		[CompilerGenerated]
		private long _E000;

		[CompilerGenerated]
		private long _E001;

		[CompilerGenerated]
		private decimal _E002;

		public long TotalCount
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public long Count
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public decimal Amount
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
