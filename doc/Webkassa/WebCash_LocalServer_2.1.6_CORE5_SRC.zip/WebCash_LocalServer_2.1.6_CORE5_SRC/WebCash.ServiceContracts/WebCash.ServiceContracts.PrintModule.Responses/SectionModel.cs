using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.PrintModule.Responses
{
	public class SectionModel
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool _E001;

		[CompilerGenerated]
		private byte? _E002;

		public string Code
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public bool IsVAT
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public byte? Percent
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
