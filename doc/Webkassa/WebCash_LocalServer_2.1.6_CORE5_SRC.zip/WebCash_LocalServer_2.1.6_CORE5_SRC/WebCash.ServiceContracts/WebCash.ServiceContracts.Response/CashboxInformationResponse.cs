using System;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxInformationResponse
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private CashboxStatusEnum _E002;

		[CompilerGenerated]
		private bool _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private string _E006;

		[CompilerGenerated]
		private DateTime? _E007;

		public string OrganizationXin
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string OrganizationFullName
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public CashboxStatusEnum Status
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public bool VATPayer
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public string VATSeries
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public string VATNumber
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public string LegalAddress
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public DateTime? LicenseExpirationDate
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}
	}
}
