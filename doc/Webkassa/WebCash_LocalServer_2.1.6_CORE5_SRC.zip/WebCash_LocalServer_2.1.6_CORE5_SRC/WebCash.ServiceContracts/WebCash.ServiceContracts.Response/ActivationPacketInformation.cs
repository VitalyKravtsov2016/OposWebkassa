using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class ActivationPacketInformation
	{
		[CompilerGenerated]
		private int? _E000;

		[CompilerGenerated]
		private int? _E001;

		[CompilerGenerated]
		private DateTime _E002;

		public int? TicketsCount
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public int? MaxTicketsCount
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public DateTime Expiring
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
