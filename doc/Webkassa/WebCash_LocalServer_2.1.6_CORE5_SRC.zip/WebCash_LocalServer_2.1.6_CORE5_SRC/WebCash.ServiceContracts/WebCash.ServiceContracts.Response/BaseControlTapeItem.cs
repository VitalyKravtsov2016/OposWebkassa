using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class BaseControlTapeItem
	{
		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private decimal _E002;

		[CompilerGenerated]
		private DateTime _E003;

		[CompilerGenerated]
		private long _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private bool _E006;

		[CompilerGenerated]
		private string _E007;

		public string OperationTypeText
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public DateTime Date
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public long EmployeeCode
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public bool IsOffline
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public string ExternalOperationId
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}
	}
}
