using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxInfo
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private OfdInformation _E004;

		public string UniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string RegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string IdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public OfdInformation Ofd
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public CashboxInfo(string unique, string registration, string identity, string address, OfdInformation ofd)
		{
			UniqueNumber = unique;
			RegistrationNumber = registration;
			IdentityNumber = identity;
			Address = address;
			Ofd = ofd;
		}

		public CashboxInfo()
		{
		}
	}
}
