using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public abstract class BasePageResponse<T> where T : class
	{
		[CompilerGenerated]
		private int _E000;

		[CompilerGenerated]
		private int _E001;

		[CompilerGenerated]
		private long _E002;

		[CompilerGenerated]
		private T[] _E003;

		public int Skip
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public int Take
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public long Total
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public T[] Items
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		protected BasePageResponse()
		{
			Items = new T[0];
		}
	}
}
