using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Response
{
	public class BaseOperationInfo
	{
		[CompilerGenerated]
		private OperationTypeEnum _E001;

		[CompilerGenerated]
		private decimal _E002;

		public OperationTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
