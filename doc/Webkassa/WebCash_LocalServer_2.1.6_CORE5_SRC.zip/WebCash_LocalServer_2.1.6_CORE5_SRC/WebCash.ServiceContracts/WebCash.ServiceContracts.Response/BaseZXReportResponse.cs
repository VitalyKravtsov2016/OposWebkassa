using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class BaseZXReportResponse : IOfflineModeInfo
	{
		[CompilerGenerated]
		private long _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private long _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private DateTime _E004;

		[CompilerGenerated]
		private DateTime _E005;

		[CompilerGenerated]
		private DateTime? _E006;

		[CompilerGenerated]
		private long _E007;

		[CompilerGenerated]
		private long _E008;

		[CompilerGenerated]
		private long _E009;

		[CompilerGenerated]
		private decimal _E00A;

		[CompilerGenerated]
		private decimal _E00B;

		[CompilerGenerated]
		private int _E00C;

		[CompilerGenerated]
		private bool _E00D;

		[CompilerGenerated]
		private bool _E00E;

		[CompilerGenerated]
		private DateTime? _E00F;

		[CompilerGenerated]
		private decimal _E010;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E011;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E012;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E013;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E014;

		[CompilerGenerated]
		private NonNullableApiModel _E015;

		[CompilerGenerated]
		private NonNullableApiModel _E016;

		[CompilerGenerated]
		private OfdInformation _E017;

		public long ReportNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string CashboxSN
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public long CashboxIN
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string CashboxRN
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public DateTime StartOn
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public DateTime ReportOn
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public DateTime? CloseOn
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public long CashierCode
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public long DocumentCount
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public decimal PutMoneySum
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public decimal TakeMoneySum
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public int ControlSum
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public bool OfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public bool CashboxOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		public DateTime? StartOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		public decimal SumInCashbox
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		public OperationTypeSummaryApiModel Sell
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		public OperationTypeSummaryApiModel Buy
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		public OperationTypeSummaryApiModel ReturnSell
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		public OperationTypeSummaryApiModel ReturnBuy
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public NonNullableApiModel EndNonNullable
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public NonNullableApiModel StartNonNullable
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public OfdInformation Ofd
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}
	}
}
