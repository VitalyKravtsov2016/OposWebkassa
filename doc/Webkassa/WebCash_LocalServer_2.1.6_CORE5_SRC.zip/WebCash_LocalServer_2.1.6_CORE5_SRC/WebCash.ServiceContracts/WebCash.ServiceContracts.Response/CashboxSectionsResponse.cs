using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxSectionsResponse
	{
		[CompilerGenerated]
		private long _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private string _E004;

		public long SectionId
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string Code
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string NameKz
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string NameEn
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public string NameRu
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}
	}
}
