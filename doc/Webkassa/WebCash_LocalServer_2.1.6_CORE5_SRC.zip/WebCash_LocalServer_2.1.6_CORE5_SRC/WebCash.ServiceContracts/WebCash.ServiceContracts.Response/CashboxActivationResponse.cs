using System;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxActivationResponse
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private ActivationPacketStatusEnum _E001;

		[CompilerGenerated]
		private DateTime? _E002;

		public string PackageNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public ActivationPacketStatusEnum PackageStatus
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public DateTime? ActivationDate
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
