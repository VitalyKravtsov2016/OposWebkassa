using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class Cashbox1C
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private DateTime? _E002;

		[CompilerGenerated]
		private List<CashboxLicense> _E003;

		public string CashboxName
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public DateTime? ActivationEndDate
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public List<CashboxLicense> Licenses
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}
	}
}
