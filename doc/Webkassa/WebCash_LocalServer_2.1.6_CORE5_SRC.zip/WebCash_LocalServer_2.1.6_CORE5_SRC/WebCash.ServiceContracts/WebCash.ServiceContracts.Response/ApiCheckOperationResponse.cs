using System;
using System.Runtime.CompilerServices;
using WebCash.ServiceContracts.Response.Advertising;

namespace WebCash.ServiceContracts.Response
{
	public class ApiCheckOperationResponse : IOfflineModeInfo
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private DateTime _E001;

		[CompilerGenerated]
		private bool _E002;

		[CompilerGenerated]
		private bool _E003;

		[CompilerGenerated]
		private DateTime? _E004;

		[CompilerGenerated]
		private CashboxInfo _E005;

		[CompilerGenerated]
		private OrganizationInfoForCheckResponse _E006;

		[CompilerGenerated]
		private long _E007;

		[CompilerGenerated]
		private long _E008;

		[CompilerGenerated]
		private string _E009;

		[CompilerGenerated]
		private string _E00A;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private AdvertisingContentResponse _E00C;

		public string CheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public DateTime DateTime
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public bool OfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public bool CashboxOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public DateTime? StartOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public CashboxInfo Cashbox
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public OrganizationInfoForCheckResponse Organization
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public long CheckOrderNumber
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public string EmployeeName
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public string TicketUrl
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public string TicketPrintUrl
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public AdvertisingContentResponse AdvertisingContent
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}
	}
}
