using System;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxMobileStateResponse : IOfflineModeInfo
	{
		[CompilerGenerated]
		private DateTime? _E000;

		[CompilerGenerated]
		private long _E001;

		[CompilerGenerated]
		private long _E002;

		[CompilerGenerated]
		private bool _E003;

		[CompilerGenerated]
		private decimal _E004;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E005;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E006;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E007;

		[CompilerGenerated]
		private OperationTypeSummaryApiModel _E008;

		[CompilerGenerated]
		private NonNullableApiModel _E009;

		[CompilerGenerated]
		private RoundTypeEnum? _E00A;

		[CompilerGenerated]
		private bool _E00B;

		[CompilerGenerated]
		private bool _E00C;

		[CompilerGenerated]
		private OfflineSupportMode _E00D;

		[CompilerGenerated]
		private DateTime _E00E;

		[CompilerGenerated]
		private NonNullableApiModel _E00F;

		[CompilerGenerated]
		private bool _E010;

		[CompilerGenerated]
		private long _E011;

		[CompilerGenerated]
		private decimal _E012;

		[CompilerGenerated]
		private decimal _E013;

		[CompilerGenerated]
		private PaymentTypeEnum[] _E014;

		[CompilerGenerated]
		private string _E015;

		[CompilerGenerated]
		private string _E016;

		[CompilerGenerated]
		private CashboxModelTypeEnum _E017;

		[CompilerGenerated]
		private bool _E018;

		[CompilerGenerated]
		private DateTime? _E019;

		[CompilerGenerated]
		private string _E01A;

		[CompilerGenerated]
		private long _E01B;

		[CompilerGenerated]
		private string _E01C;

		[CompilerGenerated]
		private DateTime? _E01D;

		[CompilerGenerated]
		private bool _E01E;

		[CompilerGenerated]
		private BlockPriceListUserInputMode _E01F;

		[CompilerGenerated]
		private string _E020;

		[CompilerGenerated]
		private bool _E021;

		[CompilerGenerated]
		private bool _E022;

		[CompilerGenerated]
		private QrGenerationMode _E023;

		[CompilerGenerated]
		private OfdInformation _E024;

		[CompilerGenerated]
		private string _E025;

		[CompilerGenerated]
		private string _E026;

		[CompilerGenerated]
		private ActivationPacketInformation _E027;

		[CompilerGenerated]
		private CashboxSettingsShortResponse _E028;

		[CompilerGenerated]
		private byte[] _E029;

		[CompilerGenerated]
		private string _E02A;

		[CompilerGenerated]
		private bool _E02B;

		[CompilerGenerated]
		private bool _E02C;

		[CompilerGenerated]
		private MarkingModeEnum _E02D;

		[CompilerGenerated]
		private OfdProtocolVersion _E02E;

		public DateTime? ShiftOpened
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public long DocumentsCount
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public bool ShiftClosed
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public decimal SumInCashbox
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public OperationTypeSummaryApiModel Sell
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public OperationTypeSummaryApiModel Buy
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public OperationTypeSummaryApiModel ReturnSell
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public OperationTypeSummaryApiModel ReturnBuy
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public NonNullableApiModel CurrentNonNullable
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public RoundTypeEnum? RoundType
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public bool AllowOfflineChecks
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public bool AllowSpecialOfflineChecks
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public OfflineSupportMode OfflineSupportMode
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public DateTime SystemTime
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		public NonNullableApiModel StartShiftNonNullable
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		public bool AutoWithDrawal
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		public long ShiftLastDocumentNumber
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		public decimal DepositMoneyInShift
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		public decimal WithdrawalMoneyInShift
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		public PaymentTypeEnum[] PaymentsTypeEnums
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public string LastCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public string DeviceSerialNumber
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public CashboxModelTypeEnum CashboxType
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}

		public bool CashboxOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E018;
			}
			[CompilerGenerated]
			set
			{
				_E018 = value;
			}
		}

		public DateTime? StartOfflineMode
		{
			[CompilerGenerated]
			get
			{
				return _E019;
			}
			[CompilerGenerated]
			set
			{
				_E019 = value;
			}
		}

		public string CasboxRegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E01A;
			}
			[CompilerGenerated]
			set
			{
				_E01A = value;
			}
		}

		public long CashboxIdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E01B;
			}
			[CompilerGenerated]
			set
			{
				_E01B = value;
			}
		}

		public string CashboxName
		{
			[CompilerGenerated]
			get
			{
				return _E01C;
			}
			[CompilerGenerated]
			set
			{
				_E01C = value;
			}
		}

		public DateTime? ShiftClosedOn
		{
			[CompilerGenerated]
			get
			{
				return _E01D;
			}
			[CompilerGenerated]
			set
			{
				_E01D = value;
			}
		}

		public bool BlockPriceListUserInput
		{
			[CompilerGenerated]
			get
			{
				return _E01E;
			}
			[CompilerGenerated]
			set
			{
				_E01E = value;
			}
		}

		public BlockPriceListUserInputMode BlockPriceListManualEntry
		{
			[CompilerGenerated]
			get
			{
				return _E01F;
			}
			[CompilerGenerated]
			set
			{
				_E01F = value;
			}
		}

		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E020;
			}
			[CompilerGenerated]
			set
			{
				_E020 = value;
			}
		}

		public bool PrintTicketQr
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		public bool HasBoundQr
		{
			[CompilerGenerated]
			get
			{
				return _E022;
			}
			[CompilerGenerated]
			set
			{
				_E022 = value;
			}
		}

		public QrGenerationMode QrGenerationMode
		{
			[CompilerGenerated]
			get
			{
				return _E023;
			}
			[CompilerGenerated]
			set
			{
				_E023 = value;
			}
		}

		public OfdInformation Ofd
		{
			[CompilerGenerated]
			get
			{
				return _E024;
			}
			[CompilerGenerated]
			set
			{
				_E024 = value;
			}
		}

		public string DefaultSellPositionName
		{
			[CompilerGenerated]
			get
			{
				return _E025;
			}
			[CompilerGenerated]
			set
			{
				_E025 = value;
			}
		}

		public string DefaultPurchasePositionName
		{
			[CompilerGenerated]
			get
			{
				return _E026;
			}
			[CompilerGenerated]
			set
			{
				_E026 = value;
			}
		}

		public ActivationPacketInformation CurrentActivationPacket
		{
			[CompilerGenerated]
			get
			{
				return _E027;
			}
			[CompilerGenerated]
			set
			{
				_E027 = value;
			}
		}

		public CashboxSettingsShortResponse Settings
		{
			[CompilerGenerated]
			get
			{
				return _E028;
			}
			[CompilerGenerated]
			set
			{
				_E028 = value;
			}
		}

		public byte[] LogoImage
		{
			[CompilerGenerated]
			get
			{
				return _E029;
			}
			[CompilerGenerated]
			set
			{
				_E029 = value;
			}
		}

		public string AdText
		{
			[CompilerGenerated]
			get
			{
				return _E02A;
			}
			[CompilerGenerated]
			set
			{
				_E02A = value;
			}
		}

		public bool EnterCustomerXin
		{
			[CompilerGenerated]
			get
			{
				return _E02B;
			}
			[CompilerGenerated]
			set
			{
				_E02B = value;
			}
		}

		public bool CourierMode
		{
			[CompilerGenerated]
			get
			{
				return _E02C;
			}
			[CompilerGenerated]
			set
			{
				_E02C = value;
			}
		}

		public MarkingModeEnum MarkingMode
		{
			[CompilerGenerated]
			get
			{
				return _E02D;
			}
			[CompilerGenerated]
			set
			{
				_E02D = value;
			}
		}

		public OfdProtocolVersion OfdProtocolVersion
		{
			[CompilerGenerated]
			get
			{
				return _E02E;
			}
			[CompilerGenerated]
			set
			{
				_E02E = value;
			}
		}

		public CashboxMobileStateResponse()
		{
			ShiftClosed = true;
		}
	}
}
