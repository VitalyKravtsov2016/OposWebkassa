using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Response
{
	public class CashboxesWithToken : TokenResponse
	{
		[CompilerGenerated]
		private string[] _E000;

		public string[] Cashboxes
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public CashboxesWithToken(string value)
			: base(value)
		{
		}
	}
}
