using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.WebScan
{
	public class BindDeviceRequest
	{
		[CompilerGenerated]
		private long _E000;

		[CompilerGenerated]
		private string _E001;

		public long TradePointId
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string DeviceId
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
