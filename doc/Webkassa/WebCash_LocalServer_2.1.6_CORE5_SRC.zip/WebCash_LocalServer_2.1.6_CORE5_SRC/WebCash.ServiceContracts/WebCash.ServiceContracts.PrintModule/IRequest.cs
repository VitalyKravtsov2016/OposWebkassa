namespace WebCash.ServiceContracts.PrintModule
{
	public interface IRequest
	{
	}
}
