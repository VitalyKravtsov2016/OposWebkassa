using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.PrintModule
{
	public class UploadLogRequest : IRequest
	{
		[CompilerGenerated]
		private byte[] _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private int _E005;

		[CompilerGenerated]
		private string[] _E006;

		[CompilerGenerated]
		private string[] _E007;

		public byte[] LogFile
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string Settings
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string UserDescription
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string Version
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public string OSVersion
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public int ProcessorCount
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public string[] Cashboxes
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public string[] Logins
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}
	}
}
