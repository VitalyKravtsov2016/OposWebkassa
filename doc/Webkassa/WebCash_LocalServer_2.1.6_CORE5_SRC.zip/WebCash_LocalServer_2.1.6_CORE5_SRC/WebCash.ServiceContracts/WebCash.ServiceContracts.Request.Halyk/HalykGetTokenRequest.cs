using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.Halyk
{
	public class HalykGetTokenRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E083;

		[Required]
		public string OperatorLogin
		{
			[CompilerGenerated]
			get
			{
				return _E083;
			}
			[CompilerGenerated]
			set
			{
				_E083 = value;
			}
		}
	}
}
