using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request.Halyk
{
	public class HalykSetTokenRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private int _E003;

		[CompilerGenerated]
		private string _E004;

		[JsonProperty(PropertyName = "@MsgNum")]
		public string CorrelationId
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[JsonProperty(PropertyName = "OpLogin")]
		public string OperatorLogin
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[JsonProperty(PropertyName = "Token")]
		public string Token
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[JsonProperty(PropertyName = "TokenTimeout")]
		public int TokenTimeout
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[JsonProperty(PropertyName = "ServerTime")]
		public string ServerTimeAsString
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[JsonIgnore]
		public DateTimeOffset? InternalServerTime
		{
			get
			{
				if (DateTimeOffset.TryParseExact(ServerTimeAsString, _E006._E000("\uf19b\uf19b\uf1d1\uf1b2\uf1b2\uf1d1\uf186\uf186\uf186\uf186\uf1df\uf1b7\uf1b7\uf1c5\uf192\uf192\uf1c5\uf18c\uf18c\uf1df\uf1a3\uf1b8\uf1a3\uf1b2\uf1a3\uf1ab\uf185\uf185\uf185", 61863), new DateTimeFormatInfo(), DateTimeStyles.None, out var result))
				{
					return result;
				}
				return null;
			}
		}
	}
}
