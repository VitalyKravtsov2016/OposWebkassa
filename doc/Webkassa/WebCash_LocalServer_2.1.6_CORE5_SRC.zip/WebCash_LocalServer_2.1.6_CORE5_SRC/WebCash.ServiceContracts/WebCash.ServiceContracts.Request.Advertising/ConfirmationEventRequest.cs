using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.Advertising
{
	public class ConfirmationEventRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private EventStatusEnum _E001;

		public string ExternalNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public EventStatusEnum Status
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
