using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxChangeProtocolRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string[] _E01C;

		[Required]
		public string[] UniqueNumbers
		{
			[CompilerGenerated]
			get
			{
				return _E01C;
			}
			[CompilerGenerated]
			set
			{
				_E01C = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.Programming };
		}
	}
}
