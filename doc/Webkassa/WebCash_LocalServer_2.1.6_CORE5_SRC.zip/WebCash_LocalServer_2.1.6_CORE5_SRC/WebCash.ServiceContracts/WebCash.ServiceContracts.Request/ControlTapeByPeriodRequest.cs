using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request
{
	public class ControlTapeByPeriodRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private DateTime _E047;

		[CompilerGenerated]
		private DateTime _E048;

		[CompilerGenerated]
		private string _E000;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public DateTime DateFrom
		{
			[CompilerGenerated]
			get
			{
				return _E047;
			}
			[CompilerGenerated]
			set
			{
				_E047 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public DateTime DateTo
		{
			[CompilerGenerated]
			get
			{
				return _E048;
			}
			[CompilerGenerated]
			set
			{
				_E048 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
