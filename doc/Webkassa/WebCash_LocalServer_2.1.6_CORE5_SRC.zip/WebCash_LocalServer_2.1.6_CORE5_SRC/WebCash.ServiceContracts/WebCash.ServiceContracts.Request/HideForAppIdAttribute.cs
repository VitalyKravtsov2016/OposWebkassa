using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class HideForAppIdAttribute : Attribute
	{
		[CompilerGenerated]
		private readonly string[] _E000;

		public string[] AppIdentificators
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
		}

		public HideForAppIdAttribute(params string[] appIdentificators)
		{
			_E000 = appIdentificators;
		}
	}
}
