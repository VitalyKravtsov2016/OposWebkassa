using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class TicketTestPrintRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private PrinterTypeEnum _E07E;

		[CompilerGenerated]
		private string _E07F;

		[CompilerGenerated]
		private byte[] _E080;

		public PrinterTypeEnum PrinterType
		{
			[CompilerGenerated]
			get
			{
				return _E07E;
			}
			[CompilerGenerated]
			set
			{
				_E07E = value;
			}
		}

		public string AdText
		{
			[CompilerGenerated]
			get
			{
				return _E07F;
			}
			[CompilerGenerated]
			set
			{
				_E07F = value;
			}
		}

		public byte[] LogoImage
		{
			[CompilerGenerated]
			get
			{
				return _E080;
			}
			[CompilerGenerated]
			set
			{
				_E080 = value;
			}
		}
	}
}
