using System;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class SulpakTicketRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private long _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private long _E006;

		[CompilerGenerated]
		private DateTimeOffset _E007;

		[CompilerGenerated]
		private string _E008;

		[CompilerGenerated]
		private long _E009;

		[CompilerGenerated]
		private long _E00A;

		[CompilerGenerated]
		private long _E00B;

		[CompilerGenerated]
		private OperationTypeEnum _E00C;

		[CompilerGenerated]
		private string _E00D;

		[CompilerGenerated]
		private SulpakPayment[] _E00E;

		[CompilerGenerated]
		private decimal _E00F;

		[CompilerGenerated]
		private decimal _E010;

		[CompilerGenerated]
		private decimal _E011;

		[CompilerGenerated]
		private decimal _E012;

		[CompilerGenerated]
		private decimal _E013;

		[CompilerGenerated]
		private decimal _E014;

		[CompilerGenerated]
		private int _E015;

		[CompilerGenerated]
		private decimal _E016;

		[CompilerGenerated]
		private bool _E017;

		[CompilerGenerated]
		private SulpakPosition[] _E018;

		[CompilerGenerated]
		private SulpakTicketModifier[] _E019;

		[CompilerGenerated]
		private string _E01A;

		[CompilerGenerated]
		private bool _E01B;

		[CompilerGenerated]
		private string _E01C;

		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string CashboxRegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public long CashboxIdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public long OrderNumber
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public DateTimeOffset RegistratedOn
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public string EmployeeName
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public long EmployeeCode
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public long DocumentNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public OperationTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public string OperationTypeText
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public SulpakPayment[] Payments
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		public decimal Total
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		public decimal Change
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		public decimal Taken
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		public decimal Discount
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		public decimal MarkupPercent
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		public decimal Markup
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public int TaxPercent
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public decimal Tax
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public bool VATPayer
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}

		public SulpakPosition[] Positions
		{
			[CompilerGenerated]
			get
			{
				return _E018;
			}
			[CompilerGenerated]
			set
			{
				_E018 = value;
			}
		}

		public SulpakTicketModifier[] TicketModifiers
		{
			[CompilerGenerated]
			get
			{
				return _E019;
			}
			[CompilerGenerated]
			set
			{
				_E019 = value;
			}
		}

		public string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E01A;
			}
			[CompilerGenerated]
			set
			{
				_E01A = value;
			}
		}

		public bool IsOffline
		{
			[CompilerGenerated]
			get
			{
				return _E01B;
			}
			[CompilerGenerated]
			set
			{
				_E01B = value;
			}
		}

		public string TicketUrl
		{
			[CompilerGenerated]
			get
			{
				return _E01C;
			}
			[CompilerGenerated]
			set
			{
				_E01C = value;
			}
		}
	}
}
