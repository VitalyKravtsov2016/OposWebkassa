using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class AuthorizedRequest : IValidatableObject
	{
		[CompilerGenerated]
		private string _E006;

		public string Token
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public virtual PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[0];
		}

		public virtual IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			List<ValidationResult> list = new List<ValidationResult>();
			if (string.IsNullOrEmpty(Token))
			{
				list.Add(new ValidationResult(ValidationResource.Required, new string[1] { global::_E006._E000("\uf88b\uf8b0\uf8b4\uf8ba\uf8b1", 63695) }));
			}
			list.AddRange(Validate());
			return list;
		}

		protected virtual IEnumerable<ValidationResult> Validate()
		{
			return new List<ValidationResult>();
		}

		public virtual string GetCashboxUniqueName()
		{
			return string.Empty;
		}

		public virtual RequireType GetRequireType()
		{
			return RequireType.All;
		}
	}
}
