using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class QazKomPaymentRequest
	{
		public class PaymentAmountItem
		{
			[CompilerGenerated]
			private decimal _E000;

			[CompilerGenerated]
			private string _E001;

			[Required]
			[Display(Name = "Сумма")]
			public decimal Value
			{
				[CompilerGenerated]
				get
				{
					return _E000;
				}
				[CompilerGenerated]
				set
				{
					_E000 = value;
				}
			}

			[Required]
			[RegularExpression("^\\w{3}$", ErrorMessage = "Требуется трехзначный код")]
			[Display(Name = "Валюта")]
			public string Currency
			{
				[CompilerGenerated]
				get
				{
					return _E001;
				}
				[CompilerGenerated]
				set
				{
					_E001 = value;
				}
			}
		}

		public class FeeAmountItem
		{
			[CompilerGenerated]
			private decimal? _E000;

			[CompilerGenerated]
			private string _E001;

			[Display(Name = "Сумма")]
			public decimal? Value
			{
				[CompilerGenerated]
				get
				{
					return _E000;
				}
				[CompilerGenerated]
				set
				{
					_E000 = value;
				}
			}

			[RegularExpression("^\\w{3}$", ErrorMessage = "Требуется трехзначный код")]
			[Display(Name = "Валюта")]
			public string Currency
			{
				[CompilerGenerated]
				get
				{
					return _E001;
				}
				[CompilerGenerated]
				set
				{
					_E001 = value;
				}
			}
		}

		[CompilerGenerated]
		private PaymentAmountItem _E000;

		[CompilerGenerated]
		private FeeAmountItem _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private long _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private string _E006;

		[CompilerGenerated]
		private string _E007;

		[CompilerGenerated]
		private string _E008;

		[CompilerGenerated]
		private string _E009;

		[CompilerGenerated]
		private string _E00A;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private string _E00C;

		[Required]
		[Display(Name = "Платеж")]
		public PaymentAmountItem Amount
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		[Display(Name = "Комиссия")]
		public FeeAmountItem FeeAmount
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[Required]
		[Display(Name = "Уникальный номер callback-а")]
		public string DocId
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[RegularExpression("^\\d{12}$", ErrorMessage = "Длина 12 символов")]
		[Required]
		[Display(Name = "Референс платежа в банковской системе")]
		public string Rrn
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[Required]
		[Display(Name = "Номер mVisa терминала")]
		public long TerminalId
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[RegularExpression("^\\d{6,15}$", ErrorMessage = "Длина от 6 до 15 числовых символов")]
		[Display(Name = "Основной номер заказа")]
		public string OrderId
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		[RegularExpression("^\\d{6,15}$", ErrorMessage = "Длина от 6 до 15 числовых символов")]
		[Display(Name = "Дополнительный номер заказа")]
		public string SecondaryOrderId
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		[Required]
		[Display(Name = "Код авторизации")]
		public string AuthCode
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		[Required]
		[Display(Name = "mPan коммерсанта")]
		public string MerchantPan
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		[RegularExpression("^\\d{6}\\*+\\d{4}$")]
		[Required]
		[Display(Name = "Маска карты плательщика")]
		public string SenderPan
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		[Required]
		[Display(Name = "Статус операции")]
		public string OperationStatus
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		[Required]
		[Display(Name = "Дата и время проведения транзакции")]
		public string TransactionTime
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		[Display(Name = "Имя плательщика")]
		public string SenderName
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}
	}
}
