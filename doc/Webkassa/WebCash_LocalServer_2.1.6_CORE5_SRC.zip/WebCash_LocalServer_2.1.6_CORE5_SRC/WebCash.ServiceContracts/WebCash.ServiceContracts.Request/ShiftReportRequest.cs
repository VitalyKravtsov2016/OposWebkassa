using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ShiftReportRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long _E016;

		[CompilerGenerated]
		private long _E015;

		[CompilerGenerated]
		private ReportTypeEnum _E06C;

		[CompilerGenerated]
		private bool? _E079;

		[CompilerGenerated]
		private string _E07A;

		[Required]
		public long CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		[Required]
		public long ShiftId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public ReportTypeEnum ReportType
		{
			[CompilerGenerated]
			get
			{
				return _E06C;
			}
			[CompilerGenerated]
			set
			{
				_E06C = value;
			}
		}

		public bool? Raw
		{
			[CompilerGenerated]
			get
			{
				return _E079;
			}
			[CompilerGenerated]
			set
			{
				_E079 = value;
			}
		}

		public string Format
		{
			[CompilerGenerated]
			get
			{
				return _E07A;
			}
			[CompilerGenerated]
			set
			{
				_E07A = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[3]
			{
				PermissionEnum.VewXZReport,
				PermissionEnum.SupportCabinet,
				PermissionEnum.ViewOrganization
			};
		}
	}
}
