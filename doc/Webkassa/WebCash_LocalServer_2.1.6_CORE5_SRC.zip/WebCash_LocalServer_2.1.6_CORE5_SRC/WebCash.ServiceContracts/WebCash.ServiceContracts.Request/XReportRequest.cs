using WebCash.Constants.Enums;
using WebCash.ServiceContracts.PrintModule;

namespace WebCash.ServiceContracts.Request
{
	public class XReportRequest : BaseReportRequest, IXzReport, IOfflinePackage, IRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.CreateXReport };
		}

		public override string GetCashboxUniqueName()
		{
			return base.CashboxUniqueNumber;
		}
	}
}
