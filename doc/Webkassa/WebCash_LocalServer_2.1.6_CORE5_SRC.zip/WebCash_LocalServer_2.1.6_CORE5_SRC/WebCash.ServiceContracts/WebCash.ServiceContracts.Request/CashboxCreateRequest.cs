using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxCreateRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private CashboxTimeZoneEnum _E01E;

		[CompilerGenerated]
		private int _E01F;

		[CompilerGenerated]
		private string _E020;

		[Required]
		[EnumDataType(typeof(CashboxTimeZoneEnum), ErrorMessage = "Некорректное значение перечисления")]
		public CashboxTimeZoneEnum Timezone
		{
			[CompilerGenerated]
			get
			{
				return _E01E;
			}
			[CompilerGenerated]
			set
			{
				_E01E = value;
			}
		}

		[Required]
		public int ModelType
		{
			[CompilerGenerated]
			get
			{
				return _E01F;
			}
			[CompilerGenerated]
			set
			{
				_E01F = value;
			}
		}

		[StringRange(1, 255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E020;
			}
			[CompilerGenerated]
			set
			{
				_E020 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.TrinitySystem };
		}

		protected override IEnumerable<ValidationResult> Validate()
		{
			List<ValidationResult> list = new List<ValidationResult>();
			if (!new int[1] { 238 }.Contains(ModelType))
			{
				list.Add(new ValidationResult(string.Format(_E006._E000("\uf1a2\uf1bb\uf1b1\uf1b6\uf1b1\uf1bc\uf1bc\uf1ca\uf1b8\uf5a1\uf1c3\uf1b9\uf1be\uf5a1\uf1bd\uf1bf\uf1b5\uf1b4\uf1ba\uf1b9\uf5bb\uf5a1\uf5fa\uf5b1\uf5fc\uf5a1\uf1bc\uf1b4\uf5a1\uf1c0\uf1c2\uf1c8\uf1b4\uf1c0\uf1c3\uf1b3\uf1c2\uf1b4\uf1c3", 62721), ModelType), new string[1] { _E006._E000("\ue903\ue921\ue92a\ue92b\ue922\ue91a\ue937\ue93e\ue92b", 59726) }));
			}
			return list;
		}
	}
}
