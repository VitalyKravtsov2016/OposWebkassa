using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxCardRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[Required]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
