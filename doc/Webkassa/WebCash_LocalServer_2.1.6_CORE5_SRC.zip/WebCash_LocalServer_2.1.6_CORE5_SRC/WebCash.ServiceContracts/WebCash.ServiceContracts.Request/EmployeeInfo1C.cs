using System;

namespace WebCash.ServiceContracts.Request
{
	public class EmployeeInfo1C : BaseEmployeeInfo
	{
		public override int? MaxCheckAmount => (int)Math.Pow(10.0, 9.0);
	}
}
