using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class PaymentTypeInfoApiModel
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private PaymentTypeEnum _E001;

		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[EnumDataType(typeof(PaymentTypeEnum), ErrorMessage = "Некорректное значение перечисления")]
		public PaymentTypeEnum PaymentType
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
