using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class NLastNotificationsRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private int _E061;

		public int TakeSize
		{
			[CompilerGenerated]
			get
			{
				return _E061;
			}
			[CompilerGenerated]
			set
			{
				_E061 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.UserNotificationView };
		}

		public NLastNotificationsRequest()
		{
			TakeSize = 5;
		}

		public NLastNotificationsRequest(int takeSize)
		{
			TakeSize = takeSize;
		}
	}
}
