using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class EmployeeRegistrationByServiceCenterRequest : EmployeeRegistrationRequest
	{
		[CompilerGenerated]
		private string _E022;

		[CompilerGenerated]
		private int _E04F;

		[CompilerGenerated]
		private string _E001;

		[Required]
		[Xin]
		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E022;
			}
			[CompilerGenerated]
			set
			{
				_E022 = value;
			}
		}

		[DisplayName("Максимальная сумма чека")]
		[Required]
		[Range(0, 1000000000, ErrorMessage = "Сумма не может принимать значение меньше 0 и больше 1000000000")]
		public virtual int MaxCheckAmount
		{
			[CompilerGenerated]
			get
			{
				return _E04F;
			}
			[CompilerGenerated]
			set
			{
				_E04F = value;
			}
		}

		[DisplayName("Номер телефона")]
		[Required]
		[RegularExpression("\\+77\\d{9}", ErrorMessage = "Номер телефона должен соответствовать формату +77XXXXXXXXX")]
		public new virtual string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinet };
		}
	}
}
