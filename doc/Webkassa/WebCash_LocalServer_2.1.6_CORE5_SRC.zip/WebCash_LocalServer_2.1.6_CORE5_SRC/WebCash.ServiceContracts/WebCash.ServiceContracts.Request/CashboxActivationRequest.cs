using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxActivationRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E017;

		[CompilerGenerated]
		private string _E018;

		[CompilerGenerated]
		private string _E019;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string CardNumber
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}

		public string ActivationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E018;
			}
			[CompilerGenerated]
			set
			{
				_E018 = value;
			}
		}

		public string PartnerXin
		{
			[CompilerGenerated]
			get
			{
				return _E019;
			}
			[CompilerGenerated]
			set
			{
				_E019 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
