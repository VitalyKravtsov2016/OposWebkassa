using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ServiceCenterRequest : AuthorizedRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinet };
		}
	}
}
