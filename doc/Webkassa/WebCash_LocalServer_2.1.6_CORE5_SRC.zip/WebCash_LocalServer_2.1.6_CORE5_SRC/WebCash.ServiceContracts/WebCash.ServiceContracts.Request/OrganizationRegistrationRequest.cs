using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class OrganizationRegistrationRequest
	{
		[CompilerGenerated]
		private OrganizationInfo _E000;

		[CompilerGenerated]
		private EmployeeInfo1C _E001;

		[Required]
		public OrganizationInfo Organization
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		public EmployeeInfo1C Employee
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
