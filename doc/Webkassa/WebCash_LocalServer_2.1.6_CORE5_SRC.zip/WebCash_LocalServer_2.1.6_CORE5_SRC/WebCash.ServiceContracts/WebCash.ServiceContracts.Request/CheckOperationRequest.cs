using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants;
using WebCash.Constants.Enums;
using WebCash.Resources;
using WebCash.ServiceContracts.PrintModule;
using WebCash.ServiceContracts.Response;

namespace WebCash.ServiceContracts.Request
{
	public class CheckOperationRequest : AuthorizedRequest, IRequest
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public IRounder _E000;

			internal bool _E000(CheckItemApiModel _E00E)
			{
				return _E00E.CalculateSum(this._E000) < 0m;
			}

			internal decimal _E001(CheckItemApiModel _E00F)
			{
				return _E00F.CalculateSum(this._E000);
			}
		}

		[CompilerGenerated]
		private sealed class _E001
		{
			public IRounder _E000;

			public CheckOperationRequest _E001;

			internal _E000<decimal, decimal> _E000(CheckItemApiModel _E01B)
			{
				return new _E000<decimal, decimal>(_E01B.CalculateSum(this._E000), _E01B.Tax);
			}

			internal bool _E001(_E000<decimal, decimal> _E01C)
			{
				return this._E001._E000(_E01C._E002, _E01C._E003) == RefTaxPercentValues.TaxEight;
			}
		}

		[CompilerGenerated]
		private string m__E000;

		[CompilerGenerated]
		private CheckItemApiModel[] _E02D;

		[CompilerGenerated]
		private OperationTypeEnum _E02E;

		[CompilerGenerated]
		private PaymentTypeInfoApiModel[] _E02F;

		[CompilerGenerated]
		private CardPaymentDetail _E030;

		[CompilerGenerated]
		private decimal? _E031;

		[CompilerGenerated]
		private decimal _E032;

		[CompilerGenerated]
		private decimal _E033;

		[CompilerGenerated]
		private string _E034;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private string _E035;

		[CompilerGenerated]
		private string _E036;

		[CompilerGenerated]
		private RoundTypeEnum _E037;

		[CompilerGenerated]
		private LotteryInfo _E038;

		[CompilerGenerated]
		private DateTime? _E009;

		[CompilerGenerated]
		private string _E039;

		[CompilerGenerated]
		private string _E03A;

		[CompilerGenerated]
		private string _E03B;

		[CompilerGenerated]
		private List<ModifierApiModel> _E03C;

		[CompilerGenerated]
		private List<TaxValueApiModel> _E03D;

		[CompilerGenerated]
		private ExtendedModuleEnum? _E03E;

		[CompilerGenerated]
		private int? _E03F;

		[CompilerGenerated]
		private DateTime? _E040;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return this.m__E000;
			}
			[CompilerGenerated]
			set
			{
				this.m__E000 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public CheckItemApiModel[] Positions
		{
			[CompilerGenerated]
			get
			{
				return _E02D;
			}
			[CompilerGenerated]
			set
			{
				_E02D = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		[Display(ResourceType = typeof(NameResource), Name = "CheckOperationType")]
		[EnumDataType(typeof(OperationTypeEnum), ErrorMessage = "Некорректное значение перечисления")]
		public OperationTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E02E;
			}
			[CompilerGenerated]
			set
			{
				_E02E = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		[Display(ResourceType = typeof(NameResource), Name = "CheckPaymentType")]
		public PaymentTypeInfoApiModel[] Payments
		{
			[CompilerGenerated]
			get
			{
				return _E02F;
			}
			[CompilerGenerated]
			set
			{
				_E02F = value;
			}
		}

		public CardPaymentDetail CardPaymentDetails
		{
			[CompilerGenerated]
			get
			{
				return _E030;
			}
			[CompilerGenerated]
			set
			{
				_E030 = value;
			}
		}

		[Range(0.0, double.MaxValue, ErrorMessage = "Значения поля Change не может быть отрицательным")]
		public decimal? Change
		{
			[CompilerGenerated]
			get
			{
				return _E031;
			}
			[CompilerGenerated]
			set
			{
				_E031 = value;
			}
		}

		[Display(Name = "Скидка на чек")]
		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Discount не может быть отрицательным или иметь больше 9 целых разрядов")]
		public decimal Discount
		{
			[CompilerGenerated]
			get
			{
				return _E032;
			}
			[CompilerGenerated]
			set
			{
				_E032 = value;
			}
		}

		[Display(Name = "Наценка на чек")]
		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Markup не может быть отрицательным или иметь больше 9 целых разрядов")]
		public decimal Markup
		{
			[CompilerGenerated]
			get
			{
				return _E033;
			}
			[CompilerGenerated]
			set
			{
				_E033 = value;
			}
		}

		[Email]
		[StringLength(50)]
		public string CustomerEmail
		{
			[CompilerGenerated]
			get
			{
				return _E034;
			}
			[CompilerGenerated]
			set
			{
				_E034 = value;
			}
		}

		[StringLength(50, ErrorMessage = "Длина поля не должна превышать 50 символов")]
		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public string ExternalOrderNumber
		{
			[CompilerGenerated]
			get
			{
				return _E035;
			}
			[CompilerGenerated]
			set
			{
				_E035 = value;
			}
		}

		public string ExternalLinkId
		{
			[CompilerGenerated]
			get
			{
				return _E036;
			}
			[CompilerGenerated]
			set
			{
				_E036 = value;
			}
		}

		[EnumDataType(typeof(RoundTypeEnum), ErrorMessage = "Некорректное значение перечисления")]
		public RoundTypeEnum RoundType
		{
			[CompilerGenerated]
			get
			{
				return _E037;
			}
			[CompilerGenerated]
			set
			{
				_E037 = value;
			}
		}

		[ShowForAppId(new string[] { "SattyZhuldyz" })]
		public LotteryInfo LotteryInfo
		{
			[CompilerGenerated]
			get
			{
				return _E038;
			}
			[CompilerGenerated]
			set
			{
				_E038 = value;
			}
		}

		public DateTime? OfflineDate
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public string OfflineNumber
		{
			[CompilerGenerated]
			get
			{
				return _E039;
			}
			[CompilerGenerated]
			set
			{
				_E039 = value;
			}
		}

		[HideForAppId(new string[] { "SattyZhuldyz", "1C" })]
		[StringLength(20)]
		public string CustomerPhone
		{
			[CompilerGenerated]
			get
			{
				return _E03A;
			}
			[CompilerGenerated]
			set
			{
				_E03A = value;
			}
		}

		[HideForAppId(new string[] { "SattyZhuldyz", "1C" })]
		[RegularExpression("^[0-9]{12}$", ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "INShouldConsistOfTwelveDigits")]
		public string CustomerXin
		{
			[CompilerGenerated]
			get
			{
				return _E03B;
			}
			[CompilerGenerated]
			set
			{
				_E03B = value;
			}
		}

		public List<ModifierApiModel> TicketModifiers
		{
			[CompilerGenerated]
			get
			{
				return _E03C;
			}
			[CompilerGenerated]
			set
			{
				_E03C = value;
			}
		}

		public List<TaxValueApiModel> TaxValues
		{
			[CompilerGenerated]
			get
			{
				return _E03D;
			}
			[CompilerGenerated]
			set
			{
				_E03D = value;
			}
		}

		public ExtendedModuleEnum? ExtendedModule
		{
			[CompilerGenerated]
			get
			{
				return _E03E;
			}
			[CompilerGenerated]
			set
			{
				_E03E = value;
			}
		}

		public int? TradeOperationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E03F;
			}
			[CompilerGenerated]
			set
			{
				_E03F = value;
			}
		}

		public DateTime? TradeOperationDate
		{
			[CompilerGenerated]
			get
			{
				return _E040;
			}
			[CompilerGenerated]
			set
			{
				_E040 = value;
			}
		}

		public CheckOperationRequest()
		{
			Positions = new CheckItemApiModel[0];
			RoundType = RoundTypeEnum.EveryItem;
			TicketModifiers = new List<ModifierApiModel>();
			TaxValues = new List<TaxValueApiModel>();
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}

		protected override IEnumerable<ValidationResult> Validate()
		{
			List<ValidationResult> list = MainValidate().ToList();
			CheckTaxExpirationDate(list);
			return list;
		}

		protected IEnumerable<ValidationResult> MainValidate()
		{
			List<ValidationResult> list = new List<ValidationResult>();
			IRounder rounder = RoundersFactory.GetRounder(RoundType);
			CheckItemApiModel[] source = Positions.Where((CheckItemApiModel _E010) => !_E010.IsStorno).ToArray();
			if (!source.Any())
			{
				list.Add(new ValidationResult(CommonResource.CheckHasNoPosition, new string[1] { _E006._E000("\ue5af\ue590\ue58c\ue596\ue58b\ue596\ue590\ue591\ue58c", 58859) }));
			}
			_E001(list);
			if (source.Any((CheckItemApiModel _E00E) => _E00E.CalculateSum(rounder) < 0m))
			{
				list.Add(new ValidationResult(CommonResource.CheckHasPositionWithAmountOfZero, new string[1] { _E006._E000("\ue5af\ue590\ue58c\ue596\ue58b\ue596\ue590\ue591\ue58c", 58859) }));
			}
			ValidateTaxes(list, rounder);
			List<decimal> list2 = (from _E011 in Positions
				where !_E011.IsStorno
				select _E011 into _E00F
				select _E00F.CalculateSum(rounder)).ToList();
			list2.AddRange(TicketModifiers.Select((ModifierApiModel _E012) => _E012.AffectedSum));
			list2.Add(rounder.RoundItem(-Discount));
			list2.Add(rounder.RoundItem(Markup));
			decimal num = rounder.RoundTotal(list2);
			if (num < 0m)
			{
				list.Add(new ValidationResult(_E006._E000("\ue3fe\ue39c\ue3e3\ue3e3\ue3ef\ue7ff\ue398\ue3ea\ue3e5\ue3ef\ue7ff\ue3e2\ue3ea\ue7ff\ue3e3\ue3e1\ue3e9\ue3ea\ue39d\ue7ff\ue3ee\ue394\ue39d\ue393\ue7ff\ue3e3\ue3ea\ue3e2\ue393\ue397\ue3ea\ue7ff\ue7ef", 59343)));
			}
			decimal num2 = Payments.Sum((PaymentTypeInfoApiModel _E013) => _E013.Sum);
			if (Payments != null && (Math.Round(num2, 0) + string.Empty).Length > 9)
			{
				return new ValidationResult[1]
				{
					new ValidationResult(_E006._E000("\uf4d6\uf4b4\uf4cb\uf4cb\uf4c7\uf0d7\uf4b0\uf4c2\uf4cd\uf4c7\uf0d7\uf4ca\uf4c2\uf0d7\uf4cb\uf4c9\uf4c1\uf4c2\uf4b5\uf0d7\uf4c6\uf4bc\uf4b5\uf4bb\uf0d7\uf4c6\uf4c9\uf4cc\uf4bb\uf4bf\uf4c2\uf0d7\uf0ce\uf0d7\uf4b1\uf4c2\uf4cc\uf4bc\uf4b2\uf0d7\uf4b7\uf4c7\uf4c0\uf4b7\uf4b8\uf4c3\uf4c9\uf4c5", 61488))
				};
			}
			if (Change.HasValue)
			{
				if (num != num2 - Change.Value)
				{
					list.Add(new ValidationResult(string.Format(_E006._E000("\uf7de\uf7bc\uf7c3\uf7c3\uf7cf\uf3df\uf7b8\uf7ca\uf7c5\uf7cf\uf3df\uf3d7\uf384\uf3cf\uf3c5\uf391\uf3cd\uf382\uf3d6\uf3df\uf7c2\uf7ca\uf3df\uf7be\uf7c1\uf7cd\uf7c0\uf7cf\uf7cb\uf7cf\uf7ca\uf7bd\uf3df\uf7be\uf3df\uf7be\uf7bc\uf7c3\uf7c3\uf7c1\uf7c6\uf3df\uf7c0\uf7c4\uf7cf\uf7bd\uf7ca\uf7c9\uf7ca\uf7c6\uf3df\uf3d7\uf384\uf3ce\uf3c5\uf391\uf3cd\uf382\uf3d6\uf3df\uf7c7\uf3df\uf7be\uf7cb\uf7cf\uf7b8\uf7ca\uf7c6\uf3df\uf3d7\uf384\uf3cd\uf3c5\uf391\uf3cd\uf382\uf3d6", 62255), num, num2, Change.Value), new string[0]));
				}
			}
			else if (num > num2)
			{
				list.Add(new ValidationResult(string.Format(_E006._E000("\uf79e\uf7fc\uf783\uf783\uf78f\uf39f\uf7f8\uf78a\uf785\uf78f\uf39f\uf397\uf3c4\uf38f\uf385\uf3d1\uf38d\uf3c2\uf396\uf39f\uf78e\uf781\uf784\uf7f3\uf7f7\uf78a\uf39f\uf7fe\uf7fc\uf783\uf783\uf7f4\uf39f\uf780\uf784\uf78f\uf7fd\uf78a\uf789\uf78a\uf786\uf39f\uf397\uf3c4\uf38e\uf385\uf3d1\uf38d\uf3c2\uf396", 62395), num, num2), new string[0]));
			}
			decimal num3 = Payments.Where((PaymentTypeInfoApiModel _E014) => _E014.PaymentType != PaymentTypeEnum.PAYMENT_CASH).Sum((PaymentTypeInfoApiModel _E015) => _E015.Sum);
			if (num3 > num)
			{
				list.Add(new ValidationResult(string.Format(_E006._E000("\uedfc\uedd3\uedd0\uedaf\uedd6\uedd2\uedde\ueda1\ue9ce\ueddf\ueddb\uedd9\uedd3\uedde\uedd5\uedd6\ueda9\uedd3\uedd0\uedd7\ue9ce\uedd0\uedd1\uedd5\uedde\uedac\uedd0\uedd7\ue9ce\uedaf\uedad\uedd2\uedd2\uedde\ue9ce\ue9c6\ue995\ue9de\ue9d4\ue980\ue9dc\ue993\ue9c7\ue9ce\ueddf\uedd0\uedd5\ueda2\ueda6\ueddb\ue9ce\uedaf\uedad\uedd2\uedd2\ueda5\ue9ce\ueda9\ueddb\uedd4\uedde\ue9c6\ue995\ue9df\ue9d4\ue980\ue9dc\ue993\ue9c7", 59812), num3, num), new string[0]));
			}
			if (OperationType != 0 && LotteryInfo != null)
			{
				list.Add(new ValidationResult(_E006._E000("\ue499\ue4bc\ue4c5\ue4bf\ue4c1\ue4bd\ue4b1\ue4c7\ue4b9\ue4ce\ue0a1\ue4be\ue4bf\ue0a1\ue4b3\ue4ca\ue4b9\ue4b2\ue4c1\ue4ca\ue4c9\ue4c2\ue0a1\ue4b6\ue4b1\ue4be\ue4bf\ue4ba\ue4bc\ue4ce\ue4b4\ue4c3\ue4c0\ue4ce\ue0a1\ue4c3\ue4bf\ue4ba\ue4cd\ue4bb\ue4bf\ue0a1\ue4b5\ue4ba\ue4ce\ue0a1\ue4bf\ue4be\ue4b4\ue4c1\ue4b1\ue4c7\ue4b9\ue4b8\ue0a1\ue4c3\ue4b9\ue4be\ue4b1\ue0a1\ue49e\ue4bf\ue4bb\ue4c2\ue4be\ue4bb\ue4b1", 57473), new string[2]
				{
					_E006._E000("\ue773\ue750\ue74b\ue74b\ue75a\ue74d\ue746\ue776\ue751\ue759\ue750", 59163),
					_E006._E000("\uedb0\ued8f\ued9a\ued8d\ued9e\ued8b\ued96\ued90\ued91\uedab\ued86\ued8f\ued9a", 60887)
				}));
			}
			return list;
		}

		protected virtual void ValidateTaxes(List<ValidationResult> list, IRounder rounder)
		{
			foreach (CheckItemApiModel item in Positions.Where((CheckItemApiModel _E016) => _E016.TaxType >= 0 && _E016.TaxValidationType == TaxValidationTypeEnum.FullValidate))
			{
				Validator validator = new Validator(list, string.Format(_E006._E000("\uef80\uefa1\uefa8\uefa7\uefd9\uefa7\uefd0\uebbf\uebb8\uebe4\uebaf\uebe2\uebb8\ueba5\uebbf", 60165), item.PositionName));
				decimal num = 0.0m;
				if (item.TaxType == 100)
				{
					if (!item.TaxPercent.HasValue)
					{
						break;
					}
					num = (decimal)item.TaxPercent.Value / 100m;
				}
				validator.Equal(item.Tax, Math.Round(item.CalculateSum(rounder) * num / (1m + num), 2, MidpointRounding.AwayFromZero), _E006._E000("\ue7a2\ue78f\ue784\ue781\ue78c\ue39f\ue780\ue781\ue78b\ue7fe\ue7f8\ue787\ue7fd\ue78f\ue782\ue39f\ue782\ue78a\ue78d\ue78a\ue7ff\ue782\ue781\ue391", 58299));
			}
		}

		protected void CheckTaxExpirationDate(List<ValidationResult> list)
		{
			IRounder rounder = RoundersFactory.GetRounder(RoundType);
			DateTime dateTime = (OfflineDate.HasValue ? OfflineDate.Value : DateTime.Now);
			if (new DateTime(2020, 10, 1) < dateTime)
			{
				byte[] source = (from _E017 in Positions
					where _E017.TaxPercent.HasValue
					select _E017 into _E018
					select _E018.TaxPercent.Value).ToArray();
				_E000<decimal, decimal>[] source2 = (from _E019 in Positions
					where !_E019.TaxPercent.HasValue && _E019.Tax > 0m
					select _E019 into _E01B
					select new _E000<decimal, decimal>(_E01B.CalculateSum(rounder), _E01B.Tax)).ToArray();
				if (source.Any((byte _E01A) => _E01A == RefTaxPercentValues.TaxEight) || source2.Any((_E000<decimal, decimal> _E01C) => _E000(_E01C._E002, _E01C._E003) == RefTaxPercentValues.TaxEight))
				{
					list.Add(new ValidationResult(_E006._E000("\uf5d6\uf5b5\uf5c7\uf5c5\uf5cd\uf5c7\uf1d7\uf5ea\uf5e3\uf5d6\uf1d7\uf1cf\uf1d2\uf1d7\uf5ca\uf5c2\uf1d7\uf5c8\uf5c9\uf5c3\uf5c3\uf5c2\uf5b7\uf5c1\uf5cf\uf5c5\uf5c7\uf5c2\uf5b5\uf5b6\uf5b8", 61907)));
				}
			}
		}

		private byte _E000(decimal _E00B, decimal _E00C)
		{
			if (_E00B < 2m)
			{
				return 12;
			}
			decimal num = Math.Round(100m * _E00C / (_E00B - _E00C), 0, MidpointRounding.AwayFromZero);
			if (num < 1m || num > 255m)
			{
				return 12;
			}
			return (byte)num;
		}

		private void _E001(List<ValidationResult> _E00D)
		{
			CheckItemApiModel[] positions = Positions;
			foreach (CheckItemApiModel checkItemApiModel in positions)
			{
				if (checkItemApiModel.WarehouseType == WarehouseTypeEnum.VirtualWarehouseProduct)
				{
					if (!string.IsNullOrEmpty(checkItemApiModel.Gtin) && checkItemApiModel.ProductId.HasValue)
					{
						_E00D.Add(new ValidationResult(_E006._E000("\ue220\ue201\ue208\ue207\ue279\ue207\ue270\ue61f\ue618", 58886) + checkItemApiModel.PositionName + _E006._E000("\ue898\ue885\ue89f\uec8b\uec84\uecf0\ue89f\ue8e8\ue8de\ue8cd\ue8da\ue8d7\ue8d0\ue8ca\ue8cc\ue8da\ue8eb\ue8c6\ue8cf\ue8da\ue89f\ue882\ue89f\ue88e\ue89f\uec8b\uec81\uec80\uecfc\uecfe\uec85\uec8f\uec8a\uecfd\uecfe\uecf0\ue89f\uec88\uec8f\uec80\uec81\uec84\uec82\uec8a\uec82\uec87\uec8a\ue89f\uec81\uec8b\uec82\uec81\uec8c\uec81\ue89f\uec87\uec88\ue89f\uec80\uec81\uec84\uec8a\uec86\ue885\ue89f\ue8f8\ue8cb\ue8d6\ue8d1\ue89f\uec87\uec84\uec87\ue89f\ue8ef\ue8cd\ue8d0\ue8db\ue8ca\ue8dc\ue8cb\ue8f6\ue8db", 59558)));
					}
					else if (string.IsNullOrEmpty(checkItemApiModel.Gtin) && !checkItemApiModel.ProductId.HasValue)
					{
						_E00D.Add(new ValidationResult(_E006._E000("\ue220\ue201\ue208\ue207\ue279\ue207\ue270\ue61f\ue618", 58886) + checkItemApiModel.PositionName + _E006._E000("\uf8d8\uf8c5\uf8dfﳋﳄﲰ\uf8df\uf8a8\uf89e\uf88d\uf89a\uf897\uf890\uf88a\uf88c\uf89a\uf8ab\uf886\uf88f\uf89a\uf8df\uf8c2\uf8df\uf8ce\uf8dfﳁﳎﲰﳈﳏﲽﳊﳄﲳﳂﳁ\uf8dfﳈﳏﳀﳁﳄﳂﳊﳂﳇﳊ\uf8dfﳁﳋﳂﳁﳌﳁ\uf8dfﳇﳈ\uf8dfﳀﳁﳄﳊﳆ\uf8c5\uf8df\uf8b8\uf88b\uf896\uf891\uf8dfﳇﳄﳇ\uf8df\uf8af\uf88d\uf890\uf89b\uf88a\uf89c\uf88b\uf8b6\uf89b", 63589)));
					}
				}
			}
		}
	}
}
