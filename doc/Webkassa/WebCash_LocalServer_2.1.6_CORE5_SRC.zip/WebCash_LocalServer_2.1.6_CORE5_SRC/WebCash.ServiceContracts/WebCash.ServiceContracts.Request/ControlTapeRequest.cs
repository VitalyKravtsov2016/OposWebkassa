using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request
{
	public class ControlTapeRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private int _E046;

		[CompilerGenerated]
		private string _E000;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public int ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E046;
			}
			[CompilerGenerated]
			set
			{
				_E046 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
