using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class NotificationCreationRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E064;

		[CompilerGenerated]
		private string _E065;

		[CompilerGenerated]
		private NotificationCreationRecipientType _E066;

		[CompilerGenerated]
		private ViewTextTypeEnum _E067;

		public string Title
		{
			[CompilerGenerated]
			get
			{
				return _E064;
			}
			[CompilerGenerated]
			set
			{
				_E064 = value;
			}
		}

		public string Content
		{
			[CompilerGenerated]
			get
			{
				return _E065;
			}
			[CompilerGenerated]
			set
			{
				_E065 = value;
			}
		}

		public NotificationCreationRecipientType RecipientType
		{
			[CompilerGenerated]
			get
			{
				return _E066;
			}
			[CompilerGenerated]
			set
			{
				_E066 = value;
			}
		}

		public virtual ViewTextTypeEnum TextType
		{
			[CompilerGenerated]
			get
			{
				return _E067;
			}
			[CompilerGenerated]
			set
			{
				_E067 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.UserNotificationCreation };
		}
	}
}
