using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class TaxValueApiModel
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private TaxTypeEnum _E001;

		public decimal Amount
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[EnumDataType(typeof(TaxTypeEnum), ErrorMessage = "Некорректное значение перечисления")]
		public TaxTypeEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
