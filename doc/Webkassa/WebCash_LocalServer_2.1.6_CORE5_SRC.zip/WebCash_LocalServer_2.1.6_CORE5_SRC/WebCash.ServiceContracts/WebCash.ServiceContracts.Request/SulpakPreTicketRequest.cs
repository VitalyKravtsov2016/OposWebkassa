using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class SulpakPreTicketRequest
	{
		[CompilerGenerated]
		private string _E000;

		public string CardNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}
	}
}
