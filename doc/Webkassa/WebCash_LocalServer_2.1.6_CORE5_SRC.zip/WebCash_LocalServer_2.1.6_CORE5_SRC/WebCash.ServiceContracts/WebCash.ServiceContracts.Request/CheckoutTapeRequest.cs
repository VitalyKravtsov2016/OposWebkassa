using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class CheckoutTapeRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long _E016;

		[CompilerGenerated]
		private long _E015;

		[Required]
		public long CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		[Required]
		public long ShiftId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}
	}
}
