namespace WebCash.ServiceContracts.Request
{
	public class PartnerListRequest : AuthorizedRequest
	{
	}
}
