using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class ProgrammingRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long? _E016;

		[CompilerGenerated]
		private string _E000;

		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		public long? CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.Programming };
		}
	}
}
