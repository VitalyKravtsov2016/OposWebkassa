using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class MoneyPackagePageRequest : PageRequest
	{
		[CompilerGenerated]
		private long _E046;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(Name = "Номер смены")]
		[JsonProperty(Required = Required.Always)]
		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E046;
			}
			[CompilerGenerated]
			set
			{
				_E046 = value;
			}
		}
	}
}
