using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ServiceCenterDetailRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E075;

		[CompilerGenerated]
		private long _E076;

		[CompilerGenerated]
		private TariffPlanTypeEnum _E077;

		[CompilerGenerated]
		private DateTime _E078;

		[Required]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		public string CashboxRegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E075;
			}
			[CompilerGenerated]
			set
			{
				_E075 = value;
			}
		}

		[Required]
		[Range(1.0, 9.223372036854776E+18)]
		public long CashboxIdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E076;
			}
			[CompilerGenerated]
			set
			{
				_E076 = value;
			}
		}

		[Required]
		public TariffPlanTypeEnum ServiceType
		{
			[CompilerGenerated]
			get
			{
				return _E077;
			}
			[CompilerGenerated]
			set
			{
				_E077 = value;
			}
		}

		[Required]
		public DateTime ActivationDate
		{
			[CompilerGenerated]
			get
			{
				return _E078;
			}
			[CompilerGenerated]
			set
			{
				_E078 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.SystemViewInformationAboutOrganization };
		}
	}
}
