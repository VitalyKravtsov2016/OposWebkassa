using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxActivationServiceCenterRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E01A;

		[CompilerGenerated]
		private string _E01B;

		[Required]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[JsonProperty("РackageType")]
		public string PackageTypeWrong
		{
			[CompilerGenerated]
			get
			{
				return _E01A;
			}
			[CompilerGenerated]
			set
			{
				_E01A = value;
			}
		}

		[JsonProperty("PackageType")]
		public string PackageTypeRight
		{
			[CompilerGenerated]
			get
			{
				return _E01B;
			}
			[CompilerGenerated]
			set
			{
				_E01B = value;
			}
		}

		[Required]
		[RegularExpression("(MTIS31)|(BFY)|(MOB)|(12M)|(6M)|(1M)|(BF)|Y|H|M|F|C|(PM)", ErrorMessage = "Не найдено соответствий типов пакета в системе")]
		[JsonIgnore]
		public string PackageType => PackageTypeRight ?? PackageTypeWrong;

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinet };
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
