using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ListCashboxesRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private ExternalSystemsEnum? _E05B;

		public ExternalSystemsEnum? ExternalSystem
		{
			[CompilerGenerated]
			get
			{
				return _E05B;
			}
			[CompilerGenerated]
			set
			{
				_E05B = value;
			}
		}
	}
}
