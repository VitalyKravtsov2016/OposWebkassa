using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class GenerateDynamicQrRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E056;

		[CompilerGenerated]
		private string _E057;

		[CompilerGenerated]
		private decimal _E058;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string ExternalTicketNumber
		{
			[CompilerGenerated]
			get
			{
				return _E056;
			}
			[CompilerGenerated]
			set
			{
				_E056 = value;
			}
		}

		public string DeviceUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E057;
			}
			[CompilerGenerated]
			set
			{
				_E057 = value;
			}
		}

		public decimal Amount
		{
			[CompilerGenerated]
			get
			{
				return _E058;
			}
			[CompilerGenerated]
			set
			{
				_E058 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.QRCodeRegistration };
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
