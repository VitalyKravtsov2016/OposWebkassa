namespace WebCash.ServiceContracts.Request
{
	public class EmployeePinsRequest : AuthorizedRequest
	{
	}
}
