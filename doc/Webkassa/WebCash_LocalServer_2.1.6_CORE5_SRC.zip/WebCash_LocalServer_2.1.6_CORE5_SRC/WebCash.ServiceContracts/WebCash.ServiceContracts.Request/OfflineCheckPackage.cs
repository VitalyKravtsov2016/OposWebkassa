using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class OfflineCheckPackage : AuthorizedRequest
	{
		[CompilerGenerated]
		private OfflineCheckOperationRequest[] _E069;

		public OfflineCheckOperationRequest[] Checks
		{
			[CompilerGenerated]
			get
			{
				return _E069;
			}
			[CompilerGenerated]
			set
			{
				_E069 = value;
			}
		}

		public OfflineCheckPackage()
		{
			Checks = new OfflineCheckOperationRequest[0];
		}
	}
}
