using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ExternalModuleStatusRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private DateTimeOffset _E001;

		[CompilerGenerated]
		private DateTimeOffset? _E002;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public DateTimeOffset SystemDateTime
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public DateTimeOffset? LastCommandDateTime
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
