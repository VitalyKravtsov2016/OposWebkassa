using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class NotificationSettingsSaveRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private NotificationSettingsItem[] _E068;

		public NotificationSettingsItem[] Items
		{
			[CompilerGenerated]
			get
			{
				return _E068;
			}
			[CompilerGenerated]
			set
			{
				_E068 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.UserNotificationsettings };
		}

		public NotificationSettingsSaveRequest()
		{
			Items = new NotificationSettingsItem[0];
		}
	}
}
