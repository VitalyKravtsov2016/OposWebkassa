using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class DatePageRequest : PageRequest
	{
		[CompilerGenerated]
		private DateTime? _E072;

		[CompilerGenerated]
		private DateTime? _E073;

		[Display(Name = "Дата от")]
		public DateTime? FromDate
		{
			[CompilerGenerated]
			get
			{
				return _E072;
			}
			[CompilerGenerated]
			set
			{
				_E072 = value;
			}
		}

		[Display(Name = "Дата до")]
		public DateTime? ToDate
		{
			[CompilerGenerated]
			get
			{
				return _E073;
			}
			[CompilerGenerated]
			set
			{
				_E073 = value;
			}
		}
	}
}
