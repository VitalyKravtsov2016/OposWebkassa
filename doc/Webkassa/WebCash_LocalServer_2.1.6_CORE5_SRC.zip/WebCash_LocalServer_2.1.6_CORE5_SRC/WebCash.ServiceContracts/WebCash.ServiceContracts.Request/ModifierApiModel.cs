using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ModifierApiModel
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private double _E002;

		[CompilerGenerated]
		private ModifierTypeEnum _E003;

		[CompilerGenerated]
		private int _E004;

		[CompilerGenerated]
		private decimal _E005;

		[CompilerGenerated]
		private byte? _E006;

		[CompilerGenerated]
		private bool _E007;

		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[StringLength(50, ErrorMessage = "Длина поля не должна превышать 50 символов")]
		public string Text
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public double Percent
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public ModifierTypeEnum Type
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public int TaxType
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public decimal Tax
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public byte? TaxPercent
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public bool IsStorned
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public decimal AffectedSum => Type switch
		{
			ModifierTypeEnum.Discount => -Sum, 
			ModifierTypeEnum.Markup => Sum, 
			_ => throw new ArgumentOutOfRangeException(), 
		};
	}
}
