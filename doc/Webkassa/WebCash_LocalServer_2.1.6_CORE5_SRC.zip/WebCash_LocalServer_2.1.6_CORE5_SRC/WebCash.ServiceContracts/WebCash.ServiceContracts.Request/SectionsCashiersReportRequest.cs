using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request
{
	public class SectionsCashiersReportRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long _E016;

		[CompilerGenerated]
		private long _E015;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public long CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public long ShiftId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}
	}
}
