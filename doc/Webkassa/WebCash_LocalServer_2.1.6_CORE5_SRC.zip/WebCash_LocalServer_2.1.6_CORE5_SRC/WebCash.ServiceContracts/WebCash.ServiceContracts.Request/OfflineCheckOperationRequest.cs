using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class OfflineCheckOperationRequest : CheckOperationRequest, IOfflinePackage
	{
		[CompilerGenerated]
		private string _E039;

		public new string OfflineNumber
		{
			[CompilerGenerated]
			get
			{
				return _E039;
			}
			[CompilerGenerated]
			set
			{
				_E039 = value;
			}
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return MainValidate();
		}
	}
}
