using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.ServiceContracts.PrintModule;

namespace WebCash.ServiceContracts.Request
{
	public class ZReportRequest : BaseReportRequest, IXzReport, IRequest
	{
		[CompilerGenerated]
		private bool _E082;

		public bool Withdrawal
		{
			[CompilerGenerated]
			get
			{
				return _E082;
			}
			[CompilerGenerated]
			set
			{
				_E082 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.CloseShift };
		}

		public override string GetCashboxUniqueName()
		{
			return base.CashboxUniqueNumber;
		}
	}
}
