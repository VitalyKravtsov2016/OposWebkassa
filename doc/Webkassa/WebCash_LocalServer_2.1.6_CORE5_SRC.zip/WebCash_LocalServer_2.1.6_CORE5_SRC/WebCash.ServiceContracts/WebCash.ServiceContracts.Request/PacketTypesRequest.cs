using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class PacketTypesRequest : WebInterfaceRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[4]
			{
				PermissionEnum.Administrator,
				PermissionEnum.ServiceCenterCabinet,
				PermissionEnum.SupportCabinet,
				PermissionEnum.SystemCabinet
			};
		}

		public override RequireType GetRequireType()
		{
			return RequireType.Any;
		}
	}
}
