using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class AccessToCashboxesRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string[] _E005;

		[Required]
		public string EmployeeLogin
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public string[] Cashboxes
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}
	}
}
