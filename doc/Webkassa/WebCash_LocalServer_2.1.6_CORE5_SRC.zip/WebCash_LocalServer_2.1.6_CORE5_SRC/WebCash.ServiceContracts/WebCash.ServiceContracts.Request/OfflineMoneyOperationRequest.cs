using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebCash.ServiceContracts.Request
{
	public class OfflineMoneyOperationRequest : MoneyOperationRequest
	{
		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return Validate();
		}
	}
}
