using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ShowForAppIdAttribute : Attribute
	{
		[CompilerGenerated]
		private readonly string[] _E000;

		public string[] AppIdentificators
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
		}

		public ShowForAppIdAttribute(params string[] appIdentificators)
		{
			_E000 = appIdentificators;
		}
	}
}
