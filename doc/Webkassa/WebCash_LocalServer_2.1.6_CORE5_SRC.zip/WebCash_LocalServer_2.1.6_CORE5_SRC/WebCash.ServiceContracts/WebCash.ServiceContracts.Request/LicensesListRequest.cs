namespace WebCash.ServiceContracts.Request
{
	public class LicensesListRequest : AuthorizedRequest
	{
	}
}
