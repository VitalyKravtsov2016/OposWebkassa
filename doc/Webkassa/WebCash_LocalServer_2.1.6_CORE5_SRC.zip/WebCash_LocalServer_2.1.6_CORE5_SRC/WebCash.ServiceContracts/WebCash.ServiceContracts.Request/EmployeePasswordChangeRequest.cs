using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class EmployeePasswordChangeRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E04D;

		[CompilerGenerated]
		private string _E04E;

		[Required]
		public string OldPassword
		{
			[CompilerGenerated]
			get
			{
				return _E04D;
			}
			[CompilerGenerated]
			set
			{
				_E04D = value;
			}
		}

		[RegularExpression("(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\da-zA-Z]*).{8,}", ErrorMessage = "Пароль должен содержать знаки: A-Z, a-z, 0-9")]
		[Required]
		public string NewPassword
		{
			[CompilerGenerated]
			get
			{
				return _E04E;
			}
			[CompilerGenerated]
			set
			{
				_E04E = value;
			}
		}
	}
}
