using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ChangeDeviceTradepointRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E026;

		[CompilerGenerated]
		private long _E027;

		[Required]
		public string DeviceId
		{
			[CompilerGenerated]
			get
			{
				return _E026;
			}
			[CompilerGenerated]
			set
			{
				_E026 = value;
			}
		}

		[Required]
		public long TradePointId
		{
			[CompilerGenerated]
			get
			{
				return _E027;
			}
			[CompilerGenerated]
			set
			{
				_E027 = value;
			}
		}
	}
}
