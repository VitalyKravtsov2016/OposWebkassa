using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ShiftRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long? _E016;

		[CompilerGenerated]
		private DateTime _E047;

		[CompilerGenerated]
		private DateTime _E048;

		public long? CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public DateTime DateFrom
		{
			[CompilerGenerated]
			get
			{
				return _E047;
			}
			[CompilerGenerated]
			set
			{
				_E047 = value;
			}
		}

		public DateTime DateTo
		{
			[CompilerGenerated]
			get
			{
				return _E048;
			}
			[CompilerGenerated]
			set
			{
				_E048 = value;
			}
		}
	}
}
