namespace WebCash.ServiceContracts.Request
{
	public class OrganizationInfoRequest : AuthorizedRequest
	{
	}
}
