using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CancelledTicketsWebInterfaceRequest : WebInterfaceRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.CancelledTicketsView };
		}
	}
}
