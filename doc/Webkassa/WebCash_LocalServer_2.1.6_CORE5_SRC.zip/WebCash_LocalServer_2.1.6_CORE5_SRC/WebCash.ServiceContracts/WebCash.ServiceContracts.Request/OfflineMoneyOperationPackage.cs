using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class OfflineMoneyOperationPackage : AuthorizedRequest
	{
		[CompilerGenerated]
		private OfflineMoneyOperationRequest[] _E06A;

		public OfflineMoneyOperationRequest[] MoneyOperations
		{
			[CompilerGenerated]
			get
			{
				return _E06A;
			}
			[CompilerGenerated]
			set
			{
				_E06A = value;
			}
		}

		public OfflineMoneyOperationPackage()
		{
			MoneyOperations = new OfflineMoneyOperationRequest[0];
		}
	}
}
