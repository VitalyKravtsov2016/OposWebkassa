namespace WebCash.ServiceContracts.Request
{
	public class EmployeeListRequest : AuthorizedRequest
	{
	}
}
