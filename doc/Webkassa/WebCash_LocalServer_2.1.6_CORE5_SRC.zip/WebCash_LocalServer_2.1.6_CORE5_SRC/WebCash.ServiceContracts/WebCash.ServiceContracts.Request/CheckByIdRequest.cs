using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class CheckByIdRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private long _E028;

		public long Id
		{
			[CompilerGenerated]
			get
			{
				return _E028;
			}
			[CompilerGenerated]
			set
			{
				_E028 = value;
			}
		}
	}
}
