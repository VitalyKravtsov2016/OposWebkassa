using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class MobileCheckItemApiModel : CheckItemApiModel
	{
		[CompilerGenerated]
		private decimal _E017;

		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}
	}
}
