namespace WebCash.ServiceContracts.Request
{
	public interface IXzReport
	{
		string CashboxUniqueNumber { get; set; }

		bool AsImage { get; set; }
	}
}
