namespace WebCash.ServiceContracts.Request
{
	public class ExciseSeriesListRequest : AuthorizedRequest
	{
	}
}
