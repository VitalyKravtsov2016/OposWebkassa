using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebCash.ServiceContracts.Request
{
	public class WebInterfaceRequest : AuthorizedRequest
	{
		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			List<ValidationResult> list = new List<ValidationResult>();
			list.AddRange(Validate());
			return list;
		}
	}
}
