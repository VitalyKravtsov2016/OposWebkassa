using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class OrganizationRegistrationServiceCenterRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private OrganizationInfo _E06E;

		[CompilerGenerated]
		private ExtendedEmployeeInfo _E06F;

		[Required]
		public OrganizationInfo Organization
		{
			[CompilerGenerated]
			get
			{
				return _E06E;
			}
			[CompilerGenerated]
			set
			{
				_E06E = value;
			}
		}

		[Required]
		public ExtendedEmployeeInfo Employee
		{
			[CompilerGenerated]
			get
			{
				return _E06F;
			}
			[CompilerGenerated]
			set
			{
				_E06F = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinet };
		}
	}
}
