using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ExciseCheckByUsidRequest : BaseExciseCheckRequest
	{
		[CompilerGenerated]
		private string _E054;

		public string Usid
		{
			[CompilerGenerated]
			get
			{
				return _E054;
			}
			[CompilerGenerated]
			set
			{
				_E054 = value;
			}
		}
	}
}
