using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class NotificationChangeReadStatusRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long _E062;

		[CompilerGenerated]
		private ReadStatusEnum _E063;

		public long NotificationId
		{
			[CompilerGenerated]
			get
			{
				return _E062;
			}
			[CompilerGenerated]
			set
			{
				_E062 = value;
			}
		}

		public ReadStatusEnum NewReadStatus
		{
			[CompilerGenerated]
			get
			{
				return _E063;
			}
			[CompilerGenerated]
			set
			{
				_E063 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.UserNotificationView };
		}
	}
}
