using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class SearchTicketsRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E029;

		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E029;
			}
			[CompilerGenerated]
			set
			{
				_E029 = value;
			}
		}
	}
}
