using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class MobileCashboxModel : CashboxModel
	{
		[CompilerGenerated]
		private string _E008;

		[CompilerGenerated]
		private bool _E009;

		[CompilerGenerated]
		private bool _E00A;

		[CompilerGenerated]
		private bool _E00B;

		[CompilerGenerated]
		private bool _E00C;

		[CompilerGenerated]
		private bool _E00D;

		[CompilerGenerated]
		private string _E00E;

		public string DeviceSerialNumber
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		public bool AllowOfflineChecks
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public bool AllowSpecialOfflineChecks
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public bool HasActivePacket
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public bool ReInitOfflineState
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public bool KaspiQrSupported
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public string ReferralLink
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}
	}
}
