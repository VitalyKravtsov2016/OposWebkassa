using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public abstract class BaseEmployeeInfo
	{
		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private int? _E001;

		[CompilerGenerated]
		private string _E000;

		[DisplayName("Полное имя")]
		[StringLength(255, MinimumLength = 1, ErrorMessage = "Длина имени кассира должна быть не менее 1 и не более 255 символов")]
		public virtual string FullName
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[DisplayName("Email")]
		[StringLength(50, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "LengthCanBeMaximum50Symbols")]
		[Required]
		[Email]
		public string Email
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[DisplayName("Пароль")]
		[RegularExpression("(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\da-zA-Z]*).{8,}", ErrorMessage = "Пароль должен содержать знаки: A-Z, a-z, 0-9")]
		[Required]
		public string Password
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[DisplayName("Максимальная сумма чека")]
		[Range(0, 1000000000, ErrorMessage = "Сумма не может принимать значение меньше 0 и больше 1000000000")]
		public virtual int? MaxCheckAmount
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[DisplayName("Номер телефона")]
		[RegularExpression("\\+77\\d{9}", ErrorMessage = "Номер телефона должен соответствовать формату +77XXXXXXXXX")]
		[StringLength(12, MinimumLength = 12, ErrorMessage = "Номер телефона должен содержать 12 знаков")]
		public virtual string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}
	}
}
