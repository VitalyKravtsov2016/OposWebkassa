using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class OfflineXzReportRequest : AuthorizedRequest, IXzReport, IOfflinePackage
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool _E00A;

		[CompilerGenerated]
		private ReportTypeEnum _E06C;

		[CompilerGenerated]
		private DateTime? _E009;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private bool _E06D;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public bool AsImage
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public ReportTypeEnum ReportType
		{
			[CompilerGenerated]
			get
			{
				return _E06C;
			}
			[CompilerGenerated]
			set
			{
				_E06C = value;
			}
		}

		public DateTime? OfflineDate
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public bool AutoWithdrawal
		{
			[CompilerGenerated]
			get
			{
				return _E06D;
			}
			[CompilerGenerated]
			set
			{
				_E06D = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[2]
			{
				PermissionEnum.CreateXReport,
				PermissionEnum.CloseShift
			};
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return base.Validate();
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
