using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class HistoryTicketPaymentsRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private long _E015;

		[CompilerGenerated]
		private long[] _E059;

		public long ShiftId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public long[] TicketIds
		{
			[CompilerGenerated]
			get
			{
				return _E059;
			}
			[CompilerGenerated]
			set
			{
				_E059 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.CheckHistory };
		}
	}
}
