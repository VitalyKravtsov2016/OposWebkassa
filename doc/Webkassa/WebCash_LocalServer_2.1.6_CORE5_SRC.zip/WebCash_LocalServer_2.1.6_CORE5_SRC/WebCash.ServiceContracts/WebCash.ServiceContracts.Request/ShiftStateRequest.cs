using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class ShiftStateRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
