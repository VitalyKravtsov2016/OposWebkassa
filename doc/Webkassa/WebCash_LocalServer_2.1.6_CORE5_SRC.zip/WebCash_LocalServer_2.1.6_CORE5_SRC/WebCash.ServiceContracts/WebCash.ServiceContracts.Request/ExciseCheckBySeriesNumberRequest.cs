using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ExciseCheckBySeriesNumberRequest : BaseExciseCheckRequest
	{
		[CompilerGenerated]
		private string _E053;

		[CompilerGenerated]
		private string _E029;

		public string Series
		{
			[CompilerGenerated]
			get
			{
				return _E053;
			}
			[CompilerGenerated]
			set
			{
				_E053 = value;
			}
		}

		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E029;
			}
			[CompilerGenerated]
			set
			{
				_E029 = value;
			}
		}
	}
}
