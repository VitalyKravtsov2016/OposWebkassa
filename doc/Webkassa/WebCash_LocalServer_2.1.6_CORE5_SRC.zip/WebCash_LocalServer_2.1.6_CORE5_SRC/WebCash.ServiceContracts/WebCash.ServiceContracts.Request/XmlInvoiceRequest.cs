using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class XmlInvoiceRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E081;

		[Required]
		public string CacheGuid
		{
			[CompilerGenerated]
			get
			{
				return _E081;
			}
			[CompilerGenerated]
			set
			{
				_E081 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.BookKeeping };
		}
	}
}
