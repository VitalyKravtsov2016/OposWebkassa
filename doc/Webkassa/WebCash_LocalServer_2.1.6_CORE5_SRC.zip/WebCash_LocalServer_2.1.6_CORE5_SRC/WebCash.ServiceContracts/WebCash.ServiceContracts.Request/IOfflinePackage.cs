using System;

namespace WebCash.ServiceContracts.Request
{
	public interface IOfflinePackage
	{
		DateTime? OfflineDate { get; set; }

		string ExternalCheckNumber { get; set; }
	}
}
