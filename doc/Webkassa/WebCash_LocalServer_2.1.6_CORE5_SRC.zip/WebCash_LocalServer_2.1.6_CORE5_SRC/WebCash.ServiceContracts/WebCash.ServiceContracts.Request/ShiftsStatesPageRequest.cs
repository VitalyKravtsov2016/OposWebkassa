namespace WebCash.ServiceContracts.Request
{
	public class ShiftsStatesPageRequest : BasePageRequest
	{
	}
}
