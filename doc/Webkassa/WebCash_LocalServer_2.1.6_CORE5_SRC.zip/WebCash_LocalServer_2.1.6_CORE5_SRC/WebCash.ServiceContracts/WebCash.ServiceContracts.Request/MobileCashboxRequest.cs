using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;
using WebCash.ServiceContracts.PrintModule;

namespace WebCash.ServiceContracts.Request
{
	public class MobileCashboxRequest : AuthorizedRequest, IRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E024;

		[CompilerGenerated]
		private string _E05C;

		[CompilerGenerated]
		private string _E05D;

		[CompilerGenerated]
		private string _E05E;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string ProductVersion
		{
			[CompilerGenerated]
			get
			{
				return _E024;
			}
			[CompilerGenerated]
			set
			{
				_E024 = value;
			}
		}

		public string Platform
		{
			[CompilerGenerated]
			get
			{
				return _E05C;
			}
			[CompilerGenerated]
			set
			{
				_E05C = value;
			}
		}

		public string PlatformSerialNumber
		{
			[CompilerGenerated]
			get
			{
				return _E05D;
			}
			[CompilerGenerated]
			set
			{
				_E05D = value;
			}
		}

		public string Settings
		{
			[CompilerGenerated]
			get
			{
				return _E05E;
			}
			[CompilerGenerated]
			set
			{
				_E05E = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
