using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxRegistrationRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E021;

		[CompilerGenerated]
		private long _E023;

		[CompilerGenerated]
		private CashboxTimeZoneEnum _E01E;

		[CompilerGenerated]
		private int _E01F;

		[CompilerGenerated]
		private string _E020;

		[Required]
		[StringLength(255, MinimumLength = 1, ErrorMessage = "Длина наименования кассы должна быть не менее 1 и не более 255 символов")]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		[Required]
		public long ProductRegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E023;
			}
			[CompilerGenerated]
			set
			{
				_E023 = value;
			}
		}

		[EnumDataType(typeof(CashboxTimeZoneEnum), ErrorMessage = "Некорректное значение перечисления")]
		public CashboxTimeZoneEnum Timezone
		{
			[CompilerGenerated]
			get
			{
				return _E01E;
			}
			[CompilerGenerated]
			set
			{
				_E01E = value;
			}
		}

		public int ModelType
		{
			[CompilerGenerated]
			get
			{
				return _E01F;
			}
			[CompilerGenerated]
			set
			{
				_E01F = value;
			}
		}

		[StringRange(1, 255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E020;
			}
			[CompilerGenerated]
			set
			{
				_E020 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.Programming };
		}
	}
}
