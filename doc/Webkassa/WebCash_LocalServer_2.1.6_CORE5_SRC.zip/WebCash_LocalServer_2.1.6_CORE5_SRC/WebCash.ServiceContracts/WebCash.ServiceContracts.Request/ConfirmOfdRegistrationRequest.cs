using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class ConfirmOfdRegistrationRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E043;

		[CompilerGenerated]
		private long _E044;

		[CompilerGenerated]
		private uint _E01D;

		[CompilerGenerated]
		private OfdEnum? _E045;

		[Required]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		[RegularExpression("^\\d{12}$", ErrorMessage = "Регистрационный номер должен состоять из 12 цифр")]
		public string RegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E043;
			}
			[CompilerGenerated]
			set
			{
				_E043 = value;
			}
		}

		[Required]
		public long IdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E044;
			}
			[CompilerGenerated]
			set
			{
				_E044 = value;
			}
		}

		[Required]
		public uint OfdToken
		{
			[CompilerGenerated]
			get
			{
				return _E01D;
			}
			[CompilerGenerated]
			set
			{
				_E01D = value;
			}
		}

		public OfdEnum? Ofd
		{
			[CompilerGenerated]
			get
			{
				return _E045;
			}
			[CompilerGenerated]
			set
			{
				_E045 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
