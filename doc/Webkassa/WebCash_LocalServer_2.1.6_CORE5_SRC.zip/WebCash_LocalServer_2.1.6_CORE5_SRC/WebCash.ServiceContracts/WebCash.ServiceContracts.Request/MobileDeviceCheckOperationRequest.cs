using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class MobileDeviceCheckOperationRequest : CheckOperationRequest
	{
		[CompilerGenerated]
		private string _E05F;

		public string SerialNumber
		{
			[CompilerGenerated]
			get
			{
				return _E05F;
			}
			[CompilerGenerated]
			set
			{
				_E05F = value;
			}
		}
	}
}
