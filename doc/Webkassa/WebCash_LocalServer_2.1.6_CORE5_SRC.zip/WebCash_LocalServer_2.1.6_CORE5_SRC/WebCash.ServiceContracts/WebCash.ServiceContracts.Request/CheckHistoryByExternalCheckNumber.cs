using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request
{
	public class CheckHistoryByExternalCheckNumber : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private string _E000;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}
	}
}
