using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class BaseExciseCheckRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool _E007;

		[CompilerGenerated]
		private double[] _E008;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public bool UseXin
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		[Required]
		public double[] Location
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}
	}
}
