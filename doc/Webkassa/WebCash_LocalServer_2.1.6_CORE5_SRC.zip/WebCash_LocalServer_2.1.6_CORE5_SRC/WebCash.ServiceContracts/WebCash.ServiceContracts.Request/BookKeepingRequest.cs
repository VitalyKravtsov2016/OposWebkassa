using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class BookKeepingRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private int[] _E00D;

		[CompilerGenerated]
		private int[] _E00E;

		[CompilerGenerated]
		private DateTime _E00F;

		[CompilerGenerated]
		private DateTime _E010;

		[CompilerGenerated]
		private bool _E011;

		[CompilerGenerated]
		private bool _E012;

		[CompilerGenerated]
		private InvoiceDocumentType _E013;

		[CompilerGenerated]
		private string _E014;

		[Required]
		public int[] ServiceCenterIds
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public int[] ClientsIds
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		[Required]
		public DateTime StartSearchPeriod
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		[Required]
		public DateTime EndSearchPeriod
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		[Required]
		public bool ForServiceCenter
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		[Required]
		public bool SelectAllServiceCenter
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		[Required]
		public InvoiceDocumentType InvoiceDocumentType
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		public string Subcount
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.BookKeeping };
		}

		protected override IEnumerable<ValidationResult> Validate()
		{
			List<ValidationResult> list = new List<ValidationResult>();
			if (ForServiceCenter && ClientsIds != null)
			{
				list.Add(new ValidationResult(_E006._E000("\uf7e2\uf7ca\uf7c4\uf7b3\uf7c8\uf7b0\uf3df\uf7bc\uf7c5\uf7cf\uf7c8\uf7b4\uf7cd\uf7cf\uf7bd\uf7b3\uf3df\uf7c5\uf7c4\uf7c7\uf7ca\uf7c2\uf7bd\uf7c1\uf7cd\uf3df\uf7ca\uf7be\uf7c4\uf7c7\uf3df\uf7cd\uf7b4\uf7ce\uf7bf\uf7cf\uf7c2\uf3df\uf7bf\uf7ca\uf7c9\uf7c7\uf7c3\uf3df\uf7cd\uf3df\uf7cf\uf7cb\uf7bf\uf7ca\uf7be\uf3df\uf7d9\uf7dd\uf7e1", 62399)));
			}
			if (SelectAllServiceCenter && ClientsIds != null)
			{
				list.Add(new ValidationResult(_E006._E000("\uf3e2\uf3ca\uf3c4\uf3b3\uf3c8\uf3b0\uf7df\uf3bc\uf3c5\uf3cf\uf3c8\uf3b4\uf3cd\uf3cf\uf3bd\uf3b3\uf7df\uf3c5\uf3c4\uf3c7\uf3ca\uf3c2\uf3bd\uf3c1\uf3cd\uf7df\uf3ca\uf3be\uf3c4\uf3c7\uf7df\uf3cd\uf3b4\uf3ce\uf3bf\uf3cf\uf3c2\uf7df\uf3bf\uf3ca\uf3c9\uf3c7\uf3c3\uf7df\uf3cd\uf3b4\uf3ce\uf3bf\uf3cf\uf3bd\uf3b3\uf7df\uf3cd\uf3be\uf3ca\uf7df\uf3d9\uf3dd\uf3e1", 63430)));
			}
			if ((ClientsIds != null || !ForServiceCenter) && ServiceCenterIds.Length > 1)
			{
				list.Add(new ValidationResult(_E006._E000("\uf0e2\uf0ca\uf0c4\uf0b3\uf0c8\uf0b0\uf4df\uf0bc\uf0c5\uf0cf\uf0c8\uf0b4\uf0cd\uf0cf\uf0bd\uf0b3\uf4df\uf0ce\uf0c1\uf0c4\uf0b3\uf0b7\uf0ca\uf4df\uf0c1\uf0cb\uf0c2\uf0c1\uf0cc\uf0c1\uf4df\uf0d9\uf0dd\uf0e1\uf4df\uf0ca\uf0be\uf0c4\uf0c7\uf4df\uf0cd\uf0b4\uf0ce\uf0bf\uf0cf\uf0c2\uf4df\uf0bf\uf0ca\uf0c9\uf0c7\uf0c3\uf4df\uf0cd\uf4df\uf0cf\uf0cb\uf0bf\uf0ca\uf0be\uf4df\uf0c5\uf0c4\uf0c7\uf0ca\uf0c2\uf0bd\uf0cf", 62662)));
			}
			if (StartSearchPeriod > EndSearchPeriod)
			{
				list.Add(new ValidationResult(_E006._E000("\uf5e8\uf5b7\uf5c9\uf5c5\uf5c2\uf5b7\uf5bb\uf5b5\uf5c2\uf1d7\uf5c8\uf5b7\uf5c7\uf5c5\uf5cf\uf5cc\uf5bb\uf5ca\uf5c9\uf5b6\uf5b5\uf5bb\uf1d7\uf5c3\uf5c7\uf5b5\uf5bc", 61744)));
			}
			return list;
		}
	}
}
