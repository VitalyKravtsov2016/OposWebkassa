using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class RegisterQrCodeRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E065;

		public string Content
		{
			[CompilerGenerated]
			get
			{
				return _E065;
			}
			[CompilerGenerated]
			set
			{
				_E065 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.QRCodeRegistration };
		}
	}
}
