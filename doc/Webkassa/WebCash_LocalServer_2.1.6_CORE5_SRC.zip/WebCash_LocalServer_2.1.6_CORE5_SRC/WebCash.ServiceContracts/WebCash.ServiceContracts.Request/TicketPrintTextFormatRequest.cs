using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class TicketPrintTextFormatRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private long _E015;

		[CompilerGenerated]
		private long _E07D;

		[CompilerGenerated]
		private bool _E07B;

		[CompilerGenerated]
		private PrintPaperKind _E07C;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public long ShiftId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public long TicketId
		{
			[CompilerGenerated]
			get
			{
				return _E07D;
			}
			[CompilerGenerated]
			set
			{
				_E07D = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		public bool IsDuplicate
		{
			[CompilerGenerated]
			get
			{
				return _E07B;
			}
			[CompilerGenerated]
			set
			{
				_E07B = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		[EnumDataType(typeof(PrintPaperKind), ErrorMessage = "Некорректное значение перечисления")]
		public PrintPaperKind PaperKind
		{
			[CompilerGenerated]
			get
			{
				return _E07C;
			}
			[CompilerGenerated]
			set
			{
				_E07C = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
