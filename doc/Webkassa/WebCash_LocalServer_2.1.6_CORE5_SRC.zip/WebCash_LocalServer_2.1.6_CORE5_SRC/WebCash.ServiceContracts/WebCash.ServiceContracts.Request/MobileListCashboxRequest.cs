using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class MobileListCashboxRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E060;

		public string DeviceSerialNumber
		{
			[CompilerGenerated]
			get
			{
				return _E060;
			}
			[CompilerGenerated]
			set
			{
				_E060 = value;
			}
		}
	}
}
