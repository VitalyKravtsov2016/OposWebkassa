using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CourierOrderCreateRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E04A;

		[CompilerGenerated]
		private List<CourierOrderPosition> _E02D;

		[Required]
		[StringLength(50, ErrorMessage = "Длина поля \"Номер заказа\" не может быть больше 50")]
		public string OrderNumber
		{
			[CompilerGenerated]
			get
			{
				return _E04A;
			}
			[CompilerGenerated]
			set
			{
				_E04A = value;
			}
		}

		[Required]
		public List<CourierOrderPosition> Positions
		{
			[CompilerGenerated]
			get
			{
				return _E02D;
			}
			[CompilerGenerated]
			set
			{
				_E02D = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.CourierModeControl };
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			List<ValidationResult> list = new List<ValidationResult>();
			foreach (CourierOrderPosition position in Positions)
			{
				if (string.IsNullOrWhiteSpace(position.SectionCode) && string.IsNullOrWhiteSpace(position.PositionCode))
				{
					list.Add(new ValidationResult(_E006._E000("\ue4a1\ue480\ue485\ue48b\ue09e\ue09c\ue4a4\ue480\ue48a\ue09e\ue4ff\ue48b\ue484\ue4f8\ue486\ue486\ue09c\ue09e\ue483\ue48b\ue09e\ue482\ue480\ue488\ue48b\ue4fc\ue09e\ue48f\ue4f5\ue4fc\ue4f2\ue09e\ue481\ue4fd\ue4ff\ue4fc\ue4f5\ue482", 57394)));
				}
				if (position.Discount > position.Price * position.Count)
				{
					list.Add(new ValidationResult(_E006._E000("ﳑﳰﳵﳻ\uf8ee\uf8ecﳯﳴﳶﳺﳴﳾ\uf8eeﳼ\uf8eeﲌﳻﳳﳽﳻ\uf8ec\uf8eeﳳﳻ\uf8eeﳲﳰﳸﳻﲌ\uf8eeﳿﲅﲌﲂ\uf8eeﳿﳰﳵﲂﲆﳻ\uf8eeﲉﳻﳲ\uf8ee\uf895ﳯﲌﳰﳶﳲﳰﲏﲌﲂ\uf8ee\uf8e4\uf8eeﳔﳰﳵ\uf8e3ﳼﳰ\uf893", 63620)));
				}
			}
			return list;
		}
	}
}
