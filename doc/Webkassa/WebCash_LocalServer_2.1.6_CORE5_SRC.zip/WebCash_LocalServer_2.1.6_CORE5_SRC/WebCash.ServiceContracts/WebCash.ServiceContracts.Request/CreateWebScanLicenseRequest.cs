using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CreateWebScanLicenseRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E022;

		[CompilerGenerated]
		private long _E04B;

		[CompilerGenerated]
		private int _E04C;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E022;
			}
			[CompilerGenerated]
			set
			{
				_E022 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		public long PacketTypeId
		{
			[CompilerGenerated]
			get
			{
				return _E04B;
			}
			[CompilerGenerated]
			set
			{
				_E04B = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Range(0, int.MaxValue, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "NumMustBeNatural")]
		public int Count
		{
			[CompilerGenerated]
			get
			{
				return _E04C;
			}
			[CompilerGenerated]
			set
			{
				_E04C = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinetExcise };
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return new List<ValidationResult>();
		}
	}
}
