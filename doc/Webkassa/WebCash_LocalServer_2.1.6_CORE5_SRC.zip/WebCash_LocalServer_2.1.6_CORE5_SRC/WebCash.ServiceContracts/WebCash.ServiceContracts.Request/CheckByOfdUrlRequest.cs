using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CheckByOfdUrlRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E02A;

		[CompilerGenerated]
		private string _E029;

		[CompilerGenerated]
		private DateTime? _E02B;

		[CompilerGenerated]
		private decimal _E02C;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "CashboxRegistrationNumber")]
		[JsonProperty(Required = Required.Always)]
		public string CashboxRegNumber
		{
			[CompilerGenerated]
			get
			{
				return _E02A;
			}
			[CompilerGenerated]
			set
			{
				_E02A = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "CheckNumber")]
		[JsonProperty(Required = Required.Always)]
		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E029;
			}
			[CompilerGenerated]
			set
			{
				_E029 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "FiscalOperationDate")]
		[JsonProperty(Required = Required.Always)]
		public DateTime? Date
		{
			[CompilerGenerated]
			get
			{
				return _E02B;
			}
			[CompilerGenerated]
			set
			{
				_E02B = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "TotalSum")]
		[JsonProperty(Required = Required.Always)]
		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E02C;
			}
			[CompilerGenerated]
			set
			{
				_E02C = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.TicketHistoryByOfdUrl };
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxRegNumber;
		}
	}
}
