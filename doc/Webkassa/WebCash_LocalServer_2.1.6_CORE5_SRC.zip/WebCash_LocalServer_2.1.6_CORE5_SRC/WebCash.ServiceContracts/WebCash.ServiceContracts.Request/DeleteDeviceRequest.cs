using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class DeleteDeviceRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E026;

		[Required]
		public string DeviceId
		{
			[CompilerGenerated]
			get
			{
				return _E026;
			}
			[CompilerGenerated]
			set
			{
				_E026 = value;
			}
		}
	}
}
