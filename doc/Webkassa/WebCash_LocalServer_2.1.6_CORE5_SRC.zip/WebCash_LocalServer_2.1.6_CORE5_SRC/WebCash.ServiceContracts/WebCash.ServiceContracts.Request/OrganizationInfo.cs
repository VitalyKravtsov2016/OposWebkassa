using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class OrganizationInfo
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool? _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private TaxationTypeEnum _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private bool _E006;

		[CompilerGenerated]
		private string _E007;

		[CompilerGenerated]
		private string _E008;

		[DisplayName("ИИН/БИН")]
		[Required]
		[Xin]
		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[DisplayName("Признак ЮЛ")]
		[Required]
		public bool? IsLegal
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[DisplayName("Полное наименование)")]
		[Required]
		[StringLength(255, MinimumLength = 1, ErrorMessage = "Длина наименования организации должна быть не менее 1 и не более 255 символов")]
		public string FullName
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[DisplayName("Адрес регистрации")]
		[Required]
		public string LegalAddress
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[DisplayName("Налоговый режим")]
		[Required]
		[EnumDataType(typeof(TaxationTypeEnum), ErrorMessage = "Некорректно указано значение Налогового режима")]
		public TaxationTypeEnum TaxationType
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[DisplayName("Код ОКЭД")]
		[Required]
		public string EconomicActivityCode
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public bool VATpayer
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		public string VATseries
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		public string VATnumber
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}
	}
}
