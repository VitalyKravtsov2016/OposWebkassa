using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CheckItemApiModel
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private decimal _E001;

		[CompilerGenerated]
		private decimal _E002;

		[CompilerGenerated]
		private byte? _E003;

		[CompilerGenerated]
		private int _E004;

		[CompilerGenerated]
		private TaxValidationTypeEnum _E005;

		[CompilerGenerated]
		private string _E006;

		[CompilerGenerated]
		private string _E007;

		[CompilerGenerated]
		private decimal _E008;

		[CompilerGenerated]
		private decimal _E009;

		[CompilerGenerated]
		private decimal _E00A;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private bool _E00C;

		[CompilerGenerated]
		private bool _E00D;

		[CompilerGenerated]
		private bool _E00E;

		[CompilerGenerated]
		private decimal _E00F;

		[CompilerGenerated]
		private bool _E010;

		[CompilerGenerated]
		private long? _E011;

		[CompilerGenerated]
		private decimal? _E012;

		[CompilerGenerated]
		private string _E013;

		[CompilerGenerated]
		private string _E014;

		[CompilerGenerated]
		private long? _E015;

		[CompilerGenerated]
		private WarehouseTypeEnum _E016;

		[Required]
		[JsonProperty(Required = Required.Always)]
		[Range(0.0, 4294967.295, ErrorMessage = "Количество не должно принимать значение меньше 0 и больше 4 294 967")]
		public decimal Count
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Price не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Price
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		[Range(0.0, double.MaxValue, ErrorMessage = "Значение поля Tax не может быть отрицательным")]
		public decimal Tax
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public byte? TaxPercent
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public int TaxType
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		public TaxValidationTypeEnum TaxValidationType
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		[StringLength(255, ErrorMessage = "Длина наименования позиции не должна превышать 255 символов")]
		public string PositionName
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		[StringLength(50, ErrorMessage = "Длина кода позиции не должна превышать 50 символов")]
		public string PositionCode
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Discount не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Discount
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		[Range(0.0, 999999999.0, ErrorMessage = "Значения поля Markup не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Markup
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		[HideForAppId(new string[] { "SattyZhuldyz", "1C" })]
		public decimal MarkupPercent
		{
			[CompilerGenerated]
			get
			{
				return _E00A;
			}
			[CompilerGenerated]
			set
			{
				_E00A = value;
			}
		}

		public string SectionCode
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public bool IsStorno
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public bool MarkupDeleted
		{
			[CompilerGenerated]
			get
			{
				return _E00D;
			}
			[CompilerGenerated]
			set
			{
				_E00D = value;
			}
		}

		public bool DiscountDeleted
		{
			[CompilerGenerated]
			get
			{
				return _E00E;
			}
			[CompilerGenerated]
			set
			{
				_E00E = value;
			}
		}

		[HideForAppId(new string[] { "SattyZhuldyz", "1C" })]
		public decimal DiscountPercent
		{
			[CompilerGenerated]
			get
			{
				return _E00F;
			}
			[CompilerGenerated]
			set
			{
				_E00F = value;
			}
		}

		[HideForAppId(new string[] { "SattyZhuldyz", "1C" })]
		public bool IsReturned
		{
			[CompilerGenerated]
			get
			{
				return _E010;
			}
			[CompilerGenerated]
			set
			{
				_E010 = value;
			}
		}

		public long? UnitCode
		{
			[CompilerGenerated]
			get
			{
				return _E011;
			}
			[CompilerGenerated]
			set
			{
				_E011 = value;
			}
		}

		public decimal? SumOverride
		{
			[CompilerGenerated]
			get
			{
				return _E012;
			}
			[CompilerGenerated]
			set
			{
				_E012 = value;
			}
		}

		public string Mark
		{
			[CompilerGenerated]
			get
			{
				return _E013;
			}
			[CompilerGenerated]
			set
			{
				_E013 = value;
			}
		}

		[StringLength(14, ErrorMessage = "Длина Gtin не должна превышать 14 символов")]
		public string Gtin
		{
			[CompilerGenerated]
			get
			{
				return _E014;
			}
			[CompilerGenerated]
			set
			{
				_E014 = value;
			}
		}

		public long? ProductId
		{
			[CompilerGenerated]
			get
			{
				return _E015;
			}
			[CompilerGenerated]
			set
			{
				_E015 = value;
			}
		}

		public WarehouseTypeEnum WarehouseType
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public decimal CalculateSum(IRounder rounder)
		{
			decimal num = SumOverride ?? (Price * Count);
			return rounder.RoundItem(num - (DiscountDeleted ? 0m : rounder.RoundItem(Discount)) + (MarkupDeleted ? 0m : rounder.RoundItem(Markup)));
		}

		public decimal CalculateSumWithoutModifier(IRounder rounder)
		{
			decimal item = SumOverride ?? (Price * Count);
			return rounder.RoundItem(item);
		}
	}
}
