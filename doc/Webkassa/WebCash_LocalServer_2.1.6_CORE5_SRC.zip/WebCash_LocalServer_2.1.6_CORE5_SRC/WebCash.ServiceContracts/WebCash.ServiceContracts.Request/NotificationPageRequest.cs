namespace WebCash.ServiceContracts.Request
{
	public class NotificationPageRequest : BasePageRequest
	{
	}
}
