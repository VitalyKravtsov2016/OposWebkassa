using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class TicketPrintTextFormatByNumberRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private long _E003;

		[CompilerGenerated]
		private PrintPaperKind _E004;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		public bool IsDuplicate
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public string Number
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public long ShiftNumber
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		[EnumDataType(typeof(PrintPaperKind), ErrorMessage = "Некорректное значение перечисления")]
		public PrintPaperKind PaperKind
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}
	}
}
