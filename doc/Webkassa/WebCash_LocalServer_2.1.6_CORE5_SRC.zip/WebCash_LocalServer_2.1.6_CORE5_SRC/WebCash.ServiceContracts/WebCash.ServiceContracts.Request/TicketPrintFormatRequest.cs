using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class TicketPrintFormatRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private bool _E07B;

		[CompilerGenerated]
		private PrintPaperKind _E07C;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[JsonProperty(Required = Required.Always)]
		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		public bool IsDuplicate
		{
			[CompilerGenerated]
			get
			{
				return _E07B;
			}
			[CompilerGenerated]
			set
			{
				_E07B = value;
			}
		}

		[JsonProperty(Required = Required.Always)]
		[EnumDataType(typeof(PrintPaperKind), ErrorMessage = "Некорректное значение перечисления")]
		public PrintPaperKind PaperKind
		{
			[CompilerGenerated]
			get
			{
				return _E07C;
			}
			[CompilerGenerated]
			set
			{
				_E07C = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
