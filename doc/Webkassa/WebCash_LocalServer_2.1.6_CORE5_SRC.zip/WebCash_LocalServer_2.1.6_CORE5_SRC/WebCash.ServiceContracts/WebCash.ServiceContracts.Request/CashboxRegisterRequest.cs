using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CashboxRegisterRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E021;

		[CompilerGenerated]
		private CashboxTimeZoneEnum _E01E;

		[CompilerGenerated]
		private string _E022;

		[CompilerGenerated]
		private int? _E01F;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string _E020;

		[StringRange(1, 255, LeftOfRangeErrorMessage = "Поле не может быть пустым", RightOfRangeErrorMessage = "Не должно превышать 255 символов")]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		[EnumDataType(typeof(CashboxTimeZoneEnum), ErrorMessage = "Некорректное значение перечисления")]
		public CashboxTimeZoneEnum Timezone
		{
			[CompilerGenerated]
			get
			{
				return _E01E;
			}
			[CompilerGenerated]
			set
			{
				_E01E = value;
			}
		}

		[Required]
		[Xin]
		public string Xin
		{
			[CompilerGenerated]
			get
			{
				return _E022;
			}
			[CompilerGenerated]
			set
			{
				_E022 = value;
			}
		}

		public int? ModelType
		{
			[CompilerGenerated]
			get
			{
				return _E01F;
			}
			[CompilerGenerated]
			set
			{
				_E01F = value;
			}
		}

		[Required]
		public string EmployeeLogin
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[StringRange(1, 255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Address
		{
			[CompilerGenerated]
			get
			{
				return _E020;
			}
			[CompilerGenerated]
			set
			{
				_E020 = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[2]
			{
				PermissionEnum.Programming,
				PermissionEnum.ServiceCenterCabinet
			};
		}
	}
}
