using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class CheckPinRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E041;

		[CompilerGenerated]
		private PinType _E042;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[RegularExpression("^\\d{4}$", ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "PinInvalidFormat")]
		public string Pin
		{
			[CompilerGenerated]
			get
			{
				return _E041;
			}
			[CompilerGenerated]
			set
			{
				_E041 = value;
			}
		}

		[EnumDataType(typeof(PinType))]
		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public PinType Type
		{
			[CompilerGenerated]
			get
			{
				return _E042;
			}
			[CompilerGenerated]
			set
			{
				_E042 = value;
			}
		}
	}
}
