using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class NotificationSettingsItem
	{
		[CompilerGenerated]
		private NotificationTypeEnum _E000;

		[CompilerGenerated]
		private NotificationDeliveryTypeEnum[] _E001;

		public NotificationTypeEnum NotificationType
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public NotificationDeliveryTypeEnum[] DeliveryTypes
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public NotificationSettingsItem()
		{
			DeliveryTypes = new NotificationDeliveryTypeEnum[0];
		}
	}
}
