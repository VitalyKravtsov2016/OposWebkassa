using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;
using WebCash.ServiceContracts.PrintModule;

namespace WebCash.ServiceContracts.Request
{
	public class MoneyOperationRequest : AuthorizedRequest, IOfflinePackage, IRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private MoneyPlacementTypeEnum _E02E;

		[CompilerGenerated]
		private decimal _E02C;

		[CompilerGenerated]
		private string _E00B;

		[CompilerGenerated]
		private DateTime? _E009;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[EnumDataType(typeof(MoneyPlacementTypeEnum), ErrorMessage = "Некорректное значение перечисления")]
		public MoneyPlacementTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E02E;
			}
			[CompilerGenerated]
			set
			{
				_E02E = value;
			}
		}

		[Range(0.0, 999999999.0, ErrorMessageResourceType = typeof(ExceptionResource), ErrorMessageResourceName = "SumIsOutOfRangeErrorMessage")]
		public decimal Sum
		{
			[CompilerGenerated]
			get
			{
				return _E02C;
			}
			[CompilerGenerated]
			set
			{
				_E02C = value;
			}
		}

		[StringLength(50, ErrorMessage = "Длина поля не должна превышать 50 символов")]
		public string ExternalCheckNumber
		{
			[CompilerGenerated]
			get
			{
				return _E00B;
			}
			[CompilerGenerated]
			set
			{
				_E00B = value;
			}
		}

		public DateTime? OfflineDate
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}

		protected override IEnumerable<ValidationResult> Validate()
		{
			List<ValidationResult> list = new List<ValidationResult>();
			string text = Sum.ToString(CultureInfo.InvariantCulture);
			int num = text.IndexOf(_E006._E000("\ue1f1", 57615), StringComparison.InvariantCulture);
			int num2 = 2;
			int length = text.Substring(num + 1).Length;
			if (num != -1 && length > num2)
			{
				list.Add(new ValidationResult(_E006._E000("\uefa3\uef81\uef8c\ueffc\ueffd\ueb9f\uef80\uefff\uef81\ueffa\uef81\uef8b\uef87\ueffd\ueff3\ueb9f\ueffd\uef81\uef84\ueff3\uef85\uef81\ueb9f\uef8b\uefff\uef81\uef8e\uef82\ueff4\uef8a\ueb9f\ueffe\ueffc\uef83\uef83\ueff4\ueb9f\uef8b\uef81\ueb9f\uef8b\uef8d\ueffc\ueffa\ueb9f\uef88\uef82\uef8f\uef85\uef81\uef8d\ueb9f\uef80\uef81\ueffe\uef84\uef8a\ueb9f\uef88\uef8f\uef80\ueff0\ueffd\uef81\uef86", 60344)));
			}
			return list;
		}
	}
}
