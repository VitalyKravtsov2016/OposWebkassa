using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class PushNotificationRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
