using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request
{
	public class Change1CServiceCenterRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E019;

		[CompilerGenerated]
		private string _E025;

		[CompilerGenerated]
		private string _E017;

		[CompilerGenerated]
		private string _E018;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(ResourceType = typeof(NameResource), Name = "Cashbox")]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(Name = "ИИН/БИН партнера")]
		public string PartnerXin
		{
			[CompilerGenerated]
			get
			{
				return _E019;
			}
			[CompilerGenerated]
			set
			{
				_E019 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(Name = "Код партнера")]
		public string PartnerCode
		{
			[CompilerGenerated]
			get
			{
				return _E025;
			}
			[CompilerGenerated]
			set
			{
				_E025 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(Name = "Номер карты")]
		public string CardNumber
		{
			[CompilerGenerated]
			get
			{
				return _E017;
			}
			[CompilerGenerated]
			set
			{
				_E017 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "Required")]
		[Display(Name = "Активационный номер")]
		public string ActivationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E018;
			}
			[CompilerGenerated]
			set
			{
				_E018 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
