using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class MobileCashboxesListResponse
	{
		[CompilerGenerated]
		private MobileCashboxModel[] _E000;

		public MobileCashboxModel[] List
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}
	}
}
