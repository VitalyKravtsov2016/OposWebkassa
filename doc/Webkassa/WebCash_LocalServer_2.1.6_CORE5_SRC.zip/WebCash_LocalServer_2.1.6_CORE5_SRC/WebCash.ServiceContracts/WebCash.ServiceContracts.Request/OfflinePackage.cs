using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class OfflinePackage : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private OfflineCheckOperationRequest[] _E069;

		[CompilerGenerated]
		private OfflineMoneyOperationRequest[] _E06A;

		[CompilerGenerated]
		private OfflineXzReportRequest[] _E06B;

		[CompilerGenerated]
		private string _E024;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public OfflineCheckOperationRequest[] Checks
		{
			[CompilerGenerated]
			get
			{
				return _E069;
			}
			[CompilerGenerated]
			set
			{
				_E069 = value;
			}
		}

		public OfflineMoneyOperationRequest[] MoneyOperations
		{
			[CompilerGenerated]
			get
			{
				return _E06A;
			}
			[CompilerGenerated]
			set
			{
				_E06A = value;
			}
		}

		public OfflineXzReportRequest[] XzReports
		{
			[CompilerGenerated]
			get
			{
				return _E06B;
			}
			[CompilerGenerated]
			set
			{
				_E06B = value;
			}
		}

		public string ProductVersion
		{
			[CompilerGenerated]
			get
			{
				return _E024;
			}
			[CompilerGenerated]
			set
			{
				_E024 = value;
			}
		}

		public OfflinePackage()
		{
			Checks = new OfflineCheckOperationRequest[0];
			MoneyOperations = new OfflineMoneyOperationRequest[0];
			XzReports = new OfflineXzReportRequest[0];
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
