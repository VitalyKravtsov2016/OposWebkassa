using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;
using WebCash.ServiceContracts.Attributes;

namespace WebCash.ServiceContracts.Request
{
	public class EmployeeRegistrationRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E050;

		[CompilerGenerated]
		private string _E051;

		[CompilerGenerated]
		private string _E052;

		[CompilerGenerated]
		private string[] _E005;

		[CompilerGenerated]
		private string _E001;

		[DisplayName("Полное имя")]
		[Required]
		[StringLength(255, MinimumLength = 1, ErrorMessage = "Длина имени кассира должна быть не менее 1 и не более 255 символов")]
		public string FullName
		{
			[CompilerGenerated]
			get
			{
				return _E050;
			}
			[CompilerGenerated]
			set
			{
				_E050 = value;
			}
		}

		[DisplayName("Email")]
		[StringLength(50, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "LengthCanBeMaximum50Symbols")]
		[Required]
		[Email]
		public string Email
		{
			[CompilerGenerated]
			get
			{
				return _E051;
			}
			[CompilerGenerated]
			set
			{
				_E051 = value;
			}
		}

		[DisplayName("Пароль")]
		[RegularExpression("(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\da-zA-Z]*).{8,}", ErrorMessage = "Пароль должен содержать знаки: A-Z, a-z, 0-9")]
		[Required]
		public string Password
		{
			[CompilerGenerated]
			get
			{
				return _E052;
			}
			[CompilerGenerated]
			set
			{
				_E052 = value;
			}
		}

		[Required]
		[ArrayLength(1u)]
		public string[] Cashboxes
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		[RegularExpression("\\+77\\d{9}", ErrorMessage = "Номер телефона должен соответствовать формату +77XXXXXXXXX")]
		[StringLength(12, MinimumLength = 12, ErrorMessage = "Номер телефона должен содержать 12 знаков")]
		public virtual string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public EmployeeRegistrationRequest()
		{
			Cashboxes = new string[0];
		}
	}
}
