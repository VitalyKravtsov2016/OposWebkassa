using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class LicenseCancelationServiceCenterRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E05A;

		[Required]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[JsonProperty("PackageNumber")]
		[Required]
		public string PackageNumber
		{
			[CompilerGenerated]
			get
			{
				return _E05A;
			}
			[CompilerGenerated]
			set
			{
				_E05A = value;
			}
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.ServiceCenterCabinet };
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
