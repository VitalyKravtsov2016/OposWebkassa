using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class CourierOrderPosition
	{
		[CompilerGenerated]
		private decimal _E000;

		[CompilerGenerated]
		private decimal _E001;

		[CompilerGenerated]
		private byte _E002;

		[CompilerGenerated]
		private long _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string _E005;

		[CompilerGenerated]
		private decimal _E006;

		[CompilerGenerated]
		private decimal _E007;

		[CompilerGenerated]
		private string _E008;

		[CompilerGenerated]
		private int _E009;

		[Required]
		[JsonProperty(Required = Required.Always)]
		[Range(0.0, 4294967.295, ErrorMessage = "Количество не должно принимать значение меньше 0 и больше 4 294 967")]
		public decimal Count
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Price не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Price
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[Required]
		public byte TaxPercent
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[Required]
		[EnumDataType(typeof(TaxTypeEnum), ErrorMessage = "Некорректно указано значение Налогового режима")]
		public long TaxType
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[Required]
		[StringLength(255, ErrorMessage = "Длина наименования позиции не должна превышать 255 символов")]
		public string PositionName
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[Required]
		[StringLength(50, ErrorMessage = "Длина кода позиции не должна превышать 50 символов")]
		public string PositionCode
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		[Range(0.0, 999999999.0, ErrorMessage = "Значение поля Discount не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Discount
		{
			[CompilerGenerated]
			get
			{
				return _E006;
			}
			[CompilerGenerated]
			set
			{
				_E006 = value;
			}
		}

		[Range(0.0, 999999999.0, ErrorMessage = "Значения поля Markup не может быть отрицательным или превышать 9 целых разрядов")]
		public decimal Markup
		{
			[CompilerGenerated]
			get
			{
				return _E007;
			}
			[CompilerGenerated]
			set
			{
				_E007 = value;
			}
		}

		[Required]
		public string SectionCode
		{
			[CompilerGenerated]
			get
			{
				return _E008;
			}
			[CompilerGenerated]
			set
			{
				_E008 = value;
			}
		}

		[Required]
		public int UnitCode
		{
			[CompilerGenerated]
			get
			{
				return _E009;
			}
			[CompilerGenerated]
			set
			{
				_E009 = value;
			}
		}
	}
}
