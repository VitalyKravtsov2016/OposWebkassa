using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class SulpakAcceptSmsCodeRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private decimal _E002;

		public string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string SmsCode
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public decimal Bonus
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
