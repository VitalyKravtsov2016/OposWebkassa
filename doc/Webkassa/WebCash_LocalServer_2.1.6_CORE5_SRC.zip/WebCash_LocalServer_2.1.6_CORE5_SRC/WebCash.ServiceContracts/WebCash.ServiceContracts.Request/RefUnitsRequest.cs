namespace WebCash.ServiceContracts.Request
{
	public class RefUnitsRequest : AuthorizedRequest
	{
	}
}
