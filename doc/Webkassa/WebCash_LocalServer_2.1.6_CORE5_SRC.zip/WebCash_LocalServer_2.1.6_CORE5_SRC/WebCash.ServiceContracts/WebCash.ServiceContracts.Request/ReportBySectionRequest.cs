using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request
{
	public class ReportBySectionRequest : WebInterfaceRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private DateTime _E02B;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		[JsonProperty(Required = Required.Always)]
		public DateTime Date
		{
			[CompilerGenerated]
			get
			{
				return _E02B;
			}
			[CompilerGenerated]
			set
			{
				_E02B = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}
	}
}
