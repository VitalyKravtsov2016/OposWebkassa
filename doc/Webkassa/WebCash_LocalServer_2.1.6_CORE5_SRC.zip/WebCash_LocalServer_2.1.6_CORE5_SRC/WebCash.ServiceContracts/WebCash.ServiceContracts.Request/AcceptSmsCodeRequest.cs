using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class AcceptSmsCodeRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private decimal _E003;

		public string CashboxUniqueNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string SmsCode
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public decimal Bonus
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return CashboxUniqueNumber;
		}

		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.SulpakCourier };
		}
	}
}
