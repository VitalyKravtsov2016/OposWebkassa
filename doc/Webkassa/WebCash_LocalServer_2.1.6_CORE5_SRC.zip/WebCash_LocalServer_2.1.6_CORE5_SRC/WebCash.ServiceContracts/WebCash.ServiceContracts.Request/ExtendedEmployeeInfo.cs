using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class ExtendedEmployeeInfo : BaseEmployeeInfo
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private int? _E001;

		[Required]
		public override string PhoneNumber
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[Required]
		public override int? MaxCheckAmount
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
