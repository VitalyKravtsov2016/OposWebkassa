using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request
{
	public class BlockMobileCashboxRequest : MobileCashboxRequest
	{
		[CompilerGenerated]
		private string _E00C;

		public string BlockReason
		{
			[CompilerGenerated]
			get
			{
				return _E00C;
			}
			[CompilerGenerated]
			set
			{
				_E00C = value;
			}
		}

		public override string GetCashboxUniqueName()
		{
			return base.CashboxUniqueNumber;
		}
	}
}
