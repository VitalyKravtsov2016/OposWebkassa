using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request
{
	public class PromotionCashboxRequest : WebInterfaceRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return new PermissionEnum[1] { PermissionEnum.PromotionView };
		}
	}
}
