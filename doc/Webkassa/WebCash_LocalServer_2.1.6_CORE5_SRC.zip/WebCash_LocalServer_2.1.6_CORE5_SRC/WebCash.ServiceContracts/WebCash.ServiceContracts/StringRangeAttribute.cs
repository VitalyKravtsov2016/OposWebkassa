using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	public class StringRangeAttribute : ValidationAttribute
	{
		[CompilerGenerated]
		private int? _E000;

		[CompilerGenerated]
		private int? _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		private const string _E004 = "Не должно быть меньше {0} символа(ов)";

		private const string _E005 = "Не должно быть больше {0} символа(ов)";

		public int? MinimumLength
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public int? MaximumLength
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string LeftOfRangeErrorMessage
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		public string RightOfRangeErrorMessage
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		public StringRangeAttribute(int minimumLength, int maximumLength)
		{
			MinimumLength = minimumLength;
			MaximumLength = maximumLength;
		}

		protected override ValidationResult IsValid(object value, ValidationContext validationContext)
		{
			if (value == null)
			{
				return ValidationResult.Success;
			}
			int length = (value?.ToString() + string.Empty).Length;
			if (MinimumLength.HasValue && length < MinimumLength.Value)
			{
				if (string.IsNullOrEmpty(LeftOfRangeErrorMessage))
				{
					return new ValidationResult(string.Format(_E006._E000("\uefe2\uefca\uebdf\uefcb\uefc1\uefc4\uefc9\uefc2\uefc1\uebdf\uefce\uefb4\uefbd\uefb3\uebdf\uefc3\uefca\uefc2\uefb3\uefb7\uefca\uebdf\ueb84\uebcf\ueb82\uebdf\uefbe\uefc7\uefc3\uefcd\uefc1\uefc4\uefcf\uebd7\uefc1\uefcd\uebd6", 60207), MinimumLength.Value));
				}
				return new ValidationResult(LeftOfRangeErrorMessage);
			}
			if (MaximumLength.HasValue && length > MaximumLength.Value)
			{
				if (string.IsNullOrEmpty(RightOfRangeErrorMessage))
				{
					return new ValidationResult(string.Format(_E006._E000("\ue886\ue8ae\uecbb\ue8af\ue8a5\ue8a0\ue8ad\ue8a6\ue8a5\uecbb\ue8aa\ue8d0\ue8d9\ue8d7\uecbb\ue8aa\ue8a5\ue8a0\ue8d7\ue8d3\ue8ae\uecbb\uece0\uecab\uece6\uecbb\ue8da\ue8a3\ue8a7\ue8a9\ue8a5\ue8a0\ue8ab\uecb3\ue8a5\ue8a9\uecb2", 60426), MaximumLength.Value));
				}
				return new ValidationResult(RightOfRangeErrorMessage);
			}
			return ValidationResult.Success;
		}
	}
}
