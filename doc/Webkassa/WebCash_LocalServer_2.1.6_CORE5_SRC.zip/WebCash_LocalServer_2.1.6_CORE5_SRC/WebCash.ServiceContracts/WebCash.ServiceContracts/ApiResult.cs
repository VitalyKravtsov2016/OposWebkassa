using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts
{
	public class ApiResult
	{
		[CompilerGenerated]
		private sealed class _E000
		{
			public ApiErrorCode _E000;

			internal bool _E000(ErrorItem _E002)
			{
				return _E002.Code == this._E000;
			}
		}

		[CompilerGenerated]
		private List<ErrorItem> m__E000;

		public List<ErrorItem> Errors
		{
			[CompilerGenerated]
			get
			{
				return this.m__E000;
			}
			[CompilerGenerated]
			set
			{
				this.m__E000 = value;
			}
		}

		public void AddError(ApiErrorCode code, string text)
		{
			if (Errors == null)
			{
				Errors = new List<ErrorItem>();
			}
			Errors.Add(new ErrorItem(code, text));
		}

		public static ApiResult Error(ApiErrorCode code, string text = "")
		{
			ApiResult apiResult = new ApiResult();
			apiResult.AddError(code, text);
			return apiResult;
		}

		public bool HasError(ApiErrorCode apiErrorCode)
		{
			if (Errors != null)
			{
				return Errors.Any((ErrorItem _E002) => _E002.Code == apiErrorCode);
			}
			return false;
		}

		public bool HasError()
		{
			if (Errors != null)
			{
				return Errors.Any();
			}
			return false;
		}

		public static ApiResult<T> Success<T>(T data)
		{
			return new ApiResult<T>(data);
		}
	}
	public sealed class ApiResult<T> : ApiResult
	{
		[CompilerGenerated]
		private T _E001;

		public T Data
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public ApiResult(T data)
		{
			Data = data;
		}

		public ApiResult()
		{
		}

		public ApiResult(ApiErrorCode code, string text)
		{
			AddError(code, text);
		}
	}
}
