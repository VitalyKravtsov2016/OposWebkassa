using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class MustUseReturnValueAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CanBeNull]
		public string Justification
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public MustUseReturnValueAttribute()
		{
		}

		public MustUseReturnValueAttribute([NotNull] string justification)
		{
			Justification = justification;
		}
	}
}
