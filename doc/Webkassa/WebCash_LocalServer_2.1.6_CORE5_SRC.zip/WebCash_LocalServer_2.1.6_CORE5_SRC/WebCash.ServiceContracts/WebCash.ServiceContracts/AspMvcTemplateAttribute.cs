using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcTemplateAttribute : Attribute
	{
	}
}
