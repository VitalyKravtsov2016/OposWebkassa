using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using WebCash.Resources;

namespace WebCash.ServiceContracts
{
	public class XinAttribute : ValidationAttribute
	{
		private const int m__E000 = 11;

		private const int m__E001 = 12;

		private bool? _E002;

		public XinAttribute()
			: this(null)
		{
		}

		public XinAttribute(bool isBin)
			: this((bool?)isBin)
		{
		}

		private XinAttribute(bool? _E005 = null)
			: base(() => ValidationResource.XinInvalid)
		{
			_E002 = _E005;
		}

		protected override ValidationResult IsValid(object value, ValidationContext validationContext)
		{
			if (value == null)
			{
				return ValidationResult.Success;
			}
			string text = value.ToString();
			if (text.Length != 12 || !text.All(char.IsDigit))
			{
				return new ValidationResult(ValidationResource.INShouldConsistOfTwelveDigits, new string[1] { validationContext.MemberName });
			}
			int num = _E000(text, 0);
			if (num == 10)
			{
				num = _E000(text, 2);
			}
			if (num != text.Last() - 48)
			{
				return new ValidationResult(ValidationResource.XinInvalidControlDigit, new string[1] { validationContext.MemberName });
			}
			int num2 = _E001(text, 2);
			if (num2 < 1 || num2 > 12)
			{
				return new ValidationResult(ValidationResource.XinInvalid, new string[1] { validationContext.MemberName });
			}
			bool flag = _E001(text, 4, 1) > 3;
			if (_E002.HasValue && flag != _E002)
			{
				return new ValidationResult(_E002.Value ? ValidationResource.XinInvalidBIN : ValidationResource.XinInvalidIIN, new string[1] { validationContext.MemberName });
			}
			if (!flag)
			{
				int num3 = _E001(text, 6, 1);
				if (num3 < 0 || num3 > 8)
				{
					return new ValidationResult(ValidationResource.XinInvalidIIN, new string[1] { validationContext.MemberName });
				}
				int num4 = (num3 - 1) / 2;
				DateTime dateTime = new DateTime(_E001(text, 0) + (18 + num4) * 100, _E001(text, 2), 1);
				int num5 = _E001(text, 4);
				if (num5 < 1 || num5 > DateTime.DaysInMonth(dateTime.Year, dateTime.Month))
				{
					return new ValidationResult(ValidationResource.XinInvalidBirthDate, new string[1] { validationContext.MemberName });
				}
			}
			return ValidationResult.Success;
		}

		private static int _E000(string _E006, int _E007)
		{
			int num = 0;
			for (int i = 0; i < 11; i++)
			{
				num = (num + (_E006[i] - 48) * ((i + _E007) % 11 + 1)) % 11;
			}
			return num;
		}

		private static int _E001(string _E008, int _E009, int _E00A = 2)
		{
			return int.Parse(_E008.Substring(_E009, _E00A));
		}
	}
}
