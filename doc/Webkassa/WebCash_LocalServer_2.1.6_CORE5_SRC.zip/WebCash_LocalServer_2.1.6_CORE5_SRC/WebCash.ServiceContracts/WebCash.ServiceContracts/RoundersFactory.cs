using System;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts
{
	public static class RoundersFactory
	{
		public static IRounder GetRounder(RoundTypeEnum type, bool fixedTotal = false)
		{
			switch (type)
			{
			case RoundTypeEnum.None:
				return new _E004();
			case RoundTypeEnum.Total:
				if (fixedTotal)
				{
					return new FixedTotalRounder();
				}
				return new _E003();
			case RoundTypeEnum.EveryItem:
				return new global::_E002();
			case RoundTypeEnum.TotalOnly:
				return new FixedTotalRounder();
			default:
				throw new NotImplementedException();
			}
		}
	}
}
