using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcAreaViewLocationFormatAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[NotNull]
		public string Format
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public AspMvcAreaViewLocationFormatAttribute([NotNull] string format)
		{
			Format = format;
		}
	}
}
