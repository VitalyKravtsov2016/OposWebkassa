using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcControllerAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CanBeNull]
		public string AnonymousProperty
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public AspMvcControllerAttribute()
		{
		}

		public AspMvcControllerAttribute([NotNull] string anonymousProperty)
		{
			AnonymousProperty = anonymousProperty;
		}
	}
}
