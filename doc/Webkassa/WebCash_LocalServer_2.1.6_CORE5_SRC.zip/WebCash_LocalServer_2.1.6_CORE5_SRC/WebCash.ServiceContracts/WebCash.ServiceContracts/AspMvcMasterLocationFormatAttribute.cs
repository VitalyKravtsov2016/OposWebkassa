using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcMasterLocationFormatAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		public string Format
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public AspMvcMasterLocationFormatAttribute(string format)
		{
			Format = format;
		}
	}
}
