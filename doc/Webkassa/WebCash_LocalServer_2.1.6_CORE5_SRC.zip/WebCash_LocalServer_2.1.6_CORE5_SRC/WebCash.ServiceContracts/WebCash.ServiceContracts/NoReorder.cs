using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.All)]
	public sealed class NoReorder : Attribute
	{
	}
}
