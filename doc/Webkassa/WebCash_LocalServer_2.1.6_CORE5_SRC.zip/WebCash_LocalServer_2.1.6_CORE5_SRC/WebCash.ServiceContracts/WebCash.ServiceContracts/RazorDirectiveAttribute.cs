using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class RazorDirectiveAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[NotNull]
		public string Directive
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public RazorDirectiveAttribute([NotNull] string directive)
		{
			Directive = directive;
		}
	}
}
