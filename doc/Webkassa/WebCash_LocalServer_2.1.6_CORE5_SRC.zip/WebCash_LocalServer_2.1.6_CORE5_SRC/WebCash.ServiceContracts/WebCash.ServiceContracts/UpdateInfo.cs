using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	public class UpdateInfo
	{
		[CompilerGenerated]
		private Version _E000;

		[CompilerGenerated]
		private DateTime _E001;

		[CompilerGenerated]
		private string _E002;

		public Version AssemblyInfo
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public DateTime ReleaseDate
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public string ContentPath
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}
	}
}
