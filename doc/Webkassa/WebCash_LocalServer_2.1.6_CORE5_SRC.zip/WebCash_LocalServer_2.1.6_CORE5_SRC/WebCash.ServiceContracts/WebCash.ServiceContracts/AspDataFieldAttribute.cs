using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Property)]
	public sealed class AspDataFieldAttribute : Attribute
	{
	}
}
