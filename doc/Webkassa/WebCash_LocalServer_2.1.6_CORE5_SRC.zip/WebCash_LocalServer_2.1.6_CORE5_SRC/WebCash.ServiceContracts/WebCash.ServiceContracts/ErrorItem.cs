using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts
{
	public class ErrorItem
	{
		[CompilerGenerated]
		private ApiErrorCode _E000;

		[CompilerGenerated]
		private string _E001;

		public ApiErrorCode Code
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string Text
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		public ErrorItem(ApiErrorCode code, string text = "")
		{
			Code = code;
			Text = text;
		}

		public override string ToString()
		{
			return string.Format(_E006._E000("\ue68c\ue6c7\ue68a\ue6cd\ue6d7\ue6d7\ue68c\ue6c6\ue68a", 58928), Code, Text);
		}
	}
}
