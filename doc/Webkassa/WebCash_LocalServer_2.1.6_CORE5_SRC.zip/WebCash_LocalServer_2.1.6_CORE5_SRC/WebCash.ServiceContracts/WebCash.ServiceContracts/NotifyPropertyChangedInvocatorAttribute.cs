using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class NotifyPropertyChangedInvocatorAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CanBeNull]
		public string ParameterName
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public NotifyPropertyChangedInvocatorAttribute()
		{
		}

		public NotifyPropertyChangedInvocatorAttribute([NotNull] string parameterName)
		{
			ParameterName = parameterName;
		}
	}
}
