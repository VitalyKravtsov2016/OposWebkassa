using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public sealed class AspChildControlTypeAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private Type _E001;

		[NotNull]
		public string TagName
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		[NotNull]
		public Type ControlType
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			private set
			{
				_E001 = value;
			}
		}

		public AspChildControlTypeAttribute([NotNull] string tagName, [NotNull] Type controlType)
		{
			TagName = tagName;
			ControlType = controlType;
		}
	}
}
