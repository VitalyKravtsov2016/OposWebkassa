using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class PathReferenceAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CanBeNull]
		public string BasePath
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public PathReferenceAttribute()
		{
		}

		public PathReferenceAttribute([NotNull][PathReference] string basePath)
		{
			BasePath = basePath;
		}
	}
}
