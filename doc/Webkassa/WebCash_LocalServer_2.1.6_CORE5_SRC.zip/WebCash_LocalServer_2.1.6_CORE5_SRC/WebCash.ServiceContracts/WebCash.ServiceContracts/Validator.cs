using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebCash.ServiceContracts
{
	public class Validator
	{
		private readonly List<ValidationResult> _E000;

		private readonly string _E001;

		public Validator(List<ValidationResult> errorsContainer)
		{
			_E000 = errorsContainer;
		}

		public Validator(List<ValidationResult> errorsContainer, string prefix)
			: this(errorsContainer)
		{
			_E000 = errorsContainer;
			_E001 = prefix;
		}

		public bool Condition(bool condition, string errorMessage)
		{
			if (condition)
			{
				return true;
			}
			_E000.Add(new ValidationResult(string.Format(_E006._E000("\ue415\ue45e\ue413\ue415\ue45f\ue413", 58478), _E001, errorMessage)));
			return true;
		}

		public void Equal<T>(T original, T expected, string errorMessage)
		{
			Condition(object.Equals(original, expected), string.Format(_E006._E000("\ue6c5\ue68e\ue6c3\ue69e\ue696\ue29c\ue28b\ue284\ue2fd\ue2f7\ue28b\ue28b\ue684\ue69e\ue6c5\ue68f\ue6c3\ue692\ue69e\ue2a0\ue288\ue286\ue28a\ue28e\ue285\ue280\ue2ff\ue2f2\ue684\ue69e\ue6c5\ue68c\ue6c3\ue697", 59070), errorMessage, original, expected));
		}

		public void Equal<T>(T original, T expected, string errorMessage, IEqualityComparer<T> comparer)
		{
			Condition(comparer.Equals(original, expected), string.Format(_E006._E000("\ue6c5\ue68e\ue6c3\ue69e\ue696\ue29c\ue28b\ue284\ue2fd\ue2f7\ue28b\ue28b\ue684\ue69e\ue6c5\ue68f\ue6c3\ue692\ue69e\ue2a0\ue288\ue286\ue28a\ue28e\ue285\ue280\ue2ff\ue2f2\ue684\ue69e\ue6c5\ue68c\ue6c3\ue697", 59070), errorMessage, original, expected));
		}
	}
}
