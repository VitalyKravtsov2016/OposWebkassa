using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class RazorHelperCommonAttribute : Attribute
	{
	}
}
