using System.Collections.Generic;

namespace WebCash.ServiceContracts
{
	public interface IRounder
	{
		decimal RoundTotal(IEnumerable<decimal> items);

		decimal RoundItem(decimal item);
	}
}
