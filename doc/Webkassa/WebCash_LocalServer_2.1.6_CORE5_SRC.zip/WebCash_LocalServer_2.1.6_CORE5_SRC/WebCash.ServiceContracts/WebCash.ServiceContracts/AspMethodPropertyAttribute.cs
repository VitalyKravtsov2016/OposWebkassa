using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Property)]
	public sealed class AspMethodPropertyAttribute : Attribute
	{
	}
}
