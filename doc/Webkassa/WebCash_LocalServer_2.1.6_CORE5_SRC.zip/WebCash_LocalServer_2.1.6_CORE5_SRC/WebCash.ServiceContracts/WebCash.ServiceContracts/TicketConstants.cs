using System;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts
{
	public static class TicketConstants
	{
		public static string GenerateTicketUrl(string cashboxUniqueNumber, string externalTicketNumber, long shiftNumber, bool isIntegrationEnv = false)
		{
			if (isIntegrationEnv)
			{
				return string.Format(_E006._E000("\uf097\uf08b\uf08b\uf08f\uf08c\uf0c5\uf0d0\uf0d0\uf09b\uf09a\uf089\uf094\uf094\uf092\uf0d1\uf088\uf09a\uf09d\uf094\uf09e\uf08c\uf08c\uf09e\uf0d1\uf094\uf085\uf0d0\uf0ab\uf096\uf09c\uf094\uf09a\uf08b\uf0c0\uf09c\uf097\uf09d\uf0c2\uf084\uf0cf\uf082\uf0d9\uf08c\uf097\uf0c2\uf084\uf0ce\uf082\uf0d9\uf09a\uf087\uf08b\uf091\uf08a\uf092\uf0c2\uf084\uf0cd\uf082", 61639), cashboxUniqueNumber, shiftNumber, externalTicketNumber);
			}
			return string.Format(_E006._E000("\uf2df\uf2c3\uf2c3\uf2c7\uf2c4\uf28d\uf298\uf298\uf2da\uf2ce\uf299\uf2c0\uf2d2\uf2d5\uf2dc\uf2d6\uf2c4\uf2c4\uf2d6\uf299\uf2dc\uf2cd\uf298\uf2e3\uf2de\uf2d4\uf2dc\uf2d2\uf2c3\uf288\uf2d4\uf2df\uf2d5\uf28a\uf2cc\uf287\uf2ca\uf291\uf2c4\uf2df\uf28a\uf2cc\uf286\uf2ca\uf291\uf2d2\uf2cf\uf2c3\uf2d9\uf2c2\uf2da\uf28a\uf2cc\uf285\uf2ca", 62131), cashboxUniqueNumber, shiftNumber, externalTicketNumber);
		}

		public static string GenerateTicketUrl(string cashboxUniqueNumber, long shiftNumber, string ticketNumber, bool isIntegrationEnv = false)
		{
			if (isIntegrationEnv)
			{
				return string.Format(_E006._E000("\ue197\ue18b\ue18b\ue18f\ue18c\ue1c5\ue1d0\ue1d0\ue19b\ue19a\ue189\ue194\ue194\ue192\ue1d1\ue188\ue19a\ue19d\ue194\ue19e\ue18c\ue18c\ue19e\ue1d1\ue194\ue185\ue1d0\ue1ab\ue196\ue19c\ue194\ue19a\ue18b\ue1d0\ue1bd\ue186\ue1b1\ue18a\ue192\ue19d\ue19a\ue18d\ue1c0\ue19c\ue197\ue19d\ue1c2\ue184\ue1cf\ue182\ue1d9\ue18c\ue197\ue1c2\ue184\ue1ce\ue182\ue1d9\ue191\ue18a\ue192\ue1c2\ue184\ue1cd\ue182", 57819), cashboxUniqueNumber, shiftNumber, ticketNumber);
			}
			return string.Format(_E006._E000("\uf097\uf08b\uf08b\uf08f\uf08c\uf0c5\uf0d0\uf0d0\uf092\uf086\uf0d1\uf088\uf09a\uf09d\uf094\uf09e\uf08c\uf08c\uf09e\uf0d1\uf094\uf085\uf0d0\uf0ab\uf096\uf09c\uf094\uf09a\uf08b\uf0d0\uf0bd\uf086\uf0b1\uf08a\uf092\uf09d\uf09a\uf08d\uf0c0\uf09c\uf097\uf09d\uf0c2\uf084\uf0cf\uf082\uf0d9\uf08c\uf097\uf0c2\uf084\uf0ce\uf082\uf0d9\uf091\uf08a\uf092\uf0c2\uf084\uf0cd\uf082", 61575), cashboxUniqueNumber, shiftNumber, ticketNumber);
		}

		public static string GenerateTicketUrl(string cashboxRegNumber, string fiscalNumber, decimal ticketSum, DateTimeOffset ticketDate, string ofdHost, OfdEnum ofd)
		{
			DateTime dateTime = ticketDate.DateTime;
			string text = ticketSum.ToString(_E006._E000("\uf28e\uf290\uf28e\uf28e", 62142)).Replace(_E006._E000("\ue8b7", 59530), _E006._E000("\ue1f1", 57615));
			return ofd switch
			{
				OfdEnum.KazakhTelecom => string.Format(_E006._E000("\uf49f\uf483\uf483\uf487\uf4cd\uf4d8\uf4d8\uf48c\uf4c7\uf48a\uf4c8\uf49e\uf4ca\uf48c\uf4c6\uf48a\uf4d1\uf491\uf4ca\uf48c\uf4c5\uf48a\uf4d1\uf484\uf4ca\uf48c\uf4c4\uf48a\uf4d1\uf483\uf4ca\uf48c\uf4c3\uf4cd\uf48e\uf48e\uf48e\uf48e\uf4ba\uf4ba\uf493\uf493\uf4a3\uf4bf\uf4bf\uf49a\uf49a\uf484\uf484\uf48a", 62640), ofdHost, fiscalNumber, cashboxRegNumber, text, dateTime), 
				OfdEnum.TransTelecom => string.Format(_E006._E000("\uf7b6\uf7aa\uf7aa\uf7ae\uf7e4\uf7f1\uf7f1\uf7a5\uf7ee\uf7a3\uf7f1\uf7aa\uf7f1\uf7e1\uf7b7\uf7e3\uf7a5\uf7ef\uf7a3\uf7f8\uf7b8\uf7e3\uf7a5\uf7ec\uf7a3\uf7f8\uf7ad\uf7e3\uf7a5\uf7ed\uf7a3\uf7f8\uf7aa\uf7e3\uf7a5\uf7ea\uf7e4\uf7a7\uf7a7\uf7a7\uf7a7\uf793\uf793\uf7ba\uf7ba\uf78a\uf796\uf796\uf7b3\uf7b3\uf7ad\uf7ad\uf7a3", 63314), ofdHost, fiscalNumber, cashboxRegNumber, text, dateTime), 
				OfdEnum.KazTranscom => string.Format(_E006._E000("\uf49f\uf483\uf483\uf487\uf4cd\uf4d8\uf4d8\uf48c\uf4c7\uf48a\uf4c8\uf49e\uf4ca\uf48c\uf4c6\uf48a\uf4d1\uf491\uf4ca\uf48c\uf4c5\uf48a\uf4d1\uf484\uf4ca\uf48c\uf4c4\uf48a\uf4d1\uf483\uf4ca\uf48c\uf4c3\uf4cd\uf48e\uf48e\uf48e\uf48e\uf4ba\uf4ba\uf493\uf493\uf4a3\uf4bf\uf4bf\uf49a\uf49a\uf484\uf484\uf48a", 62640), ofdHost, fiscalNumber, cashboxRegNumber, text, dateTime), 
				_ => string.Format(_E006._E000("\uf49f\uf483\uf483\uf487\uf4cd\uf4d8\uf4d8\uf48c\uf4c7\uf48a\uf4c8\uf49e\uf4ca\uf48c\uf4c6\uf48a\uf4d1\uf491\uf4ca\uf48c\uf4c5\uf48a\uf4d1\uf484\uf4ca\uf48c\uf4c4\uf48a\uf4d1\uf483\uf4ca\uf48c\uf4c3\uf4cd\uf48e\uf48e\uf48e\uf48e\uf4ba\uf4ba\uf493\uf493\uf4a3\uf4bf\uf4bf\uf49a\uf49a\uf484\uf484\uf48a", 62640), ofdHost, fiscalNumber, cashboxRegNumber, text, dateTime), 
			};
		}

		public static string GenerateTradeTicketUrl(string tradeOperationId, int tradeOperationNum, DateTime tradeOperationDate)
		{
			return string.Format(_E006._E000("\ue357\ue34b\ue34b\ue34f\ue305\ue310\ue310\ue348\ue35a\ue35d\ue35c\ue357\ue35a\ue35c\ue354\ue311\ue354\ue345\ue310\ue34a\ue356\ue310\ue359\ue356\ue351\ue35b\ue300\ue356\ue35b\ue302\ue344\ue30f\ue342\ue319\ue351\ue34a\ue352\ue302\ue344\ue30e\ue342\ue319\ue35b\ue34b\ue302\ue344\ue30d\ue305\ue346\ue346\ue346\ue346\ue372\ue372\ue35b\ue35b\ue36b\ue377\ue377\ue352\ue352\ue34c\ue34c\ue342", 58134), tradeOperationId, tradeOperationNum, tradeOperationDate);
		}

		public static string GenerateOfflineNumber(long cashboxIdentityNumber, DateTime offlineDate)
		{
			int num = (int)(offlineDate.TimeOfDay.TotalMilliseconds / 100.0);
			string text = cashboxIdentityNumber.ToString().PadLeft(3, '0');
			text = text.Substring(text.Length - 3, 3);
			return string.Format(_E006._E000("\ue415\ue45e\ue413\ue415\ue45f\ue413", 58478), text, num).TrimStart(new char[1] { '0' });
		}

		public static string GenerateOfflineNumber(long cashboxIdentityNumber, DateTimeOffset offlineDate)
		{
			return GenerateOfflineNumber(cashboxIdentityNumber, offlineDate.Date);
		}
	}
}
