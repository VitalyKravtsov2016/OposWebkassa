namespace WebCash.ServiceContracts
{
	public enum AssertionConditionType
	{
		IS_TRUE,
		IS_FALSE,
		IS_NULL,
		IS_NOT_NULL
	}
}
