namespace WebCash.ServiceContracts
{
	public enum FontStyle
	{
		Normal,
		Bold,
		Italic
	}
}
