using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	public class FixedTotalRounder : IRounder
	{
		public decimal RoundTotal(IEnumerable<decimal> items)
		{
			return Math.Round(items.Sum((decimal _E003) => RoundItem(_E003)), 0, MidpointRounding.AwayFromZero);
		}

		public decimal RoundItem(decimal item)
		{
			return Math.Round(item, 2, MidpointRounding.AwayFromZero);
		}

		[CompilerGenerated]
		private decimal _E000(decimal _E003)
		{
			return RoundItem(_E003);
		}
	}
}
