using System;
using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
	public sealed class ContractAnnotationAttribute : Attribute
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private bool _E001;

		[NotNull]
		public string Contract
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			private set
			{
				_E000 = value;
			}
		}

		public bool ForceFullStates
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			private set
			{
				_E001 = value;
			}
		}

		public ContractAnnotationAttribute([NotNull] string contract)
			: this(contract, forceFullStates: false)
		{
		}

		public ContractAnnotationAttribute([NotNull] string contract, bool forceFullStates)
		{
			Contract = contract;
			ForceFullStates = forceFullStates;
		}
	}
}
