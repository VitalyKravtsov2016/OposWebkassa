using System;
using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
	public class EmailAttribute : RegularExpressionAttribute
	{
		static EmailAttribute()
		{
		}

		public EmailAttribute()
			: base(_E006._E000("\uee85\ueef3\uee80\ueef6\uee84\ueeeb\ueef6\ueee2\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\ueef3\uee80\ueef0\uee86\ueef1\uee80\ueef5\uee86\ueea0\ueeeb\ueef7\ueeea\ueea6\uee80\ueef6\uee84\ueeeb\ueef6\ueee2\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\ueef2\ueea0\ueeeb\ueef7\ueeed\ueee8\ueea6\uee9b\ueef3\uee80\ueeeb\ueef6\ueee2\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\uee80\ueef6\ueeeb\ueef6\ueee2\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\ueea0\ueeeb\ueef7\ueeed\ueeea\ueea6\uee80\ueeeb\ueef6\ueee2\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\uee87\ueef5\ueef2\ueef0\uee80\ueeba\ueef6\ueea1\uee9a\ueef6\uee81\uee86\ueea0\ueee9\ueef7\ueee2\ueea6\ueef2\ueeff", 61146))
		{
			base.ErrorMessageResourceType = typeof(ValidationResource);
			base.ErrorMessageResourceName = _E006._E000("\uf29b\uf2b3\uf2bf\uf2b7\uf2b2\uf297\uf2b0\uf2bd\uf2b1\uf2ac\uf2ac\uf2bb\uf2bd\uf2aa", 62164);
		}
	}
}
