using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcViewComponentViewAttribute : Attribute
	{
	}
}
