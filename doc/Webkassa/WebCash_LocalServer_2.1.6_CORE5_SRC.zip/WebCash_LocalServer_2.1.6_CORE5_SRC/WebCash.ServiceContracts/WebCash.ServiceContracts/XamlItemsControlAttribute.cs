using System;

namespace WebCash.ServiceContracts
{
	[AttributeUsage(AttributeTargets.Class)]
	public sealed class XamlItemsControlAttribute : Attribute
	{
	}
}
