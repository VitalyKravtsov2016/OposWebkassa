using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts
{
	public class UpdateModel
	{
		[CompilerGenerated]
		private UpdateInfo _E000;

		[CompilerGenerated]
		private byte[] _E001;

		public UpdateInfo UpdateInfo
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public byte[] Content
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
