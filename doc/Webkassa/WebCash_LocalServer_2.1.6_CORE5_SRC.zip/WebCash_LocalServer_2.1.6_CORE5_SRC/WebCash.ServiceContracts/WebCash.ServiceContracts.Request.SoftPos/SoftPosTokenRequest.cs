using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request.SoftPos
{
	public class SoftPosTokenRequest
	{
		[CompilerGenerated]
		private string _E000;

		[CompilerGenerated]
		private string _E001;

		[CompilerGenerated]
		private string _E002;

		[CompilerGenerated]
		private string _E003;

		[CompilerGenerated]
		private string _E004;

		[CompilerGenerated]
		private string _E005;

		[JsonProperty(PropertyName = "@MsgNum")]
		public string CorrelationId
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		[JsonProperty(PropertyName = "OpLogin")]
		public string OperatorLogin
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}

		[JsonProperty(PropertyName = "SysLogin")]
		public string SystemLogin
		{
			[CompilerGenerated]
			get
			{
				return _E002;
			}
			[CompilerGenerated]
			set
			{
				_E002 = value;
			}
		}

		[JsonProperty(PropertyName = "SysPwd")]
		public string SystemPwdHash
		{
			[CompilerGenerated]
			get
			{
				return _E003;
			}
			[CompilerGenerated]
			set
			{
				_E003 = value;
			}
		}

		[JsonProperty(PropertyName = "Lang")]
		public string Language
		{
			[CompilerGenerated]
			get
			{
				return _E004;
			}
			[CompilerGenerated]
			set
			{
				_E004 = value;
			}
		}

		[JsonProperty(PropertyName = "Info")]
		public string Information
		{
			[CompilerGenerated]
			get
			{
				return _E005;
			}
			[CompilerGenerated]
			set
			{
				_E005 = value;
			}
		}

		public SoftPosTokenRequest()
		{
			Language = _E006._E000("\uf62c\uf62b\uf62d", 62996);
			Information = _E006._E000("\uf43d\uf41b\uf410\uf40a\uf431\uf42d\uf45e\uf449", 62580);
		}
	}
}
