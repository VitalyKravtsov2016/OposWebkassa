using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateTicketSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private PrinterTypeEnum _E07E;

		[CompilerGenerated]
		private string _E07F;

		[CompilerGenerated]
		private bool _E0B9;

		[CompilerGenerated]
		private bool _E0BA;

		[CompilerGenerated]
		private bool _E0BB;

		[CompilerGenerated]
		private bool _E0BC;

		[CompilerGenerated]
		private byte[] _E080;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(PrinterTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public PrinterTypeEnum PrinterType
		{
			[CompilerGenerated]
			get
			{
				return _E07E;
			}
			[CompilerGenerated]
			set
			{
				_E07E = value;
			}
		}

		[StringLength(500, ErrorMessageResourceName = "CannotBeMore500", ErrorMessageResourceType = typeof(ValidationResource))]
		public string AdText
		{
			[CompilerGenerated]
			get
			{
				return _E07F;
			}
			[CompilerGenerated]
			set
			{
				_E07F = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool ApplyToAll
		{
			[CompilerGenerated]
			get
			{
				return _E0B9;
			}
			[CompilerGenerated]
			set
			{
				_E0B9 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool UseLogo
		{
			[CompilerGenerated]
			get
			{
				return _E0BA;
			}
			[CompilerGenerated]
			set
			{
				_E0BA = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool PrintSlipCheck
		{
			[CompilerGenerated]
			get
			{
				return _E0BB;
			}
			[CompilerGenerated]
			set
			{
				_E0BB = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool AutoDownloadPDF
		{
			[CompilerGenerated]
			get
			{
				return _E0BC;
			}
			[CompilerGenerated]
			set
			{
				_E0BC = value;
			}
		}

		public byte[] LogoImage
		{
			[CompilerGenerated]
			get
			{
				return _E080;
			}
			[CompilerGenerated]
			set
			{
				_E080 = value;
			}
		}
	}
}
