using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdatePaymentTypesSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private PaymentTypeEnum[] _E09C;

		[CompilerGenerated]
		private long? _E09D;

		[CompilerGenerated]
		private PaymentTypeEnum? _E09E;

		public PaymentTypeEnum[] PaymentTypes
		{
			[CompilerGenerated]
			get
			{
				return _E09C;
			}
			[CompilerGenerated]
			set
			{
				_E09C = value;
			}
		}

		public long? KaspiQrTradePointId
		{
			[CompilerGenerated]
			get
			{
				return _E09D;
			}
			[CompilerGenerated]
			set
			{
				_E09D = value;
			}
		}

		public PaymentTypeEnum? DefaultPaymentType
		{
			[CompilerGenerated]
			get
			{
				return _E09E;
			}
			[CompilerGenerated]
			set
			{
				_E09E = value;
			}
		}
	}
}
