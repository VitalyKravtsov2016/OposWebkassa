using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxRegisterRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private string _E021;

		[CompilerGenerated]
		private string _E043;

		[CompilerGenerated]
		private long _E044;

		[CompilerGenerated]
		private uint _E01D;

		[CompilerGenerated]
		private DateTime _E08B;

		[CompilerGenerated]
		private OfdEnum _E08C;

		[CompilerGenerated]
		private CashboxTimeZoneEnum _E08D;

		[CompilerGenerated]
		private long? _E027;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[RegularExpression("^[0-9]*$", ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "NumberRequired")]
		[StringLength(12, MinimumLength = 12, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "CashboxRegistrationNumberLength")]
		public string RegistrationNumber
		{
			[CompilerGenerated]
			get
			{
				return _E043;
			}
			[CompilerGenerated]
			set
			{
				_E043 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public long IdentityNumber
		{
			[CompilerGenerated]
			get
			{
				return _E044;
			}
			[CompilerGenerated]
			set
			{
				_E044 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public uint OfdToken
		{
			[CompilerGenerated]
			get
			{
				return _E01D;
			}
			[CompilerGenerated]
			set
			{
				_E01D = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[DataType(DataType.Date)]
		public DateTime RegistrationDate
		{
			[CompilerGenerated]
			get
			{
				return _E08B;
			}
			[CompilerGenerated]
			set
			{
				_E08B = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(OfdEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public OfdEnum OfdCode
		{
			[CompilerGenerated]
			get
			{
				return _E08C;
			}
			[CompilerGenerated]
			set
			{
				_E08C = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(CashboxTimeZoneEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public CashboxTimeZoneEnum TimeZoneCode
		{
			[CompilerGenerated]
			get
			{
				return _E08D;
			}
			[CompilerGenerated]
			set
			{
				_E08D = value;
			}
		}

		public long? TradePointId
		{
			[CompilerGenerated]
			get
			{
				return _E027;
			}
			[CompilerGenerated]
			set
			{
				_E027 = value;
			}
		}
	}
}
