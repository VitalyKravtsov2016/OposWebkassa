using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateTicketModifiersSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private RoundTypeEnum _E037;

		[CompilerGenerated]
		private DiscountInputTypeEnum _E0B4;

		[CompilerGenerated]
		private bool _E0B5;

		[CompilerGenerated]
		private bool _E0B6;

		[CompilerGenerated]
		private string _E0B7;

		[CompilerGenerated]
		private decimal _E0B8;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(RoundTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public RoundTypeEnum RoundType
		{
			[CompilerGenerated]
			get
			{
				return _E037;
			}
			[CompilerGenerated]
			set
			{
				_E037 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(DiscountInputTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public DiscountInputTypeEnum DiscountInputType
		{
			[CompilerGenerated]
			get
			{
				return _E0B4;
			}
			[CompilerGenerated]
			set
			{
				_E0B4 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool MarkupVisiblity
		{
			[CompilerGenerated]
			get
			{
				return _E0B5;
			}
			[CompilerGenerated]
			set
			{
				_E0B5 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool IsCheckMarkup
		{
			[CompilerGenerated]
			get
			{
				return _E0B6;
			}
			[CompilerGenerated]
			set
			{
				_E0B6 = value;
			}
		}

		public string CheckMarkupName
		{
			[CompilerGenerated]
			get
			{
				return _E0B7;
			}
			[CompilerGenerated]
			set
			{
				_E0B7 = value;
			}
		}

		public decimal CheckMarkupValue
		{
			[CompilerGenerated]
			get
			{
				return _E0B8;
			}
			[CompilerGenerated]
			set
			{
				_E0B8 = value;
			}
		}
	}
}
