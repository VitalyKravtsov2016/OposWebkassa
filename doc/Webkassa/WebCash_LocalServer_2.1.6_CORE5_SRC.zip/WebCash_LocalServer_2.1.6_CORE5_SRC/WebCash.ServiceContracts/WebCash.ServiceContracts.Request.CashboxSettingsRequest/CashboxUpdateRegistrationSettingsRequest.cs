using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateRegistrationSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private string _E021;

		[CompilerGenerated]
		private CashboxTimeZoneEnum _E08D;

		[CompilerGenerated]
		private long? _E027;

		[CompilerGenerated]
		private string _E0A6;

		[CompilerGenerated]
		private string _E0A7;

		[CompilerGenerated]
		private string _E0A8;

		[CompilerGenerated]
		private string _E0A9;

		[CompilerGenerated]
		private DomainTypeEnum _E0AA;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Name
		{
			[CompilerGenerated]
			get
			{
				return _E021;
			}
			[CompilerGenerated]
			set
			{
				_E021 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(CashboxTimeZoneEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public CashboxTimeZoneEnum TimeZoneCode
		{
			[CompilerGenerated]
			get
			{
				return _E08D;
			}
			[CompilerGenerated]
			set
			{
				_E08D = value;
			}
		}

		public long? TradePointId
		{
			[CompilerGenerated]
			get
			{
				return _E027;
			}
			[CompilerGenerated]
			set
			{
				_E027 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public string KatoCode
		{
			[CompilerGenerated]
			get
			{
				return _E0A6;
			}
			[CompilerGenerated]
			set
			{
				_E0A6 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string Street
		{
			[CompilerGenerated]
			get
			{
				return _E0A7;
			}
			[CompilerGenerated]
			set
			{
				_E0A7 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string House
		{
			[CompilerGenerated]
			get
			{
				return _E0A8;
			}
			[CompilerGenerated]
			set
			{
				_E0A8 = value;
			}
		}

		public string Office
		{
			[CompilerGenerated]
			get
			{
				return _E0A9;
			}
			[CompilerGenerated]
			set
			{
				_E0A9 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(DomainTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public DomainTypeEnum DefaultDomainType
		{
			[CompilerGenerated]
			get
			{
				return _E0AA;
			}
			[CompilerGenerated]
			set
			{
				_E0AA = value;
			}
		}
	}
}
