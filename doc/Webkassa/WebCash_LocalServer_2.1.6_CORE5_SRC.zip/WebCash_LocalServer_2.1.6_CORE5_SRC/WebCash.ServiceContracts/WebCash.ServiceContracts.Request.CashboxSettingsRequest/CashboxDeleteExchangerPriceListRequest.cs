using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxDeleteExchangerPriceListRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private long _E028;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public long Id
		{
			[CompilerGenerated]
			get
			{
				return _E028;
			}
			[CompilerGenerated]
			set
			{
				_E028 = value;
			}
		}
	}
}
