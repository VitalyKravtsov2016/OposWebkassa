using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateExternalOrganizationSettingsRequest : CashboxExternalOrganizationsRequest
	{
		[CompilerGenerated]
		private long? _E09A;

		[CompilerGenerated]
		private bool _E09B;

		[CompilerGenerated]
		private string _E052;

		public long? ExternalOrganizationId
		{
			[CompilerGenerated]
			get
			{
				return _E09A;
			}
			[CompilerGenerated]
			set
			{
				_E09A = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool IsTransferData
		{
			[CompilerGenerated]
			get
			{
				return _E09B;
			}
			[CompilerGenerated]
			set
			{
				_E09B = value;
			}
		}

		public string Password
		{
			[CompilerGenerated]
			get
			{
				return _E052;
			}
			[CompilerGenerated]
			set
			{
				_E052 = value;
			}
		}
	}
}
