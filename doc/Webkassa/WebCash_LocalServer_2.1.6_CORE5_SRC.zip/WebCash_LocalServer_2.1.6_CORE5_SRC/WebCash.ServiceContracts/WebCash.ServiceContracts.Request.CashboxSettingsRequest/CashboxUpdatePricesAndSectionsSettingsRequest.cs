using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdatePricesAndSectionsSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private bool _E09F;

		[CompilerGenerated]
		private BlockPriceListUserInputMode _E0A0;

		[CompilerGenerated]
		private string _E0A1;

		[CompilerGenerated]
		private string _E0A2;

		[CompilerGenerated]
		private long? _E0A3;

		[CompilerGenerated]
		private long? _E0A4;

		[CompilerGenerated]
		private long[] _E0A5;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool UsePriceList
		{
			[CompilerGenerated]
			get
			{
				return _E09F;
			}
			[CompilerGenerated]
			set
			{
				_E09F = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public BlockPriceListUserInputMode BlockPriceListUserInput
		{
			[CompilerGenerated]
			get
			{
				return _E0A0;
			}
			[CompilerGenerated]
			set
			{
				_E0A0 = value;
			}
		}

		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string DefaultSellPositionName
		{
			[CompilerGenerated]
			get
			{
				return _E0A1;
			}
			[CompilerGenerated]
			set
			{
				_E0A1 = value;
			}
		}

		[StringLength(255, ErrorMessageResourceName = "CannotBeMore255", ErrorMessageResourceType = typeof(ValidationResource))]
		public string DefaultPurchasePositionName
		{
			[CompilerGenerated]
			get
			{
				return _E0A2;
			}
			[CompilerGenerated]
			set
			{
				_E0A2 = value;
			}
		}

		public long? DefaultSectionId
		{
			[CompilerGenerated]
			get
			{
				return _E0A3;
			}
			[CompilerGenerated]
			set
			{
				_E0A3 = value;
			}
		}

		public long? DefaultUnitId
		{
			[CompilerGenerated]
			get
			{
				return _E0A4;
			}
			[CompilerGenerated]
			set
			{
				_E0A4 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public long[] Sections
		{
			[CompilerGenerated]
			get
			{
				return _E0A5;
			}
			[CompilerGenerated]
			set
			{
				_E0A5 = value;
			}
		}
	}
}
