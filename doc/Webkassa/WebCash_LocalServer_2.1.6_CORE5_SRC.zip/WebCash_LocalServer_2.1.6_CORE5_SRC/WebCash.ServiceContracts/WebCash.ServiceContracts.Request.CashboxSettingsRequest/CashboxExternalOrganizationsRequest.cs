using System.Linq;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxExternalOrganizationsRequest : CashboxProgrammingRequest
	{
		public override PermissionEnum[] GetRequiredPermissions()
		{
			return base.GetRequiredPermissions().Concat(new PermissionEnum[1] { PermissionEnum.ManageExternalOrganizationsDataTransfer }).ToArray();
		}
	}
}
