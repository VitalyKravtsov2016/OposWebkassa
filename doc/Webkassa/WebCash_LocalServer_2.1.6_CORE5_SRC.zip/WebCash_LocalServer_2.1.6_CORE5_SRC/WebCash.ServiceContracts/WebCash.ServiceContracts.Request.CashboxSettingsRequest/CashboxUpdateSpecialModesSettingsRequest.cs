using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateSpecialModesSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private bool _E0AB;

		[CompilerGenerated]
		private bool _E0AC;

		[CompilerGenerated]
		private bool _E0AD;

		[CompilerGenerated]
		private bool _E0AE;

		[CompilerGenerated]
		private bool _E0AF;

		[CompilerGenerated]
		private bool _E0B0;

		[CompilerGenerated]
		private MarkingModeEnum _E0B1;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool HasBuyMode
		{
			[CompilerGenerated]
			get
			{
				return _E0AB;
			}
			[CompilerGenerated]
			set
			{
				_E0AB = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool HasExchangeMode
		{
			[CompilerGenerated]
			get
			{
				return _E0AC;
			}
			[CompilerGenerated]
			set
			{
				_E0AC = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool CourierMode
		{
			[CompilerGenerated]
			get
			{
				return _E0AD;
			}
			[CompilerGenerated]
			set
			{
				_E0AD = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool OfflineCheckApiSupported
		{
			[CompilerGenerated]
			get
			{
				return _E0AE;
			}
			[CompilerGenerated]
			set
			{
				_E0AE = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool IsExcise
		{
			[CompilerGenerated]
			get
			{
				return _E0AF;
			}
			[CompilerGenerated]
			set
			{
				_E0AF = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool ApplyMarkingToAllCashboxes
		{
			[CompilerGenerated]
			get
			{
				return _E0B0;
			}
			[CompilerGenerated]
			set
			{
				_E0B0 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(MarkingModeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public MarkingModeEnum MarkingMode
		{
			[CompilerGenerated]
			get
			{
				return _E0B1;
			}
			[CompilerGenerated]
			set
			{
				_E0B1 = value;
			}
		}
	}
}
