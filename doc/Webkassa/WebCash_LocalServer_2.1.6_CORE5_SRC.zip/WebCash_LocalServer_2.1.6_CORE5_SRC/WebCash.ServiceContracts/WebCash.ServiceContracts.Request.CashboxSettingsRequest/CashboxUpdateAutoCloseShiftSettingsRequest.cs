using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateAutoCloseShiftSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private long? _E08E;

		[CompilerGenerated]
		private bool _E08F;

		[CompilerGenerated]
		private int _E090;

		[CompilerGenerated]
		private int _E091;

		[CompilerGenerated]
		private decimal? _E092;

		[CompilerGenerated]
		private AutoWithDrawalTypeEnum _E093;

		[CompilerGenerated]
		private EmailSendModeEnum _E094;

		[CompilerGenerated]
		private string _E095;

		public long? AutoCloseByEmployeeId
		{
			[CompilerGenerated]
			get
			{
				return _E08E;
			}
			[CompilerGenerated]
			set
			{
				_E08E = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool AutoCloseEnabled
		{
			[CompilerGenerated]
			get
			{
				return _E08F;
			}
			[CompilerGenerated]
			set
			{
				_E08F = value;
			}
		}

		[Range(0, 23, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "ValueShoulds")]
		public int AutoCloseHours
		{
			[CompilerGenerated]
			get
			{
				return _E090;
			}
			[CompilerGenerated]
			set
			{
				_E090 = value;
			}
		}

		[Range(0, 59, ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "ValueShoulds")]
		public int AutoCloseMinutes
		{
			[CompilerGenerated]
			get
			{
				return _E091;
			}
			[CompilerGenerated]
			set
			{
				_E091 = value;
			}
		}

		public decimal? PartialAutoWithdrawalSum
		{
			[CompilerGenerated]
			get
			{
				return _E092;
			}
			[CompilerGenerated]
			set
			{
				_E092 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(AutoWithDrawalTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public AutoWithDrawalTypeEnum AutoWithdrawalType
		{
			[CompilerGenerated]
			get
			{
				return _E093;
			}
			[CompilerGenerated]
			set
			{
				_E093 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(EmailSendModeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public EmailSendModeEnum EmailSendMode
		{
			[CompilerGenerated]
			get
			{
				return _E094;
			}
			[CompilerGenerated]
			set
			{
				_E094 = value;
			}
		}

		[Email]
		public string EmailZReport
		{
			[CompilerGenerated]
			get
			{
				return _E095;
			}
			[CompilerGenerated]
			set
			{
				_E095 = value;
			}
		}
	}
}
