using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateCustomersSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private bool _E097;

		[CompilerGenerated]
		private bool _E098;

		[CompilerGenerated]
		private bool _E099;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool EnterCustomerXin
		{
			[CompilerGenerated]
			get
			{
				return _E097;
			}
			[CompilerGenerated]
			set
			{
				_E097 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool IsPrintCustomerXin
		{
			[CompilerGenerated]
			get
			{
				return _E098;
			}
			[CompilerGenerated]
			set
			{
				_E098 = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public bool AutoSendEmail
		{
			[CompilerGenerated]
			get
			{
				return _E099;
			}
			[CompilerGenerated]
			set
			{
				_E099 = value;
			}
		}
	}
}
