using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateTokenSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private uint _E01D;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		public uint OfdToken
		{
			[CompilerGenerated]
			get
			{
				return _E01D;
			}
			[CompilerGenerated]
			set
			{
				_E01D = value;
			}
		}
	}
}
