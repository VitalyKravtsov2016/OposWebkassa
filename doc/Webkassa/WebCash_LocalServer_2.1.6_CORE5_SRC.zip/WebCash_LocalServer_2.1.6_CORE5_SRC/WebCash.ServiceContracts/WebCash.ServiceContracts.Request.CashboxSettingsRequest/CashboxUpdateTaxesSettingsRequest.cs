using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateTaxesSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private bool _E0B2;

		[CompilerGenerated]
		private TaxPercentTypeEnum? _E0B3;

		public bool PrintWithoutVat
		{
			[CompilerGenerated]
			get
			{
				return _E0B2;
			}
			[CompilerGenerated]
			set
			{
				_E0B2 = value;
			}
		}

		public TaxPercentTypeEnum? DefaultVatRate
		{
			[CompilerGenerated]
			get
			{
				return _E0B3;
			}
			[CompilerGenerated]
			set
			{
				_E0B3 = value;
			}
		}
	}
}
