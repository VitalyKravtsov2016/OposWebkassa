using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxRequest : AuthorizedRequest
	{
		[CompilerGenerated]
		private long _E016;

		[Required]
		[JsonProperty(Required = Required.Always)]
		public long CashboxId
		{
			[CompilerGenerated]
			get
			{
				return _E016;
			}
			[CompilerGenerated]
			set
			{
				_E016 = value;
			}
		}

		public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
		{
			return new List<ValidationResult>();
		}
	}
}
