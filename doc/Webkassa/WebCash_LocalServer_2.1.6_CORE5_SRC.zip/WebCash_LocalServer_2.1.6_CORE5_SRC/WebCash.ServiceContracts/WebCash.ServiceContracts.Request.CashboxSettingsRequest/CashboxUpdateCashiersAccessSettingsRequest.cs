using System.Runtime.CompilerServices;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxUpdateCashiersAccessSettingsRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private long[] _E096;

		public long[] Cashiers
		{
			[CompilerGenerated]
			get
			{
				return _E096;
			}
			[CompilerGenerated]
			set
			{
				_E096 = value;
			}
		}
	}
}
