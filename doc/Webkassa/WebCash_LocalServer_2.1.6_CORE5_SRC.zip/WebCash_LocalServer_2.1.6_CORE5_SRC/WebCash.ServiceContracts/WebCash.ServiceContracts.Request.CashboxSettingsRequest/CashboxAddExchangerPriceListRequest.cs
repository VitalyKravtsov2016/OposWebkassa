using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using WebCash.Constants.Enums;
using WebCash.Resources;

namespace WebCash.ServiceContracts.Request.CashboxSettingsRequest
{
	public class CashboxAddExchangerPriceListRequest : CashboxProgrammingRequest
	{
		[CompilerGenerated]
		private CurrencyTypeEnum _E08A;

		[CompilerGenerated]
		private OperationTypeEnum _E02E;

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(CurrencyTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public CurrencyTypeEnum CurrencyCode
		{
			[CompilerGenerated]
			get
			{
				return _E08A;
			}
			[CompilerGenerated]
			set
			{
				_E08A = value;
			}
		}

		[Required(ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "RequiredField")]
		[EnumDataType(typeof(OperationTypeEnum), ErrorMessageResourceType = typeof(ValidationResource), ErrorMessageResourceName = "IncorrectEnum")]
		public OperationTypeEnum OperationType
		{
			[CompilerGenerated]
			get
			{
				return _E02E;
			}
			[CompilerGenerated]
			set
			{
				_E02E = value;
			}
		}
	}
}
