namespace WebCash.Resources.Interfaces
{
	public interface ILocalizable
	{
		string NameRu { get; set; }

		string NameKz { get; set; }

		string NameEn { get; set; }
	}
}
