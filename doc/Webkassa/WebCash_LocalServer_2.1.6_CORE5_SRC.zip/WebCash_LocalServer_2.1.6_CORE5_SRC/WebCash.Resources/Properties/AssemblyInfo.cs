using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Webkassa")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("\r\n            Resources библиотека с файлами локализации для внутренних модулей\r\n        ")]
[assembly: AssemblyFileVersion("1.1.1.0")]
[assembly: AssemblyInformationalVersion("1.1.1")]
[assembly: AssemblyProduct("WebCash.Resources")]
[assembly: AssemblyTitle("WebCash.Resources")]
[assembly: AssemblyVersion("1.1.1.0")]
