using System.IO;
using System.Reflection;

internal sealed class _E000
{
	private delegate string _E000();

	private sealed class _E001
	{
		private static readonly _E000 m__E001;

		public static readonly _E001 _E004;

		private byte[] _E005;

		static _E001()
		{
			m__E001 = global::_E000._E001;
			_E004 = new _E001();
		}

		private _E001()
		{
			Stream manifestResourceStream = typeof(_E001).GetTypeInfo().Assembly.GetManifestResourceStream(m__E001());
			if (((manifestResourceStream == null) ? (~((0x359DB332 ^ -526279774) - -120367967) - 597109775) : (579396570 - 579396570 << 7)) == 0)
			{
				_E005 = new byte[-((-(~(-(-(-1219976429 - -225765209) + -649498758 - 530991747))) ^ -562674282) + 714333920 >> 2)];
				manifestResourceStream.Read(_E005, -(~(~(-176873745 ^ 0x11023102) + -646419398 - 295050553 + 479518956) << 7), _E005.Length);
			}
		}

		public string _E000(string _E007, int _E008)
		{
			int num = _E007.Length;
			char[] array = _E007.ToCharArray();
			while ((num -= ~(-9) >> 3) >= ~231392102 + 324997384 + -93605281)
			{
				array[num] = (char)(array[num] ^ (_E005[_E008 & 0xF] | _E008));
			}
			return new string(array);
		}
	}

	public static string _E000(string _E003, int _E004)
	{
		return global::_E000._E001._E004._E000(_E003, _E004);
	}

	public static string _E001()
	{
		char[] array = "-/(\u00036".ToCharArray();
		int num = array.Length;
		while ((num -= -(~(0x604039FB ^ 0x265A04D6) + 164767880 - -707130572) ^ 0x12221FDB) >= -(302500678 + 150355836 + -390482636) - -62373878 >> 3)
		{
			array[num] = (char)(array[num] ^ ~(-((~((-294940930 ^ -279162451) - 467027372) << 1) - 526691565) ^ 0x15D81FB9));
		}
		return new string(array);
	}
}
