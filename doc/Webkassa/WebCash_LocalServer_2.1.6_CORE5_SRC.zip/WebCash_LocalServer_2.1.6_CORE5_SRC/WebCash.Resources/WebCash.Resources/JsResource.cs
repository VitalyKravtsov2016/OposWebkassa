using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace WebCash.Resources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class JsResource
	{
		private static ResourceManager _E000;

		private static CultureInfo _E001;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (_E000 == null)
				{
					_E000 = new ResourceManager(global::_E000._E000("\uf3b8\uf38a\uf38d\uf3ac\uf38e\uf39c\uf387\uf3c1\uf3bd\uf38a\uf39c\uf380\uf39a\uf39d\uf38c\uf38a\uf39c\uf3c1\uf3a5\uf39c\uf3bd\uf38a\uf39c\uf380\uf39a\uf39d\uf38c\uf38a", 62438), typeof(JsResource).Assembly);
				}
				return _E000;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return _E001;
			}
			set
			{
				_E001 = value;
			}
		}

		public static string Address => ResourceManager.GetString(global::_E000._E000("\ue19e\ue1bb\ue1bb\ue1ad\ue1ba\ue1ac\ue1ac", 57750), _E001);

		public static string AdText => ResourceManager.GetString(global::_E000._E000("\uf12c\uf109\uf139\uf108\uf115\uf119", 61804), _E001);

		public static string AfterDeleteCashboxNotificate => ResourceManager.GetString(global::_E000._E000("\uf0f8\uf0df\uf0cd\uf0dc\uf0cb\uf0fd\uf0dc\uf0d5\uf0dc\uf0cd\uf0dc\uf0fa\uf0d8\uf0ca\uf0d1\uf0db\uf0d6\uf0c1\uf0f7\uf0d6\uf0cd\uf0d0\uf0df\uf0d0\uf0da\uf0d8\uf0cd\uf0dc", 61625), _E001);

		public static string AkmolaRegionNurSultan => ResourceManager.GetString(global::_E000._E000("\ue5be\ue594\ue592\ue590\ue593\ue59e\ue5ad\ue59a\ue598\ue596\ue590\ue591\ue5b1\ue58a\ue58d\ue5ac\ue58a\ue593\ue58b\ue59e\ue591", 58855), _E001);

		public static string AllCashboxMarking => ResourceManager.GetString(global::_E000._E000("\ue8ae\ue883\ue883\ue8ac\ue88e\ue89c\ue887\ue88d\ue880\ue897\ue8a2\ue88e\ue89d\ue884\ue886\ue881\ue888", 59530), _E001);

		public static string Apartment => ResourceManager.GetString(global::_E000._E000("\uf7de\uf7ef\uf7fe\uf7ed\uf7eb\uf7f2\uf7fa\uf7f1\uf7eb", 63255), _E001);

		public static string Application => ResourceManager.GetString(global::_E000._E000("\ue6bc\ue68d\ue68d\ue691\ue694\ue69e\ue69c\ue689\ue694\ue692\ue693", 59112), _E001);

		public static string ApplyVatForSection => ResourceManager.GetString(global::_E000._E000("\ue39e\ue3af\ue3af\ue3b3\ue3a6\ue389\ue3be\ue3ab\ue399\ue3b0\ue3ad\ue38c\ue3ba\ue3bc\ue3ab\ue3b6\ue3b0\ue3b1", 58311), _E001);

		public static string Area => ResourceManager.GetString(global::_E000._E000("\ueabc\uea8f\uea98\uea9c", 60149), _E001);

		public static string AreYouSureDeleteCashier => ResourceManager.GetString(global::_E000._E000("\uea96\ueaa5\ueab2\uea8e\ueab8\ueaa2\uea84\ueaa2\ueaa5\ueab2\uea93\ueab2\ueabb\ueab2\ueaa3\ueab2\uea94\ueab6\ueaa4\ueabf\ueabe\ueab2\ueaa5", 60052), _E001);

		public static string Attention => ResourceManager.GetString(global::_E000._E000("\uf4ea\uf4df\uf4df\uf4ce\uf4c5\uf4df\uf4c2\uf4c4\uf4c5", 62595), _E001);

		public static string AutoCloseShift => ResourceManager.GetString(global::_E000._E000("\ue1aa\ue19e\ue19f\ue184\ue1a8\ue187\ue184\ue198\ue18e\ue1b8\ue183\ue182\ue18d\ue19f", 57825), _E001);

		public static string AutoCloseShiftTime => ResourceManager.GetString(global::_E000._E000("\uea2c\uea18\uea19\uea02\uea2e\uea01\uea02\uea1e\uea08\uea3e\uea05\uea04\uea0b\uea19\uea39\uea04\uea00\uea08", 59980), _E001);

		public static string AutoCloseShiftUser => ResourceManager.GetString(global::_E000._E000("\uf0ae\uf09a\uf09b\uf080\uf0ac\uf083\uf080\uf09c\uf08a\uf0bc\uf087\uf086\uf089\uf09b\uf0ba\uf09c\uf08a\uf09d", 61679), _E001);

		public static string AutoDownloadPDF => ResourceManager.GetString(global::_E000._E000("\ue6fa\ue6ce\ue6cf\ue6d4\ue6ff\ue6d4\ue6cc\ue6d5\ue6d7\ue6d4\ue6da\ue6df\ue6eb\ue6ff\ue6fd", 59025), _E001);

		public static string AutoSendEmail => ResourceManager.GetString(global::_E000._E000("\ue99e\ue9aa\ue9ab\ue9b0\ue98c\ue9ba\ue9b1\ue9bb\ue99a\ue9b2\ue9be\ue9b6\ue9b3", 59863), _E001);

		public static string AutoWithDrawal => ResourceManager.GetString(global::_E000._E000("\uf33c\uf308\uf309\uf312\uf32a\uf314\uf309\uf315\uf339\uf30f\uf31c\uf30a\uf31c\uf311", 62293), _E001);

		public static string AutoWithDrawalFull => ResourceManager.GetString(global::_E000._E000("\ue7fc\ue7c8\ue7c9\ue7d2\ue7ea\ue7d4\ue7c9\ue7d5\ue7f9\ue7cf\ue7dc\ue7ca\ue7dc\ue7d1\ue7fb\ue7c8\ue7d1\ue7d1", 59324), _E001);

		public static string AutoWithDrawalFullShort => ResourceManager.GetString(global::_E000._E000("\ue8bc\ue888\ue889\ue892\ue8aa\ue894\ue889\ue895\ue8b9\ue88f\ue89c\ue88a\ue89c\ue891\ue8bb\ue888\ue891\ue891\ue8ae\ue895\ue892\ue88f\ue889", 59644), _E001);

		public static string AutoWithDrawalNone => ResourceManager.GetString(global::_E000._E000("\uf3be\uf38a\uf38b\uf390\uf3a8\uf396\uf38b\uf397\uf3bb\uf38d\uf39e\uf388\uf39e\uf393\uf3b1\uf390\uf391\uf39a", 62461), _E001);

		public static string AutoWithDrawalNoneShort => ResourceManager.GetString(global::_E000._E000("\uf3a6\uf392\uf393\uf388\uf3b0\uf38e\uf393\uf38f\uf3a3\uf395\uf386\uf390\uf386\uf38b\uf3a9\uf388\uf389\uf382\uf3b4\uf38f\uf388\uf395\uf393", 62436), _E001);

		public static string AutoWithDrawalPartial => ResourceManager.GetString(global::_E000._E000("\ue71c\ue728\ue729\ue732\ue70a\ue734\ue729\ue735\ue719\ue72f\ue73c\ue72a\ue73c\ue731\ue70d\ue73c\ue72f\ue729\ue734\ue73c\ue731", 59208), _E001);

		public static string AutoWithDrawalPartialShort => ResourceManager.GetString(global::_E000._E000("\uf1de\uf1ea\uf1eb\uf1f0\uf1c8\uf1f6\uf1eb\uf1f7\uf1db\uf1ed\uf1fe\uf1e8\uf1fe\uf1f3\uf1cf\uf1fe\uf1ed\uf1eb\uf1f6\uf1fe\uf1f3\uf1cc\uf1f7\uf1f0\uf1ed\uf1eb", 61847), _E001);

		public static string AvailableWhenShiftClosed => ResourceManager.GetString(global::_E000._E000("\ue5be\ue589\ue59e\ue596\ue593\ue59e\ue59d\ue593\ue59a\ue5a8\ue597\ue59a\ue591\ue5ac\ue597\ue596\ue599\ue58b\ue5bc\ue593\ue590\ue58c\ue59a\ue59b", 58810), _E001);

		public static string Avenue => ResourceManager.GetString(global::_E000._E000("\uf2b6\uf281\uf292\uf299\uf282\uf292", 62196), _E001);

		public static string BankCard => ResourceManager.GetString(global::_E000._E000("\uf8a9\uf88a\uf885\uf880\uf8a8\uf88a\uf899\uf88f", 63585), _E001);

		public static string BlockInputModeLabelDisabled => ResourceManager.GetString(global::_E000._E000("\uf42d\uf403\uf400\uf40c\uf404\uf426\uf401\uf41f\uf41a\uf41b\uf422\uf400\uf40b\uf40a\uf423\uf40e\uf40d\uf40a\uf403\uf42b\uf406\uf41c\uf40e\uf40d\uf403\uf40a\uf40b", 62570), _E001);

		public static string BlockInputModeLabelForAll => ResourceManager.GetString(global::_E000._E000("\uf79b\uf7b5\uf7b6\uf7ba\uf7b2\uf790\uf7b7\uf7a9\uf7ac\uf7ad\uf794\uf7b6\uf7bd\uf7bc\uf795\uf7b8\uf7bb\uf7bc\uf7b5\uf79f\uf7b6\uf7ab\uf798\uf7b5\uf7b5", 63321), _E001);

		public static string BlockInputModeLabelForNameOnly => ResourceManager.GetString(global::_E000._E000("\ue8ad\ue883\ue880\ue88c\ue884\ue8a6\ue881\ue89f\ue89a\ue89b\ue8a2\ue880\ue88b\ue88a\ue8a3\ue88e\ue88d\ue88a\ue883\ue8a9\ue880\ue89d\ue8a1\ue88e\ue882\ue88a\ue8a0\ue881\ue883\ue896", 59562), _E001);

		public static string BlockPriceListUserInput => ResourceManager.GetString(global::_E000._E000("\ue53c\ue512\ue511\ue51d\ue515\ue52e\ue50c\ue517\ue51d\ue51b\ue532\ue517\ue50d\ue50a\ue52b\ue50d\ue51b\ue50c\ue537\ue510\ue50e\ue50b\ue50a", 58750), _E001);

		public static string BookKeeping => ResourceManager.GetString(global::_E000._E000("\ue6fd\ue6d0\ue6d0\ue6d4\ue6f4\ue6da\ue6da\ue6cf\ue6d6\ue6d1\ue6d8", 58935), _E001);

		public static string Boulevard => ResourceManager.GetString(global::_E000._E000("\ue9a9\ue984\ue99e\ue987\ue98e\ue99d\ue98a\ue999\ue98f", 59715), _E001);

		public static string Building => ResourceManager.GetString(global::_E000._E000("\ue89c\ue8ab\ue8b7\ue8b2\ue8ba\ue8b7\ue8b0\ue8b9", 59598), _E001);

		public static string Buttons => ResourceManager.GetString(global::_E000._E000("\uf35c\uf36b\uf36a\uf36a\uf371\uf370\uf36d", 62238), _E001);

		public static string BuyMode => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue79e\ue792\ue7a6\ue784\ue78f\ue78e", 59331), _E001);

		public static string CalculateTariffUpgrade => ResourceManager.GetString(global::_E000._E000("\uf6f1\uf6d3\uf6de\uf6d1\uf6c7\uf6de\uf6d3\uf6c6\uf6d7\uf6e6\uf6d3\uf6c0\uf6db\uf6d4\uf6d4\uf6e7\uf6c2\uf6d5\uf6c0\uf6d3\uf6d6\uf6d7", 63120), _E001);

		public static string Cancel => ResourceManager.GetString(global::_E000._E000("\uef3e\uef1c\uef13\uef1e\uef18\uef11", 61288), _E001);

		public static string CantSendCheckWithSumLessNull => ResourceManager.GetString(global::_E000._E000("\ue9bc\ue99e\ue991\ue98b\ue9ac\ue99a\ue991\ue99b\ue9bc\ue997\ue99a\ue99c\ue994\ue9a8\ue996\ue98b\ue997\ue9ac\ue98a\ue992\ue9b3\ue99a\ue98c\ue98c\ue9b1\ue98a\ue993\ue993", 59895), _E001);

		public static string CantSendRequestCheckConnect => ResourceManager.GetString(global::_E000._E000("\ue5f8\ue5da\ue5d5\ue5cf\ue5e8\ue5de\ue5d5\ue5df\ue5e9\ue5de\ue5ca\ue5ce\ue5de\ue5c8\ue5cf\ue5f8\ue5d3\ue5de\ue5d8\ue5d0\ue5f8\ue5d4\ue5d5\ue5d5\ue5de\ue5d8\ue5cf", 58641), _E001);

		public static string Cash => ResourceManager.GetString(global::_E000._E000("\uf030\uf012\uf000\uf01b", 61554), _E001);

		public static string Cashbox => ResourceManager.GetString(global::_E000._E000("\ue0e8\ue0ca\ue0d8\ue0c3\ue0c9\ue0c4\ue0d3", 57347), _E001);

		public static string CashboxActivation => ResourceManager.GetString(global::_E000._E000("\ue170\ue152\ue140\ue15b\ue151\ue15c\ue14b\ue172\ue150\ue147\ue15a\ue145\ue152\ue147\ue15a\ue15c\ue15d", 57618), _E001);

		public static string CashboxAddress => ResourceManager.GetString(global::_E000._E000("\uf1f8\uf1da\uf1c8\uf1d3\uf1d9\uf1d4\uf1c3\uf1fa\uf1df\uf1df\uf1c9\uf1de\uf1c8\uf1c8", 61875), _E001);

		public static string CashboxCard => ResourceManager.GetString(global::_E000._E000("\ue39c\ue3be\ue3ac\ue3b7\ue3bd\ue3b0\ue3a7\ue39c\ue3be\ue3ad\ue3bb", 58183), _E001);

		public static string CashboxDefaultDomainType => ResourceManager.GetString(global::_E000._E000("\ue8fc\ue8de\ue8cc\ue8d7\ue8dd\ue8d0\ue8c7\ue8fb\ue8da\ue8d9\ue8de\ue8ca\ue8d3\ue8cb\ue8fb\ue8d0\ue8d2\ue8de\ue8d6\ue8d1\ue8eb\ue8c6\ue8cf\ue8da", 59575), _E001);

		public static string CashboxDescription => ResourceManager.GetString(global::_E000._E000("\ue2ea\ue2c8\ue2da\ue2c1\ue2cb\ue2c6\ue2d1\ue2ed\ue2cc\ue2da\ue2ca\ue2db\ue2c0\ue2d9\ue2dd\ue2c0\ue2c6\ue2c7", 57897), _E001);

		public static string CashboxDiscountInputType => ResourceManager.GetString(global::_E000._E000("\uedb8\ued9a\ued88\ued93\ued99\ued94\ued83\uedbf\ued92\ued88\ued98\ued94\ued8e\ued95\ued8f\uedb2\ued95\ued8b\ued8e\ued8f\uedaf\ued82\ued8b\ued9e", 60753), _E001);

		public static string CashBoxEdit => ResourceManager.GetString(global::_E000._E000("\uefb8\uef9a\uef88\uef93\uefb9\uef94\uef83\uefbe\uef9f\uef92\uef8f", 61427), _E001);

		public static string CashboxIdentityNumber => ResourceManager.GetString(global::_E000._E000("\uf2be\uf29c\uf28e\uf295\uf29f\uf292\uf285\uf2b4\uf299\uf298\uf293\uf289\uf294\uf289\uf284\uf2b3\uf288\uf290\uf29f\uf298\uf28f", 62136), _E001);

		public static string CashboxInformation => ResourceManager.GetString(global::_E000._E000("\uf23c\uf21e\uf20c\uf217\uf21d\uf210\uf207\uf236\uf211\uf219\uf210\uf20d\uf212\uf21e\uf20b\uf216\uf210\uf211", 62059), _E001);

		public static string CashboxManagement => ResourceManager.GetString(global::_E000._E000("\uf61e\uf63c\uf62e\uf635\uf63f\uf632\uf625\uf610\uf63c\uf633\uf63c\uf63a\uf638\uf630\uf638\uf633\uf629", 63000), _E001);

		public static string CashboxMarkupVisiblity => ResourceManager.GetString(global::_E000._E000("\ue0ac\ue08e\ue09c\ue087\ue08d\ue080\ue097\ue0a2\ue08e\ue09d\ue084\ue09a\ue09f\ue0b9\ue086\ue09c\ue086\ue08d\ue083\ue086\ue09b\ue096", 57357), _E001);

		public static string CashboxModelType => ResourceManager.GetString(global::_E000._E000("\uecac\uec8e\uec9c\uec87\uec8d\uec80\uec97\ueca2\uec80\uec8b\uec8a\uec83\uecbb\uec96\uec9f\uec8a", 60586), _E001);

		public static string CashboxModelType0 => ResourceManager.GetString(global::_E000._E000("\ue98a\ue9a8\ue9ba\ue9a1\ue9ab\ue9a6\ue9b1\ue984\ue9a6\ue9ad\ue9ac\ue9a5\ue99d\ue9b0\ue9b9\ue9ac\ue9f9", 59849), _E001);

		public static string CashboxModelType1 => ResourceManager.GetString(global::_E000._E000("\uf8a4\uf886\uf894\uf88f\uf885\uf888\uf89f\uf8aa\uf888\uf883\uf882\uf88b\uf8b3\uf89e\uf897\uf882\uf8d6", 63524), _E001);

		public static string CashboxModelType2 => ResourceManager.GetString(global::_E000._E000("\uf2b8\uf29a\uf288\uf293\uf299\uf294\uf283\uf2b6\uf294\uf29f\uf29e\uf297\uf2af\uf282\uf28b\uf29e\uf2c9", 62067), _E001);

		public static string CashboxModelType3 => ResourceManager.GetString(global::_E000._E000("\uf5a8\uf58a\uf598\uf583\uf589\uf584\uf593\uf5a6\uf584\uf58f\uf58e\uf587\uf5bf\uf592\uf59b\uf58e\uf5d8", 62915), _E001);

		public static string CashboxName => ResourceManager.GetString(global::_E000._E000("\ued2c\ued0e\ued1c\ued07\ued0d\ued00\ued17\ued21\ued0e\ued02\ued0a", 60746), _E001);

		public static string CashboxPaymentTypes => ResourceManager.GetString(global::_E000._E000("\uf7b0\uf792\uf780\uf79b\uf791\uf79c\uf78b\uf7a3\uf792\uf78a\uf79e\uf796\uf79d\uf787\uf7a7\uf78a\uf783\uf796\uf780", 63458), _E001);

		public static string CashboxProgramming => ResourceManager.GetString(global::_E000._E000("\ue230\ue212\ue200\ue21b\ue211\ue21c\ue20b\ue223\ue201\ue21c\ue214\ue201\ue212\ue21e\ue21e\ue21a\ue21d\ue214", 57922), _E001);

		public static string CashboxRegistrationDate => ResourceManager.GetString(global::_E000._E000("\uf484\uf4a6\uf4b4\uf4af\uf4a5\uf4a8\uf4bf\uf495\uf4a2\uf4a0\uf4ae\uf4b4\uf4b3\uf4b5\uf4a6\uf4b3\uf4ae\uf4a8\uf4a9\uf483\uf4a6\uf4b3\uf4a2", 62532), _E001);

		public static string CashboxRegistrationNumber => ResourceManager.GetString(global::_E000._E000("\ue9be\ue99c\ue98e\ue995\ue99f\ue992\ue985\ue9af\ue998\ue99a\ue994\ue98e\ue989\ue98f\ue99c\ue989\ue994\ue992\ue993\ue9b3\ue988\ue990\ue99f\ue998\ue98f", 59832), _E001);

		public static string CashboxToken => ResourceManager.GetString(global::_E000._E000("\ue130\ue112\ue100\ue11b\ue111\ue11c\ue10b\ue127\ue11c\ue118\ue116\ue11d", 57714), _E001);

		public static string CashboxUniqueNumber => ResourceManager.GetString(global::_E000._E000("\uedf8\uedda\uedc8\uedd3\uedd9\uedd4\uedc3\uedee\uedd5\uedd2\uedca\uedce\uedde\uedf5\uedce\uedd6\uedd9\uedde\uedc9", 60849), _E001);

		public static string Cashier => ResourceManager.GetString(global::_E000._E000("\ue730\ue712\ue700\ue71b\ue71a\ue716\ue701", 59202), _E001);

		public static string Cashiers => ResourceManager.GetString(global::_E000._E000("\uee9a\ueeb8\ueeaa\ueeb1\ueeb0\ueebc\ueeab\ueeaa", 61017), _E001);

		public static string CashiersAssignmentModelSelectedEmployees => ResourceManager.GetString(global::_E000._E000("\ueffa\uefd8\uefca\uefd1\uefd0\uefdc\uefcb\uefca\ueff8\uefca\uefca\uefd0\uefde\uefd7\uefd4\uefdc\uefd7\uefcd\ueff4\uefd6\uefdd\uefdc\uefd5\uefea\uefdc\uefd5\uefdc\uefda\uefcd\uefdc\uefdd\ueffc\uefd4\uefc9\uefd5\uefd6\uefc0\uefdc\uefdc\uefca", 61369), _E001);

		public static string CashiersAssignmentModelSelectedSection => ResourceManager.GetString(global::_E000._E000("\ue71e\ue73c\ue72e\ue735\ue734\ue738\ue72f\ue72e\ue71c\ue72e\ue72e\ue734\ue73a\ue733\ue730\ue738\ue733\ue729\ue710\ue732\ue739\ue738\ue731\ue70e\ue738\ue731\ue738\ue73e\ue729\ue738\ue739\ue70e\ue738\ue73e\ue729\ue734\ue732\ue733", 59208), _E001);

		public static string ChangeToken => ResourceManager.GetString(global::_E000._E000("\uebea\uebc1\uebc8\uebc7\uebce\uebcc\uebfd\uebc6\uebc2\uebcc\uebc7", 60201), _E001);

		public static string CheckEdit => ResourceManager.GetString(global::_E000._E000("\uf0bc\uf097\uf09a\uf09c\uf094\uf0ba\uf09b\uf096\uf08b", 61663), _E001);

		public static string CheckError => ResourceManager.GetString(global::_E000._E000("\uee3c\uee17\uee1a\uee1c\uee14\uee3a\uee0d\uee0d\uee10\uee0d", 61019), _E001);

		public static string CheckRegistrationDate => ResourceManager.GetString(global::_E000._E000("\ueb3c\ueb17\ueb1a\ueb1c\ueb14\ueb2d\ueb1a\ueb18\ueb16\ueb0c\ueb0b\ueb0d\ueb1e\ueb0b\ueb16\ueb10\ueb11\ueb3b\ueb1e\ueb0b\ueb1a", 60283), _E001);

		public static string Choose => ResourceManager.GetString(global::_E000._E000("\uea84\ueaaf\ueaa8\ueaa8\ueab4\ueaa2", 60100), _E001);

		public static string ChooseListElement => ResourceManager.GetString(global::_E000._E000("\uea3e\uea15\uea12\uea12\uea0e\uea18\uea31\uea14\uea0e\uea09\uea38\uea11\uea18\uea10\uea18\uea13\uea09", 60024), _E001);

		public static string ChoosePriceList => ResourceManager.GetString(global::_E000._E000("\uea61\uea4a\uea4d\uea4d\uea51\uea47\uea72\uea50\uea4b\uea41\uea47\uea6e\uea4b\uea51\uea56", 59904), _E001);

		public static string Close => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf593\uf590\uf58c\uf59a", 62967), _E001);

		public static string ClosedOn => ResourceManager.GetString(global::_E000._E000("\ued94\uedbb\uedb8\ueda4\uedb2\uedb3\ued98\uedb9", 60692), _E001);

		public static string ConfirmBalanceWithdrawal => ResourceManager.GetString(global::_E000._E000("\uf16e\uf142\uf143\uf14b\uf144\uf15f\uf140\uf16f\uf14c\uf141\uf14c\uf143\uf14e\uf148\uf17a\uf144\uf159\uf145\uf149\uf15f\uf14c\uf15a\uf14c\uf141", 61740), _E001);

		public static string Count => ResourceManager.GetString(global::_E000._E000("\ue23c\ue210\ue20a\ue211\ue20b", 57910), _E001);

		public static string CourierMode => ResourceManager.GetString(global::_E000._E000("\ue3dd\ue3f1\ue3eb\ue3ec\ue3f7\ue3fb\ue3ec\ue3d3\ue3f1\ue3fa\ue3fb", 58270), _E001);

		public static string Credit => ResourceManager.GetString(global::_E000._E000("\uf0ba\uf08b\uf09c\uf09d\uf090\uf08d", 61689), _E001);

		public static string CurrentStatus => ResourceManager.GetString(global::_E000._E000("\uf5be\uf588\uf58f\uf58f\uf598\uf593\uf589\uf5ae\uf589\uf59c\uf589\uf588\uf58e", 62888), _E001);

		public static string CurrentStatusDate => ResourceManager.GetString(global::_E000._E000("\ue4a1\ue497\ue490\ue490\ue487\ue48c\ue496\ue4b1\ue496\ue483\ue496\ue497\ue491\ue4a6\ue483\ue496\ue487", 58592), _E001);

		public static string Customer => ResourceManager.GetString(global::_E000._E000("\ue3a8\ue39e\ue398\ue39f\ue384\ue386\ue38e\ue399", 58179), _E001);

		public static string CustomerEmail => ResourceManager.GetString(global::_E000._E000("\ue7fe\ue7c8\ue7ce\ue7c9\ue7d2\ue7d0\ue7d8\ue7cf\ue7f8\ue7d0\ue7dc\ue7d4\ue7d1", 59324), _E001);

		public static string CustomerPhone => ResourceManager.GetString(global::_E000._E000("\ue38c\ue3ba\ue3bc\ue3bb\ue3a0\ue3a2\ue3aa\ue3bd\ue39f\ue3a7\ue3a0\ue3a1\ue3aa", 58310), _E001);

		public static string CustomerPhoneIncorrectPattern => ResourceManager.GetString(global::_E000._E000("\uf28a\uf2bc\uf2ba\uf2bd\uf2a6\uf2a4\uf2ac\uf2bb\uf299\uf2a1\uf2a6\uf2a7\uf2ac\uf280\uf2a7\uf2aa\uf2a6\uf2bb\uf2bb\uf2ac\uf2aa\uf2bd\uf299\uf2a8\uf2bd\uf2bd\uf2ac\uf2bb\uf2a7", 62153), _E001);

		public static string Default => ResourceManager.GetString(global::_E000._E000("\ue293\ue2b2\ue2b1\ue2b6\ue2a2\ue2bb\ue2a3", 58004), _E001);

		public static string DefaultPurchasePositionName => ResourceManager.GetString(global::_E000._E000("\uebb9\ueb98\ueb9b\ueb9c\ueb88\ueb91\ueb89\uebad\ueb88\ueb8f\ueb9e\ueb95\ueb9c\ueb8e\ueb98\uebad\ueb92\ueb8e\ueb94\ueb89\ueb94\ueb92\ueb93\uebb3\ueb9c\ueb90\ueb98", 60373), _E001);

		public static string DefaultSection => ResourceManager.GetString(global::_E000._E000("\uee93\ueeb2\ueeb1\ueeb6\ueea2\ueebb\ueea3\uee84\ueeb2\ueeb4\ueea3\ueebe\ueeb8\ueeb9", 61076), _E001);

		public static string DefaultSellPositionName => ResourceManager.GetString(global::_E000._E000("\uf1ab\uf18a\uf189\uf18e\uf19a\uf183\uf19b\uf1bc\uf18a\uf183\uf183\uf1bf\uf180\uf19c\uf186\uf19b\uf186\uf180\uf181\uf1a1\uf18e\uf182\uf18a", 61862), _E001);

		public static string DefaultUnitType => ResourceManager.GetString(global::_E000._E000("\ue2bb\ue29a\ue299\ue29e\ue28a\ue293\ue28b\ue2aa\ue291\ue296\ue28b\ue2ab\ue286\ue28f\ue29a", 58013), _E001);

		public static string DeleteCashbox => ResourceManager.GetString(global::_E000._E000("\ue5ab\ue58a\ue583\ue58a\ue59b\ue58a\ue5ac\ue58e\ue59c\ue587\ue58d\ue580\ue597", 58637), _E001);

		public static string Demo => ResourceManager.GetString(global::_E000._E000("\ueb39\ueb18\ueb10\ueb12", 60200), _E001);

		public static string Description => ResourceManager.GetString(global::_E000._E000("\ue6ff\ue6de\ue6c8\ue6d8\ue6c9\ue6d2\ue6cb\ue6cf\ue6d2\ue6d4\ue6d5", 58931), _E001);

		public static string DictionaryActual => ResourceManager.GetString(global::_E000._E000("\uf0ff\uf0d2\uf0d8\uf0cf\uf0d2\uf0d4\uf0d5\uf0da\uf0c9\uf0c2\uf0fa\uf0d8\uf0cf\uf0ce\uf0da\uf0d7", 61489), _E001);

		public static string DictionaryNameKz => ResourceManager.GetString(global::_E000._E000("\ue63b\ue616\ue61c\ue60b\ue616\ue610\ue611\ue61e\ue60d\ue606\ue631\ue61e\ue612\ue61a\ue634\ue605", 58934), _E001);

		public static string DictionaryNameRu => ResourceManager.GetString(global::_E000._E000("\ue71a\ue737\ue73d\ue72a\ue737\ue731\ue730\ue73f\ue72c\ue727\ue710\ue73f\ue733\ue73b\ue70c\ue72b", 59214), _E001);

		public static string Disabled => ResourceManager.GetString(global::_E000._E000("\uebb9\ueb94\ueb8e\ueb9c\ueb9f\ueb91\ueb98\ueb99", 60412), _E001);

		public static string DiscountInputType => ResourceManager.GetString(global::_E000._E000("\ue237\ue21a\ue200\ue210\ue21c\ue206\ue21d\ue207\ue23a\ue21d\ue203\ue206\ue207\ue227\ue20a\ue203\ue216", 57970), _E001);

		public static string DisсountInTenge => ResourceManager.GetString(global::_E000._E000("\ue093\ue0be\ue0a4\ue496\ue0b8\ue0a2\ue0b9\ue0a3\ue09e\ue0b9\ue083\ue0b2\ue0b9\ue0b0\ue0b2", 57556), _E001);

		public static string Download => ResourceManager.GetString(global::_E000._E000("\uf729\uf702\uf71a\uf703\uf701\uf702\uf70c\uf709", 63340), _E001);

		public static string DoYouReallyWantToDeleteTradePoint => ResourceManager.GetString(global::_E000._E000("\ue39a\ue3b1\ue387\ue3b1\ue3ab\ue38c\ue3bb\ue3bf\ue3b2\ue3b2\ue3a7\ue389\ue3bf\ue3b0\ue3aa\ue38a\ue3b1\ue39a\ue3bb\ue3b2\ue3bb\ue3aa\ue3bb\ue38a\ue3ac\ue3bf\ue3ba\ue3bb\ue38e\ue3b1\ue3b7\ue3b0\ue3aa", 58334), _E001);

		public static string e => ResourceManager.GetString(global::_E000._E000("\uf792", 63476), _E001);

		public static string EmailSendMode => ResourceManager.GetString(global::_E000._E000("\uf3db\uf3f3\uf3ff\uf3f7\uf3f2\uf3cd\uf3fb\uf3f0\uf3fa\uf3d3\uf3f1\uf3fa\uf3fb", 62366), _E001);

		public static string EmailSendModeAlways => ResourceManager.GetString(global::_E000._E000("\uf527\uf50f\uf503\uf50b\uf50e\uf531\uf507\uf50c\uf506\uf52f\uf50d\uf506\uf507\uf523\uf50e\uf515\uf503\uf51b\uf511", 62816), _E001);

		public static string EmailSendModeNone => ResourceManager.GetString(global::_E000._E000("\uf4ba\uf492\uf49e\uf496\uf493\uf4ac\uf49a\uf491\uf49b\uf4b2\uf490\uf49b\uf49a\uf4b1\uf490\uf491\uf49a", 62682), _E001);

		public static string EmailSendModeShiftClose => ResourceManager.GetString(global::_E000._E000("\ue9ee\ue9c6\ue9ca\ue9c2\ue9c7\ue9f8\ue9ce\ue9c5\ue9cf\ue9e6\ue9c4\ue9cf\ue9ce\ue9f8\ue9c3\ue9c2\ue9cd\ue9df\ue9e8\ue9c7\ue9c4\ue9d8\ue9ce", 59683), _E001);

		public static string EmailZReport => ResourceManager.GetString(global::_E000._E000("\uf592\uf5ba\uf5b6\uf5be\uf5bb\uf58d\uf585\uf5b2\uf5a7\uf5b8\uf5a5\uf5a3", 62868), _E001);

		public static string Enabled => ResourceManager.GetString(global::_E000._E000("\uf0fb\uf0d0\uf0df\uf0dc\uf0d2\uf0db\uf0da", 61614), _E001);

		public static string EnterTicketNumberForSearch => ResourceManager.GetString(global::_E000._E000("\uf5db\uf5f0\uf5ea\uf5fb\uf5ec\uf5ca\uf5f7\uf5fd\uf5f5\uf5fb\uf5ea\uf5d0\uf5eb\uf5f3\uf5fc\uf5fb\uf5ec\uf5d8\uf5f1\uf5ec\uf5cd\uf5fb\uf5ff\uf5ec\uf5fd\uf5f6", 62862), _E001);

		public static string EnterСustomerXin => ResourceManager.GetString(global::_E000._E000("\uf328\uf303\uf319\uf308\uf31f\uf74c\uf318\uf31e\uf319\uf302\uf300\uf308\uf31f\uf335\uf304\uf303", 62245), _E001);

		public static string Error => ResourceManager.GetString(global::_E000._E000("\uf5ea\uf5dd\uf5dd\uf5c0\uf5dd", 62863), _E001);

		public static string Example => ResourceManager.GetString(global::_E000._E000("\uf87a\uf847\uf85e\uf852\uf84f\uf853\uf85a", 63499), _E001);

		public static string ExchangeModePriceList => ResourceManager.GetString(global::_E000._E000("\uf6ae\uf693\uf688\uf683\uf68a\uf685\uf68c\uf68e\uf6a6\uf684\uf68f\uf68e\uf6bb\uf699\uf682\uf688\uf68e\uf6a7\uf682\uf698\uf69f", 63073), _E001);

		public static string ExternalOrganization => ResourceManager.GetString(global::_E000._E000("\uf57a\uf547\uf54b\uf55a\uf54d\uf551\uf55e\uf553\uf570\uf54d\uf558\uf55e\uf551\uf556\uf545\uf55e\uf54b\uf556\uf550\uf551", 62763), _E001);

		public static string ExternalOrganizationDataTransfer => ResourceManager.GetString(global::_E000._E000("\uf8fa\uf8c7\uf8cb\uf8da\uf8cd\uf8d1\uf8de\uf8d3\uf8f0\uf8cd\uf8d8\uf8de\uf8d1\uf8d6\uf8c5\uf8de\uf8cb\uf8d6\uf8d0\uf8d1\uf8fb\uf8de\uf8cb\uf8de\uf8eb\uf8cd\uf8de\uf8d1\uf8cc\uf8d9\uf8da\uf8cd", 63543), _E001);

		public static string FillAddress => ResourceManager.GetString(global::_E000._E000("\uf729\uf706\uf703\uf703\uf72e\uf70b\uf70b\uf71d\uf70a\uf71c\uf71c", 63242), _E001);

		public static string FiscalizationCashbox => ResourceManager.GetString(global::_E000._E000("\ue491\ue4be\ue4a4\ue4b4\ue4b6\ue4bb\ue4be\ue4ad\ue4b6\ue4a3\ue4be\ue4b8\ue4b9\ue494\ue4b6\ue4a4\ue4bf\ue4b5\ue4b8\ue4af", 58388), _E001);

		public static string FiscalizationDate => ResourceManager.GetString(global::_E000._E000("\uf7bd\uf792\uf788\uf798\uf79a\uf797\uf792\uf781\uf79a\uf78f\uf792\uf794\uf795\uf7bf\uf79a\uf78f\uf79e", 63443), _E001);

		public static string FiscalSign => ResourceManager.GetString(global::_E000._E000("\ue8ed\ue8c2\ue8d8\ue8c8\ue8ca\ue8c7\ue8f8\ue8c2\ue8cc\ue8c5", 59427), _E001);

		public static string FormatNotSupported => ResourceManager.GetString(global::_E000._E000("\ue674\ue65d\ue640\ue65f\ue653\ue646\ue67c\ue65d\ue646\ue661\ue647\ue642\ue642\ue65d\ue640\ue646\ue657\ue656", 58896), _E001);

		public static string HasExchangeOfficeMode => ResourceManager.GetString(global::_E000._E000("\ue496\ue4bf\ue4ad\ue49b\ue4a6\ue4bd\ue4b6\ue4bf\ue4b0\ue4b9\ue4bb\ue491\ue4b8\ue4b8\ue4b7\ue4bd\ue4bb\ue493\ue4b1\ue4ba\ue4bb", 58590), _E001);

		public static string HasLicense => ResourceManager.GetString(global::_E000._E000("\uf237\uf21e\uf20c\uf233\uf216\uf21c\uf21a\uf211\uf20c\uf21a", 62075), _E001);

		public static string HistoryChecks => ResourceManager.GetString(global::_E000._E000("\uf315\uf334\uf32e\uf329\uf332\uf32f\uf324\uf31e\uf335\uf338\uf33e\uf336\uf32e", 62232), _E001);

		public static string House => ResourceManager.GetString(global::_E000._E000("\ue2b7\ue290\ue28a\ue28c\ue29a", 58042), _E001);

		public static string HouseNumber => ResourceManager.GetString(global::_E000._E000("\ue2b5\ue292\ue288\ue28e\ue298\ue2b3\ue288\ue290\ue29f\ue298\ue28f", 58037), _E001);

		public static string HouseType => ResourceManager.GetString(global::_E000._E000("\ue4b7\ue490\ue48a\ue48c\ue49a\ue4ab\ue486\ue48f\ue49a", 58586), _E001);

		public static string HousingArea => ResourceManager.GetString(global::_E000._E000("\ueaf7\uead0\ueaca\ueacc\uead6\uead1\uead8\ueafe\ueacd\ueada\ueade", 60059), _E001);

		public static string IdentityNumber => ResourceManager.GetString(global::_E000._E000("\uf386\uf3ab\uf3aa\uf3a1\uf3bb\uf3a6\uf3bb\uf3b6\uf381\uf3ba\uf3a2\uf3ad\uf3aa\uf3bd", 62406), _E001);

		public static string InhabitedLocality => ResourceManager.GetString(global::_E000._E000("\uf02b\uf00c\uf00a\uf003\uf000\uf00b\uf016\uf007\uf006\uf02e\uf00d\uf001\uf003\uf00e\uf00b\uf016\uf01b", 61504), _E001);

		public static string IntegerError => ResourceManager.GetString(global::_E000._E000("\uedb6\ued91\ued8b\ued9a\ued98\ued9a\ued8d\uedba\ued8d\ued8d\ued90\ued8d", 60893), _E001);

		public static string IsExcise => ResourceManager.GetString(global::_E000._E000("\uf377\uf34d\uf37b\uf346\uf35d\uf357\uf34d\uf35b", 62254), _E001);

		public static string KeruenDataTransfer => ResourceManager.GetString(global::_E000._E000("\ue6f6\ue6d8\ue6cf\ue6c8\ue6d8\ue6d3\ue6f9\ue6dc\ue6c9\ue6dc\ue6e9\ue6cf\ue6dc\ue6d3\ue6ce\ue6db\ue6d8\ue6cf", 59068), _E001);

		public static string KgdRegistrationForm => ResourceManager.GetString(global::_E000._E000("\uf69c\uf6b0\uf6b3\uf685\uf6b2\uf6b0\uf6be\uf6a4\uf6a3\uf6a5\uf6b6\uf6a3\uf6be\uf6b8\uf6b9\uf691\uf6b8\uf6a5\uf6ba", 62996), _E001);

		public static string Lane => ResourceManager.GetString(global::_E000._E000("\uf5a3\uf58e\uf581\uf58a", 62893), _E001);

		public static string LanguageShortKz => ResourceManager.GetString(global::_E000._E000("\ue86e\ue843\ue84c\ue845\ue857\ue843\ue845\ue847\ue871\ue84a\ue84d\ue850\ue856\ue869\ue858", 59424), _E001);

		public static string LanguageShortRus => ResourceManager.GetString(global::_E000._E000("\uf093\uf0be\uf0b1\uf0b8\uf0aa\uf0be\uf0b8\uf0ba\uf08c\uf0b7\uf0b0\uf0ad\uf0ab\uf08d\uf0aa\uf0ac", 61590), _E001);

		public static string LinkToCashboxRegistration => ResourceManager.GetString(global::_E000._E000("\ue1f3\ue1d6\ue1d1\ue1d4\ue1eb\ue1d0\ue1fc\ue1de\ue1cc\ue1d7\ue1dd\ue1d0\ue1c7\ue1ed\ue1da\ue1d8\ue1d6\ue1cc\ue1cb\ue1cd\ue1de\ue1cb\ue1d6\ue1d0\ue1d1", 57755), _E001);

		public static string LivingQuarter => ResourceManager.GetString(global::_E000._E000("\ue5be\ue59b\ue584\ue59b\ue59c\ue595\ue5a3\ue587\ue593\ue580\ue586\ue597\ue580", 58832), _E001);

		public static string LoadingData => ResourceManager.GetString(global::_E000._E000("\uf6b1\uf692\uf69c\uf699\uf694\uf693\uf69a\uf6b9\uf69c\uf689\uf69c", 63208), _E001);

		public static string LoadingDate => ResourceManager.GetString(global::_E000._E000("\uf133\uf110\uf11e\uf11b\uf116\uf111\uf118\uf13b\uf11e\uf10b\uf11a", 61722), _E001);

		public static string LoadingWait => ResourceManager.GetString(global::_E000._E000("\ue3b3\ue390\ue39e\ue39b\ue396\ue391\ue398\ue3a8\ue39e\ue396\ue38b", 58237), _E001);

		public static string LogoImage => ResourceManager.GetString(global::_E000._E000("\ue6a1\ue682\ue68a\ue682\ue6a4\ue680\ue68c\ue68a\ue688", 59109), _E001);

		public static string ManualEntryBlock => ResourceManager.GetString(global::_E000._E000("\ue892\ue8be\ue8b1\ue8aa\ue8be\ue8b3\ue89a\ue8b1\ue8ab\ue8ad\ue8a6\ue89d\ue8b3\ue8b0\ue8bc\ue8b4", 59463), _E001);

		public static string Marking => ResourceManager.GetString(global::_E000._E000("\uf27e\uf252\uf241\uf258\uf25a\uf25d\uf254", 62002), _E001);

		public static string MarkingItem => ResourceManager.GetString(global::_E000._E000("\uf8ef\uf8c3\uf8d0\uf8c9\uf8cb\uf8cc\uf8c5\uf8eb\uf8d6\uf8c7\uf8cf", 63648), _E001);

		public static string MarkingMode => ResourceManager.GetString(global::_E000._E000("\uf2ff\uf2d3\uf2c0\uf2d9\uf2db\uf2dc\uf2d5\uf2ff\uf2dd\uf2d6\uf2d7", 62096), _E001);

		public static string MarkupForCheck => ResourceManager.GetString(global::_E000._E000("\ue8a6\ue88a\ue899\ue880\ue89e\ue89b\ue8ad\ue884\ue899\ue8a8\ue883\ue88e\ue888\ue880", 59491), _E001);

		public static string MarkupInTenge => ResourceManager.GetString(global::_E000._E000("\ue994\ue9b8\ue9ab\ue9b2\ue9ac\ue9a9\ue990\ue9b7\ue98d\ue9bc\ue9b7\ue9be\ue9bc", 59737), _E001);

		public static string MarkupName => ResourceManager.GetString(global::_E000._E000("\ue373\ue35f\ue34c\ue355\ue34b\ue34e\ue370\ue35f\ue353\ue35b", 58174), _E001);

		public static string MarkupValue => ResourceManager.GetString(global::_E000._E000("\ueb32\ueb1e\ueb0d\ueb14\ueb0a\ueb0f\ueb29\ueb1e\ueb13\ueb0a\ueb1a", 60214), _E001);

		public static string MarkupVisiblity => ResourceManager.GetString(global::_E000._E000("\uedb2\ued9e\ued8d\ued94\ued8a\ued8f\ueda9\ued96\ued8c\ued96\ued9d\ued93\ued96\ued8b\ued86", 60858), _E001);

		public static string MessageResultTypeBlocked => ResourceManager.GetString(global::_E000._E000("\uf132\uf11a\uf10c\uf10c\uf11e\uf118\uf11a\uf12d\uf11a\uf10c\uf10a\uf113\uf10b\uf12b\uf106\uf10f\uf11a\uf13d\uf113\uf110\uf11c\uf114\uf11a\uf11b", 61754), _E001);

		public static string MessageResultTypeCantCancelTicket => ResourceManager.GetString(global::_E000._E000("\ueab2\uea9a\uea8c\uea8c\uea9e\uea98\uea9a\ueaad\uea9a\uea8c\uea8a\uea93\uea8b\ueaab\uea86\uea8f\uea9a\ueabc\uea9e\uea91\uea8b\ueabc\uea9e\uea91\uea9c\uea9a\uea93\ueaab\uea96\uea9c\uea94\uea9a\uea8b", 60159), _E001);

		public static string MessageResultTypeIncorrectRequestData => ResourceManager.GetString(global::_E000._E000("\ue0a2\ue08a\ue09c\ue09c\ue08e\ue088\ue08a\ue0bd\ue08a\ue09c\ue09a\ue083\ue09b\ue0bb\ue096\ue09f\ue08a\ue0a6\ue081\ue08c\ue080\ue09d\ue09d\ue08a\ue08c\ue09b\ue0bd\ue08a\ue09e\ue09a\ue08a\ue09c\ue09b\ue0ab\ue08e\ue09b\ue08e", 57581), _E001);

		public static string MessageResultTypeInvalidConfiguration => ResourceManager.GetString(global::_E000._E000("\ue1b6\ue19e\ue188\ue188\ue19a\ue19c\ue19e\ue1a9\ue19e\ue188\ue18e\ue197\ue18f\ue1af\ue182\ue18b\ue19e\ue1b2\ue195\ue18d\ue19a\ue197\ue192\ue19f\ue1b8\ue194\ue195\ue19d\ue192\ue19c\ue18e\ue189\ue19a\ue18f\ue192\ue194\ue195", 57713), _E001);

		public static string MessageResultTypeInvalidLoginPassword => ResourceManager.GetString(global::_E000._E000("\ueef6\ueede\ueec8\ueec8\ueeda\ueedc\ueede\ueee9\ueede\ueec8\ueece\ueed7\ueecf\ueeef\ueec2\ueecb\ueede\ueef2\ueed5\ueecd\ueeda\ueed7\ueed2\ueedf\ueef7\ueed4\ueedc\ueed2\ueed5\ueeeb\ueeda\ueec8\ueec8\ueecc\ueed4\ueec9\ueedf", 60977), _E001);

		public static string MessageResultTypeInvalidRequestNumber => ResourceManager.GetString(global::_E000._E000("\uf1a2\uf18a\uf19c\uf19c\uf18e\uf188\uf18a\uf1bd\uf18a\uf19c\uf19a\uf183\uf19b\uf1bb\uf196\uf19f\uf18a\uf1a6\uf181\uf199\uf18e\uf183\uf186\uf18b\uf1bd\uf18a\uf19e\uf19a\uf18a\uf19c\uf19b\uf1a1\uf19a\uf182\uf18d\uf18a\uf19d", 61775), _E001);

		public static string MessageResultTypeInvalidRetryRequest => ResourceManager.GetString(global::_E000._E000("\uede2\uedca\ueddc\ueddc\uedce\uedc8\uedca\uedfd\uedca\ueddc\uedda\uedc3\ueddb\uedfb\uedd6\ueddf\uedca\uede6\uedc1\uedd9\uedce\uedc3\uedc6\uedcb\uedfd\uedca\ueddb\ueddd\uedd6\uedfd\uedca\uedde\uedda\uedca\ueddc\ueddb", 60815), _E001);

		public static string MessageResultTypeInvalidToken => ResourceManager.GetString(global::_E000._E000("\uf4f2\uf4da\uf4cc\uf4cc\uf4de\uf4d8\uf4da\uf4ed\uf4da\uf4cc\uf4ca\uf4d3\uf4cb\uf4eb\uf4c6\uf4cf\uf4da\uf4f6\uf4d1\uf4c9\uf4de\uf4d3\uf4d6\uf4db\uf4eb\uf4d0\uf4d4\uf4da\uf4d1", 62631), _E001);

		public static string MessageResultTypeNotEnoughCash => ResourceManager.GetString(global::_E000._E000("\uf0b2\uf09a\uf08c\uf08c\uf09e\uf098\uf09a\uf0ad\uf09a\uf08c\uf08a\uf093\uf08b\uf0ab\uf086\uf08f\uf09a\uf0b1\uf090\uf08b\uf0ba\uf091\uf090\uf08a\uf098\uf097\uf0bc\uf09e\uf08c\uf097", 61533), _E001);

		public static string MessageResultTypeOk => ResourceManager.GetString(global::_E000._E000("\ue8b0\ue898\ue88e\ue88e\ue89c\ue89a\ue898\ue8af\ue898\ue88e\ue888\ue891\ue889\ue8a9\ue884\ue88d\ue898\ue8b2\ue896", 59541), _E001);

		public static string MessageResultTypeOpenShiftTimeoutExpired => ResourceManager.GetString(global::_E000._E000("\ue694\ue6bc\ue6aa\ue6aa\ue6b8\ue6be\ue6bc\ue68b\ue6bc\ue6aa\ue6ac\ue6b5\ue6ad\ue68d\ue6a0\ue6a9\ue6bc\ue696\ue6a9\ue6bc\ue6b7\ue68a\ue6b1\ue6b0\ue6bf\ue6ad\ue68d\ue6b0\ue6b4\ue6bc\ue6b6\ue6ac\ue6ad\ue69c\ue6a1\ue6a9\ue6b0\ue6ab\ue6bc\ue6bd", 58969), _E001);

		public static string MessageResultTypeProtokolError => ResourceManager.GetString(global::_E000._E000("\uec22\uec0a\uec1c\uec1c\uec0e\uec08\uec0a\uec3d\uec0a\uec1c\uec1a\uec03\uec1b\uec3b\uec16\uec1f\uec0a\uec3f\uec1d\uec00\uec1b\uec00\uec04\uec00\uec03\uec2a\uec1d\uec1d\uec00\uec1d", 60490), _E001);

		public static string MessageResultTypeServiceTemporarilyUnavailable => ResourceManager.GetString(global::_E000._E000("\uee7e\uee56\uee40\uee40\uee52\uee54\uee56\uee61\uee56\uee40\uee46\uee5f\uee47\uee67\uee4a\uee43\uee56\uee60\uee56\uee41\uee45\uee5a\uee50\uee56\uee67\uee56\uee5e\uee43\uee5c\uee41\uee52\uee41\uee5a\uee5f\uee4a\uee66\uee5d\uee52\uee45\uee52\uee5a\uee5f\uee52\uee51\uee5f\uee56", 60978), _E001);

		public static string MessageResultTypeSslIsNotAllowed => ResourceManager.GetString(global::_E000._E000("\uf47e\uf456\uf440\uf440\uf452\uf454\uf456\uf461\uf456\uf440\uf446\uf45f\uf447\uf467\uf44a\uf443\uf456\uf460\uf440\uf45f\uf47a\uf440\uf47d\uf45c\uf447\uf472\uf45f\uf45f\uf45c\uf444\uf456\uf457", 62482), _E001);

		public static string MessageResultTypeUnknownCommand => ResourceManager.GetString(global::_E000._E000("\ue9e2\ue9ca\ue9dc\ue9dc\ue9ce\ue9c8\ue9ca\ue9fd\ue9ca\ue9dc\ue9da\ue9c3\ue9db\ue9fb\ue9d6\ue9df\ue9ca\ue9fa\ue9c1\ue9c4\ue9c1\ue9c0\ue9d8\ue9c1\ue9ec\ue9c0\ue9c2\ue9c2\ue9ce\ue9c1\ue9cb", 59695), _E001);

		public static string MessageResultTypeUnknownError => ResourceManager.GetString(global::_E000._E000("\uf3b2\uf39a\uf38c\uf38c\uf39e\uf398\uf39a\uf3ad\uf39a\uf38c\uf38a\uf393\uf38b\uf3ab\uf386\uf38f\uf39a\uf3aa\uf391\uf394\uf391\uf390\uf388\uf391\uf3ba\uf38d\uf38d\uf390\uf38d", 62237), _E001);

		public static string MessageResultTypeUnknownID => ResourceManager.GetString(global::_E000._E000("\uf0a2\uf08a\uf09c\uf09c\uf08e\uf088\uf08a\uf0bd\uf08a\uf09c\uf09a\uf083\uf09b\uf0bb\uf096\uf09f\uf08a\uf0ba\uf081\uf084\uf081\uf080\uf098\uf081\uf0a6\uf0ab", 61581), _E001);

		public static string MessageResultTypeUnsupportedCommand => ResourceManager.GetString(global::_E000._E000("\uef22\uef0a\uef1c\uef1c\uef0e\uef08\uef0a\uef3d\uef0a\uef1c\uef1a\uef03\uef1b\uef3b\uef16\uef1f\uef0a\uef3a\uef01\uef1c\uef1a\uef1f\uef1f\uef00\uef1d\uef1b\uef0a\uef0b\uef2c\uef00\uef02\uef02\uef0e\uef01\uef0b", 61222), _E001);

		public static string Microdistrict => ResourceManager.GetString(global::_E000._E000("\ue722\ue706\ue70c\ue71d\ue700\ue70b\ue706\ue71c\ue71b\ue71d\ue706\ue70c\ue71b", 59242), _E001);

		public static string Mobile => ResourceManager.GetString(global::_E000._E000("\uf18a\uf1a8\uf1a5\uf1ae\uf1ab\uf1a2", 61700), _E001);

		public static string NeedToSelectFileLogo => ResourceManager.GetString(global::_E000._E000("\ue46c\ue447\ue447\ue446\ue476\ue44d\ue471\ue447\ue44e\ue447\ue441\ue456\ue464\ue44b\ue44e\ue447\ue46e\ue44d\ue445\ue44d", 58368), _E001);

		public static string No => ResourceManager.GetString(global::_E000._E000("\ueee1\ueec0", 61103), _E001);

		public static string NonResidentialPremise => ResourceManager.GetString(global::_E000._E000("\ue8f3\ue8d2\ue8d3\ue8ef\ue8d8\ue8ce\ue8d4\ue8d9\ue8d8\ue8d3\ue8c9\ue8d4\ue8dc\ue8d1\ue8ed\ue8cf\ue8d8\ue8d0\ue8d4\ue8ce\ue8d8", 59548), _E001);

		public static string NoPrint => ResourceManager.GetString(global::_E000._E000("\uea91\ueab0\uea8f\ueaad\ueab6\ueab1\ueaab", 60054), _E001);

		public static string OfdServicesNotAvailable => ResourceManager.GetString(global::_E000._E000("\ue730\ue719\ue71b\ue72c\ue71a\ue70d\ue709\ue716\ue71c\ue71a\ue70c\ue731\ue710\ue70b\ue73e\ue709\ue71e\ue716\ue713\ue71e\ue71d\ue713\ue71a", 59259), _E001);

		public static string OfdServicesNotAvailableForCashbox => ResourceManager.GetString(global::_E000._E000("\ueeb2\uee9b\uee99\ueeae\uee98\uee8f\uee8b\uee94\uee9e\uee98\uee8e\ueeb3\uee92\uee89\ueebc\uee8b\uee9c\uee94\uee91\uee9c\uee9f\uee91\uee98\ueebb\uee92\uee8f\ueebe\uee9c\uee8e\uee95\uee9f\uee92\uee85", 61112), _E001);

		public static string Office => ResourceManager.GetString(global::_E000._E000("\uedb8\ued91\ued91\ued9e\ued94\ued92", 60788), _E001);

		public static string OfficeType => ResourceManager.GetString(global::_E000._E000("\uea00\uea29\uea29\uea26\uea2c\uea2a\uea1b\uea36\uea3f\uea2a", 59910), _E001);

		public static string OfflineCheckApiSupported => ResourceManager.GetString(global::_E000._E000("\ue57c\ue555\ue555\ue55f\ue55a\ue55d\ue556\ue570\ue55b\ue556\ue550\ue558\ue572\ue543\ue55a\ue560\ue546\ue543\ue543\ue55c\ue541\ue547\ue556\ue557", 58674), _E001);

		public static string OpenShiftDate => ResourceManager.GetString(global::_E000._E000("\ue6f2\ue6cd\ue6d8\ue6d3\ue6ee\ue6d5\ue6d4\ue6db\ue6c9\ue6f9\ue6dc\ue6c9\ue6d8", 59036), _E001);

		public static string OrderNumber => ResourceManager.GetString(global::_E000._E000("\uf5fd\uf5c0\uf5d6\uf5d7\uf5c0\uf5fc\uf5c7\uf5df\uf5d0\uf5d7\uf5c0", 62864), _E001);

		public static string PacketsLeftDays => ResourceManager.GetString(global::_E000._E000("\uf7e2\uf7d3\uf7d1\uf7d9\uf7d7\uf7c6\uf7c1\uf7fe\uf7d7\uf7d4\uf7c6\uf7f6\uf7d3\uf7cb\uf7c1", 63376), _E001);

		public static string PartialAutoWithDrawalSum => ResourceManager.GetString(global::_E000._E000("\ueeaf\uee9e\uee8d\uee8b\uee96\uee9e\uee93\ueebe\uee8a\uee8b\uee90\ueea8\uee96\uee8b\uee97\ueebb\uee8d\uee9e\uee88\uee9e\uee93\ueeac\uee8a\uee92", 61146), _E001);

		public static string PerformingAction => ResourceManager.GetString(global::_E000._E000("\ue8bf\ue88a\ue89d\ue889\ue880\ue89d\ue882\ue886\ue881\ue888\ue8ae\ue88c\ue89b\ue886\ue880\ue881", 59562), _E001);

		public static string PermissionBookKeeping => ResourceManager.GetString(global::_E000._E000("\uf7af\uf79a\uf78d\uf792\uf796\uf78c\uf78c\uf796\uf790\uf791\uf7bd\uf790\uf790\uf794\uf7b4\uf79a\uf79a\uf78f\uf796\uf791\uf798", 63421), _E001);

		public static string PermissionsCloseShift => ResourceManager.GetString(global::_E000._E000("\ue64e\ue67b\ue66c\ue673\ue677\ue66d\ue66d\ue677\ue671\ue670\ue66d\ue65d\ue672\ue671\ue66d\ue67b\ue64d\ue676\ue677\ue678\ue66a", 58894), _E001);

		public static string PermissionsCreateXReport => ResourceManager.GetString(global::_E000._E000("\uf4af\uf49a\uf48d\uf492\uf496\uf48c\uf48c\uf496\uf490\uf491\uf48c\uf4bc\uf48d\uf49a\uf49e\uf48b\uf49a\uf4a7\uf4ad\uf49a\uf48f\uf490\uf48d\uf48b", 62699), _E001);

		public static string PermissionsVewZXReport => ResourceManager.GetString(global::_E000._E000("\ue96f\ue95a\ue94d\ue952\ue956\ue94c\ue94c\ue956\ue950\ue951\ue94c\ue969\ue95a\ue948\ue965\ue967\ue96d\ue95a\ue94f\ue950\ue94d\ue94b", 59675), _E001);

		public static string Phone => ResourceManager.GetString(global::_E000._E000("\uf1ff\uf1c7\uf1c0\uf1c1\uf1ca", 61711), _E001);

		public static string PinCode => ResourceManager.GetString(global::_E000._E000("\ue472\ue44b\ue44c\ue461\ue44d\ue446\ue447", 58400), _E001);

		public static string PleaseWait => ResourceManager.GetString(global::_E000._E000("\uf1ed\uf1d1\uf1d8\uf1dc\uf1ce\uf1d8\uf1ea\uf1dc\uf1d4\uf1c9", 61852), _E001);

		public static string Plinth => ResourceManager.GetString(global::_E000._E000("\ue82d\ue811\ue814\ue813\ue809\ue815", 59432), _E001);

		public static string Position => ResourceManager.GetString(global::_E000._E000("\uec63\uec5c\uec40\uec5a\uec47\uec5a\uec5c\uec5d", 60418), _E001);

		public static string PremiseNumber => ResourceManager.GetString(global::_E000._E000("\ueacf\ueaed\ueafa\ueaf2\ueaf6\ueaec\ueafa\uead1\ueaea\ueaf2\ueafd\ueafa\ueaed", 60039), _E001);

		public static string PremiseRequired => ResourceManager.GetString(global::_E000._E000("\ueeaf\uee8d\uee9a\uee92\uee96\uee8c\uee9a\ueead\uee9a\uee8e\uee8a\uee96\uee8d\uee9a\uee9b", 61085), _E001);

		public static string PremiseTypeRequired => ResourceManager.GetString(global::_E000._E000("\ue5a7\ue585\ue592\ue59a\ue59e\ue584\ue592\ue5a3\ue58e\ue587\ue592\ue5a5\ue592\ue586\ue582\ue59e\ue585\ue592\ue593", 58868), _E001);

		public static string Price => ResourceManager.GetString(global::_E000._E000("\ue2cf\ue2ed\ue2f6\ue2fc\ue2fa", 57879), _E001);

		public static string PricePerOneWithNds => ResourceManager.GetString(global::_E000._E000("\uf1fb\uf1d9\uf1c2\uf1c8\uf1ce\uf1fb\uf1ce\uf1d9\uf1e4\uf1c5\uf1ce\uf1fc\uf1c2\uf1df\uf1c3\uf1e5\uf1cf\uf1d8", 61825), _E001);

		public static string Print => ResourceManager.GetString(global::_E000._E000("\uf5b7\uf595\uf58e\uf589\uf593", 62820), _E001);

		public static string PrintDostykQR => ResourceManager.GetString(global::_E000._E000("\ueead\uee8f\uee94\uee93\uee89\ueeb9\uee92\uee8e\uee89\uee84\uee96\ueeac\ueeaf", 61180), _E001);

		public static string PrinterType => ResourceManager.GetString(global::_E000._E000("\uf0ed\uf0cf\uf0d4\uf0d3\uf0c9\uf0d8\uf0cf\uf0e9\uf0c4\uf0cd\uf0d8", 61628), _E001);

		public static string PrintQrCodeMode => ResourceManager.GetString(global::_E000._E000("\ue2af\ue28d\ue296\ue291\ue28b\ue2ae\ue28d\ue2bc\ue290\ue29b\ue29a\ue2b2\ue290\ue29b\ue29a", 58077), _E001);

		public static string PrintSlipCheck => ResourceManager.GetString(global::_E000._E000("\uf0f2\uf0d0\uf0cb\uf0cc\uf0d6\uf0f1\uf0ce\uf0cb\uf0d2\uf0e1\uf0ca\uf0c7\uf0c1\uf0c9", 61600), _E001);

		public static string PrintTicketQR => ResourceManager.GetString(global::_E000._E000("\ue6eb\ue6c9\ue6d2\ue6d5\ue6cf\ue6ef\ue6d2\ue6d8\ue6d0\ue6de\ue6cf\ue6ea\ue6e9", 58929), _E001);

		public static string PrintXinOnTicket => ResourceManager.GetString(global::_E000._E000("\ue5eb\ue5c9\ue5d2\ue5d5\ue5cf\ue5e3\ue5d2\ue5d5\ue5f4\ue5d5\ue5ef\ue5d2\ue5d8\ue5d0\ue5de\ue5cf", 58675), _E001);

		public static string ProductCode => ResourceManager.GetString(global::_E000._E000("\ue7bf\ue79d\ue780\ue78b\ue79a\ue78c\ue79b\ue7ac\ue780\ue78b\ue78a", 59181), _E001);

		public static string ProductCodeFromPriceList => ResourceManager.GetString(global::_E000._E000("\uf78d\uf7af\uf7b2\uf7b9\uf7a8\uf7be\uf7a9\uf79e\uf7b2\uf7b9\uf7b8\uf79b\uf7af\uf7b2\uf7b0\uf78d\uf7af\uf7b4\uf7be\uf7b8\uf791\uf7b4\uf7ae\uf7a9", 63368), _E001);

		public static string ProductName => ResourceManager.GetString(global::_E000._E000("\ue823\ue801\ue81c\ue817\ue806\ue810\ue807\ue83d\ue812\ue81e\ue816", 59506), _E001);

		public static string ProductStatusInOrder => ResourceManager.GetString(global::_E000._E000("\uf2ef\uf2cd\uf2d0\uf2db\uf2ca\uf2dc\uf2cb\uf2ec\uf2cb\uf2de\uf2cb\uf2ca\uf2cc\uf2f6\uf2d1\uf2f0\uf2cd\uf2db\uf2da\uf2cd", 62107), _E001);

		public static string Programming => ResourceManager.GetString(global::_E000._E000("\uee1f\uee3d\uee20\uee28\uee3d\uee2e\uee22\uee22\uee26\uee21\uee28", 60998), _E001);

		public static string ProgrammingCashboxPossibleOnlyInClosedShift => ResourceManager.GetString(global::_E000._E000("\uf5af\uf58d\uf590\uf598\uf58d\uf59e\uf592\uf592\uf596\uf591\uf598\uf5bc\uf59e\uf58c\uf597\uf59d\uf590\uf587\uf5af\uf590\uf58c\uf58c\uf596\uf59d\uf593\uf59a\uf5b0\uf591\uf593\uf586\uf5b6\uf591\uf5bc\uf593\uf590\uf58c\uf59a\uf59b\uf5ac\uf597\uf596\uf599\uf58b", 62973), _E001);

		public static string ProgrammingCheck => ResourceManager.GetString(global::_E000._E000("\ue3b7\ue395\ue388\ue380\ue395\ue386\ue38a\ue38a\ue38e\ue389\ue380\ue3a4\ue38f\ue382\ue384\ue38c", 58212), _E001);

		public static string ProgrammingXZReport => ResourceManager.GetString(global::_E000._E000("\ue3eb\ue3c9\ue3d4\ue3dc\ue3c9\ue3da\ue3d6\ue3d6\ue3d2\ue3d5\ue3dc\ue3e3\ue3e1\ue3e9\ue3de\ue3cb\ue3d4\ue3c9\ue3cf", 58289), _E001);

		public static string PromptReturnTypeChange => ResourceManager.GetString(global::_E000._E000("\uf4af\uf48d\uf490\uf492\uf48f\uf48b\uf4ad\uf49a\uf48b\uf48a\uf48d\uf491\uf4ab\uf486\uf48f\uf49a\uf4bc\uf497\uf49e\uf491\uf498\uf49a", 62710), _E001);

		public static string QrCodeOfdFormat => ResourceManager.GetString(global::_E000._E000("\ue02c\ue00f\ue03e\ue012\ue019\ue018\ue032\ue01b\ue019\ue03b\ue012\ue00f\ue010\ue01c\ue009", 57400), _E001);

		public static string QrCodeWkFormat => ResourceManager.GetString(global::_E000._E000("\ue91e\ue93d\ue90c\ue920\ue92b\ue92a\ue918\ue924\ue909\ue920\ue93d\ue922\ue92e\ue93b", 59718), _E001);

		public static string Quarter => ResourceManager.GetString(global::_E000._E000("\uf263\uf247\uf253\uf240\uf246\uf257\uf240", 61968), _E001);

		public static string Refresh => ResourceManager.GetString(global::_E000._E000("\uf6ad\uf69a\uf699\uf68d\uf69a\uf68c\uf697", 63158), _E001);

		public static string RegistratedOn => ResourceManager.GetString(global::_E000._E000("\ue62d\ue61a\ue618\ue616\ue60c\ue60b\ue60d\ue61e\ue60b\ue61a\ue61b\ue630\ue611", 58971), _E001);

		public static string RegistrationDate => ResourceManager.GetString(global::_E000._E000("\ue9b0\ue987\ue985\ue98b\ue991\ue996\ue990\ue983\ue996\ue98b\ue98d\ue98c\ue9a6\ue983\ue996\ue987", 59872), _E001);

		public static string RegistrationNumber => ResourceManager.GetString(global::_E000._E000("\uee0f\uee38\uee3a\uee34\uee2e\uee29\uee2f\uee3c\uee29\uee34\uee32\uee33\uee13\uee28\uee30\uee3f\uee38\uee2f", 60936), _E001);

		public static string ReportCheckoutTape => ResourceManager.GetString(global::_E000._E000("\ueea0\uee97\uee82\uee9d\uee80\uee86\ueeb1\uee9a\uee97\uee91\uee99\uee9d\uee87\uee86\ueea6\uee93\uee82\uee97", 61136), _E001);

		public static string Reports => ResourceManager.GetString(global::_E000._E000("\ue1b9\ue18e\ue19b\ue184\ue199\ue19f\ue198", 57793), _E001);

		public static string Required => ResourceManager.GetString(global::_E000._E000("\ue94c\ue97b\ue96f\ue96b\ue977\ue96c\ue97b\ue97a", 59662), _E001);

		public static string RoomNumber => ResourceManager.GetString(global::_E000._E000("\uf4ad\uf490\uf490\uf492\uf4b1\uf48a\uf492\uf49d\uf49a\uf48d", 62719), _E001);

		public static string RoundType => ResourceManager.GetString(global::_E000._E000("\uedaf\ued92\ued88\ued93\ued99\ueda9\ued84\ued8d\ued98", 60856), _E001);

		public static string SalemMobileDeleteRequest => ResourceManager.GetString(global::_E000._E000("\ue92c\ue91e\ue913\ue91a\ue912\ue932\ue910\ue91d\ue916\ue913\ue91a\ue93b\ue91a\ue913\ue91a\ue90b\ue91a\ue92d\ue91a\ue90e\ue90a\ue91a\ue90c\ue90b", 59706), _E001);

		public static string SalemMobileDeleteService => ResourceManager.GetString(global::_E000._E000("\ue82e\ue81c\ue811\ue818\ue810\ue830\ue812\ue81f\ue814\ue811\ue818\ue839\ue818\ue811\ue818\ue809\ue818\ue82e\ue818\ue80f\ue80b\ue814\ue81e\ue818", 59413), _E001);

		public static string Save => ResourceManager.GetString(global::_E000._E000("\ue5a0\ue592\ue585\ue596", 58818), _E001);

		public static string Search => ResourceManager.GetString(global::_E000._E000("\ue8a8\ue89e\ue89a\ue889\ue898\ue893", 59507), _E001);

		public static string Section => ResourceManager.GetString(global::_E000._E000("\uf42c\uf41a\uf41c\uf40b\uf416\uf410\uf411", 62555), _E001);

		public static string SectionDepartment => ResourceManager.GetString(global::_E000._E000("\uf6bc\uf68a\uf68c\uf69b\uf686\uf680\uf681\uf6ab\uf68a\uf69f\uf68e\uf69d\uf69b\uf682\uf68a\uf681\uf69b", 63178), _E001);

		public static string SectionForBuyOption => ResourceManager.GetString(global::_E000._E000("\ue52c\ue51a\ue51c\ue50b\ue516\ue510\ue511\ue539\ue510\ue50d\ue53d\ue50a\ue506\ue530\ue50f\ue50b\ue516\ue510\ue511", 58715), _E001);

		public static string SectionForSellOption => ResourceManager.GetString(global::_E000._E000("\uf7b8\uf78e\uf788\uf79f\uf782\uf784\uf785\uf7ad\uf784\uf799\uf7b8\uf78e\uf787\uf787\uf7a4\uf79b\uf79f\uf782\uf784\uf785", 63299), _E001);

		public static string Sections => ResourceManager.GetString(global::_E000._E000("\uedac\ued9a\ued9c\ued8b\ued96\ued90\ued91\ued8c", 60893), _E001);

		public static string SelectAvailableCashbox => ResourceManager.GetString(global::_E000._E000("\uf24d\uf27b\uf272\uf27b\uf27d\uf26a\uf25f\uf268\uf27f\uf277\uf272\uf27f\uf27c\uf272\uf27b\uf25d\uf27f\uf26d\uf276\uf27c\uf271\uf266", 61982), _E001);

		public static string SelectAvailableCashboxInTheDropDownListOrGoTo => ResourceManager.GetString(global::_E000._E000("\ue28a\ue2bc\ue2b5\ue2bc\ue2ba\ue2ad\ue298\ue2af\ue2b8\ue2b0\ue2b5\ue2b8\ue2bb\ue2b5\ue2bc\ue29a\ue2b8\ue2aa\ue2b1\ue2bb\ue2b6\ue2a1\ue290\ue2b7\ue28d\ue2b1\ue2bc\ue29d\ue2ab\ue2b6\ue2a9\ue29d\ue2b6\ue2ae\ue2b7\ue295\ue2b0\ue2aa\ue2ad\ue296\ue2ab\ue29e\ue2b6\ue28d\ue2b6", 57945), _E001);

		public static string SelectCTO => ResourceManager.GetString(global::_E000._E000("\ue3f8\ue3ce\ue3c7\ue3ce\ue3c8\ue3df\ue3e8\ue3ff\ue3e4", 58147), _E001);

		public static string SelectUnitType => ResourceManager.GetString(global::_E000._E000("\uf4a1\uf497\uf49e\uf497\uf491\uf486\uf4a7\uf49c\uf49b\uf486\uf4a6\uf48b\uf482\uf497", 62672), _E001);

		public static string SessionExpired => ResourceManager.GetString(global::_E000._E000("\ue8ae\ue898\ue88e\ue88e\ue894\ue892\ue893\ue8b8\ue885\ue88d\ue894\ue88f\ue898\ue899", 59560), _E001);

		public static string SettingForAllCashbox => ResourceManager.GetString(global::_E000._E000("\uecca\uecfc\ueced\ueced\uecf0\uecf7\uecfe\uecdf\uecf6\ueceb\uecd8\uecf5\uecf5\uecda\uecf8\uecea\uecf1\uecfb\uecf6\uece1", 60569), _E001);

		public static string SettingsSaved => ResourceManager.GetString(global::_E000._E000("\uf1ac\uf19a\uf18b\uf18b\uf196\uf191\uf198\uf18c\uf1ac\uf19e\uf189\uf19a\uf19b", 61949), _E001);

		public static string ShiftCloseDates => ResourceManager.GetString(global::_E000._E000("\ue2a1\ue29a\ue29b\ue294\ue286\ue2b1\ue29e\ue29d\ue281\ue297\ue2b6\ue293\ue286\ue297\ue281", 58096), _E001);

		public static string ShiftClosedOn => ResourceManager.GetString(global::_E000._E000("\ue43e\ue405\ue404\ue40b\ue419\ue42e\ue401\ue402\ue41e\ue408\ue409\ue422\ue403", 58476), _E001);

		public static string ShiftNumber => ResourceManager.GetString(global::_E000._E000("\uecec\uecd7\uecd6\uecd9\ueccb\uecf1\uecca\uecd2\uecdd\uecda\ueccd", 60471), _E001);

		public static string ShiftOpenOn => ResourceManager.GetString(global::_E000._E000("\ue22c\ue217\ue216\ue219\ue20b\ue230\ue20f\ue21a\ue211\ue230\ue211", 57978), _E001);

		public static string ShortHour => ResourceManager.GetString(global::_E000._E000("\ue9ac\ue997\ue990\ue98d\ue98b\ue9b7\ue990\ue98a\ue98d", 59775), _E001);

		public static string ShortMin => ResourceManager.GetString(global::_E000._E000("\ueabc\uea87\uea80\uea9d\uea9b\ueaa2\uea86\uea81", 60070), _E001);

		public static string ShortTenge => ResourceManager.GetString(global::_E000._E000("\ue1ec\ue1d7\ue1d0\ue1cd\ue1cb\ue1eb\ue1da\ue1d1\ue1d8\ue1da", 57783), _E001);

		public static string ShowReports => ResourceManager.GetString(global::_E000._E000("\uef3e\uef05\uef02\uef1a\uef3f\uef08\uef1d\uef02\uef1f\uef19\uef1e", 61189), _E001);

		public static string Status => ResourceManager.GetString(global::_E000._E000("\ue7cc\ue7eb\ue7fe\ue7eb\ue7ea\ue7ec", 59287), _E001);

		public static string Street => ResourceManager.GetString(global::_E000._E000("\ue23c\ue21b\ue21d\ue20a\ue20a\ue21b", 57930), _E001);

		public static string StreetName => ResourceManager.GetString(global::_E000._E000("\uefbe\uef99\uef9f\uef88\uef88\uef99\uefa3\uef8c\uef80\uef88", 61381), _E001);

		public static string StreetType => ResourceManager.GetString(global::_E000._E000("\uf2e8\uf2cf\uf2c9\uf2de\uf2de\uf2cf\uf2ef\uf2c2\uf2cb\uf2de", 62003), _E001);

		public static string String1 => ResourceManager.GetString(global::_E000._E000("\uf72c\uf70b\uf70d\uf716\uf711\uf718\uf74e", 63290), _E001);

		public static string Structure => ResourceManager.GetString(global::_E000._E000("\ue694\ue6b3\ue6b5\ue6b2\ue6a4\ue6b3\ue6b2\ue6b5\ue6a2", 58884), _E001);

		public static string StructureNumber => ResourceManager.GetString(global::_E000._E000("\ue9ec\ue9cb\ue9cd\ue9ca\ue9dc\ue9cb\ue9ca\ue9cd\ue9da\ue9f1\ue9ca\ue9d2\ue9dd\ue9da\ue9cd", 59835), _E001);

		public static string SuccessfullyPassed => ResourceManager.GetString(global::_E000._E000("\ue13e\ue118\ue10e\ue10e\ue108\ue11e\ue11e\ue10b\ue118\ue101\ue101\ue114\ue13d\ue10c\ue11e\ue11e\ue108\ue109", 57669), _E001);

		public static string SumLessThenNull => ResourceManager.GetString(global::_E000._E000("\ue42e\ue408\ue410\ue431\ue418\ue40e\ue40e\ue429\ue415\ue418\ue413\ue433\ue408\ue411\ue411", 58472), _E001);

		public static string SystemTypeEnumComputerSystem => ResourceManager.GetString(global::_E000._E000("\ue4ac\ue486\ue48c\ue48b\ue49a\ue492\ue4ab\ue486\ue48f\ue49a\ue4ba\ue491\ue48a\ue492\ue4bc\ue490\ue492\ue48f\ue48a\ue48b\ue49a\ue48d\ue4ac\ue486\ue48c\ue48b\ue49a\ue492", 58463), _E001);

		public static string SystemTypeEnumWebCashDemo => ResourceManager.GetString(global::_E000._E000("\ue77e\ue754\ue75e\ue759\ue748\ue740\ue779\ue754\ue75d\ue748\ue768\ue743\ue758\ue740\ue77a\ue748\ue74f\ue76e\ue74c\ue75e\ue745\ue769\ue748\ue740\ue742", 59180), _E001);

		public static string Tara => ResourceManager.GetString(global::_E000._E000("\ue3e9\ue3dc\ue3cf\ue3dc", 58300), _E001);

		public static string Taxed => ResourceManager.GetString(global::_E000._E000("\ue06b\ue05e\ue047\ue05a\ue05b", 57371), _E001);

		public static string TengeShort => ResourceManager.GetString(global::_E000._E000("\ue30a\ue33b\ue330\ue339\ue33b\ue30d\ue336\ue331\ue32c\ue32a", 58206), _E001);

		public static string Testing => ResourceManager.GetString(global::_E000._E000("\uf33b\uf30a\uf31c\uf31b\uf306\uf301\uf308", 62218), _E001);

		public static string Total => ResourceManager.GetString(global::_E000._E000("\ueee9\ueed2\ueec9\ueedc\ueed1", 61084), _E001);

		public static string TotalMarking => ResourceManager.GetString(global::_E000._E000("\ue7a3\ue798\ue783\ue796\ue79b\ue7ba\ue796\ue785\ue79c\ue79e\ue799\ue790", 59316), _E001);

		public static string TotalSum => ResourceManager.GetString(global::_E000._E000("\uf8ff\uf8c4\uf8df\uf8ca\uf8c7\uf8f8\uf8de\uf8c6", 63617), _E001);

		public static string TradePoint => ResourceManager.GetString(global::_E000._E000("\ue7eb\ue7cd\ue7de\ue7db\ue7da\ue7ef\ue7d0\ue7d6\ue7d1\ue7cb", 59319), _E001);

		public static string TradePointDeleteFailedBecauseOfCashbox => ResourceManager.GetString(global::_E000._E000("\uf139\uf11f\uf10c\uf109\uf108\uf13d\uf102\uf104\uf103\uf119\uf129\uf108\uf101\uf108\uf119\uf108\uf12b\uf10c\uf104\uf101\uf108\uf109\uf12f\uf108\uf10e\uf10c\uf118\uf11e\uf108\uf122\uf10b\uf12e\uf10c\uf11e\uf105\uf10f\uf102\uf115", 61733), _E001);

		public static string TurnOff => ResourceManager.GetString(global::_E000._E000("\ue889\ue8a8\ue8af\ue8b3\ue892\ue8bb\ue8bb", 59592), _E001);

		public static string TurnOn => ResourceManager.GetString(global::_E000._E000("\uf2cd\uf2ec\uf2eb\uf2f7\uf2d6\uf2f7", 61977), _E001);

		public static string UniqueNumber => ResourceManager.GetString(global::_E000._E000("\uf6b2\uf689\uf68e\uf696\uf692\uf682\uf6a9\uf692\uf68a\uf685\uf682\uf695", 63012), _E001);

		public static string UnitOfMeasurement => ResourceManager.GetString(global::_E000._E000("\ue2ba\ue281\ue286\ue29b\ue2a0\ue289\ue2a2\ue28a\ue28e\ue29c\ue29a\ue29d\ue28a\ue282\ue28a\ue281\ue29b", 58063), _E001);

		public static string UnitType => ResourceManager.GetString(global::_E000._E000("\uf2ae\uf295\uf292\uf28f\uf2af\uf282\uf28b\uf29e", 62195), _E001);

		public static string UpdateDate => ResourceManager.GetString(global::_E000._E000("\ue3ca\ue3ef\ue3fb\ue3fe\ue3eb\ue3fa\ue3db\ue3fe\ue3eb\ue3fa", 58263), _E001);

		public static string UseLogo => ResourceManager.GetString(global::_E000._E000("\uec6a\uec4c\uec5a\uec73\uec50\uec58\uec50", 60427), _E001);

		public static string UsePriceList => ResourceManager.GetString(global::_E000._E000("\ue33a\ue31c\ue30a\ue33f\ue31d\ue306\ue30c\ue30a\ue323\ue306\ue31c\ue31b", 58214), _E001);

		public static string UserTimeZone => ResourceManager.GetString(global::_E000._E000("\ued67\ued41\ued57\ued40\ued66\ued5b\ued5f\ued57\ued68\ued5d\ued5c\ued57", 60688), _E001);

		public static string ValidationCode => ResourceManager.GetString(global::_E000._E000("\uf2e9\uf2de\uf2d3\uf2d6\uf2db\uf2de\uf2cb\uf2d6\uf2d0\uf2d1\uf2fc\uf2d0\uf2db\uf2da", 62107), _E001);

		public static string ValueMustBeGreaterThanZero => ResourceManager.GetString(global::_E000._E000("\ueaa9\uea9e\uea93\uea8a\uea9a\ueab2\uea8a\uea8c\uea8b\ueabd\uea9a\ueab8\uea8d\uea9a\uea9e\uea8b\uea9a\uea8d\ueaab\uea97\uea9e\uea91\ueaa5\uea9a\uea8d\uea90", 60023), _E001);

		public static string ValueMustBePositive => ResourceManager.GetString(global::_E000._E000("\ue7a4\ue793\ue79e\ue787\ue797\ue7bf\ue787\ue781\ue786\ue7b0\ue797\ue7a2\ue79d\ue781\ue79b\ue786\ue79b\ue784\ue797", 59344), _E001);

		public static string ValueMustBePositiveAndThreeSignPrecission => ResourceManager.GetString(global::_E000._E000("\uf3bb\uf38c\uf381\uf398\uf388\uf3a0\uf398\uf39e\uf399\uf3af\uf388\uf3bd\uf382\uf39e\uf384\uf399\uf384\uf39b\uf388\uf3ac\uf383\uf389\uf3b9\uf385\uf39f\uf388\uf388\uf3be\uf384\uf38a\uf383\uf3bd\uf39f\uf388\uf38e\uf384\uf39e\uf39e\uf384\uf382\uf383", 62405), _E001);

		public static string ValueMustBePositiveAndTwoSignPrecission => ResourceManager.GetString(global::_E000._E000("\ue029\ue01e\ue013\ue00a\ue01a\ue032\ue00a\ue00c\ue00b\ue03d\ue01a\ue02f\ue010\ue00c\ue016\ue00b\ue016\ue009\ue01a\ue03e\ue011\ue01b\ue02b\ue008\ue010\ue02c\ue016\ue018\ue011\ue02f\ue00d\ue01a\ue01c\ue016\ue00c\ue00c\ue016\ue010\ue011", 57467), _E001);

		public static string VatRateIncludedPercent => ResourceManager.GetString(global::_E000._E000("\uf481\uf4b6\uf4a3\uf485\uf4b6\uf4a3\uf4b2\uf49e\uf4b9\uf4b4\uf4bb\uf4a2\uf4b3\uf4b2\uf4b3\uf487\uf4b2\uf4a5\uf4b4\uf4b2\uf4b9\uf4a3", 62548), _E001);

		public static string Welcome => ResourceManager.GetString(global::_E000._E000("\uecac\uec9e\uec97\uec98\uec94\uec96\uec9e", 60659), _E001);

		public static string WithoutMarking => ResourceManager.GetString(global::_E000._E000("\ue0b5\ue08b\ue096\ue08a\ue08d\ue097\ue096\ue0af\ue083\ue090\ue089\ue08b\ue08c\ue085", 57568), _E001);

		public static string WithoutTax => ResourceManager.GetString(global::_E000._E000("\uf5aa\uf594\uf589\uf595\uf592\uf588\uf589\uf5a9\uf59c\uf585", 62888), _E001);

		public static string Yes => ResourceManager.GetString(global::_E000._E000("\ueda7\ued9b\ued8d", 60910), _E001);

		public static string YesDelete => ResourceManager.GetString(global::_E000._E000("\uefe0\uefdc\uefca\ueffd\uefdc\uefd5\uefdc\uefcd\uefdc", 61241), _E001);

		internal JsResource()
		{
		}
	}
}
