using System;
using System.Globalization;
using System.Resources;
using System.Threading;
using WebCash.Resources.Interfaces;

namespace WebCash.Resources
{
	public static class Languages
	{
		public const string Russian = "ru-RU";

		public const string Kazakh = "kk-KZ";

		public const string English = "en-US";

		public const string Ru = "ru";

		public const string Kk = "kk";

		public const string En = "en";

		public const string Default = "ru-RU";

		public const string LangRouteName = "lang";

		public const string LangCookieName = "webcash-lang";

		public const string LangAcceptLangName = "Accept-Language";

		public static string[] List => new string[3]
		{
			_E000._E000("\uf801\uf806\uf85e\uf821\uf826", 63570),
			_E000._E000("\uf009\uf009\uf04f\uf029\uf038", 61504),
			_E000._E000("\ue2a2\ue2a9\ue2ea\ue292\ue294", 57860)
		};

		public static string[] ListOfShort => new string[3]
		{
			_E000._E000("\ue10f\ue108", 57692),
			_E000._E000("\ue616\ue616", 58901),
			_E000._E000("\uf21a\uf211", 62010)
		};

		public static string CurrentLanguage => Thread.CurrentThread.CurrentCulture.TwoLetterISOLanguageName;

		public static bool IsCurrentLanguage(string lang)
		{
			return Thread.CurrentThread.CurrentCulture.TwoLetterISOLanguageName == lang;
		}

		public static string LocalizedValue<TModel>(TModel model, Func<TModel, string> ru, Func<TModel, string> kz, Func<TModel, string> en)
		{
			string twoLetterISOLanguageName = Thread.CurrentThread.CurrentCulture.TwoLetterISOLanguageName;
			if (!(twoLetterISOLanguageName == _E000._E000("\ue616\ue616", 58901)))
			{
				if (twoLetterISOLanguageName == _E000._E000("\uf21a\uf211", 62010))
				{
					string text = en(model);
					if (!string.IsNullOrEmpty(text))
					{
						return text;
					}
				}
			}
			else
			{
				string text2 = kz(model);
				if (!string.IsNullOrEmpty(text2))
				{
					return text2;
				}
			}
			return ru(model);
		}

		public static string LocalizedValue<TModel>(this TModel model) where TModel : ILocalizable
		{
			return LocalizedValue(model, (TModel _E000) => _E000.NameRu, (TModel _E001) => _E001.NameKz, (TModel _E002) => _E002.NameEn);
		}

		public static string ToShortText(string twoLetterIsoLanguageName)
		{
			if (!(twoLetterIsoLanguageName == _E000._E000("\ue10f\ue108", 57692)))
			{
				if (!(twoLetterIsoLanguageName == _E000._E000("\ue616\ue616", 58901)))
				{
					if (twoLetterIsoLanguageName == _E000._E000("\uf21a\uf211", 62010))
					{
						return _E000._E000("\uf436\uf43d\uf434", 62546);
					}
					throw new NotImplementedException();
				}
				return _E000._E000("\uecf5\uecff\uecf8", 59533);
			}
			return _E000._E000("\uf4df\uf4dc\uf4de", 61559);
		}

		public static string ToFullText(string twoLetterIsoLanguageName)
		{
			if (!(twoLetterIsoLanguageName == _E000._E000("\ue10f\ue108", 57692)))
			{
				if (!(twoLetterIsoLanguageName == _E000._E000("\ue616\ue616", 58901)))
				{
					if (twoLetterIsoLanguageName == _E000._E000("\uf21a\uf211", 62010))
					{
						return _E000._E000("\uf0da\uf0f1\uf0f8\uf0f3\uf0f6\uf0ec\uf0f7", 61463);
					}
					return _E000._E000("\ueaaa\uea91\uea94\uea91\uea90\uea88", 59997);
				}
				return _E000._E000("\ue771\ue7db\ue7dc\ue7db\ue770", 58339);
			}
			return _E000._E000("\uecfe\uec9d\uec9f\uec9f\uece4\uece6\uece7", 59614);
		}

		public static string GetLocalizedValue(Type resourceType, string resourceName, string lang)
		{
			return new ResourceManager(resourceType).GetResourceSet(new CultureInfo(lang), createIfNotExists: true, tryParents: true).GetString(resourceName);
		}

		public static string GetCurrentDateTimeFormat()
		{
			string currentLanguage = CurrentLanguage;
			if (!(currentLanguage == _E000._E000("\ue10f\ue108", 57692)) && !(currentLanguage == _E000._E000("\ue616\ue616", 58901)))
			{
				if (currentLanguage == _E000._E000("\uf21a\uf211", 62010))
				{
					return _E000._E000("\ue2f3\ue2f3\ue2b3\ue2fa\ue2fa\ue2b3\ue2e7\ue2e7\ue2e7\ue2e7", 58014);
				}
				throw new NotImplementedException();
			}
			return _E000._E000("\uf2cf\uf2cf\uf285\uf2c6\uf2c6\uf285\uf2d2\uf2d2\uf2d2\uf2d2", 62113);
		}
	}
}
