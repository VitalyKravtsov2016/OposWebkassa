using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace WebCash.Resources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class NameResource
	{
		private static ResourceManager _E000;

		private static CultureInfo _E001;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (_E000 == null)
				{
					_E000 = new ResourceManager(global::_E000._E000("\ue2b8\ue28a\ue28d\ue2ac\ue28e\ue29c\ue287\ue2c1\ue2bd\ue28a\ue29c\ue280\ue29a\ue29d\ue28c\ue28a\ue29c\ue2c1\ue2a1\ue28e\ue282\ue28a\ue2bd\ue28a\ue29c\ue280\ue29a\ue29d\ue28c\ue28a", 58061), typeof(NameResource).Assembly);
				}
				return _E000;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return _E001;
			}
			set
			{
				_E001 = value;
			}
		}

		public static string Absent => ResourceManager.GetString(global::_E000._E000("\uf53e\uf51d\uf50c\uf51a\uf511\uf50b", 62842), _E001);

		public static string ActivationPacket => ResourceManager.GetString(global::_E000._E000("\ue2ae\ue28c\ue29b\ue286\ue299\ue28e\ue29b\ue286\ue280\ue281\ue2bf\ue28e\ue28c\ue284\ue28a\ue29b", 58026), _E001);

		public static string ActivationPacketNumber => ResourceManager.GetString(global::_E000._E000("\uedea\uedc8\ueddf\uedc2\ueddd\uedca\ueddf\uedc2\uedc4\uedc5\uedfb\uedca\uedc8\uedc0\uedce\ueddf\uede5\uedde\uedc6\uedc9\uedce\uedd9", 60803), _E001);

		public static string ActivationPacketType => ResourceManager.GetString(global::_E000._E000("\uefac\uef8e\uef99\uef84\uef9b\uef8c\uef99\uef84\uef82\uef83\uefbd\uef8c\uef8e\uef86\uef88\uef99\uefb9\uef94\uef9d\uef88", 61381), _E001);

		public static string Active => ResourceManager.GetString(global::_E000._E000("\uf27c\uf25e\uf249\uf254\uf24b\uf258", 61980), _E001);

		public static string ActiveCashboxes => ResourceManager.GetString(global::_E000._E000("\ue7be\ue79c\ue78b\ue796\ue789\ue79a\ue7bc\ue79e\ue78c\ue797\ue79d\ue790\ue787\ue79a\ue78c", 59197), _E001);

		public static string Administrator => ResourceManager.GetString(global::_E000._E000("\ue1bc\ue199\ue190\ue194\ue193\ue194\ue18e\ue189\ue18f\ue19c\ue189\ue192\ue18f", 57768), _E001);

		public static string AdText => ResourceManager.GetString(global::_E000._E000("\uf12c\uf109\uf139\uf108\uf115\uf119", 61804), _E001);

		public static string AfterThreeDays => ResourceManager.GetString(global::_E000._E000("\uf78e\uf7a9\uf7bb\uf7aa\uf7bd\uf79b\uf7a7\uf7bd\uf7aa\uf7aa\uf78b\uf7ae\uf7b6\uf7bc", 63366), _E001);

		public static string AfterWeek => ResourceManager.GetString(global::_E000._E000("\uf3b6\uf391\uf383\uf392\uf385\uf3a0\uf392\uf392\uf39c", 62324), _E001);

		public static string AllCashSum => ResourceManager.GetString(global::_E000._E000("\ue65f\ue672\ue672\ue65d\ue67f\ue66d\ue676\ue64d\ue66b\ue673", 58910), _E001);

		public static string AnalyticMonitoring => ResourceManager.GetString(global::_E000._E000("\uf8aa\uf885\uf88a\uf887\uf892\uf89f\uf882\uf888\uf8a6\uf884\uf885\uf882\uf89f\uf884\uf899\uf882\uf885\uf88c", 63555), _E001);

		public static string Annual => ResourceManager.GetString(global::_E000._E000("\ue67e\ue651\ue651\ue64a\ue65e\ue653", 58939), _E001);

		public static string Application => ResourceManager.GetString(global::_E000._E000("\ue6bc\ue68d\ue68d\ue691\ue694\ue69e\ue69c\ue689\ue694\ue692\ue693", 59112), _E001);

		public static string AutoCloseShift => ResourceManager.GetString(global::_E000._E000("\ue1aa\ue19e\ue19f\ue184\ue1a8\ue187\ue184\ue198\ue18e\ue1b8\ue183\ue182\ue18d\ue19f", 57825), _E001);

		public static string AutoCloseShiftTime => ResourceManager.GetString(global::_E000._E000("\uea2c\uea18\uea19\uea02\uea2e\uea01\uea02\uea1e\uea08\uea3e\uea05\uea04\uea0b\uea19\uea39\uea04\uea00\uea08", 59980), _E001);

		public static string AutoCloseShiftUser => ResourceManager.GetString(global::_E000._E000("\uf0ae\uf09a\uf09b\uf080\uf0ac\uf083\uf080\uf09c\uf08a\uf0bc\uf087\uf086\uf089\uf09b\uf0ba\uf09c\uf08a\uf09d", 61679), _E001);

		public static string AutoDownloadPDF => ResourceManager.GetString(global::_E000._E000("\ue6fa\ue6ce\ue6cf\ue6d4\ue6ff\ue6d4\ue6cc\ue6d5\ue6d7\ue6d4\ue6da\ue6df\ue6eb\ue6ff\ue6fd", 59025), _E001);

		public static string AutoOrWithoutCutter => ResourceManager.GetString(global::_E000._E000("\ue93e\ue90a\ue90b\ue910\ue930\ue90d\ue928\ue916\ue90b\ue917\ue910\ue90a\ue90b\ue93c\ue90a\ue90b\ue90b\ue91a\ue90d", 59674), _E001);

		public static string AutoOrWithoutCutterDescription => ResourceManager.GetString(global::_E000._E000("\uf1de\uf1ea\uf1eb\uf1f0\uf1d0\uf1ed\uf1c8\uf1f6\uf1eb\uf1f7\uf1f0\uf1ea\uf1eb\uf1dc\uf1ea\uf1eb\uf1eb\uf1fa\uf1ed\uf1db\uf1fa\uf1ec\uf1fc\uf1ed\uf1f6\uf1ef\uf1eb\uf1f6\uf1f0\uf1f1", 61703), _E001);

		public static string AutoSendEmail => ResourceManager.GetString(global::_E000._E000("\ue99e\ue9aa\ue9ab\ue9b0\ue98c\ue9ba\ue9b1\ue9bb\ue99a\ue9b2\ue9be\ue9b6\ue9b3", 59863), _E001);

		public static string AutoWithDrawal => ResourceManager.GetString(global::_E000._E000("\uf33c\uf308\uf309\uf312\uf32a\uf314\uf309\uf315\uf339\uf30f\uf31c\uf30a\uf31c\uf311", 62293), _E001);

		public static string AutoWithDrawalFull => ResourceManager.GetString(global::_E000._E000("\ue7fc\ue7c8\ue7c9\ue7d2\ue7ea\ue7d4\ue7c9\ue7d5\ue7f9\ue7cf\ue7dc\ue7ca\ue7dc\ue7d1\ue7fb\ue7c8\ue7d1\ue7d1", 59324), _E001);

		public static string AutoWithDrawalNone => ResourceManager.GetString(global::_E000._E000("\uf3be\uf38a\uf38b\uf390\uf3a8\uf396\uf38b\uf397\uf3bb\uf38d\uf39e\uf388\uf39e\uf393\uf3b1\uf390\uf391\uf39a", 62461), _E001);

		public static string AutoWithDrawalPartial => ResourceManager.GetString(global::_E000._E000("\ue71c\ue728\ue729\ue732\ue70a\ue734\ue729\ue735\ue719\ue72f\ue73c\ue72a\ue73c\ue731\ue70d\ue73c\ue72f\ue729\ue734\ue73c\ue731", 59208), _E001);

		public static string AwaitActivation => ResourceManager.GetString(global::_E000._E000("\uf1ae\uf198\uf18e\uf186\uf19b\uf1ae\uf18c\uf19b\uf186\uf199\uf18e\uf19b\uf186\uf180\uf181", 61926), _E001);

		public static string AwaitActiveted => ResourceManager.GetString(global::_E000._E000("\uf5ba\uf58c\uf59a\uf592\uf58f\uf5ba\uf598\uf58f\uf592\uf58d\uf59e\uf58f\uf59e\uf59f", 62833), _E001);

		public static string Awaiting => ResourceManager.GetString(global::_E000._E000("\ue2fa\ue2cc\ue2da\ue2d2\ue2cf\ue2d2\ue2d5\ue2dc", 58003), _E001);

		public static string AwaitingIssuance => ResourceManager.GetString(global::_E000._E000("\ue3ae\ue398\ue38e\ue386\ue39b\ue386\ue381\ue388\ue3a6\ue39c\ue39c\ue39a\ue38e\ue381\ue38c\ue38a", 58314), _E001);

		public static string AwaitingOperation => ResourceManager.GetString(global::_E000._E000("\uec9e\ueca8\uecbe\uecb6\uecab\uecb6\uecb1\uecb8\uec90\uecaf\uecba\uecad\uecbe\uecab\uecb6\uecb0\uecb1", 60503), _E001);

		public static string AwaitUserConfirm => ResourceManager.GetString(global::_E000._E000("\ue0aa\ue09c\ue08a\ue082\ue09f\ue0be\ue098\ue08e\ue099\ue0a8\ue084\ue085\ue08d\ue082\ue099\ue086", 57571), _E001);

		public static string BankCard => ResourceManager.GetString(global::_E000._E000("\uf8a9\uf88a\uf885\uf880\uf8a8\uf88a\uf899\uf88f", 63585), _E001);

		public static string BankCardShort => ResourceManager.GetString(global::_E000._E000("\ue39d\ue3be\ue3b1\ue3b4\ue39c\ue3be\ue3ad\ue3bb\ue38c\ue3b7\ue3b0\ue3ad\ue3ab", 58326), _E001);

		public static string BaudRate => ResourceManager.GetString(global::_E000._E000("\ue71f\ue73c\ue728\ue739\ue70f\ue73c\ue729\ue738", 59144), _E001);

		public static string BaudRateDescription => ResourceManager.GetString(global::_E000._E000("\uf0f9\uf0da\uf0ce\uf0df\uf0e9\uf0da\uf0cf\uf0de\uf0ff\uf0de\uf0c8\uf0d8\uf0c9\uf0d2\uf0cb\uf0cf\uf0d2\uf0d4\uf0d5", 61491), _E001);

		public static string BillWidth => ResourceManager.GetString(global::_E000._E000("\uede9\uedc2\uedc7\uedc7\uedfc\uedc2\uedcf\ueddf\uedc3", 60705), _E001);

		public static string BillWidthDescription => ResourceManager.GetString(global::_E000._E000("\uebb9\ueb92\ueb97\ueb97\uebac\ueb92\ueb9f\ueb8f\ueb93\uebbf\ueb9e\ueb88\ueb98\ueb89\ueb92\ueb8b\ueb8f\ueb92\ueb94\ueb95", 60371), _E001);

		public static string BIN => ResourceManager.GetString(global::_E000._E000("\uf3b1\uf3ba\uf3bd", 62434), _E001);

		public static string BKCabinet => ResourceManager.GetString(global::_E000._E000("\uf8ff\uf8f6\uf8fe\uf8dc\uf8df\uf8d4\uf8d3\uf8d8\uf8c9", 63676), _E001);

		public static string BlockPriceListUserInput => ResourceManager.GetString(global::_E000._E000("\ue53c\ue512\ue511\ue51d\ue515\ue52e\ue50c\ue517\ue51d\ue51b\ue532\ue517\ue50d\ue50a\ue52b\ue50d\ue51b\ue50c\ue537\ue510\ue50e\ue50b\ue50a", 58750), _E001);

		public static string BonusCount => ResourceManager.GetString(global::_E000._E000("\ue03d\ue010\ue011\ue00a\ue00c\ue03c\ue010\ue00a\ue011\ue00b", 57370), _E001);

		public static string BufferTimeout => ResourceManager.GetString(global::_E000._E000("\uf8ad\uf89a\uf889\uf889\uf88a\uf89d\uf8bb\uf886\uf882\uf88a\uf880\uf89a\uf89b", 63629), _E001);

		public static string BufferTimeoutDesription => ResourceManager.GetString(global::_E000._E000("\uf0e9\uf0de\uf0cd\uf0cd\uf0ce\uf0d9\uf0ff\uf0c2\uf0c6\uf0ce\uf0c4\uf0de\uf0df\uf0ef\uf0ce\uf0d8\uf0d9\uf0c2\uf0db\uf0df\uf0c2\uf0c4\uf0c5", 61475), _E001);

		public static string BuyCount => ResourceManager.GetString(global::_E000._E000("\uec3f\uec08\uec04\uec3e\uec12\uec08\uec13\uec09", 60508), _E001);

		public static string BuyMode => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue79e\ue792\ue7a6\ue784\ue78f\ue78e", 59331), _E001);

		public static string BuySum => ResourceManager.GetString(global::_E000._E000("\ue920\ue917\ue91b\ue931\ue917\ue90f", 59712), _E001);

		public static string CalculateLevel => ResourceManager.GetString(global::_E000._E000("\uefbc\uef9e\uef93\uef9c\uef8a\uef93\uef9e\uef8b\uef9a\uefb3\uef9a\uef89\uef9a\uef93", 61245), _E001);

		public static string CallCenter => ResourceManager.GetString(global::_E000._E000("\uf5fc\uf5de\uf5d3\uf5d3\uf5fc\uf5da\uf5d1\uf5cb\uf5da\uf5cd", 62887), _E001);

		public static string Cash => ResourceManager.GetString(global::_E000._E000("\uf030\uf012\uf000\uf01b", 61554), _E001);

		public static string Cashbox => ResourceManager.GetString(global::_E000._E000("\ue0e8\ue0ca\ue0d8\ue0c3\ue0c9\ue0c4\ue0d3", 57347), _E001);

		public static string CashboxAddress => ResourceManager.GetString(global::_E000._E000("\uf1f8\uf1da\uf1c8\uf1d3\uf1d9\uf1d4\uf1c3\uf1fa\uf1df\uf1df\uf1c9\uf1de\uf1c8\uf1c8", 61875), _E001);

		public static string CashboxCodeSRC => ResourceManager.GetString(global::_E000._E000("\uedfc\uedde\uedcc\uedd7\ueddd\uedd0\uedc7\uedfc\uedd0\ueddb\uedda\uedec\ueded\uedfc", 60863), _E001);

		public static string CashboxCount => ResourceManager.GetString(global::_E000._E000("\ue93e\ue91c\ue90e\ue915\ue91f\ue912\ue905\ue93e\ue912\ue908\ue913\ue909", 59701), _E001);

		public static string CashboxDescription => ResourceManager.GetString(global::_E000._E000("\ue2ea\ue2c8\ue2da\ue2c1\ue2cb\ue2c6\ue2d1\ue2ed\ue2cc\ue2da\ue2ca\ue2db\ue2c0\ue2d9\ue2dd\ue2c0\ue2c6\ue2c7", 57897), _E001);

		public static string CashboxDiscountInputType => ResourceManager.GetString(global::_E000._E000("\uedb8\ued9a\ued88\ued93\ued99\ued94\ued83\uedbf\ued92\ued88\ued98\ued94\ued8e\ued95\ued8f\uedb2\ued95\ued8b\ued8e\ued8f\uedaf\ued82\ued8b\ued9e", 60753), _E001);

		public static string CashboxIdentityNumber => ResourceManager.GetString(global::_E000._E000("\uf2be\uf29c\uf28e\uf295\uf29f\uf292\uf285\uf2b4\uf299\uf298\uf293\uf289\uf294\uf289\uf284\uf2b3\uf288\uf290\uf29f\uf298\uf28f", 62136), _E001);

		public static string CashboxIN => ResourceManager.GetString(global::_E000._E000("\uf1fe\uf1dc\uf1ce\uf1d5\uf1df\uf1d2\uf1c5\uf1f4\uf1f3", 61884), _E001);

		public static string CashboxLessee => ResourceManager.GetString(global::_E000._E000("\uf394\uf3b6\uf3a4\uf3bf\uf3b5\uf3b8\uf3af\uf39b\uf3b2\uf3a4\uf3a4\uf3b2\uf3b2", 62228), _E001);

		public static string CashboxMarkupVisiblity => ResourceManager.GetString(global::_E000._E000("\ue0ac\ue08e\ue09c\ue087\ue08d\ue080\ue097\ue0a2\ue08e\ue09d\ue084\ue09a\ue09f\ue0b9\ue086\ue09c\ue086\ue08d\ue083\ue086\ue09b\ue096", 57357), _E001);

		public static string CashboxMessage => ResourceManager.GetString(global::_E000._E000("\uee61\uee43\uee51\uee4a\uee40\uee4d\uee5a\uee6f\uee47\uee51\uee51\uee43\uee45\uee47", 60960), _E001);

		public static string CashboxModelType => ResourceManager.GetString(global::_E000._E000("\uecac\uec8e\uec9c\uec87\uec8d\uec80\uec97\ueca2\uec80\uec8b\uec8a\uec83\uecbb\uec96\uec9f\uec8a", 60586), _E001);

		public static string CashboxName => ResourceManager.GetString(global::_E000._E000("\ued2c\ued0e\ued1c\ued07\ued0d\ued00\ued17\ued21\ued0e\ued02\ued0a", 60746), _E001);

		public static string CashboxOFDIN => ResourceManager.GetString(global::_E000._E000("\uf69c\uf6be\uf6ac\uf6b7\uf6bd\uf6b0\uf6a7\uf690\uf699\uf69b\uf696\uf691", 63175), _E001);

		public static string CashboxPaymentTypes => ResourceManager.GetString(global::_E000._E000("\uf7b0\uf792\uf780\uf79b\uf791\uf79c\uf78b\uf7a3\uf792\uf78a\uf79e\uf796\uf79d\uf787\uf7a7\uf78a\uf783\uf796\uf780", 63458), _E001);

		public static string CashboxRegistrateModelCurrentStatusDate => ResourceManager.GetString(global::_E000._E000("\ue4a8\ue48a\ue498\ue483\ue489\ue484\ue493\ue4b9\ue48e\ue48c\ue482\ue498\ue49f\ue499\ue48a\ue49f\ue48e\ue4a6\ue484\ue48f\ue48e\ue487\ue4a8\ue49e\ue499\ue499\ue48e\ue485\ue49f\ue4b8\ue49f\ue48a\ue49f\ue49e\ue498\ue4af\ue48a\ue49f\ue48e", 58563), _E001);

		public static string CashboxRegistrationDate => ResourceManager.GetString(global::_E000._E000("\uf484\uf4a6\uf4b4\uf4af\uf4a5\uf4a8\uf4bf\uf495\uf4a2\uf4a0\uf4ae\uf4b4\uf4b3\uf4b5\uf4a6\uf4b3\uf4ae\uf4a8\uf4a9\uf483\uf4a6\uf4b3\uf4a2", 62532), _E001);

		public static string CashboxRegistrationNumber => ResourceManager.GetString(global::_E000._E000("\ue9be\ue99c\ue98e\ue995\ue99f\ue992\ue985\ue9af\ue998\ue99a\ue994\ue98e\ue989\ue98f\ue99c\ue989\ue994\ue992\ue993\ue9b3\ue988\ue990\ue99f\ue998\ue98f", 59832), _E001);

		public static string CashboxRequestNumber => ResourceManager.GetString(global::_E000._E000("\uebbc\ueb9e\ueb8c\ueb97\ueb9d\ueb90\ueb87\uebad\ueb9a\ueb8e\ueb8a\ueb9a\ueb8c\ueb8b\uebb1\ueb8a\ueb92\ueb9d\ueb9a\ueb8d", 60285), _E001);

		public static string CashboxRN => ResourceManager.GetString(global::_E000._E000("\uecfa\uecd8\uecca\uecd1\uecdb\uecd6\uecc1\ueceb\uecf7", 60473), _E001);

		public static string CashboxSN => ResourceManager.GetString(global::_E000._E000("\uf03e\uf01c\uf00e\uf015\uf01f\uf012\uf005\uf02e\uf033", 61525), _E001);

		public static string CashboxStatus => ResourceManager.GetString(global::_E000._E000("\ue13e\ue11c\ue10e\ue115\ue11f\ue112\ue105\ue12e\ue109\ue11c\ue109\ue108\ue10e", 57717), _E001);

		public static string CashboxStatusActive => ResourceManager.GetString(global::_E000._E000("\uedba\ued98\ued8a\ued91\ued9b\ued96\ued81\uedaa\ued8d\ued98\ued8d\ued8c\ued8a\uedb8\ued9a\ued8d\ued90\ued8f\ued9c", 60921), _E001);

		public static string CashboxStatusCreated => ResourceManager.GetString(global::_E000._E000("\ue4ca\ue4e8\ue4fa\ue4e1\ue4eb\ue4e6\ue4f1\ue4da\ue4fd\ue4e8\ue4fd\ue4fc\ue4fa\ue4ca\ue4fb\ue4ec\ue4e8\ue4fd\ue4ec\ue4ed", 58505), _E001);

		public static string CashboxStatusDate => ResourceManager.GetString(global::_E000._E000("\ue2e8\ue2ca\ue2d8\ue2c3\ue2c9\ue2c4\ue2d3\ue2f8\ue2df\ue2ca\ue2df\ue2de\ue2d8\ue2ef\ue2ca\ue2df\ue2ce", 57985), _E001);

		public static string CashboxStatusDeregistered => ResourceManager.GetString(global::_E000._E000("\uf5ae\uf58c\uf59e\uf585\uf58f\uf582\uf595\uf5be\uf599\uf58c\uf599\uf598\uf59e\uf5a9\uf588\uf59f\uf588\uf58a\uf584\uf59e\uf599\uf588\uf59f\uf588\uf589", 62924), _E001);

		public static string CashboxStatusInvalid => ResourceManager.GetString(global::_E000._E000("\ue0bc\ue09e\ue08c\ue097\ue09d\ue090\ue087\ue0ac\ue08b\ue09e\ue08b\ue08a\ue08c\ue0b6\ue091\ue089\ue09e\ue093\ue096\ue09b", 57547), _E001);

		public static string CashboxStatusLocked => ResourceManager.GetString(global::_E000._E000("\uf4fe\uf4dc\uf4ce\uf4d5\uf4df\uf4d2\uf4c5\uf4ee\uf4c9\uf4dc\uf4c9\uf4c8\uf4ce\uf4f1\uf4d2\uf4de\uf4d6\uf4d8\uf4d9", 62652), _E001);

		public static string CashboxStatusRMNILocked => ResourceManager.GetString(global::_E000._E000("\ue3ca\ue3e8\ue3fa\ue3e1\ue3eb\ue3e6\ue3f1\ue3da\ue3fd\ue3e8\ue3fd\ue3fc\ue3fa\ue3db\ue3c4\ue3c7\ue3c0\ue3c5\ue3e6\ue3ea\ue3e2\ue3ec\ue3ed", 58121), _E001);

		public static string CashboxTimeZoneAstanaUTC06 => ResourceManager.GetString(global::_E000._E000("\uf630\uf612\uf600\uf61b\uf611\uf61c\uf60b\uf627\uf61a\uf61e\uf616\uf629\uf61c\uf61d\uf616\uf632\uf600\uf607\uf612\uf61d\uf612\uf626\uf627\uf630\uf643\uf645", 63042), _E001);

		public static string CashboxTimeZoneUralUTC05 => ResourceManager.GetString(global::_E000._E000("\uf4be\uf49c\uf48e\uf495\uf49f\uf492\uf485\uf4a9\uf494\uf490\uf498\uf4a7\uf492\uf493\uf498\uf4a8\uf48f\uf49c\uf491\uf4a8\uf4a9\uf4be\uf4cd\uf4c8", 62712), _E001);

		public static string CashboxToken => ResourceManager.GetString(global::_E000._E000("\ue130\ue112\ue100\ue11b\ue111\ue11c\ue10b\ue127\ue11c\ue118\ue116\ue11d", 57714), _E001);

		public static string CashboxUniqueNumber => ResourceManager.GetString(global::_E000._E000("\uedf8\uedda\uedc8\uedd3\uedd9\uedd4\uedc3\uedee\uedd5\uedd2\uedca\uedce\uedde\uedf5\uedce\uedd6\uedd9\uedde\uedc9", 60849), _E001);

		public static string Cashier => ResourceManager.GetString(global::_E000._E000("\ue730\ue712\ue700\ue71b\ue71a\ue716\ue701", 59202), _E001);

		public static string CashiersAssignmentModelSelectedEmployees => ResourceManager.GetString(global::_E000._E000("\ueffa\uefd8\uefca\uefd1\uefd0\uefdc\uefcb\uefca\ueff8\uefca\uefca\uefd0\uefde\uefd7\uefd4\uefdc\uefd7\uefcd\ueff4\uefd6\uefdd\uefdc\uefd5\uefea\uefdc\uefd5\uefdc\uefda\uefcd\uefdc\uefdd\ueffc\uefd4\uefc9\uefd5\uefd6\uefc0\uefdc\uefdc\uefca", 61369), _E001);

		public static string CashiersAssignmentModelSelectedSection => ResourceManager.GetString(global::_E000._E000("\ue71e\ue73c\ue72e\ue735\ue734\ue738\ue72f\ue72e\ue71c\ue72e\ue72e\ue734\ue73a\ue733\ue730\ue738\ue733\ue729\ue710\ue732\ue739\ue738\ue731\ue70e\ue738\ue731\ue738\ue73e\ue729\ue738\ue739\ue70e\ue738\ue73e\ue729\ue734\ue732\ue733", 59208), _E001);

		public static string CashlessSum => ResourceManager.GetString(global::_E000._E000("\ue7bc\ue79e\ue78c\ue797\ue793\ue79a\ue78c\ue78c\ue7ac\ue78a\ue792", 59339), _E001);

		public static string CashSum => ResourceManager.GetString(global::_E000._E000("\uebfd\uebdf\uebcd\uebd6\uebed\uebcb\uebd3", 60334), _E001);

		public static string CashTape57Lite => ResourceManager.GetString(global::_E000._E000("\uf62e\uf60c\uf61e\uf605\uf639\uf60c\uf61d\uf608\uf658\uf65a\uf621\uf604\uf619\uf608", 63084), _E001);

		public static string CashTape57Rongta => ResourceManager.GetString(global::_E000._E000("\uec2c\uec0e\uec1c\uec07\uec3b\uec0e\uec1f\uec0a\uec5a\uec58\uec3d\uec00\uec01\uec08\uec1b\uec0e", 60454), _E001);

		public static string CashTape57Shtrikh => ResourceManager.GetString(global::_E000._E000("\uf4be\uf49c\uf48e\uf495\uf4a9\uf49c\uf48d\uf498\uf4c8\uf4ca\uf4ae\uf495\uf489\uf48f\uf494\uf496\uf495", 62712), _E001);

		public static string CashTape57ShtrikhLite => ResourceManager.GetString(global::_E000._E000("\uebbc\ueb9e\ueb8c\ueb97\uebab\ueb9e\ueb8f\ueb9a\uebca\uebc8\uebac\ueb97\ueb8b\ueb8d\ueb96\ueb94\ueb97\uebb3\ueb96\ueb8b\ueb9a", 60381), _E001);

		public static string CashTape80 => ResourceManager.GetString(global::_E000._E000("\ue9be\ue99c\ue98e\ue995\ue9a9\ue99c\ue98d\ue998\ue9c5\ue9cd", 59797), _E001);

		public static string CashTape80Aura => ResourceManager.GetString(global::_E000._E000("\uf2a8\uf28a\uf298\uf283\uf2bf\uf28a\uf29b\uf28e\uf2d3\uf2db\uf2aa\uf29e\uf299\uf28a", 62177), _E001);

		public static string CashTape80Lite => ResourceManager.GetString(global::_E000._E000("\uf8be\uf89c\uf88e\uf895\uf8a9\uf89c\uf88d\uf898\uf8c5\uf8cd\uf8b1\uf894\uf889\uf898", 63736), _E001);

		public static string CashTape80Posiflex => ResourceManager.GetString(global::_E000._E000("\ue9a4\ue986\ue994\ue98f\ue9b3\ue986\ue997\ue982\ue9df\ue9d7\ue9b7\ue988\ue994\ue98e\ue981\ue98b\ue982\ue99f", 59684), _E001);

		public static string CashTape80Prim => ResourceManager.GetString(global::_E000._E000("\uf6f8\uf6da\uf6c8\uf6d3\uf6ef\uf6da\uf6cb\uf6de\uf683\uf68b\uf6eb\uf6c9\uf6d2\uf6d6", 62995), _E001);

		public static string CashTape80Rongta => ResourceManager.GetString(global::_E000._E000("\uf15d\uf17f\uf16d\uf176\uf14a\uf17f\uf16e\uf17b\uf126\uf12e\uf14c\uf171\uf170\uf179\uf16a\uf17f", 61710), _E001);

		public static string CashTape80Sam4s => ResourceManager.GetString(global::_E000._E000("\ue670\ue652\ue640\ue65b\ue667\ue652\ue643\ue656\ue60b\ue603\ue660\ue652\ue65e\ue607\ue640", 58914), _E001);

		public static string CashTape80ShtrikhM => ResourceManager.GetString(global::_E000._E000("\ue4bc\ue49e\ue48c\ue497\ue4ab\ue49e\ue48f\ue49a\ue4c7\ue4cf\ue4ac\ue497\ue48b\ue48d\ue496\ue494\ue497\ue4b2", 58619), _E001);

		public static string CashTape80XTerm => ResourceManager.GetString(global::_E000._E000("\uf794\uf7b6\uf7a4\uf7bf\uf783\uf7b6\uf7a7\uf7b2\uf7ef\uf7e7\uf78f\uf783\uf7b2\uf7a5\uf7ba", 63316), _E001);

		public static string CharsConfigA => ResourceManager.GetString(global::_E000._E000("\uf42c\uf407\uf40e\uf41d\uf41c\uf42c\uf400\uf401\uf409\uf406\uf408\uf42e", 62566), _E001);

		public static string CharsConfigADescription => ResourceManager.GetString(global::_E000._E000("\uf81c\uf837\uf83e\uf82d\uf82c\uf81c\uf830\uf831\uf839\uf836\uf838\uf81e\uf81b\uf83a\uf82c\uf83c\uf82d\uf836\uf82f\uf82b\uf836\uf830\uf831", 63510), _E001);

		public static string CharsConfigB => ResourceManager.GetString(global::_E000._E000("\uf22e\uf205\uf20c\uf21f\uf21e\uf22e\uf202\uf203\uf20b\uf204\uf20a\uf22f", 62028), _E001);

		public static string CharsConfigBDescription => ResourceManager.GetString(global::_E000._E000("\ue894\ue8bf\ue8b6\ue8a5\ue8a4\ue894\ue8b8\ue8b9\ue8b1\ue8be\ue8b0\ue895\ue893\ue8b2\ue8a4\ue8b4\ue8a5\ue8be\ue8a7\ue8a3\ue8be\ue8b8\ue8b9", 59540), _E001);

		public static string Check => ResourceManager.GetString(global::_E000._E000("\ue80c\ue827\ue82a\ue82c\ue824", 59398), _E001);

		public static string CheckCash => ResourceManager.GetString(global::_E000._E000("\ue294\ue2bf\ue2b2\ue2b4\ue2bc\ue294\ue2b6\ue2a4\ue2bf", 58004), _E001);

		public static string CheckChange => ResourceManager.GetString(global::_E000._E000("\ue9fe\ue9d5\ue9d8\ue9de\ue9d6\ue9fe\ue9d5\ue9dc\ue9d3\ue9da\ue9d8", 59836), _E001);

		public static string CheckDiscount => ResourceManager.GetString(global::_E000._E000("\ue2ac\ue287\ue28a\ue28c\ue284\ue2ab\ue286\ue29c\ue28c\ue280\ue29a\ue281\ue29b", 58090), _E001);

		public static string CheckDiscountPercent => ResourceManager.GetString(global::_E000._E000("\ue930\ue91b\ue916\ue910\ue918\ue937\ue91a\ue900\ue910\ue91c\ue906\ue91d\ue907\ue923\ue916\ue901\ue910\ue916\ue91d\ue907", 59714), _E001);

		public static string CheckDiscountTenge => ResourceManager.GetString(global::_E000._E000("\ue170\ue15b\ue156\ue150\ue158\ue177\ue15a\ue140\ue150\ue15c\ue146\ue15d\ue147\ue167\ue156\ue15d\ue154\ue156", 57650), _E001);

		public static string CheckMarkup => ResourceManager.GetString(global::_E000._E000("\ue69d\ue6b6\ue6bb\ue6bd\ue6b5\ue693\ue6bf\ue6ac\ue6b5\ue6ab\ue6ae", 59102), _E001);

		public static string CheckMarkupPercent => ResourceManager.GetString(global::_E000._E000("\ueabc\uea97\uea9a\uea9c\uea94\ueab2\uea9e\uea8d\uea94\uea8a\uea8f\ueaaf\uea9a\uea8d\uea9c\uea9a\uea91\uea8b", 60007), _E001);

		public static string CheckNameTRU => ResourceManager.GetString(global::_E000._E000("\uf6b8\uf693\uf69e\uf698\uf690\uf6b5\uf69a\uf696\uf69e\uf6af\uf6a9\uf6ae", 63185), _E001);

		public static string CheckNumber => ResourceManager.GetString(global::_E000._E000("\ue57e\ue555\ue558\ue55e\ue556\ue573\ue548\ue550\ue55f\ue558\ue54f", 58684), _E001);

		public static string CheckOperationType => ResourceManager.GetString(global::_E000._E000("\uf7a4\uf78f\uf782\uf784\uf78c\uf7a8\uf797\uf782\uf795\uf786\uf793\uf78e\uf788\uf789\uf7b3\uf79e\uf797\uf782", 63396), _E001);

		public static string CheckOrderNumber => ResourceManager.GetString(global::_E000._E000("\uf4b8\uf493\uf49e\uf498\uf490\uf4b4\uf489\uf49f\uf49e\uf489\uf4b5\uf48e\uf496\uf499\uf49e\uf489", 62675), _E001);

		public static string CheckPaymentType => ResourceManager.GetString(global::_E000._E000("\uf730\uf71b\uf716\uf710\uf718\uf723\uf712\uf70a\uf71e\uf716\uf71d\uf707\uf727\uf70a\uf703\uf716", 63298), _E001);

		public static string CheckPositionCost => ResourceManager.GetString(global::_E000._E000("\ue02c\ue007\ue00a\ue00c\ue004\ue03f\ue000\ue01c\ue006\ue01b\ue006\ue000\ue001\ue02c\ue000\ue01c\ue01b", 57450), _E001);

		public static string CheckPositionName => ResourceManager.GetString(global::_E000._E000("\uf2b4\uf29f\uf292\uf294\uf29c\uf2a7\uf298\uf284\uf29e\uf283\uf29e\uf298\uf299\uf2b9\uf296\uf29a\uf292", 62004), _E001);

		public static string CheckPositionPrice => ResourceManager.GetString(global::_E000._E000("\uf59e\uf5b5\uf5b8\uf5be\uf5b6\uf58d\uf5b2\uf5ae\uf5b4\uf5a9\uf5b4\uf5b2\uf5b3\uf58d\uf5af\uf5b4\uf5be\uf5b8", 62872), _E001);

		public static string CheckPositions => ResourceManager.GetString(global::_E000._E000("\uf5e8\uf5c3\uf5ce\uf5c8\uf5c0\uf5fb\uf5c4\uf5d8\uf5c2\uf5df\uf5c2\uf5c4\uf5c5\uf5d8", 62721), _E001);

		public static string CheckReturn => ResourceManager.GetString(global::_E000._E000("\ue5fd\ue5d6\ue5db\ue5dd\ue5d5\ue5ec\ue5db\ue5ca\ue5cb\ue5cc\ue5d0", 58798), _E001);

		public static string CheckTaken => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf597\uf59a\uf59c\uf594\uf5ab\uf59e\uf594\uf59a\uf591", 62815), _E001);

		public static string CheckTax => ResourceManager.GetString(global::_E000._E000("\uebb8\ueb93\ueb9e\ueb98\ueb90\uebaf\ueb9a\ueb83", 60243), _E001);

		public static string CheckTotalSum => ResourceManager.GetString(global::_E000._E000("\ue2ba\ue291\ue29c\ue29a\ue292\ue2ad\ue296\ue28d\ue298\ue295\ue2aa\ue28c\ue294", 58105), _E001);

		public static string CheckVATPayer => ResourceManager.GetString(global::_E000._E000("\ue0b0\ue09b\ue096\ue090\ue098\ue0a5\ue0b2\ue0a7\ue0a3\ue092\ue08a\ue096\ue081", 57554), _E001);

		public static string CheckVATPercent => ResourceManager.GetString(global::_E000._E000("\ueaa4\uea8f\uea82\uea84\uea8c\ueab1\ueaa6\ueab3\ueab7\uea82\uea95\uea84\uea82\uea89\uea93", 59940), _E001);

		public static string City => ResourceManager.GetString(global::_E000._E000("\ue43e\ue414\ue409\ue404", 58389), _E001);

		public static string Client => ResourceManager.GetString(global::_E000._E000("\uf7bd\uf792\uf797\uf79b\uf790\uf78a", 63486), _E001);

		public static string Closed => ResourceManager.GetString(global::_E000._E000("\uf49c\uf4b3\uf4b0\uf4ac\uf4ba\uf4bb", 62535), _E001);

		public static string CloseShiftPeriodBeginDate => ResourceManager.GetString(global::_E000._E000("\uf6ac\uf683\uf680\uf69c\uf68a\uf6bc\uf687\uf686\uf689\uf69b\uf6bf\uf68a\uf69d\uf686\uf680\uf68b\uf6ad\uf68a\uf688\uf686\uf681\uf6ab\uf68e\uf69b\uf68a", 63149), _E001);

		public static string CloseShiftPeriodEndDate => ResourceManager.GetString(global::_E000._E000("\uf83e\uf811\uf812\uf80e\uf818\uf82e\uf815\uf814\uf81b\uf809\uf82d\uf818\uf80f\uf814\uf812\uf819\uf838\uf813\uf819\uf839\uf81c\uf809\uf818", 63605), _E001);

		public static string Code => ResourceManager.GetString(global::_E000._E000("\uef84\uefa8\uefa3\uefa2", 61188), _E001);

		public static string CodePageNumber => ResourceManager.GetString(global::_E000._E000("\ue8bc\ue890\ue89b\ue89a\ue8af\ue89e\ue898\ue89a\ue8b1\ue88a\ue892\ue89d\ue89a\ue88d", 59574), _E001);

		public static string CodePageNumberDescription => ResourceManager.GetString(global::_E000._E000("\ueeb4\uee98\uee93\uee92\ueea7\uee96\uee90\uee92\ueeb9\uee82\uee9a\uee95\uee92\uee85\ueeb3\uee92\uee84\uee94\uee85\uee9e\uee87\uee83\uee9e\uee98\uee99", 61172), _E001);

		public static string CommandOpenShift => ResourceManager.GetString(global::_E000._E000("\ue33c\ue310\ue312\ue312\ue31e\ue311\ue31b\ue330\ue30f\ue31a\ue311\ue32c\ue317\ue316\ue319\ue30b", 58166), _E001);

		public static string CommandTypeAuth => ResourceManager.GetString(global::_E000._E000("\ue99c\ue9b0\ue9b2\ue9b2\ue9be\ue9b1\ue9bb\ue98b\ue9a6\ue9af\ue9ba\ue99e\ue9aa\ue9ab\ue9b7", 59863), _E001);

		public static string CommandTypeCancelTicket => ResourceManager.GetString(global::_E000._E000("\ue79d\ue7b1\ue7b3\ue7b3\ue7bf\ue7b0\ue7ba\ue78a\ue7a7\ue7ae\ue7bb\ue79d\ue7bf\ue7b0\ue7bd\ue7bb\ue7b2\ue78a\ue7b7\ue7bd\ue7b5\ue7bb\ue7aa", 59358), _E001);

		public static string CommandTypeCloseShift => ResourceManager.GetString(global::_E000._E000("\ueb6e\ueb42\ueb40\ueb40\ueb4c\ueb43\ueb49\ueb79\ueb54\ueb5d\ueb48\ueb6e\ueb41\ueb42\ueb5e\ueb48\ueb7e\ueb45\ueb44\ueb4b\ueb59", 60204), _E001);

		public static string CommandTypeInfo => ResourceManager.GetString(global::_E000._E000("\uf19c\uf1b0\uf1b2\uf1b2\uf1be\uf1b1\uf1bb\uf18b\uf1a6\uf1af\uf1ba\uf196\uf1b1\uf1b9\uf1b0", 61911), _E001);

		public static string CommandTypeMoneyPlacement => ResourceManager.GetString(global::_E000._E000("\ue0f8\ue0d4\ue0d6\ue0d6\ue0da\ue0d5\ue0df\ue0ef\ue0c2\ue0cb\ue0de\ue0f6\ue0d4\ue0d5\ue0de\ue0c2\ue0eb\ue0d7\ue0da\ue0d8\ue0de\ue0d6\ue0de\ue0d5\ue0cf", 57523), _E001);

		public static string CommandTypeNomenclature => ResourceManager.GetString(global::_E000._E000("\uf43e\uf412\uf410\uf410\uf41c\uf413\uf419\uf429\uf404\uf40d\uf418\uf433\uf412\uf410\uf418\uf413\uf41e\uf411\uf41c\uf409\uf408\uf40f\uf418", 62504), _E001);

		public static string CommandTypeReport => ResourceManager.GetString(global::_E000._E000("\ue7fc\ue7d0\ue7d2\ue7d2\ue7de\ue7d1\ue7db\ue7eb\ue7c6\ue7cf\ue7da\ue7ed\ue7da\ue7cf\ue7d0\ue7cd\ue7cb", 59303), _E001);

		public static string CommandTypeReserved => ResourceManager.GetString(global::_E000._E000("\uf7be\uf792\uf790\uf790\uf79c\uf793\uf799\uf7a9\uf784\uf78d\uf798\uf7af\uf798\uf78e\uf798\uf78f\uf78b\uf798\uf799", 63413), _E001);

		public static string CommandTypeSystem => ResourceManager.GetString(global::_E000._E000("\ue0ac\ue080\ue082\ue082\ue08e\ue081\ue08b\ue0bb\ue096\ue09f\ue08a\ue0bc\ue096\ue09c\ue09b\ue08a\ue082", 57421), _E001);

		public static string CommandTypeTicket => ResourceManager.GetString(global::_E000._E000("\uee1e\uee32\uee30\uee30\uee3c\uee33\uee39\uee09\uee24\uee2d\uee38\uee09\uee34\uee3e\uee36\uee38\uee29", 60936), _E001);

		public static string Commodity => ResourceManager.GetString(global::_E000._E000("\ue5a1\ue58d\ue58f\ue58f\ue58d\ue586\ue58b\ue596\ue59b", 58848), _E001);

		public static string CommodityStorno => ResourceManager.GetString(global::_E000._E000("\uf6ba\uf696\uf694\uf694\uf696\uf69d\uf690\uf68d\uf680\uf6aa\uf68d\uf696\uf68b\uf697\uf696", 63225), _E001);

		public static string Completed => ResourceManager.GetString(global::_E000._E000("\uefdc\ueff0\ueff2\uefef\ueff3\ueffa\uefeb\ueffa\ueffb", 61335), _E001);

		public static string ConfirmPassword => ResourceManager.GetString(global::_E000._E000("\ue6f8\ue6d4\ue6d5\ue6dd\ue6d2\ue6c9\ue6d6\ue6eb\ue6da\ue6c8\ue6c8\ue6cc\ue6d4\ue6c9\ue6df", 59025), _E001);

		public static string ConfirmPhoneCode => ResourceManager.GetString(global::_E000._E000("\ue49a\ue4b6\ue4b7\ue4bf\ue4b0\ue4ab\ue4b4\ue489\ue4b1\ue4b6\ue4b7\ue4bc\ue49a\ue4b6\ue4bd\ue4bc", 58457), _E001);

		public static string ConfirmPIN => ResourceManager.GetString(global::_E000._E000("\uecae\uec82\uec83\uec8b\uec84\uec9f\uec80\uecbd\ueca4\ueca3", 60645), _E001);

		public static string Connection => ResourceManager.GetString(global::_E000._E000("\ue631\ue61d\ue61c\ue61c\ue617\ue611\ue606\ue61b\ue61d\ue61c", 58960), _E001);

		public static string ConnectionDescription => ResourceManager.GetString(global::_E000._E000("\uf71d\uf731\uf730\uf730\uf73b\uf73d\uf72a\uf737\uf731\uf730\uf71a\uf73b\uf72d\uf73d\uf72c\uf737\uf72e\uf72a\uf737\uf731\uf730", 63310), _E001);

		public static string ConnectionTimeout => ResourceManager.GetString(global::_E000._E000("\ue870\ue85c\ue85d\ue85d\ue856\ue850\ue847\ue85a\ue85c\ue85d\ue867\ue85a\ue85e\ue856\ue85c\ue846\ue847", 59442), _E001);

		public static string ConnectionTimeoutDescription => ResourceManager.GetString(global::_E000._E000("\ue0f8\ue0d4\ue0d5\ue0d5\ue0de\ue0d8\ue0cf\ue0d2\ue0d4\ue0d5\ue0ef\ue0d2\ue0d6\ue0de\ue0d4\ue0ce\ue0cf\ue0ff\ue0de\ue0c8\ue0d8\ue0c9\ue0d2\ue0cb\ue0cf\ue0d2\ue0d4\ue0d5", 57491), _E001);

		public static string ContractBook => ResourceManager.GetString(global::_E000._E000("\ueaea\ueac6\ueac7\ueadd\ueadb\ueac8\ueaca\ueadd\ueaeb\ueac6\ueac6\ueac2", 60073), _E001);

		public static string ContractDate => ResourceManager.GetString(global::_E000._E000("\ue7dc\ue7f0\ue7f1\ue7eb\ue7ed\ue7fe\ue7fc\ue7eb\ue7db\ue7fe\ue7eb\ue7fa", 59287), _E001);

		public static string ContractNumber => ResourceManager.GetString(global::_E000._E000("\ueae8\ueac4\ueac5\ueadf\uead9\ueaca\ueac8\ueadf\ueae5\ueade\ueac6\ueac9\ueace\uead9", 59939), _E001);

		public static string CountInLine => ResourceManager.GetString(global::_E000._E000("\uf3be\uf392\uf388\uf393\uf389\uf3b4\uf393\uf3b1\uf394\uf393\uf398", 62460), _E001);

		public static string CountInLineDescription => ResourceManager.GetString(global::_E000._E000("\ue39d\ue3b1\ue3ab\ue3b0\ue3aa\ue397\ue3b0\ue392\ue3b7\ue3b0\ue3bb\ue39a\ue3bb\ue3ad\ue3bd\ue3ac\ue3b7\ue3ae\ue3aa\ue3b7\ue3b1\ue3b0", 58334), _E001);

		public static string CourierMode => ResourceManager.GetString(global::_E000._E000("\ue3dd\ue3f1\ue3eb\ue3ec\ue3f7\ue3fb\ue3ec\ue3d3\ue3f1\ue3fa\ue3fb", 58270), _E001);

		public static string Created => ResourceManager.GetString(global::_E000._E000("\uf29c\uf2ad\uf2ba\uf2be\uf2ab\uf2ba\uf2bb", 62167), _E001);

		public static string Credit => ResourceManager.GetString(global::_E000._E000("\uf0ba\uf08b\uf09c\uf09d\uf090\uf08d", 61689), _E001);

		public static string CurrentBalance => ResourceManager.GetString(global::_E000._E000("\ue43e\ue408\ue40f\ue40f\ue418\ue413\ue409\ue43f\ue41c\ue411\ue41c\ue413\ue41e\ue418", 58492), _E001);

		public static string CurrentUserPassword => ResourceManager.GetString(global::_E000._E000("\uf3b8\uf38e\uf389\uf389\uf39e\uf395\uf38f\uf3ae\uf388\uf39e\uf389\uf3ab\uf39a\uf388\uf388\uf38c\uf394\uf389\uf39f", 62323), _E001);

		public static string DaysLeft => ResourceManager.GetString(global::_E000._E000("\ued26\ued03\ued1b\ued11\ued2e\ued07\ued04\ued16", 60768), _E001);

		public static string DefaultPurchasePositionName => ResourceManager.GetString(global::_E000._E000("\uebb9\ueb98\ueb9b\ueb9c\ueb88\ueb91\ueb89\uebad\ueb88\ueb8f\ueb9e\ueb95\ueb9c\ueb8e\ueb98\uebad\ueb92\ueb8e\ueb94\ueb89\ueb94\ueb92\ueb93\uebb3\ueb9c\ueb90\ueb98", 60373), _E001);

		public static string DefaultSection => ResourceManager.GetString(global::_E000._E000("\uee93\ueeb2\ueeb1\ueeb6\ueea2\ueebb\ueea3\uee84\ueeb2\ueeb4\ueea3\ueebe\ueeb8\ueeb9", 61076), _E001);

		public static string DefaultSellPositionName => ResourceManager.GetString(global::_E000._E000("\uf1ab\uf18a\uf189\uf18e\uf19a\uf183\uf19b\uf1bc\uf18a\uf183\uf183\uf1bf\uf180\uf19c\uf186\uf19b\uf186\uf180\uf181\uf1a1\uf18e\uf182\uf18a", 61862), _E001);

		public static string DescriptionBook => ResourceManager.GetString(global::_E000._E000("\ue3bb\ue39a\ue38c\ue39c\ue38d\ue396\ue38f\ue38b\ue396\ue390\ue391\ue3bd\ue390\ue390\ue394", 58330), _E001);

		public static string DictionaryActual => ResourceManager.GetString(global::_E000._E000("\uf0ff\uf0d2\uf0d8\uf0cf\uf0d2\uf0d4\uf0d5\uf0da\uf0c9\uf0c2\uf0fa\uf0d8\uf0cf\uf0ce\uf0da\uf0d7", 61489), _E001);

		public static string DictionaryNameKz => ResourceManager.GetString(global::_E000._E000("\ue63b\ue616\ue61c\ue60b\ue616\ue610\ue611\ue61e\ue60d\ue606\ue631\ue61e\ue612\ue61a\ue634\ue605", 58934), _E001);

		public static string DictionaryNameRu => ResourceManager.GetString(global::_E000._E000("\ue71a\ue737\ue73d\ue72a\ue737\ue731\ue730\ue73f\ue72c\ue727\ue710\ue73f\ue733\ue73b\ue70c\ue72b", 59214), _E001);

		public static string DisableLoop => ResourceManager.GetString(global::_E000._E000("\uebbb\ueb96\ueb8c\ueb9e\ueb9d\ueb93\ueb9a\uebb3\ueb90\ueb90\ueb8f", 60255), _E001);

		public static string DiscountStorno => ResourceManager.GetString(global::_E000._E000("\ue3ba\ue397\ue38d\ue39d\ue391\ue38b\ue390\ue38a\ue3ad\ue38a\ue391\ue38c\ue390\ue391", 58350), _E001);

		public static string Distributor => ResourceManager.GetString(global::_E000._E000("\uf83b\uf816\uf80c\uf80b\uf80d\uf816\uf81d\uf80a\uf80b\uf810\uf80d", 63546), _E001);

		public static string DocumentCount => ResourceManager.GetString(global::_E000._E000("\uf099\uf0b2\uf0be\uf0a8\uf0b0\uf0b8\uf0b3\uf0a9\uf09e\uf0b2\uf0a8\uf0b3\uf0a9", 61656), _E001);

		public static string DomainTypeGasoil => ResourceManager.GetString(global::_E000._E000("\uebdb\uebf0\uebf2\uebfe\uebf6\uebf1\uebcb\uebe6\uebef\uebfa\uebd8\uebfe\uebec\uebf0\uebf6\uebf3", 60295), _E001);

		public static string DomainTypeHotels => ResourceManager.GetString(global::_E000._E000("\uf09b\uf0b0\uf0b2\uf0be\uf0b6\uf0b1\uf08b\uf0a6\uf0af\uf0ba\uf097\uf0b0\uf0ab\uf0ba\uf0b3\uf0ac", 61655), _E001);

		public static string DomainTypeParking => ResourceManager.GetString(global::_E000._E000("\ue1ab\ue180\ue182\ue18e\ue186\ue181\ue1bb\ue196\ue19f\ue18a\ue1bf\ue18e\ue19d\ue184\ue186\ue181\ue188", 57677), _E001);

		public static string DomainTypeServices => ResourceManager.GetString(global::_E000._E000("\uf429\uf402\uf400\uf40c\uf404\uf403\uf439\uf414\uf41d\uf408\uf43e\uf408\uf41f\uf41b\uf404\uf40e\uf408\uf41e", 62565), _E001);

		public static string DomainTypeTaxi => ResourceManager.GetString(global::_E000._E000("\ue6bb\ue690\ue692\ue69e\ue696\ue691\ue6ab\ue686\ue68f\ue69a\ue6ab\ue69e\ue687\ue696", 59135), _E001);

		public static string DomainTypeTrading => ResourceManager.GetString(global::_E000._E000("\ue0eb\ue0c0\ue0c2\ue0ce\ue0c6\ue0c1\ue0fb\ue0d6\ue0df\ue0ca\ue0fb\ue0dd\ue0ce\ue0cb\ue0c6\ue0c1\ue0c8", 57391), _E001);

		public static string Email => ResourceManager.GetString(global::_E000._E000("\uf5be\uf596\uf59a\uf592\uf597", 62961), _E001);

		public static string EmailLower => ResourceManager.GetString(global::_E000._E000("\ue0b6\ue09e\ue092\ue09a\ue09f\ue0bf\ue09c\ue084\ue096\ue081", 57554), _E001);

		public static string EmailSendMode => ResourceManager.GetString(global::_E000._E000("\uf3db\uf3f3\uf3ff\uf3f7\uf3f2\uf3cd\uf3fb\uf3f0\uf3fa\uf3d3\uf3f1\uf3fa\uf3fb", 62366), _E001);

		public static string EmailZReport => ResourceManager.GetString(global::_E000._E000("\uf592\uf5ba\uf5b6\uf5be\uf5bb\uf58d\uf585\uf5b2\uf5a7\uf5b8\uf5a5\uf5a3", 62868), _E001);

		public static string EmployeeCode => ResourceManager.GetString(global::_E000._E000("\uf4a2\uf48a\uf497\uf48b\uf488\uf49e\uf482\uf482\uf4a4\uf488\uf483\uf482", 62692), _E001);

		public static string EmployeeId => ResourceManager.GetString(global::_E000._E000("\ue93a\ue912\ue90f\ue913\ue910\ue906\ue91a\ue91a\ue936\ue91b", 59674), _E001);

		public static string EmployeeIsDirector => ResourceManager.GetString(global::_E000._E000("\uf2ba\uf292\uf28f\uf293\uf290\uf286\uf29a\uf29a\uf2b6\uf28c\uf2bb\uf296\uf28d\uf29a\uf29c\uf28b\uf290\uf28d", 61981), _E001);

		public static string EmployeePosition => ResourceManager.GetString(global::_E000._E000("\ue9fb\ue9d3\ue9ce\ue9d2\ue9d1\ue9c7\ue9db\ue9db\ue9ee\ue9d1\ue9cd\ue9d7\ue9ca\ue9d7\ue9d1\ue9d0", 59822), _E001);

		public static string EmployeeShortName => ResourceManager.GetString(global::_E000._E000("\uf538\uf510\uf50d\uf511\uf512\uf504\uf518\uf518\uf52e\uf515\uf512\uf50f\uf509\uf533\uf51c\uf510\uf518", 62837), _E001);

		public static string EnableRetracting => ResourceManager.GetString(global::_E000._E000("\ue4ae\ue485\ue48a\ue489\ue487\ue48e\ue4b9\ue48e\ue49f\ue499\ue48a\ue488\ue49f\ue482\ue485\ue48c", 58433), _E001);

		public static string EnterCustomerXin => ResourceManager.GetString(global::_E000._E000("\uecb8\uec93\uec89\uec98\uec8f\uecbe\uec88\uec8e\uec89\uec92\uec90\uec98\uec8f\ueca5\uec94\uec93", 60565), _E001);

		public static string ExchangePositionName => ResourceManager.GetString(global::_E000._E000("\uf6b6\uf68b\uf690\uf69b\uf692\uf69d\uf694\uf696\uf6a3\uf69c\uf680\uf69a\uf687\uf69a\uf69c\uf69d\uf6bd\uf692\uf69e\uf696", 63170), _E001);

		public static string ExchangePositionPrice => ResourceManager.GetString(global::_E000._E000("\ue7b6\ue78b\ue790\ue79b\ue792\ue79d\ue794\ue796\ue7a3\ue79c\ue780\ue79a\ue787\ue79a\ue79c\ue79d\ue7a3\ue781\ue79a\ue790\ue796", 59346), _E001);

		public static string ExitFromOfflineMode => ResourceManager.GetString(global::_E000._E000("\ue8be\ue883\ue892\ue88f\ue8bd\ue889\ue894\ue896\ue8b4\ue89d\ue89d\ue897\ue892\ue895\ue89e\ue8b6\ue894\ue89f\ue89e", 59473), _E001);

		public static string ExternalOrganization => ResourceManager.GetString(global::_E000._E000("\uf57a\uf547\uf54b\uf55a\uf54d\uf551\uf55e\uf553\uf570\uf54d\uf558\uf55e\uf551\uf556\uf545\uf55e\uf54b\uf556\uf550\uf551", 62763), _E001);

		public static string FDO => ResourceManager.GetString(global::_E000._E000("\uf1b5\uf1b7\uf1bc", 61938), _E001);

		public static string FileName => ResourceManager.GetString(global::_E000._E000("\uf39f\uf3b0\uf3b5\uf3bc\uf397\uf3b8\uf3b4\uf3bc", 62425), _E001);

		public static string FileNameDescription => ResourceManager.GetString(global::_E000._E000("\uf1bd\uf192\uf197\uf19e\uf1b5\uf19a\uf196\uf19e\uf1bf\uf19e\uf188\uf198\uf189\uf192\uf18b\uf18f\uf192\uf194\uf195", 61905), _E001);

		public static string FillingDate => ResourceManager.GetString(global::_E000._E000("\uf3b9\uf396\uf393\uf393\uf396\uf391\uf398\uf3bb\uf39e\uf38b\uf39a", 62463), _E001);

		public static string FiscalOperationDate => ResourceManager.GetString(global::_E000._E000("\ueeed\ueec2\ueed8\ueec8\ueeca\ueec7\ueee4\ueedb\ueece\ueed9\ueeca\ueedf\ueec2\ueec4\ueec5\ueeef\ueeca\ueedf\ueece", 61089), _E001);

		public static string FiscalOperationRequest => ResourceManager.GetString(global::_E000._E000("\uf6ab\uf684\uf69e\uf68e\uf68c\uf681\uf6a2\uf69d\uf688\uf69f\uf68c\uf699\uf684\uf682\uf683\uf6bf\uf688\uf69c\uf698\uf688\uf69e\uf699", 63141), _E001);

		public static string FiscalReport => ResourceManager.GetString(global::_E000._E000("\ued79\ued56\ued4c\ued5c\ued5e\ued53\ued6d\ued5a\ued4f\ued50\ued4d\ued4b", 60731), _E001);

		public static string Font => ResourceManager.GetString(global::_E000._E000("\uf1b1\uf198\uf199\uf183", 61940), _E001);

		public static string FontDescription => ResourceManager.GetString(global::_E000._E000("\uf2b9\uf290\uf291\uf28b\uf2bb\uf29a\uf28c\uf29c\uf28d\uf296\uf28f\uf28b\uf296\uf290\uf291", 62138), _E001);

		public static string FontSize => ResourceManager.GetString(global::_E000._E000("\ue9a9\ue980\ue981\ue99b\ue9bc\ue986\ue995\ue98a", 59661), _E001);

		public static string FontSizeDescription => ResourceManager.GetString(global::_E000._E000("\ue62b\ue602\ue603\ue619\ue63e\ue604\ue617\ue608\ue629\ue608\ue61e\ue60e\ue61f\ue604\ue61d\ue619\ue604\ue602\ue603", 58956), _E001);

		public static string Free => ResourceManager.GetString(global::_E000._E000("\ueaf9\ueacd\ueada\ueada", 60063), _E001);

		public static string FreeService => ResourceManager.GetString(global::_E000._E000("\uf6f9\uf6cd\uf6da\uf6da\uf6ec\uf6da\uf6cd\uf6c9\uf6d6\uf6dc\uf6da", 63147), _E001);

		public static string FullValidate => ResourceManager.GetString(global::_E000._E000("\uf4d8\uf4eb\uf4f2\uf4f2\uf4c8\uf4ff\uf4f2\uf4f7\uf4fa\uf4ff\uf4ea\uf4fb", 62622), _E001);

		public static string HasExchangeOfficeMode => ResourceManager.GetString(global::_E000._E000("\ue496\ue4bf\ue4ad\ue49b\ue4a6\ue4bd\ue4b6\ue4bf\ue4b0\ue4b9\ue4bb\ue491\ue4b8\ue4b8\ue4b7\ue4bd\ue4bb\ue493\ue4b1\ue4ba\ue4bb", 58590), _E001);

		public static string Height => ResourceManager.GetString(global::_E000._E000("\uf6e3\uf6ce\uf6c2\uf6cc\uf6c3\uf6df", 63105), _E001);

		public static string HeightDescription => ResourceManager.GetString(global::_E000._E000("\uf2f7\uf2da\uf2d6\uf2d8\uf2d7\uf2cb\uf2fb\uf2da\uf2cc\uf2dc\uf2cd\uf2d6\uf2cf\uf2cb\uf2d6\uf2d0\uf2d1", 62091), _E001);

		public static string HoldTicketInMouth => ResourceManager.GetString(global::_E000._E000("\ueaf3\uead4\uead7\ueadf\ueaef\uead2\uead8\uead0\ueade\ueacf\ueaf2\uead5\ueaf6\uead4\ueace\ueacf\uead3", 59955), _E001);

		public static string HomeNumber => ResourceManager.GetString(global::_E000._E000("\ue281\ue2a6\ue2a4\ue2ac\ue287\ue2bc\ue2a4\ue2ab\ue2ac\ue2bb", 58057), _E001);

		public static string HomeRoom => ResourceManager.GetString(global::_E000._E000("\uf5f7\uf5d0\uf5d2\uf5da\uf5ed\uf5d0\uf5d0\uf5d2", 62775), _E001);

		public static string IndividualEntrepreneur => ResourceManager.GetString(global::_E000._E000("\uf276\uf251\uf25b\uf256\uf249\uf256\uf25b\uf24a\uf25e\uf253\uf27a\uf251\uf24b\uf24d\uf25a\uf24f\uf24d\uf25a\uf251\uf25a\uf24a\uf24d", 62011), _E001);

		public static string IndividualEntrepreneurShort => ResourceManager.GetString(global::_E000._E000("\ue5a6\ue581\ue58b\ue586\ue599\ue586\ue58b\ue59a\ue58e\ue583\ue5aa\ue581\ue59b\ue59d\ue58a\ue59f\ue59d\ue58a\ue581\ue58a\ue59a\ue59d\ue5bc\ue587\ue580\ue59d\ue59b", 58735), _E001);

		public static string Invoice => ResourceManager.GetString(global::_E000._E000("\ue936\ue911\ue909\ue910\ue916\ue91c\ue91a", 59723), _E001);

		public static string IsExcise => ResourceManager.GetString(global::_E000._E000("\uf377\uf34d\uf37b\uf346\uf35d\uf357\uf34d\uf35b", 62254), _E001);

		public static string Issued => ResourceManager.GetString(global::_E000._E000("\ue52b\ue511\ue511\ue517\ue507\ue506", 58688), _E001);

		public static string Kkm => ResourceManager.GetString(global::_E000._E000("\ueab4\uea94\uea92", 60157), _E001);

		public static string KkmPageCount => ResourceManager.GetString(global::_E000._E000("\ue7ac\ue78c\ue78a\ue7b7\ue786\ue780\ue782\ue7a4\ue788\ue792\ue789\ue793", 59300), _E001);

		public static string KnifeDistance => ResourceManager.GetString(global::_E000._E000("\ued15\ued30\ued37\ued38\ued3b\ued1a\ued37\ued2d\ued2a\ued3f\ued30\ued3d\ued3b", 60750), _E001);

		public static string KnifeDistanceDescription => ResourceManager.GetString(global::_E000._E000("\uf1d4\uf1f1\uf1f6\uf1f9\uf1fa\uf1db\uf1f6\uf1ec\uf1eb\uf1fe\uf1f1\uf1fc\uf1fa\uf1db\uf1fa\uf1ec\uf1fc\uf1ed\uf1f6\uf1ef\uf1eb\uf1f6\uf1f0\uf1f1", 61847), _E001);

		public static string LastReportOn => ResourceManager.GetString(global::_E000._E000("\uf1b2\uf19f\uf18d\uf18a\uf1ac\uf19b\uf18e\uf191\uf18c\uf18a\uf1b1\uf190", 61934), _E001);

		public static string LogoImage => ResourceManager.GetString(global::_E000._E000("\ue6a1\ue682\ue68a\ue682\ue6a4\ue680\ue68c\ue68a\ue688", 59109), _E001);

		public static string ManageExternalOrganizationsDataTransfer => ResourceManager.GetString(global::_E000._E000("\ue2b0\ue29c\ue293\ue29c\ue29a\ue298\ue2b8\ue285\ue289\ue298\ue28f\ue293\ue29c\ue291\ue2b2\ue28f\ue29a\ue29c\ue293\ue294\ue287\ue29c\ue289\ue294\ue292\ue293\ue28e\ue2b9\ue29c\ue289\ue29c\ue2a9\ue28f\ue29c\ue293\ue28e\ue29b\ue298\ue28f", 58108), _E001);

		public static string MarkingMode => ResourceManager.GetString(global::_E000._E000("\uf2ff\uf2d3\uf2c0\uf2d9\uf2db\uf2dc\uf2d5\uf2ff\uf2dd\uf2d6\uf2d7", 62096), _E001);

		public static string MarkupForCheck => ResourceManager.GetString(global::_E000._E000("\ue8a6\ue88a\ue899\ue880\ue89e\ue89b\ue8ad\ue884\ue899\ue8a8\ue883\ue88e\ue888\ue880", 59491), _E001);

		public static string MarkupName => ResourceManager.GetString(global::_E000._E000("\ue373\ue35f\ue34c\ue355\ue34b\ue34e\ue370\ue35f\ue353\ue35b", 58174), _E001);

		public static string MarkupPercent => ResourceManager.GetString(global::_E000._E000("\uf0b0\uf09c\uf08f\uf096\uf088\uf08d\uf0ad\uf098\uf08f\uf09e\uf098\uf093\uf089", 61660), _E001);

		public static string MarkupStorno => ResourceManager.GetString(global::_E000._E000("\uea2f\uea03\uea10\uea09\uea17\uea12\uea31\uea16\uea0d\uea10\uea0c\uea0d", 60000), _E001);

		public static string MarkupValue => ResourceManager.GetString(global::_E000._E000("\ueb32\ueb1e\ueb0d\ueb14\ueb0a\ueb0f\ueb29\ueb1e\ueb13\ueb0a\ueb1a", 60214), _E001);

		public static string MaxAvailableSum => ResourceManager.GetString(global::_E000._E000("\ue73e\ue712\ue70b\ue732\ue705\ue712\ue71a\ue71f\ue712\ue711\ue71f\ue716\ue720\ue706\ue71e", 59250), _E001);

		public static string MessageResultTypeBlocked => ResourceManager.GetString(global::_E000._E000("\uf132\uf11a\uf10c\uf10c\uf11e\uf118\uf11a\uf12d\uf11a\uf10c\uf10a\uf113\uf10b\uf12b\uf106\uf10f\uf11a\uf13d\uf113\uf110\uf11c\uf114\uf11a\uf11b", 61754), _E001);

		public static string MessageResultTypeCantCancelTicket => ResourceManager.GetString(global::_E000._E000("\ueab2\uea9a\uea8c\uea8c\uea9e\uea98\uea9a\ueaad\uea9a\uea8c\uea8a\uea93\uea8b\ueaab\uea86\uea8f\uea9a\ueabc\uea9e\uea91\uea8b\ueabc\uea9e\uea91\uea9c\uea9a\uea93\ueaab\uea96\uea9c\uea94\uea9a\uea8b", 60159), _E001);

		public static string MessageResultTypeIncorrectRequestData => ResourceManager.GetString(global::_E000._E000("\ue0a2\ue08a\ue09c\ue09c\ue08e\ue088\ue08a\ue0bd\ue08a\ue09c\ue09a\ue083\ue09b\ue0bb\ue096\ue09f\ue08a\ue0a6\ue081\ue08c\ue080\ue09d\ue09d\ue08a\ue08c\ue09b\ue0bd\ue08a\ue09e\ue09a\ue08a\ue09c\ue09b\ue0ab\ue08e\ue09b\ue08e", 57581), _E001);

		public static string MessageResultTypeInvalidConfiguration => ResourceManager.GetString(global::_E000._E000("\ue1b6\ue19e\ue188\ue188\ue19a\ue19c\ue19e\ue1a9\ue19e\ue188\ue18e\ue197\ue18f\ue1af\ue182\ue18b\ue19e\ue1b2\ue195\ue18d\ue19a\ue197\ue192\ue19f\ue1b8\ue194\ue195\ue19d\ue192\ue19c\ue18e\ue189\ue19a\ue18f\ue192\ue194\ue195", 57713), _E001);

		public static string MessageResultTypeInvalidLoginPassword => ResourceManager.GetString(global::_E000._E000("\ueef6\ueede\ueec8\ueec8\ueeda\ueedc\ueede\ueee9\ueede\ueec8\ueece\ueed7\ueecf\ueeef\ueec2\ueecb\ueede\ueef2\ueed5\ueecd\ueeda\ueed7\ueed2\ueedf\ueef7\ueed4\ueedc\ueed2\ueed5\ueeeb\ueeda\ueec8\ueec8\ueecc\ueed4\ueec9\ueedf", 60977), _E001);

		public static string MessageResultTypeInvalidRequestNumber => ResourceManager.GetString(global::_E000._E000("\uf1a2\uf18a\uf19c\uf19c\uf18e\uf188\uf18a\uf1bd\uf18a\uf19c\uf19a\uf183\uf19b\uf1bb\uf196\uf19f\uf18a\uf1a6\uf181\uf199\uf18e\uf183\uf186\uf18b\uf1bd\uf18a\uf19e\uf19a\uf18a\uf19c\uf19b\uf1a1\uf19a\uf182\uf18d\uf18a\uf19d", 61775), _E001);

		public static string MessageResultTypeInvalidRetryRequest => ResourceManager.GetString(global::_E000._E000("\uede2\uedca\ueddc\ueddc\uedce\uedc8\uedca\uedfd\uedca\ueddc\uedda\uedc3\ueddb\uedfb\uedd6\ueddf\uedca\uede6\uedc1\uedd9\uedce\uedc3\uedc6\uedcb\uedfd\uedca\ueddb\ueddd\uedd6\uedfd\uedca\uedde\uedda\uedca\ueddc\ueddb", 60815), _E001);

		public static string MessageResultTypeInvalidToken => ResourceManager.GetString(global::_E000._E000("\uf4f2\uf4da\uf4cc\uf4cc\uf4de\uf4d8\uf4da\uf4ed\uf4da\uf4cc\uf4ca\uf4d3\uf4cb\uf4eb\uf4c6\uf4cf\uf4da\uf4f6\uf4d1\uf4c9\uf4de\uf4d3\uf4d6\uf4db\uf4eb\uf4d0\uf4d4\uf4da\uf4d1", 62631), _E001);

		public static string MessageResultTypeNotEnoughCash => ResourceManager.GetString(global::_E000._E000("\uf0b2\uf09a\uf08c\uf08c\uf09e\uf098\uf09a\uf0ad\uf09a\uf08c\uf08a\uf093\uf08b\uf0ab\uf086\uf08f\uf09a\uf0b1\uf090\uf08b\uf0ba\uf091\uf090\uf08a\uf098\uf097\uf0bc\uf09e\uf08c\uf097", 61533), _E001);

		public static string MessageResultTypeOk => ResourceManager.GetString(global::_E000._E000("\ue8b0\ue898\ue88e\ue88e\ue89c\ue89a\ue898\ue8af\ue898\ue88e\ue888\ue891\ue889\ue8a9\ue884\ue88d\ue898\ue8b2\ue896", 59541), _E001);

		public static string MessageResultTypeOpenShiftTimeoutExpired => ResourceManager.GetString(global::_E000._E000("\ue694\ue6bc\ue6aa\ue6aa\ue6b8\ue6be\ue6bc\ue68b\ue6bc\ue6aa\ue6ac\ue6b5\ue6ad\ue68d\ue6a0\ue6a9\ue6bc\ue696\ue6a9\ue6bc\ue6b7\ue68a\ue6b1\ue6b0\ue6bf\ue6ad\ue68d\ue6b0\ue6b4\ue6bc\ue6b6\ue6ac\ue6ad\ue69c\ue6a1\ue6a9\ue6b0\ue6ab\ue6bc\ue6bd", 58969), _E001);

		public static string MessageResultTypeProtokolError => ResourceManager.GetString(global::_E000._E000("\uec22\uec0a\uec1c\uec1c\uec0e\uec08\uec0a\uec3d\uec0a\uec1c\uec1a\uec03\uec1b\uec3b\uec16\uec1f\uec0a\uec3f\uec1d\uec00\uec1b\uec00\uec04\uec00\uec03\uec2a\uec1d\uec1d\uec00\uec1d", 60490), _E001);

		public static string MessageResultTypeServiceTemporarilyUnavailable => ResourceManager.GetString(global::_E000._E000("\uee7e\uee56\uee40\uee40\uee52\uee54\uee56\uee61\uee56\uee40\uee46\uee5f\uee47\uee67\uee4a\uee43\uee56\uee60\uee56\uee41\uee45\uee5a\uee50\uee56\uee67\uee56\uee5e\uee43\uee5c\uee41\uee52\uee41\uee5a\uee5f\uee4a\uee66\uee5d\uee52\uee45\uee52\uee5a\uee5f\uee52\uee51\uee5f\uee56", 60978), _E001);

		public static string MessageResultTypeSslIsNotAllowed => ResourceManager.GetString(global::_E000._E000("\uf47e\uf456\uf440\uf440\uf452\uf454\uf456\uf461\uf456\uf440\uf446\uf45f\uf447\uf467\uf44a\uf443\uf456\uf460\uf440\uf45f\uf47a\uf440\uf47d\uf45c\uf447\uf472\uf45f\uf45f\uf45c\uf444\uf456\uf457", 62482), _E001);

		public static string MessageResultTypeUnknownCommand => ResourceManager.GetString(global::_E000._E000("\ue9e2\ue9ca\ue9dc\ue9dc\ue9ce\ue9c8\ue9ca\ue9fd\ue9ca\ue9dc\ue9da\ue9c3\ue9db\ue9fb\ue9d6\ue9df\ue9ca\ue9fa\ue9c1\ue9c4\ue9c1\ue9c0\ue9d8\ue9c1\ue9ec\ue9c0\ue9c2\ue9c2\ue9ce\ue9c1\ue9cb", 59695), _E001);

		public static string MessageResultTypeUnknownError => ResourceManager.GetString(global::_E000._E000("\uf3b2\uf39a\uf38c\uf38c\uf39e\uf398\uf39a\uf3ad\uf39a\uf38c\uf38a\uf393\uf38b\uf3ab\uf386\uf38f\uf39a\uf3aa\uf391\uf394\uf391\uf390\uf388\uf391\uf3ba\uf38d\uf38d\uf390\uf38d", 62237), _E001);

		public static string MessageResultTypeUnknownID => ResourceManager.GetString(global::_E000._E000("\uf0a2\uf08a\uf09c\uf09c\uf08e\uf088\uf08a\uf0bd\uf08a\uf09c\uf09a\uf083\uf09b\uf0bb\uf096\uf09f\uf08a\uf0ba\uf081\uf084\uf081\uf080\uf098\uf081\uf0a6\uf0ab", 61581), _E001);

		public static string MessageResultTypeUnsupportedCommand => ResourceManager.GetString(global::_E000._E000("\uef22\uef0a\uef1c\uef1c\uef0e\uef08\uef0a\uef3d\uef0a\uef1c\uef1a\uef03\uef1b\uef3b\uef16\uef1f\uef0a\uef3a\uef01\uef1c\uef1a\uef1f\uef1f\uef00\uef1d\uef1b\uef0a\uef0b\uef2c\uef00\uef02\uef02\uef0e\uef01\uef0b", 61222), _E001);

		public static string Mixed => ResourceManager.GetString(global::_E000._E000("\ue1b0\ue194\ue185\ue198\ue199", 57749), _E001);

		public static string Mobile => ResourceManager.GetString(global::_E000._E000("\uf18a\uf1a8\uf1a5\uf1ae\uf1ab\uf1a2", 61700), _E001);

		public static string Model => ResourceManager.GetString(global::_E000._E000("\uebf2\uebd0\uebdb\uebda\uebd3", 60319), _E001);

		public static string ModelDescription => ResourceManager.GetString(global::_E000._E000("\uea32\uea10\uea1b\uea1a\uea13\uea3b\uea1a\uea0c\uea1c\uea0d\uea16\uea0f\uea0b\uea16\uea10\uea11", 59958), _E001);

		public static string MoneyPlacementDateTime => ResourceManager.GetString(global::_E000._E000("\ue9f2\ue9d0\ue9d1\ue9da\ue9c6\ue9ef\ue9d3\ue9de\ue9dc\ue9da\ue9d2\ue9da\ue9d1\ue9cb\ue9fb\ue9de\ue9cb\ue9da\ue9eb\ue9d6\ue9d2\ue9da", 59807), _E001);

		public static string MoneyPlacementSum => ResourceManager.GetString(global::_E000._E000("\ue29a\ue2b8\ue2b9\ue2b2\ue2ae\ue287\ue2bb\ue2b6\ue2b4\ue2b2\ue2ba\ue2b2\ue2b9\ue2a3\ue284\ue2a2\ue2ba", 58004), _E001);

		public static string MoneyPlacementTypeId => ResourceManager.GetString(global::_E000._E000("\uf6b2\uf690\uf691\uf69a\uf686\uf6af\uf693\uf69e\uf69c\uf69a\uf692\uf69a\uf691\uf68b\uf6ab\uf686\uf68f\uf69a\uf6b6\uf69b", 63071), _E001);

		public static string MoneyPlacementTypePutMoney => ResourceManager.GetString(global::_E000._E000("\uecba\uec98\uec99\uec92\uec8e\ueca7\uec9b\uec96\uec94\uec92\uec9a\uec92\uec99\uec83\ueca3\uec8e\uec87\uec92\ueca7\uec82\uec83\uecba\uec98\uec99\uec92\uec8e", 60532), _E001);

		public static string MoneyPlacementTypeTakeMoney => ResourceManager.GetString(global::_E000._E000("\ue3a2\ue380\ue381\ue38a\ue396\ue3bf\ue383\ue38e\ue38c\ue38a\ue382\ue38a\ue381\ue39b\ue3bb\ue396\ue39f\ue38a\ue3bb\ue38e\ue384\ue38a\ue3a2\ue380\ue381\ue38a\ue396", 58351), _E001);

		public static string Monthly => ResourceManager.GetString(global::_E000._E000("\uf8ba\uf898\uf899\uf883\uf89f\uf89b\uf88e", 63604), _E001);

		public static string NewCashbox => ResourceManager.GetString(global::_E000._E000("\ued31\ued1a\ued08\ued3c\ued1e\ued0c\ued17\ued1d\ued10\ued07", 60747), _E001);

		public static string NewPassword => ResourceManager.GetString(global::_E000._E000("\uf331\uf31a\uf308\uf32f\uf31e\uf30c\uf30c\uf308\uf310\uf30d\uf31b", 62298), _E001);

		public static string NewPIN => ResourceManager.GetString(global::_E000._E000("\ue1e5\ue1ce\ue1dc\ue1fb\ue1e2\ue1e5", 57601), _E001);

		public static string NoName => ResourceManager.GetString(global::_E000._E000("\ue323\ue302\ue323\ue30c\ue300\ue308", 58213), _E001);

		public static string None => ResourceManager.GetString(global::_E000._E000("\uf5c7\uf5e6\uf5e7\uf5ec", 62729), _E001);

		public static string NotMatch => ResourceManager.GetString(global::_E000._E000("\uf4b1\uf490\uf48b\uf4b2\uf49e\uf48b\uf49c\uf497", 62714), _E001);

		public static string OfflineCheckApiSupported => ResourceManager.GetString(global::_E000._E000("\ue57c\ue555\ue555\ue55f\ue55a\ue55d\ue556\ue570\ue55b\ue556\ue550\ue558\ue572\ue543\ue55a\ue560\ue546\ue543\ue543\ue55c\ue541\ue547\ue556\ue557", 58674), _E001);

		public static string OldPIN => ResourceManager.GetString(global::_E000._E000("\ue896\ue8b5\ue8bd\ue889\ue890\ue897", 59481), _E001);

		public static string Operation => ResourceManager.GetString(global::_E000._E000("\uf3f0\uf3cf\uf3da\uf3cd\uf3de\uf3cb\uf3d6\uf3d0\uf3d1", 62375), _E001);

		public static string OperationSystemType => ResourceManager.GetString(global::_E000._E000("\uf7a6\uf799\uf78c\uf79b\uf788\uf79d\uf780\uf786\uf787\uf7ba\uf790\uf79a\uf79d\uf78c\uf784\uf7bd\uf790\uf799\uf78c", 63337), _E001);

		public static string OperationTypeBuy => ResourceManager.GetString(global::_E000._E000("\uefb2\uef8d\uef98\uef8f\uef9c\uef89\uef94\uef92\uef93\uefa9\uef84\uef8d\uef98\uefbf\uef88\uef84", 61416), _E001);

		public static string OperationTypeReturnBuy => ResourceManager.GetString(global::_E000._E000("\ue886\ue8b9\ue8ac\ue8bb\ue8a8\ue8bd\ue8a0\ue8a6\ue8a7\ue89d\ue8b0\ue8b9\ue8ac\ue89b\ue8ac\ue8bd\ue8bc\ue8bb\ue8a7\ue88b\ue8bc\ue8b0", 59465), _E001);

		public static string OperationTypeReturnSell => ResourceManager.GetString(global::_E000._E000("\ue8c6\ue8f9\ue8ec\ue8fb\ue8e8\ue8fd\ue8e0\ue8e6\ue8e7\ue8dd\ue8f0\ue8f9\ue8ec\ue8db\ue8ec\ue8fd\ue8fc\ue8fb\ue8e7\ue8da\ue8ec\ue8e5\ue8e5", 59529), _E001);

		public static string OperationTypeSell => ResourceManager.GetString(global::_E000._E000("\uf7bc\uf783\uf796\uf781\uf792\uf787\uf79a\uf79c\uf79d\uf7a7\uf78a\uf783\uf796\uf7a0\uf796\uf79f\uf79f", 63458), _E001);

		public static string OperationTypeSimpleReturn => ResourceManager.GetString(global::_E000._E000("\uedb0\ued8f\ued9a\ued8d\ued9e\ued8b\ued96\ued90\ued91\uedab\ued86\ued8f\ued9a\uedac\ued96\ued92\ued8f\ued93\ued9a\uedad\ued9a\ued8b\ued8a\ued8d\ued91", 60861), _E001);

		public static string OperatorPassword => ResourceManager.GetString(global::_E000._E000("\ue210\ue22f\ue23a\ue22d\ue23e\ue22b\ue230\ue22d\ue20f\ue23e\ue22c\ue22c\ue228\ue230\ue22d\ue23b", 57942), _E001);

		public static string OrganizationActualAddressKz => ResourceManager.GetString(global::_E000._E000("\ueea6\uee9b\uee8e\uee88\uee87\uee80\uee93\uee88\uee9d\uee80\uee86\uee87\ueea8\uee8a\uee9d\uee9c\uee88\uee85\ueea8\uee8d\uee8d\uee9b\uee8c\uee9a\uee9a\ueea2\uee93", 61161), _E001);

		public static string OrganizationActualAddressRu => ResourceManager.GetString(global::_E000._E000("\ue7d6\ue7eb\ue7fe\ue7f8\ue7f7\ue7f0\ue7e3\ue7f8\ue7ed\ue7f0\ue7f6\ue7f7\ue7d8\ue7fa\ue7ed\ue7ec\ue7f8\ue7f5\ue7d8\ue7fd\ue7fd\ue7eb\ue7fc\ue7ea\ue7ea\ue7cb\ue7ec", 59289), _E001);

		public static string OrganizationBIN => ResourceManager.GetString(global::_E000._E000("\ueea0\uee9d\uee88\uee8e\uee81\uee86\uee95\uee8e\uee9b\uee86\uee80\uee81\ueead\ueea6\ueea1", 61005), _E001);

		public static string OrganizationCertificateDate => ResourceManager.GetString(global::_E000._E000("\uf7a0\uf79d\uf788\uf78e\uf781\uf786\uf795\uf78e\uf79b\uf786\uf780\uf781\uf7ac\uf78a\uf79d\uf79b\uf786\uf789\uf786\uf78c\uf78e\uf79b\uf78a\uf7ab\uf78e\uf79b\uf78a", 63462), _E001);

		public static string OrganizationCertificateNumber => ResourceManager.GetString(global::_E000._E000("\ue7a8\ue795\ue780\ue786\ue789\ue78e\ue79d\ue786\ue793\ue78e\ue788\ue789\ue7a4\ue782\ue795\ue793\ue78e\ue781\ue78e\ue784\ue786\ue793\ue782\ue7a9\ue792\ue78a\ue785\ue782\ue795", 59236), _E001);

		public static string OrganizationEconomicActivity => ResourceManager.GetString(global::_E000._E000("\ueeb2\uee8f\uee9a\uee9c\uee93\uee94\uee87\uee9c\uee89\uee94\uee92\uee93\ueeb8\uee9e\uee92\uee93\uee92\uee90\uee94\uee9e\ueebc\uee9e\uee89\uee94\uee8b\uee94\uee89\uee84", 61173), _E001);

		public static string OrganizationForm => ResourceManager.GetString(global::_E000._E000("\uf462\uf45f\uf44a\uf44c\uf443\uf444\uf457\uf44c\uf459\uf444\uf442\uf443\uf46b\uf442\uf45f\uf440", 62508), _E001);

		public static string OrganizationIndividual => ResourceManager.GetString(global::_E000._E000("\uf0c6\uf0fb\uf0ee\uf0e8\uf0e7\uf0e0\uf0f3\uf0e8\uf0fd\uf0e0\uf0e6\uf0e7\uf0c0\uf0e7\uf0ed\uf0e0\uf0ff\uf0e0\uf0ed\uf0fc\uf0e8\uf0e5", 61449), _E001);

		public static string OrganizationJuridical => ResourceManager.GetString(global::_E000._E000("\ue5b4\ue589\ue59c\ue59a\ue595\ue592\ue581\ue59a\ue58f\ue592\ue594\ue595\ue5b1\ue58e\ue589\ue592\ue59f\ue592\ue598\ue59a\ue597", 58737), _E001);

		public static string OrganizationLegalAddressKz => ResourceManager.GetString(global::_E000._E000("\uf830\uf80d\uf818\uf81e\uf811\uf816\uf805\uf81e\uf80b\uf816\uf810\uf811\uf833\uf81a\uf818\uf81e\uf813\uf83e\uf81b\uf81b\uf80d\uf81a\uf80c\uf80c\uf834\uf805", 63610), _E001);

		public static string OrganizationLegalAddressRu => ResourceManager.GetString(global::_E000._E000("\ue996\ue9ab\ue9be\ue9b8\ue9b7\ue9b0\ue9a3\ue9b8\ue9ad\ue9b0\ue9b6\ue9b7\ue995\ue9bc\ue9be\ue9b8\ue9b5\ue998\ue9bd\ue9bd\ue9ab\ue9bc\ue9aa\ue9aa\ue98b\ue9ac", 59737), _E001);

		public static string OrganizationName => ResourceManager.GetString(global::_E000._E000("\uecf4\uecc9\uecdc\uecda\uecd5\uecd2\uecc1\uecda\ueccf\uecd2\uecd4\uecd5\uecf5\uecda\uecd6\uecde", 60433), _E001);

		public static string OrganizationNameKz => ResourceManager.GetString(global::_E000._E000("\uead1\ueaec\ueaf9\ueaff\ueaf0\ueaf7\ueae4\ueaff\ueaea\ueaf7\ueaf1\ueaf0\uead0\ueaff\ueaf3\ueafb\uead5\ueae4", 60062), _E001);

		public static string OrganizationNameRu => ResourceManager.GetString(global::_E000._E000("\uf5b0\uf58d\uf598\uf59e\uf591\uf596\uf585\uf59e\uf58b\uf596\uf590\uf591\uf5b1\uf59e\uf592\uf59a\uf5ad\uf58a", 62845), _E001);

		public static string OrganizationRegDate => ResourceManager.GetString(global::_E000._E000("\ueaa2\uea9f\uea8a\uea8c\uea83\uea84\uea97\uea8c\uea99\uea84\uea82\uea83\ueabf\uea88\uea8a\ueaa9\uea8c\uea99\uea88", 60101), _E001);

		public static string OrganizationSameAddressKz => ResourceManager.GetString(global::_E000._E000("\uf0e4\uf0d9\uf0cc\uf0ca\uf0c5\uf0c2\uf0d1\uf0ca\uf0df\uf0c2\uf0c4\uf0c5\uf0f8\uf0ca\uf0c6\uf0ce\uf0ea\uf0cf\uf0cf\uf0d9\uf0ce\uf0d8\uf0d8\uf0e0\uf0d1", 61443), _E001);

		public static string OrganizationSameAddressRu => ResourceManager.GetString(global::_E000._E000("\uec3c\uec01\uec14\uec12\uec1d\uec1a\uec09\uec12\uec07\uec1a\uec1c\uec1d\uec20\uec12\uec1e\uec16\uec32\uec17\uec17\uec01\uec16\uec00\uec00\uec21\uec06", 60498), _E001);

		public static string OrganizationTaxationType => ResourceManager.GetString(global::_E000._E000("\ue8a4\ue899\ue88c\ue88a\ue885\ue882\ue891\ue88a\ue89f\ue882\ue884\ue885\ue8bf\ue88a\ue893\ue88a\ue89f\ue882\ue884\ue885\ue8bf\ue892\ue89b\ue88e", 59489), _E001);

		public static string OrganizationTaxPercent => ResourceManager.GetString(global::_E000._E000("\ue798\ue7a5\ue7b0\ue7b6\ue7b9\ue7be\ue7ad\ue7b6\ue7a3\ue7be\ue7b8\ue7b9\ue783\ue7b6\ue7af\ue787\ue7b2\ue7a5\ue7b4\ue7b2\ue7b9\ue7a3", 59156), _E001);

		public static string OrganizationVATNumber => ResourceManager.GetString(global::_E000._E000("\uf8b4\uf889\uf89c\uf89a\uf895\uf892\uf881\uf89a\uf88f\uf892\uf894\uf895\uf8ad\uf8ba\uf8af\uf8b5\uf88e\uf896\uf899\uf89e\uf889", 63601), _E001);

		public static string OrganizationVATPayer => ResourceManager.GetString(global::_E000._E000("\uf8ed\uf8d0\uf8c5\uf8c3\uf8cc\uf8cb\uf8d8\uf8c3\uf8d6\uf8cb\uf8cd\uf8cc\uf8f4\uf8e3\uf8f6\uf8f2\uf8c3\uf8db\uf8c7\uf8d0", 63616), _E001);

		public static string OrganizationVATSeria => ResourceManager.GetString(global::_E000._E000("\uf1f0\uf1cd\uf1d8\uf1de\uf1d1\uf1d6\uf1c5\uf1de\uf1cb\uf1d6\uf1d0\uf1d1\uf1e9\uf1fe\uf1eb\uf1ec\uf1da\uf1cd\uf1d6\uf1de", 61835), _E001);

		public static string Other => ResourceManager.GetString(global::_E000._E000("\uf030\uf00b\uf017\uf01a\uf00d", 61494), _E001);

		public static string OtherServices => ResourceManager.GetString(global::_E000._E000("\uf372\uf349\uf355\uf358\uf34f\uf36e\uf358\uf34f\uf34b\uf354\uf35e\uf358\uf34e", 62236), _E001);

		public static string Overdraft => ResourceManager.GetString(global::_E000._E000("\uedb2\ued8b\ued98\ued8f\ued99\ued8f\ued9c\ued9b\ued89", 60904), _E001);

		public static string PacketActive => ResourceManager.GetString(global::_E000._E000("\uee0d\uee3c\uee3e\uee36\uee38\uee29\uee1c\uee3e\uee29\uee34\uee2b\uee38", 60952), _E001);

		public static string PacketExpired => ResourceManager.GetString(global::_E000._E000("\ue62f\ue61e\ue61c\ue614\ue61a\ue60b\ue63a\ue607\ue60f\ue616\ue60d\ue61a\ue61b", 58934), _E001);

		public static string PacketNumber => ResourceManager.GetString(global::_E000._E000("\uecad\uec9c\uec9e\uec96\uec98\uec89\uecb3\uec88\uec90\uec9f\uec98\uec8f", 60636), _E001);

		public static string PacketType => ResourceManager.GetString(global::_E000._E000("\uf6ef\uf6de\uf6dc\uf6d4\uf6da\uf6cb\uf6eb\uf6c6\uf6cf\uf6da", 63159), _E001);

		public static string PaidService => ResourceManager.GetString(global::_E000._E000("\ue03f\ue00e\ue006\ue00b\ue03c\ue00a\ue01d\ue019\ue006\ue00c\ue00a", 57354), _E001);

		public static string PaperPrintableWidthInMm => ResourceManager.GetString(global::_E000._E000("\uf2eb\uf2da\uf2cb\uf2de\uf2c9\uf2eb\uf2c9\uf2d2\uf2d5\uf2cf\uf2da\uf2d9\uf2d7\uf2de\uf2ec\uf2d2\uf2df\uf2cf\uf2d3\uf2f2\uf2d5\uf2f6\uf2d6", 61971), _E001);

		public static string PaperPrintableWidthInMmDescription => ResourceManager.GetString(global::_E000._E000("\uf5bd\uf58c\uf59d\uf588\uf59f\uf5bd\uf59f\uf584\uf583\uf599\uf58c\uf58f\uf581\uf588\uf5ba\uf584\uf589\uf599\uf585\uf5a4\uf583\uf5a0\uf580\uf5a9\uf588\uf59e\uf58e\uf59f\uf584\uf59d\uf599\uf584\uf582\uf583", 62956), _E001);

		public static string PartialAutoWithDrawalSum => ResourceManager.GetString(global::_E000._E000("\ueeaf\uee9e\uee8d\uee8b\uee96\uee9e\uee93\ueebe\uee8a\uee8b\uee90\ueea8\uee96\uee8b\uee97\ueebb\uee8d\uee9e\uee88\uee9e\uee93\ueeac\uee8a\uee92", 61146), _E001);

		public static string PasportBook => ResourceManager.GetString(global::_E000._E000("\uf28e\uf2bf\uf2ad\uf2ae\uf2b1\uf2ac\uf2aa\uf29c\uf2b1\uf2b1\uf2b5", 62174), _E001);

		public static string PasportNumber => ResourceManager.GetString(global::_E000._E000("\ue7af\ue79e\ue78c\ue78f\ue790\ue78d\ue78b\ue7b1\ue78a\ue792\ue79d\ue79a\ue78d", 59263), _E001);

		public static string Password => ResourceManager.GetString(global::_E000._E000("\uf4bf\uf48e\uf49c\uf49c\uf498\uf480\uf49d\uf48b", 62573), _E001);

		public static string PasswordDescription => ResourceManager.GetString(global::_E000._E000("\ue7fb\ue7ca\ue7d8\ue7d8\ue7dc\ue7c4\ue7d9\ue7cf\ue7ef\ue7ce\ue7d8\ue7c8\ue7d9\ue7c2\ue7db\ue7df\ue7c2\ue7c4\ue7c5", 59171), _E001);

		public static string PermissionBookKeeping => ResourceManager.GetString(global::_E000._E000("\uf7af\uf79a\uf78d\uf792\uf796\uf78c\uf78c\uf796\uf790\uf791\uf7bd\uf790\uf790\uf794\uf7b4\uf79a\uf79a\uf78f\uf796\uf791\uf798", 63421), _E001);

		public static string PermissionCheckHistory => ResourceManager.GetString(global::_E000._E000("\uee3d\uee08\uee1f\uee00\uee04\uee1e\uee1e\uee04\uee02\uee03\uee2e\uee05\uee08\uee0e\uee06\uee25\uee04\uee1e\uee19\uee02\uee1f\uee14", 61029), _E001);

		public static string PermissionsCloseShift => ResourceManager.GetString(global::_E000._E000("\ue64e\ue67b\ue66c\ue673\ue677\ue66d\ue66d\ue677\ue671\ue670\ue66d\ue65d\ue672\ue671\ue66d\ue67b\ue64d\ue676\ue677\ue678\ue66a", 58894), _E001);

		public static string PermissionsContractManagement => ResourceManager.GetString(global::_E000._E000("\uf08f\uf0ba\uf0ad\uf0b2\uf0b6\uf0ac\uf0ac\uf0b6\uf0b0\uf0b1\uf0ac\uf09c\uf0b0\uf0b1\uf0ab\uf0ad\uf0be\uf0bc\uf0ab\uf092\uf0be\uf0b1\uf0be\uf0b8\uf0ba\uf0b2\uf0ba\uf0b1\uf0ab", 61511), _E001);

		public static string PermissionsCreateXReport => ResourceManager.GetString(global::_E000._E000("\uf4af\uf49a\uf48d\uf492\uf496\uf48c\uf48c\uf496\uf490\uf491\uf48c\uf4bc\uf48d\uf49a\uf49e\uf48b\uf49a\uf4a7\uf4ad\uf49a\uf48f\uf490\uf48d\uf48b", 62699), _E001);

		public static string PermissionsDepositCash => ResourceManager.GetString(global::_E000._E000("\uefaf\uef9a\uef8d\uef92\uef96\uef8c\uef8c\uef96\uef90\uef91\uef8c\uefbb\uef9a\uef8f\uef90\uef8c\uef96\uef8b\uefbc\uef9e\uef8c\uef97", 61245), _E001);

		public static string PermissionsEditEmployees => ResourceManager.GetString(global::_E000._E000("\ue2bb\ue28e\ue299\ue286\ue282\ue298\ue298\ue282\ue284\ue285\ue298\ue2ae\ue28f\ue282\ue29f\ue2ae\ue286\ue29b\ue287\ue284\ue292\ue28e\ue28e\ue298", 58081), _E001);

		public static string PermissionsProgramming => ResourceManager.GetString(global::_E000._E000("\uefa7\uef92\uef85\uef9a\uef9e\uef84\uef84\uef9e\uef98\uef99\uef84\uefa7\uef85\uef98\uef90\uef85\uef96\uef9a\uef9a\uef9e\uef99\uef90", 61364), _E001);

		public static string PermissionsPurchases => ResourceManager.GetString(global::_E000._E000("\ue58e\ue5bb\ue5ac\ue5b3\ue5b7\ue5ad\ue5ad\ue5b7\ue5b1\ue5b0\ue5ad\ue58e\ue5ab\ue5ac\ue5bd\ue5b6\ue5bf\ue5ad\ue5bb\ue5ad", 58830), _E001);

		public static string PermissionsSaleReturns => ResourceManager.GetString(global::_E000._E000("\ueead\uee98\uee8f\uee90\uee94\uee8e\uee8e\uee94\uee92\uee93\uee8e\ueeae\uee9c\uee91\uee98\ueeaf\uee98\uee89\uee88\uee8f\uee93\uee8e", 61141), _E001);

		public static string PermissionsSales => ResourceManager.GetString(global::_E000._E000("\uf889\uf8bc\uf8ab\uf8b4\uf8b0\uf8aa\uf8aa\uf8b0\uf8b6\uf8b7\uf8aa\uf88a\uf8b8\uf8b5\uf8bc\uf8aa", 63577), _E001);

		public static string PermissionsVewZXReport => ResourceManager.GetString(global::_E000._E000("\ue96f\ue95a\ue94d\ue952\ue956\ue94c\ue94c\ue956\ue950\ue951\ue94c\ue969\ue95a\ue948\ue965\ue967\ue96d\ue95a\ue94f\ue950\ue94d\ue94b", 59675), _E001);

		public static string PermissionsWithdrawalCash => ResourceManager.GetString(global::_E000._E000("\ue4af\ue49a\ue48d\ue492\ue496\ue48c\ue48c\ue496\ue490\ue491\ue48c\ue4a8\ue496\ue48b\ue497\ue49b\ue48d\ue49e\ue488\ue49e\ue493\ue4bc\ue49e\ue48c\ue497", 58471), _E001);

		public static string PersonBIN => ResourceManager.GetString(global::_E000._E000("\ueaad\uea98\uea8f\uea8e\uea92\uea93\ueabf\ueab4\ueab3", 60072), _E001);

		public static string PersonBirthdate => ResourceManager.GetString(global::_E000._E000("\ue3bf\ue38a\ue39d\ue39c\ue380\ue381\ue3ad\ue386\ue39d\ue39b\ue387\ue38b\ue38e\ue39b\ue38a", 58319), _E001);

		public static string PersonFirstName => ResourceManager.GetString(global::_E000._E000("\uedf2\uedc7\uedd0\uedd1\uedcd\uedcc\uede4\uedcb\uedd0\uedd1\uedd6\uedec\uedc3\uedcf\uedc7", 60800), _E001);

		public static string PersonLastName => ResourceManager.GetString(global::_E000._E000("\uf52f\uf51a\uf50d\uf50c\uf510\uf511\uf533\uf51e\uf50c\uf50b\uf531\uf51e\uf512\uf51a", 62842), _E001);

		public static string PersonMale => ResourceManager.GetString(global::_E000._E000("\uedaf\ued9a\ued8d\ued8c\ued90\ued91\uedb2\ued9e\ued93\ued9a", 60797), _E001);

		public static string PersonPatronymic => ResourceManager.GetString(global::_E000._E000("\ueebf\uee8a\uee9d\uee9c\uee80\uee81\ueebf\uee8e\uee9b\uee9d\uee80\uee81\uee96\uee82\uee86\uee8c", 61066), _E001);

		public static string PhoneNumber => ResourceManager.GetString(global::_E000._E000("\uf599\uf5a1\uf5a6\uf5a7\uf5ac\uf587\uf5bc\uf5a4\uf5ab\uf5ac\uf5bb", 62921), _E001);

		public static string Pin => ResourceManager.GetString(global::_E000._E000("\uf1bf\uf186\uf181", 61775), _E001);

		public static string PinOperations => ResourceManager.GetString(global::_E000._E000("\ue3ed\ue3d4\ue3d3\ue3f2\ue3cd\ue3d8\ue3cf\ue3dc\ue3c9\ue3d4\ue3d2\ue3d3\ue3ce", 58300), _E001);

		public static string PinProgramming => ResourceManager.GetString(global::_E000._E000("\ue82f\ue816\ue811\ue82f\ue80d\ue810\ue818\ue80d\ue81e\ue812\ue812\ue816\ue811\ue818", 59515), _E001);

		public static string PinShiftClose => ResourceManager.GetString(global::_E000._E000("\uf33d\uf304\uf303\uf33e\uf305\uf304\uf30b\uf319\uf32e\uf301\uf302\uf31e\uf308", 62316), _E001);

		public static string PinType => ResourceManager.GetString(global::_E000._E000("\uf5af\uf596\uf591\uf5ab\uf586\uf58f\uf59a", 62909), _E001);

		public static string PortName => ResourceManager.GetString(global::_E000._E000("\uf7ce\uf7f1\uf7ec\uf7ea\uf7d0\uf7ff\uf7f3\uf7fb", 63374), _E001);

		public static string PortNameDescription => ResourceManager.GetString(global::_E000._E000("\uefa9\uef96\uef8b\uef8d\uefb7\uef98\uef94\uef9c\uefbd\uef9c\uef8a\uef9a\uef8b\uef90\uef89\uef8d\uef90\uef96\uef97", 61433), _E001);

		public static string PositionsDiscount => ResourceManager.GetString(global::_E000._E000("\uf1a7\uf198\uf184\uf19e\uf183\uf19e\uf198\uf199\uf184\uf1b3\uf19e\uf184\uf194\uf198\uf182\uf199\uf183", 61748), _E001);

		public static string PositionsMarkup => ResourceManager.GetString(global::_E000._E000("\ue0bf\ue080\ue09c\ue086\ue09b\ue086\ue080\ue081\ue09c\ue0a2\ue08e\ue09d\ue084\ue09a\ue09f", 57485), _E001);

		public static string Pricelist => ResourceManager.GetString(global::_E000._E000("\uf172\uf150\uf14b\uf141\uf147\uf14e\uf14b\uf151\uf156", 61728), _E001);

		public static string PrintCheckAuto => ResourceManager.GetString(global::_E000._E000("\uf6ce\uf6ec\uf6f7\uf6f0\uf6ea\uf6dd\uf6f6\uf6fb\uf6fd\uf6f5\uf6df\uf6eb\uf6ea\uf6f1", 63134), _E001);

		public static string PrintDostykQR => ResourceManager.GetString(global::_E000._E000("\ueead\uee8f\uee94\uee93\uee89\ueeb9\uee92\uee8e\uee89\uee84\uee96\ueeac\ueeaf", 61180), _E001);

		public static string Printer => ResourceManager.GetString(global::_E000._E000("\uef97\uefb5\uefae\uefa9\uefb3\uefa2\uefb5", 61380), _E001);

		public static string PrinterDescription => ResourceManager.GetString(global::_E000._E000("\uee0e\uee2c\uee37\uee30\uee2a\uee3b\uee2c\uee1a\uee3b\uee2d\uee3d\uee2c\uee37\uee2e\uee2a\uee37\uee31\uee30", 61022), _E001);

		public static string PrinterModel => ResourceManager.GetString(global::_E000._E000("\uf3af\uf38d\uf396\uf391\uf38b\uf39a\uf38d\uf3b2\uf390\uf39b\uf39a\uf393", 62455), _E001);

		public static string PrinterType => ResourceManager.GetString(global::_E000._E000("\uf0ed\uf0cf\uf0d4\uf0d3\uf0c9\uf0d8\uf0cf\uf0e9\uf0c4\uf0cd\uf0d8", 61628), _E001);

		public static string PrinterTypeA4 => ResourceManager.GetString(global::_E000._E000("\uefbf\uef9d\uef86\uef81\uef9b\uef8a\uef9d\uefbb\uef96\uef9f\uef8a\uefae\uefdb", 61421), _E001);

		public static string PrinterTypeA4Rotate => ResourceManager.GetString(global::_E000._E000("\uebbf\ueb9d\ueb86\ueb81\ueb9b\ueb8a\ueb9d\uebbb\ueb96\ueb9f\ueb8a\uebae\uebdb\uebbd\ueb80\ueb9b\ueb8e\ueb9b\ueb8a", 60237), _E001);

		public static string PrinterTypeCashTape => ResourceManager.GetString(global::_E000._E000("\ue8b2\ue890\ue88b\ue88c\ue896\ue887\ue890\ue8b6\ue89b\ue892\ue887\ue8a1\ue883\ue891\ue88a\ue8b6\ue883\ue892\ue887", 59616), _E001);

		public static string PrinterTypeCashTape57 => ResourceManager.GetString(global::_E000._E000("\uf763\uf741\uf75a\uf75d\uf747\uf756\uf741\uf767\uf74a\uf743\uf756\uf770\uf752\uf740\uf75b\uf767\uf752\uf743\uf756\uf706\uf704", 63266), _E001);

		public static string PrintSlipCheck => ResourceManager.GetString(global::_E000._E000("\uf0f2\uf0d0\uf0cb\uf0cc\uf0d6\uf0f1\uf0ce\uf0cb\uf0d2\uf0e1\uf0ca\uf0c7\uf0c1\uf0c9", 61600), _E001);

		public static string PrintTicketQR => ResourceManager.GetString(global::_E000._E000("\ue6eb\ue6c9\ue6d2\ue6d5\ue6cf\ue6ef\ue6d2\ue6d8\ue6d0\ue6de\ue6cf\ue6ea\ue6e9", 58929), _E001);

		public static string PrintWidth => ResourceManager.GetString(global::_E000._E000("\ue989\ue9ab\ue9b0\ue9b7\ue9ad\ue98e\ue9b0\ue9bd\ue9ad\ue9b1", 59737), _E001);

		public static string PrintXinOnTicket => ResourceManager.GetString(global::_E000._E000("\ue5eb\ue5c9\ue5d2\ue5d5\ue5cf\ue5e3\ue5d2\ue5d5\ue5f4\ue5d5\ue5ef\ue5d2\ue5d8\ue5d0\ue5de\ue5cf", 58675), _E001);

		public static string ProductBook => ResourceManager.GetString(global::_E000._E000("\ueaaf\uea8d\uea90\uea9b\uea8a\uea9c\uea8b\ueabd\uea90\uea90\uea94", 60127), _E001);

		public static string ProductCode => ResourceManager.GetString(global::_E000._E000("\ue7bf\ue79d\ue780\ue78b\ue79a\ue78c\ue79b\ue7ac\ue780\ue78b\ue78a", 59181), _E001);

		public static string Purchases => ResourceManager.GetString(global::_E000._E000("\uf6bb\uf69e\uf699\uf688\uf683\uf68a\uf698\uf68e\uf698", 63075), _E001);

		public static string PurchasesReturn => ResourceManager.GetString(global::_E000._E000("\uf02d\uf008\uf00f\uf01e\uf015\uf01c\uf00e\uf018\uf00e\uf02f\uf018\uf009\uf008\uf00f\uf013", 61461), _E001);

		public static string PurchasesTotalCount => ResourceManager.GetString(global::_E000._E000("\uf8ef\uf8ca\uf8cd\uf8dc\uf8d7\uf8de\uf8cc\uf8da\uf8cc\uf8eb\uf8d0\uf8cb\uf8de\uf8d3\uf8fc\uf8d0\uf8ca\uf8d1\uf8cb", 63671), _E001);

		public static string PurchasesTotalReturn => ResourceManager.GetString(global::_E000._E000("\ue9b7\ue992\ue995\ue984\ue98f\ue986\ue994\ue982\ue994\ue9b3\ue988\ue993\ue986\ue98b\ue9b5\ue982\ue993\ue992\ue995\ue989", 59876), _E001);

		public static string PutCashSum => ResourceManager.GetString(global::_E000._E000("\uf697\uf6b2\uf6b3\uf684\uf6a6\uf6b4\uf6af\uf694\uf6b2\uf6aa", 63108), _E001);

		public static string PutMoney => ResourceManager.GetString(global::_E000._E000("\uf4ad\uf488\uf489\uf4b0\uf492\uf493\uf498\uf484", 62716), _E001);

		public static string ReadTimeout => ResourceManager.GetString(global::_E000._E000("\uef2f\uef18\uef1c\uef19\uef29\uef14\uef10\uef18\uef12\uef08\uef09", 61301), _E001);

		public static string ReadTimeoutDescription => ResourceManager.GetString(global::_E000._E000("\ue2ec\ue2db\ue2df\ue2da\ue2ea\ue2d7\ue2d3\ue2db\ue2d1\ue2cb\ue2ca\ue2fa\ue2db\ue2cd\ue2dd\ue2cc\ue2d7\ue2ce\ue2ca\ue2d7\ue2d1\ue2d0", 58046), _E001);

		public static string ReconnectsCount => ResourceManager.GetString(global::_E000._E000("\uf3fb\uf3cc\uf3ca\uf3c6\uf3c7\uf3c7\uf3cc\uf3ca\uf3dd\uf3da\uf3ea\uf3c6\uf3dc\uf3c7\uf3dd", 62377), _E001);

		public static string ReferalLink => ResourceManager.GetString(global::_E000._E000("\ueeb9\uee8e\uee8d\uee8e\uee99\uee8a\uee87\ueea7\uee82\uee85\uee80", 61123), _E001);

		public static string Region => ResourceManager.GetString(global::_E000._E000("\uebb5\ueb82\ueb80\ueb8e\ueb88\ueb89", 60388), _E001);

		public static string RegistrationBook => ResourceManager.GetString(global::_E000._E000("\uf361\uf356\uf354\uf35a\uf340\uf347\uf341\uf352\uf347\uf35a\uf35c\uf35d\uf371\uf35c\uf35c\uf358", 62242), _E001);

		public static string ReleaseDate => ResourceManager.GetString(global::_E000._E000("\ue2bf\ue288\ue281\ue288\ue28c\ue29e\ue288\ue2a9\ue28c\ue299\ue288", 58021), _E001);

		public static string RememberBrowser => ResourceManager.GetString(global::_E000._E000("\uedff\uedc8\uedc0\uedc8\uedc0\uedcf\uedc8\ueddf\uedef\ueddf\uedc2\uedda\uedde\uedc8\ueddf", 60812), _E001);

		public static string RememberMe => ResourceManager.GetString(global::_E000._E000("\ue4db\ue4ec\ue4e4\ue4ec\ue4e4\ue4eb\ue4ec\ue4fb\ue4c4\ue4ec", 58377), _E001);

		public static string ReportX => ResourceManager.GetString(global::_E000._E000("\uf4ad\uf49a\uf48f\uf490\uf48d\uf48b\uf4a7", 62583), _E001);

		public static string ReportZ => ResourceManager.GetString(global::_E000._E000("\uf7bf\uf788\uf79d\uf782\uf79f\uf799\uf7b7", 63468), _E001);

		public static string ReportZXCardSum => ResourceManager.GetString(global::_E000._E000("\uf5fd\uf5ca\uf5df\uf5c0\uf5dd\uf5db\uf5f5\uf5f7\uf5ec\uf5ce\uf5dd\uf5cb\uf5fc\uf5da\uf5c2", 62895), _E001);

		public static string ReportZXCashboxIN => ResourceManager.GetString(global::_E000._E000("\ue6ed\ue6da\ue6cf\ue6d0\ue6cd\ue6cb\ue6e5\ue6e7\ue6fc\ue6de\ue6cc\ue6d7\ue6dd\ue6d0\ue6c7\ue6f6\ue6f1", 58911), _E001);

		public static string ReportZXCashboxRN => ResourceManager.GetString(global::_E000._E000("\uf16c\uf15b\uf14e\uf151\uf14c\uf14a\uf164\uf166\uf17d\uf15f\uf14d\uf156\uf15c\uf151\uf146\uf16c\uf170", 61758), _E001);

		public static string ReportZXCashboxSN => ResourceManager.GetString(global::_E000._E000("\uf3ad\uf39a\uf38f\uf390\uf38d\uf38b\uf3a5\uf3a7\uf3bc\uf39e\uf38c\uf397\uf39d\uf390\uf387\uf3ac\uf3b1", 62458), _E001);

		public static string ReportZXCashSum => ResourceManager.GetString(global::_E000._E000("\ue11d\ue12a\ue13f\ue120\ue13d\ue13b\ue115\ue117\ue10c\ue12e\ue13c\ue127\ue11c\ue13a\ue122", 57606), _E001);

		public static string ReportZXChangeSum => ResourceManager.GetString(global::_E000._E000("\ueb6d\ueb5a\ueb4f\ueb50\ueb4d\ueb4b\ueb65\ueb67\ueb7c\ueb57\ueb5e\ueb51\ueb58\ueb5a\ueb6c\ueb4a\ueb52", 60219), _E001);

		public static string ReportZXCloseOn => ResourceManager.GetString(global::_E000._E000("\uf1bb\uf18c\uf199\uf186\uf19b\uf19d\uf1b3\uf1b1\uf1aa\uf185\uf186\uf19a\uf18c\uf1a6\uf187", 61929), _E001);

		public static string ReportZXControlSum => ResourceManager.GetString(global::_E000._E000("\ue2a5\ue292\ue287\ue298\ue285\ue283\ue2ad\ue2af\ue2b4\ue298\ue299\ue283\ue285\ue298\ue29b\ue2a4\ue282\ue29a", 57908), _E001);

		public static string ReportZXDiscountSum => ResourceManager.GetString(global::_E000._E000("\ue32f\ue318\ue30d\ue312\ue30f\ue309\ue327\ue325\ue339\ue314\ue30e\ue31e\ue312\ue308\ue313\ue309\ue32e\ue308\ue310", 58168), _E001);

		public static string ReportZXDocumentCount => ResourceManager.GetString(global::_E000._E000("\ue22f\ue218\ue20d\ue212\ue20f\ue209\ue227\ue225\ue239\ue212\ue21e\ue208\ue210\ue218\ue213\ue209\ue23e\ue212\ue208\ue213\ue209", 57960), _E001);

		public static string ReportZXMarkupSum => ResourceManager.GetString(global::_E000._E000("\ue5bf\ue588\ue59d\ue582\ue59f\ue599\ue5b7\ue5b5\ue5a0\ue58c\ue59f\ue586\ue598\ue59d\ue5be\ue598\ue580", 58789), _E001);

		public static string ReportZXNotNullableForCurrent => ResourceManager.GetString(global::_E000._E000("\uf5fd\uf5ca\uf5df\uf5c0\uf5dd\uf5db\uf5f5\uf5f7\uf5e1\uf5c0\uf5db\uf5e1\uf5da\uf5c3\uf5c3\uf5ce\uf5cd\uf5c3\uf5ca\uf5e9\uf5c0\uf5dd\uf5ec\uf5da\uf5dd\uf5dd\uf5ca\uf5c1\uf5db", 62895), _E001);

		public static string ReportZXNotNullableForEnd => ResourceManager.GetString(global::_E000._E000("\ue8ad\ue89a\ue88f\ue890\ue88d\ue88b\ue8a5\ue8a7\ue8b1\ue890\ue88b\ue8b1\ue88a\ue893\ue893\ue89e\ue89d\ue893\ue89a\ue8b9\ue890\ue88d\ue8ba\ue891\ue89b", 59645), _E001);

		public static string ReportZXNotNullableForStart => ResourceManager.GetString(global::_E000._E000("\uf88c\uf8bb\uf8ae\uf8b1\uf8ac\uf8aa\uf884\uf886\uf890\uf8b1\uf8aa\uf890\uf8ab\uf8b2\uf8b2\uf8bf\uf8bc\uf8b2\uf8bb\uf898\uf8b1\uf8ac\uf88d\uf8aa\uf8bf\uf8ac\uf8aa", 63694), _E001);

		public static string ReportZXNumber => ResourceManager.GetString(global::_E000._E000("\uefcb\ueffc\uefe9\ueff6\uefeb\uefed\uefc3\uefc1\uefd7\uefec\ueff4\ueffb\ueffc\uefeb", 61209), _E001);

		public static string ReportZXOperations => ResourceManager.GetString(global::_E000._E000("\ue785\ue7b2\ue7a7\ue7b8\ue7a5\ue7a3\ue78d\ue78f\ue798\ue7a7\ue7b2\ue7a5\ue7b6\ue7a3\ue7be\ue7b8\ue7b9\ue7a4", 59220), _E001);

		public static string ReportZXPutMoneySum => ResourceManager.GetString(global::_E000._E000("\uf3b5\uf382\uf397\uf388\uf395\uf393\uf3bd\uf3bf\uf3b7\uf392\uf393\uf3aa\uf388\uf389\uf382\uf39e\uf3b4\uf392\uf38a", 62372), _E001);

		public static string ReportZXReportOn => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue79e\ue78b\ue794\ue789\ue78f\ue7a1\ue7a3\ue7a9\ue79e\ue78b\ue794\ue789\ue78f\ue7b4\ue795", 59219), _E001);

		public static string ReportZXReturns => ResourceManager.GetString(global::_E000._E000("\uf4f9\uf4ce\uf4db\uf4c4\uf4d9\uf4df\uf4f1\uf4f3\uf4f9\uf4ce\uf4df\uf4de\uf4d9\uf4c5\uf4d8", 62627), _E001);

		public static string ReportZXShiftNumber => ResourceManager.GetString(global::_E000._E000("\uf021\uf016\uf003\uf01c\uf001\uf007\uf029\uf02b\uf020\uf01b\uf01a\uf015\uf007\uf03d\uf006\uf01e\uf011\uf016\uf001", 61554), _E001);

		public static string ReportZXStartOn => ResourceManager.GetString(global::_E000._E000("\ue56d\ue55a\ue54f\ue550\ue54d\ue54b\ue565\ue567\ue56c\ue54b\ue55e\ue54d\ue54b\ue570\ue551", 58667), _E001);

		public static string ReportZXTakeMoneySum => ResourceManager.GetString(global::_E000._E000("\ue53d\ue50a\ue51f\ue500\ue51d\ue51b\ue535\ue537\ue53b\ue50e\ue504\ue50a\ue522\ue500\ue501\ue50a\ue516\ue53c\ue51a\ue502", 58726), _E001);

		public static string ReportZXTakenSum => ResourceManager.GetString(global::_E000._E000("\uf1ef\uf1d8\uf1cd\uf1d2\uf1cf\uf1c9\uf1e7\uf1e5\uf1e9\uf1dc\uf1d6\uf1d8\uf1d3\uf1ee\uf1c8\uf1d0", 61884), _E001);

		public static string ReportZXTaxPayerIN => ResourceManager.GetString(global::_E000._E000("\ue38c\ue3bb\ue3ae\ue3b1\ue3ac\ue3aa\ue384\ue386\ue38a\ue3bf\ue3a6\ue38e\ue3bf\ue3a7\ue3bb\ue3ac\ue397\ue390", 58334), _E001);

		public static string ReportZXTaxPayerName => ResourceManager.GetString(global::_E000._E000("\ue1cb\ue1fc\ue1e9\ue1f6\ue1eb\ue1ed\ue1c3\ue1c1\ue1cd\ue1f8\ue1e1\ue1c9\ue1f8\ue1e0\ue1fc\ue1eb\ue1d7\ue1f8\ue1f4\ue1fc", 57625), _E001);

		public static string ReportZXTaxPayerVATNumber => ResourceManager.GetString(global::_E000._E000("\uec2d\uec1a\uec0f\uec10\uec0d\uec0b\uec25\uec27\uec2b\uec1e\uec07\uec2f\uec1e\uec06\uec1a\uec0d\uec29\uec3e\uec2b\uec31\uec0a\uec12\uec1d\uec1a\uec0d", 60507), _E001);

		public static string ReportZXTaxPayerVATSeria => ResourceManager.GetString(global::_E000._E000("\ue4bf\ue488\ue49d\ue482\ue49f\ue499\ue4b7\ue4b5\ue4b9\ue48c\ue495\ue4bd\ue48c\ue494\ue488\ue49f\ue4bb\ue4ac\ue4b9\ue4be\ue488\ue49f\ue484\ue48c", 58604), _E001);

		public static string ReportZXTaxPlayerVAT => ResourceManager.GetString(global::_E000._E000("\ue18d\ue1ba\ue1af\ue1b0\ue1ad\ue1ab\ue185\ue187\ue18b\ue1be\ue1a7\ue18f\ue1b3\ue1be\ue1a6\ue1ba\ue1ad\ue189\ue19e\ue18b", 57799), _E001);

		public static string ReportZXTitle => ResourceManager.GetString(global::_E000._E000("\uf6ad\uf69a\uf68f\uf690\uf68d\uf68b\uf6a5\uf6a7\uf6ab\uf696\uf68b\uf693\uf69a", 63197), _E001);

		public static string ReportZXValueAddedTaxSum => ResourceManager.GetString(global::_E000._E000("\uf4bd\uf48a\uf49f\uf480\uf49d\uf49b\uf4b5\uf4b7\uf4b9\uf48e\uf483\uf49a\uf48a\uf4ae\uf48b\uf48b\uf48a\uf48b\uf4bb\uf48e\uf497\uf4bc\uf49a\uf482", 62694), _E001);

		public static string ReturnBuyCount => ResourceManager.GetString(global::_E000._E000("\uec8f\uecb8\ueca9\ueca8\uecaf\uecb3\uec9f\ueca8\ueca4\uec9e\uecb2\ueca8\uecb3\ueca9", 60552), _E001);

		public static string ReturnBuySum => ResourceManager.GetString(global::_E000._E000("\ueaaf\uea98\uea89\uea88\uea8f\uea93\ueabf\uea88\uea84\ueaae\uea88\uea90", 60117), _E001);

		public static string ReturnsSellCount => ResourceManager.GetString(global::_E000._E000("\uf18f\uf1b8\uf1a9\uf1a8\uf1af\uf1b3\uf1ae\uf18e\uf1b8\uf1b1\uf1b1\uf19e\uf1b2\uf1a8\uf1b3\uf1a9", 61848), _E001);

		public static string ReturnsSellSum => ResourceManager.GetString(global::_E000._E000("\uefad\uef9a\uef8b\uef8a\uef8d\uef91\uef8c\uefac\uef9a\uef93\uef93\uefac\uef8a\uef92", 61213), _E001);

		public static string RoundType => ResourceManager.GetString(global::_E000._E000("\uedaf\ued92\ued88\ued93\ued99\ueda9\ued84\ued8d\ued98", 60856), _E001);

		public static string RoundTypeEveryItem => ResourceManager.GetString(global::_E000._E000("\ue620\ue61d\ue607\ue61c\ue616\ue626\ue60b\ue602\ue617\ue637\ue604\ue617\ue600\ue60b\ue63b\ue606\ue617\ue61f", 58960), _E001);

		public static string RoundTypeNone => ResourceManager.GetString(global::_E000._E000("\ue9ed\ue9d0\ue9ca\ue9d1\ue9db\ue9eb\ue9c6\ue9cf\ue9da\ue9f1\ue9d0\ue9d1\ue9da", 59679), _E001);

		public static string RoundTypeTotal => ResourceManager.GetString(global::_E000._E000("\uf1bf\uf182\uf198\uf183\uf189\uf1b9\uf194\uf19d\uf188\uf1b9\uf182\uf199\uf18c\uf181", 61893), _E001);

		public static string RoundTypeTotalOnly => ResourceManager.GetString(global::_E000._E000("\uf6b5\uf688\uf692\uf689\uf683\uf6b3\uf69e\uf697\uf682\uf6b3\uf688\uf693\uf686\uf68b\uf6a8\uf689\uf68b\uf69e", 63140), _E001);

		public static string RussianLanguage => ResourceManager.GetString(global::_E000._E000("\ueebd\uee9a\uee9c\uee9c\uee86\uee8e\uee81\ueea3\uee8e\uee81\uee88\uee9a\uee8e\uee88\uee8a", 61005), _E001);

		public static string SCActivityReport => ResourceManager.GetString(global::_E000._E000("\uf8be\uf8ae\uf8ac\uf88e\uf899\uf884\uf89b\uf884\uf899\uf894\uf8bf\uf888\uf89d\uf882\uf89f\uf899", 63621), _E001);

		public static string Section => ResourceManager.GetString(global::_E000._E000("\uf42c\uf41a\uf41c\uf40b\uf416\uf410\uf411", 62555), _E001);

		public static string SectionReport => ResourceManager.GetString(global::_E000._E000("\uf42c\uf41a\uf41c\uf40b\uf416\uf410\uf411\uf42d\uf41a\uf40f\uf410\uf40d\uf40b", 62518), _E001);

		public static string Sells => ResourceManager.GetString(global::_E000._E000("\ue6da\ue6ec\ue6e5\ue6e5\ue6fa", 58889), _E001);

		public static string SellsCount => ResourceManager.GetString(global::_E000._E000("\uf4be\uf488\uf481\uf481\uf49e\uf4ae\uf482\uf498\uf483\uf499", 62661), _E001);

		public static string SellsReturn => ResourceManager.GetString(global::_E000._E000("\uf42e\uf418\uf411\uf411\uf40e\uf42f\uf418\uf409\uf408\uf40f\uf413", 62520), _E001);

		public static string SellsSum => ResourceManager.GetString(global::_E000._E000("\ueebc\uee8a\uee83\uee83\uee9c\ueebc\uee9a\uee82", 60973), _E001);

		public static string SellsTotalCount => ResourceManager.GetString(global::_E000._E000("\uf494\uf4a2\uf4ab\uf4ab\uf4b4\uf493\uf4a8\uf4b3\uf4a6\uf4ab\uf484\uf4a8\uf4b2\uf4a9\uf4b3", 62532), _E001);

		public static string SellsTotalReturn => ResourceManager.GetString(global::_E000._E000("\ue63e\ue608\ue601\ue601\ue61e\ue639\ue602\ue619\ue60c\ue601\ue63f\ue608\ue619\ue618\ue61f\ue603", 58988), _E001);

		public static string SemiAnnual => ResourceManager.GetString(global::_E000._E000("\uf8ec\uf8da\uf8d2\uf8d6\uf8fe\uf8d1\uf8d1\uf8ca\uf8de\uf8d3", 63543), _E001);

		public static string ServerSettingAddress => ResourceManager.GetString(global::_E000._E000("\ueaf8\ueace\uead9\ueadd\ueace\uead9\ueaf8\ueace\ueadf\ueadf\ueac2\ueac5\ueacc\ueaea\ueacf\ueacf\uead9\ueace\uead8\uead8", 59937), _E001);

		public static string ServerSettingAppCode => ResourceManager.GetString(global::_E000._E000("\uf39a\uf3ac\uf3bb\uf3bf\uf3ac\uf3bb\uf39a\uf3ac\uf3bd\uf3bd\uf3a0\uf3a7\uf3ae\uf388\uf3b9\uf3b9\uf38a\uf3a6\uf3ad\uf3ac", 62281), _E001);

		public static string ServerSettingHeaderSize => ResourceManager.GetString(global::_E000._E000("\uef8d\uefbb\uefac\uefa8\uefbb\uefac\uef8d\uefbb\uefaa\uefaa\uefb7\uefb0\uefb9\uef96\uefbb\uefbf\uefba\uefbb\uefac\uef8d\uefb7\uefa4\uefbb", 61406), _E001);

		public static string ServerSettingPort => ResourceManager.GetString(global::_E000._E000("\ue0f8\ue0ce\ue0d9\ue0dd\ue0ce\ue0d9\ue0f8\ue0ce\ue0df\ue0df\ue0c2\ue0c5\ue0cc\ue0fb\ue0c4\ue0d9\ue0df", 57507), _E001);

		public static string ServerSettingVersion => ResourceManager.GetString(global::_E000._E000("\ued2e\ued18\ued0f\ued0b\ued18\ued0f\ued2e\ued18\ued09\ued09\ued14\ued13\ued1a\ued2b\ued18\ued0f\ued0e\ued14\ued12\ued13", 60725), _E001);

		public static string ServiceCenterCabinet => ResourceManager.GetString(global::_E000._E000("\ue8fe\ue8c8\ue8df\ue8db\ue8c4\ue8ce\ue8c8\ue8ee\ue8c8\ue8c3\ue8d9\ue8c8\ue8df\ue8ee\ue8cc\ue8cf\ue8c4\ue8c3\ue8c8\ue8d9", 59532), _E001);

		public static string ServiceCenterSupervisor => ResourceManager.GetString(global::_E000._E000("\ue28d\ue2bb\ue2ac\ue2a8\ue2b7\ue2bd\ue2bb\ue29d\ue2bb\ue2b0\ue2aa\ue2bb\ue2ac\ue28d\ue2ab\ue2ae\ue2bb\ue2ac\ue2a8\ue2b7\ue2ad\ue2b1\ue2ac", 58062), _E001);

		public static string ServiceMaintenance => ResourceManager.GetString(global::_E000._E000("\uf5e0\uf5d6\uf5c1\uf5c5\uf5da\uf5d0\uf5d6\uf5fe\uf5d2\uf5da\uf5dd\uf5c7\uf5d6\uf5dd\uf5d2\uf5dd\uf5d0\uf5d6", 62898), _E001);

		public static string ServiceProvided => ResourceManager.GetString(global::_E000._E000("\ue3ae\ue398\ue38f\ue38b\ue394\ue39e\ue398\ue3ad\ue38f\ue392\ue38b\ue394\ue399\ue398\ue399", 58280), _E001);

		public static string ShiftClosedOn => ResourceManager.GetString(global::_E000._E000("\ue43e\ue405\ue404\ue40b\ue419\ue42e\ue401\ue402\ue41e\ue408\ue409\ue422\ue403", 58476), _E001);

		public static string ShiftNumber => ResourceManager.GetString(global::_E000._E000("\uecec\uecd7\uecd6\uecd9\ueccb\uecf1\uecca\uecd2\uecdd\uecda\ueccd", 60471), _E001);

		public static string ShiftOpenOn => ResourceManager.GetString(global::_E000._E000("\ue22c\ue217\ue216\ue219\ue20b\ue230\ue20f\ue21a\ue211\ue230\ue211", 57978), _E001);

		public static string ShiftsCount => ResourceManager.GetString(global::_E000._E000("\ue62e\ue615\ue614\ue61b\ue609\ue60e\ue63e\ue612\ue608\ue613\ue609", 58984), _E001);

		public static string ShiftWasOpened => ResourceManager.GetString(global::_E000._E000("\ue9ec\ue9d7\ue9d6\ue9d9\ue9cb\ue9e8\ue9de\ue9cc\ue9f0\ue9cf\ue9da\ue9d1\ue9da\ue9db", 59687), _E001);

		public static string ShortName => ResourceManager.GetString(global::_E000._E000("\ue30e\ue335\ue332\ue32f\ue329\ue313\ue33c\ue330\ue338", 58200), _E001);

		public static string SoldOut => ResourceManager.GetString(global::_E000._E000("\ue1a0\ue19c\ue19f\ue197\ue1bc\ue186\ue187", 57794), _E001);

		public static string StationSell => ResourceManager.GetString(global::_E000._E000("\ue860\ue847\ue852\ue847\ue85a\ue85c\ue85d\ue860\ue856\ue85f\ue85f", 59442), _E001);

		public static string Street => ResourceManager.GetString(global::_E000._E000("\ue23c\ue21b\ue21d\ue20a\ue20a\ue21b", 57930), _E001);

		public static string SystemCabinetBalanceReplenishment => ResourceManager.GetString(global::_E000._E000("\ue31c\ue336\ue33c\ue33b\ue32a\ue322\ue30c\ue32e\ue32d\ue326\ue321\ue32a\ue33b\ue30d\ue32e\ue323\ue32e\ue321\ue32c\ue32a\ue31d\ue32a\ue33f\ue323\ue32a\ue321\ue326\ue33c\ue327\ue322\ue32a\ue321\ue33b", 58182), _E001);

		public static string SystemLicensesManagement => ResourceManager.GetString(global::_E000._E000("\ueda0\ued8a\ued80\ued87\ued96\ued9e\uedbf\ued9a\ued90\ued96\ued9d\ued80\ued96\ued80\uedbe\ued92\ued9d\ued92\ued94\ued96\ued9e\ued96\ued9d\ued87", 60882), _E001);

		public static string TakeCashSum => ResourceManager.GetString(global::_E000._E000("\uf8af\uf89a\uf890\uf89e\uf8b8\uf89a\uf888\uf893\uf8a8\uf88e\uf896", 63601), _E001);

		public static string TakeMoney => ResourceManager.GetString(global::_E000._E000("\uf4ab\uf49e\uf494\uf49a\uf4b2\uf490\uf491\uf49a\uf486", 62667), _E001);

		public static string TakenTotalSum => ResourceManager.GetString(global::_E000._E000("\ue92b\ue91e\ue914\ue91a\ue911\ue92b\ue910\ue90b\ue91e\ue913\ue92c\ue90a\ue912", 59723), _E001);

		public static string Tara => ResourceManager.GetString(global::_E000._E000("\ue3e9\ue3dc\ue3cf\ue3dc", 58300), _E001);

		public static string TaxValidationType => ResourceManager.GetString(global::_E000._E000("\ue6fd\ue6c8\ue6d1\ue6ff\ue6c8\ue6c5\ue6c0\ue6cd\ue6c8\ue6dd\ue6c0\ue6c6\ue6c7\ue6fd\ue6d0\ue6d9\ue6cc", 58921), _E001);

		public static string Template => ResourceManager.GetString(global::_E000._E000("\uf039\uf008\uf000\uf01d\uf001\uf00c\uf019\uf008", 61445), _E001);

		public static string TerminalSell => ResourceManager.GetString(global::_E000._E000("\uedab\ued9a\ued8d\ued92\ued96\ued91\ued9e\ued93\uedac\ued9a\ued93\ued93", 60826), _E001);

		public static string TestAddress => ResourceManager.GetString(global::_E000._E000("\uf3bf\uf38e\uf398\uf39f\uf3aa\uf38f\uf38f\uf399\uf38e\uf398\uf398", 62403), _E001);

		public static string TestCashbox => ResourceManager.GetString(global::_E000._E000("\uf5ea\uf5db\uf5cd\uf5ca\uf5fd\uf5df\uf5cd\uf5d6\uf5dc\uf5d1\uf5c6", 62894), _E001);

		public static string TestOrganizationName => ResourceManager.GetString(global::_E000._E000("\ued89\uedb8\uedae\ueda9\ued92\uedaf\uedba\uedbc\uedb3\uedb4\ueda7\uedbc\ueda9\uedb4\uedb2\uedb3\ued93\uedbc\uedb0\uedb8", 60888), _E001);

		public static string Timeout => ResourceManager.GetString(global::_E000._E000("\uf0eb\uf0d6\uf0d2\uf0da\uf0d0\uf0ca\uf0cb", 61627), _E001);

		public static string TimeoutDescription => ResourceManager.GetString(global::_E000._E000("\ueabb\uea86\uea82\uea8a\uea80\uea9a\uea9b\ueaab\uea8a\uea9c\uea8c\uea9d\uea86\uea9f\uea9b\uea86\uea80\uea81", 59917), _E001);

		public static string TobaccoProductsBase => ResourceManager.GetString(global::_E000._E000("\ue2ab\ue290\ue29d\ue29e\ue29c\ue29c\ue290\ue2af\ue28d\ue290\ue29b\ue28a\ue29c\ue28b\ue28c\ue2bd\ue29e\ue28c\ue29a", 58074), _E001);

		public static string Tomorrow => ResourceManager.GetString(global::_E000._E000("\uf28b\uf2b0\uf2b2\uf2b0\uf2ad\uf2ad\uf2b0\uf2a8", 62023), _E001);

		public static string TotalBySections => ResourceManager.GetString(global::_E000._E000("\ue9bb\ue980\ue99b\ue98e\ue983\ue9ad\ue996\ue9bc\ue98a\ue98c\ue99b\ue986\ue980\ue981\ue99c", 59885), _E001);

		public static string TotalSum => ResourceManager.GetString(global::_E000._E000("\uf8ff\uf8c4\uf8df\uf8ca\uf8c7\uf8f8\uf8de\uf8c6", 63617), _E001);

		public static string TradePoint => ResourceManager.GetString(global::_E000._E000("\ue7eb\ue7cd\ue7de\ue7db\ue7da\ue7ef\ue7d0\ue7d6\ue7d1\ue7cb", 59319), _E001);

		public static string TravelSell => ResourceManager.GetString(global::_E000._E000("\ue82b\ue80d\ue81e\ue809\ue81a\ue813\ue82c\ue81a\ue813\ue813", 59446), _E001);

		public static string TrialPacket => ResourceManager.GetString(global::_E000._E000("\ued69\ued4f\ued54\ued5c\ued51\ued6d\ued5c\ued5e\ued56\ued58\ued49", 60700), _E001);

		public static string TSPermissionsOrganizationRegistration => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue7ae\ue7ad\ue798\ue78f\ue790\ue794\ue78e\ue78e\ue794\ue792\ue793\ue78e\ue7b2\ue78f\ue79a\ue79c\ue793\ue794\ue787\ue79c\ue789\ue794\ue792\ue793\ue7af\ue798\ue79a\ue794\ue78e\ue789\ue78f\ue79c\ue789\ue794\ue792\ue793", 59304), _E001);

		public static string TSPermissionsTransferPacket => ResourceManager.GetString(global::_E000._E000("\uf50a\uf50d\uf50e\uf53b\uf52c\uf533\uf537\uf52d\uf52d\uf537\uf531\uf530\uf52d\uf50a\uf52c\uf53f\uf530\uf52d\uf538\uf53b\uf52c\uf50e\uf53f\uf53d\uf535\uf53b\uf52a", 62798), _E001);

		public static string Use80mmPaper => ResourceManager.GetString(global::_E000._E000("\uf4ec\uf4ca\uf4dc\uf481\uf489\uf4d4\uf4d4\uf4e9\uf4d8\uf4c9\uf4dc\uf4cb", 62649), _E001);

		public static string Use80mmPaperDescription => ResourceManager.GetString(global::_E000._E000("\ue5ca\ue5ec\ue5fa\ue5a7\ue5af\ue5f2\ue5f2\ue5cf\ue5fe\ue5ef\ue5fa\ue5ed\ue5db\ue5fa\ue5ec\ue5fc\ue5ed\ue5f6\ue5ef\ue5eb\ue5f6\ue5f0\ue5f1", 58631), _E001);

		public static string UseFontA => ResourceManager.GetString(global::_E000._E000("\ue4fe\ue4d8\ue4ce\ue4ed\ue4c4\ue4c5\ue4df\ue4ea", 58499), _E001);

		public static string UseFontADescription => ResourceManager.GetString(global::_E000._E000("\ue328\ue30e\ue318\ue33b\ue312\ue313\ue309\ue33c\ue339\ue318\ue30e\ue31e\ue30f\ue314\ue30d\ue309\ue314\ue312\ue313", 58152), _E001);

		public static string UseLessCpi => ResourceManager.GetString(global::_E000._E000("\ue2ba\ue29c\ue28a\ue2a3\ue28a\ue29c\ue29c\ue2ac\ue29f\ue286", 58093), _E001);

		public static string UsePlace => ResourceManager.GetString(global::_E000._E000("\uea8a\ueaac\ueaba\uea8f\ueab3\ueabe\ueabc\ueaba", 59975), _E001);

		public static string UsePriceList => ResourceManager.GetString(global::_E000._E000("\ue33a\ue31c\ue30a\ue33f\ue31d\ue306\ue30c\ue30a\ue323\ue306\ue31c\ue31b", 58214), _E001);

		public static string UserHasAccessCashboxes => ResourceManager.GetString(global::_E000._E000("\ue9b8\ue99e\ue988\ue99f\ue9a5\ue98c\ue99e\ue9ac\ue98e\ue98e\ue988\ue99e\ue99e\ue9ae\ue98c\ue99e\ue985\ue98f\ue982\ue995\ue988\ue99e", 59884), _E001);

		public static string UserName => ResourceManager.GetString(global::_E000._E000("\ue93a\ue91c\ue90a\ue91d\ue921\ue90e\ue902\ue90a", 59750), _E001);

		public static string UserPassword => ResourceManager.GetString(global::_E000._E000("\ue72b\ue70d\ue71b\ue70c\ue72e\ue71f\ue70d\ue70d\ue709\ue711\ue70c\ue71a", 59246), _E001);

		public static string UserPasswordConfirm => ResourceManager.GetString(global::_E000._E000("\uf3ba\uf39c\uf38a\uf39d\uf3bf\uf38e\uf39c\uf39c\uf398\uf380\uf39d\uf38b\uf3ac\uf380\uf381\uf389\uf386\uf39d\uf382", 62445), _E001);

		public static string UserPasswordNew => ResourceManager.GetString(global::_E000._E000("\uf18a\uf1ac\uf1ba\uf1ad\uf18f\uf1be\uf1ac\uf1ac\uf1a8\uf1b0\uf1ad\uf1bb\uf191\uf1ba\uf1a8", 61911), _E001);

		public static string UserPasswordOld => ResourceManager.GetString(global::_E000._E000("\ueee7\ueec1\ueed7\ueec0\ueee2\ueed3\ueec1\ueec1\ueec5\ueedd\ueec0\ueed6\ueefd\ueede\ueed6", 61072), _E001);

		public static string UserPermissions => ResourceManager.GetString(global::_E000._E000("\uef2a\uef0c\uef1a\uef0d\uef2f\uef1a\uef0d\uef12\uef16\uef0c\uef0c\uef16\uef10\uef11\uef0c", 61307), _E001);

		public static string UserTimeZone => ResourceManager.GetString(global::_E000._E000("\ued67\ued41\ued57\ued40\ued66\ued5b\ued5f\ued57\ued68\ued5d\ued5c\ued57", 60688), _E001);

		public static string ValueAddedTaxSum => ResourceManager.GetString(global::_E000._E000("\uf2ad\uf29a\uf297\uf28e\uf29e\uf2ba\uf29f\uf29f\uf29e\uf29f\uf2af\uf29a\uf283\uf2a8\uf28e\uf296", 62067), _E001);

		public static string VATSum => ResourceManager.GetString(global::_E000._E000("\ue8e9\ue8fe\ue8eb\ue8ec\ue8ca\ue8d2", 59583), _E001);

		public static string Version => ResourceManager.GetString(global::_E000._E000("\ue191\ue1a2\ue1b5\ue1b4\ue1ae\ue1a8\ue1a9", 57668), _E001);

		public static string ViewExternalOrganizationsCashboxes => ResourceManager.GetString(global::_E000._E000("\uf18f\uf1b0\uf1bc\uf1ae\uf19c\uf1a1\uf1ad\uf1bc\uf1ab\uf1b7\uf1b8\uf1b5\uf196\uf1ab\uf1be\uf1b8\uf1b7\uf1b0\uf1a3\uf1b8\uf1ad\uf1b0\uf1b6\uf1b7\uf1aa\uf19a\uf1b8\uf1aa\uf1b1\uf1bb\uf1b6\uf1a1\uf1bc\uf1aa", 61785), _E001);

		public static string Withdrawn => ResourceManager.GetString(global::_E000._E000("\uece8\uecd6\ueccb\uecd7\uecdb\ueccd\uecde\uecc8\uecd1", 60599), _E001);

		public static string WithoutValidate => ResourceManager.GetString(global::_E000._E000("\uf60a\uf634\uf629\uf635\uf632\uf628\uf629\uf60b\uf63c\uf631\uf634\uf639\uf63c\uf629\uf638", 63000), _E001);

		public static string WKCabinet => ResourceManager.GetString(global::_E000._E000("\ue4ce\ue4d2\ue4da\ue4f8\ue4fb\ue4f0\ue4f7\ue4fc\ue4ed", 58393), _E001);

		public static string WOTTIAccess => ResourceManager.GetString(global::_E000._E000("\ue3a9\ue3b1\ue3aa\ue3aa\ue3b7\ue3bf\ue39d\ue39d\ue39b\ue38d\ue38d", 58366), _E001);

		public static string WriteTimeout => ResourceManager.GetString(global::_E000._E000("\ue629\ue60c\ue617\ue60a\ue61b\ue62a\ue617\ue613\ue61b\ue611\ue60b\ue60a", 58990), _E001);

		public static string WriteTimeoutDescription => ResourceManager.GetString(global::_E000._E000("\ue5bc\ue599\ue582\ue59f\ue58e\ue5bf\ue582\ue586\ue58e\ue584\ue59e\ue59f\ue5af\ue58e\ue598\ue588\ue599\ue582\ue59b\ue59f\ue582\ue584\ue585", 58723), _E001);

		public static string XIN => ResourceManager.GetString(global::_E000._E000("\ue886\ue897\ue890", 59614), _E001);

		public static string XReport => ResourceManager.GetString(global::_E000._E000("\ue835\ue83f\ue808\ue81d\ue802\ue81f\ue819", 59429), _E001);

		public static string ZReport => ResourceManager.GetString(global::_E000._E000("\uf604\uf60c\uf63b\uf62e\uf631\uf62c\uf62a", 63054), _E001);

		internal NameResource()
		{
		}
	}
}
