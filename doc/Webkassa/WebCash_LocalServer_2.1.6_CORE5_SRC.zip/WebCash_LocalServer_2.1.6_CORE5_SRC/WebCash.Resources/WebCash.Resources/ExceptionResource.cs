using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace WebCash.Resources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class ExceptionResource
	{
		private static ResourceManager _E000;

		private static CultureInfo _E001;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (_E000 == null)
				{
					_E000 = new ResourceManager(global::_E000._E000("\ue4e8\ue4da\ue4dd\ue4fc\ue4de\ue4cc\ue4d7\ue491\ue4ed\ue4da\ue4cc\ue4d0\ue4ca\ue4cd\ue4dc\ue4da\ue4cc\ue491\ue4fa\ue4c7\ue4dc\ue4da\ue4cf\ue4cb\ue4d6\ue4d0\ue4d1\ue4ed\ue4da\ue4cc\ue4d0\ue4ca\ue4cd\ue4dc\ue4da", 58527), typeof(ExceptionResource).Assembly);
				}
				return _E000;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return _E001;
			}
			set
			{
				_E001 = value;
			}
		}

		public static string ActivationPacketsEmailNotificationFailed => ResourceManager.GetString(global::_E000._E000("\uefee\uefcc\uefdb\uefc6\uefd9\uefce\uefdb\uefc6\uefc0\uefc1\uefff\uefce\uefcc\uefc4\uefca\uefdb\uefdc\uefea\uefc2\uefce\uefc6\uefc3\uefe1\uefc0\uefdb\uefc6\uefc9\uefc6\uefcc\uefce\uefdb\uefc6\uefc0\uefc1\uefe9\uefce\uefc6\uefc3\uefca\uefcb", 61199), _E001);

		public static string AlreadyInPrice => ResourceManager.GetString(global::_E000._E000("\uf2bc\uf291\uf28f\uf298\uf29c\uf299\uf284\uf2b4\uf293\uf2ad\uf28f\uf294\uf29e\uf298", 62136), _E001);

		public static string CantChangeService => ResourceManager.GetString(global::_E000._E000("\uf7f1\uf7d3\uf7dc\uf7c6\uf7f1\uf7da\uf7d3\uf7dc\uf7d5\uf7d7\uf7e1\uf7d7\uf7c0\uf7c4\uf7db\uf7d1\uf7d7", 63376), _E001);

		public static string CantDeleteService => ResourceManager.GetString(global::_E000._E000("\uf870\uf852\uf85d\uf847\uf877\uf856\uf85f\uf856\uf847\uf856\uf860\uf856\uf841\uf845\uf85a\uf850\uf856", 63490), _E001);

		public static string CashboxNotFound => ResourceManager.GetString(global::_E000._E000("\uf4bc\uf49e\uf48c\uf497\uf49d\uf490\uf487\uf4b1\uf490\uf48b\uf4b9\uf490\uf48a\uf491\uf49b", 62646), _E001);

		public static string CouldNotChangeTradepointKaspiQR => ResourceManager.GetString(global::_E000._E000("\uf23e\uf212\uf208\uf211\uf219\uf233\uf212\uf209\uf23e\uf215\uf21c\uf213\uf21a\uf218\uf229\uf20f\uf21c\uf219\uf218\uf20d\uf212\uf214\uf213\uf209\uf236\uf21c\uf20e\uf20d\uf214\uf22c\uf22f", 62072), _E001);

		public static string CouldNotUntieTradepointKaspiQR => ResourceManager.GetString(global::_E000._E000("\uecb8\uec94\uec8e\uec97\uec9f\uecb5\uec94\uec8f\uecae\uec95\uec8f\uec92\uec9e\uecaf\uec89\uec9a\uec9f\uec9e\uec8b\uec94\uec92\uec95\uec8f\uecb0\uec9a\uec88\uec8b\uec92\uecaa\ueca9", 60497), _E001);

		public static string IdentityAlreadyRegistered => ResourceManager.GetString(global::_E000._E000("\ue78e\ue7a3\ue7a2\ue7a9\ue7b3\ue7ae\ue7b3\ue7be\ue786\ue7ab\ue7b5\ue7a2\ue7a6\ue7a3\ue7be\ue795\ue7a2\ue7a0\ue7ae\ue7b4\ue7b3\ue7a2\ue7b5\ue7a2\ue7a3", 59140), _E001);

		public static string IdentityCannotBeNull => ResourceManager.GetString(global::_E000._E000("\uee3a\uee17\uee16\uee1d\uee07\uee1a\uee07\uee0a\uee30\uee12\uee1d\uee1d\uee1c\uee07\uee31\uee16\uee3d\uee06\uee1f\uee1f", 60994), _E001);

		public static string KaspiQrServiceUnavailableTryLater => ResourceManager.GetString(global::_E000._E000("\ue1a2\ue188\ue19a\ue199\ue180\ue1b8\ue19b\ue1ba\ue18c\ue19b\ue19f\ue180\ue18a\ue18c\ue1bc\ue187\ue188\ue19f\ue188\ue180\ue185\ue188\ue18b\ue185\ue18c\ue1bd\ue19b\ue190\ue1a5\ue188\ue19d\ue18c\ue19b", 57705), _E001);

		public static string LogoCannotBeEmpty => ResourceManager.GetString(global::_E000._E000("\ue4f3\ue4d0\ue4d8\ue4d0\ue4fc\ue4de\ue4d1\ue4d1\ue4d0\ue4cb\ue4fd\ue4da\ue4fa\ue4d2\ue4cf\ue4cb\ue4c6", 58539), _E001);

		public static string LogoCannotBeEmptyForCashbox => ResourceManager.GetString(global::_E000._E000("\ue17f\ue15c\ue154\ue15c\ue170\ue152\ue15d\ue15d\ue15c\ue147\ue171\ue156\ue176\ue15e\ue143\ue147\ue14a\ue175\ue15c\ue141\ue170\ue152\ue140\ue15b\ue151\ue15c\ue14b", 57650), _E001);

		public static string SalemMobileIdentityNotFound => ResourceManager.GetString(global::_E000._E000("\ue6ac\ue69e\ue693\ue69a\ue692\ue6b2\ue690\ue69d\ue696\ue693\ue69a\ue6b6\ue69b\ue69a\ue691\ue68b\ue696\ue68b\ue686\ue6b1\ue690\ue68b\ue6b9\ue690\ue68a\ue691\ue69b", 59099), _E001);

		public static string SelectCashbox => ResourceManager.GetString(global::_E000._E000("\uee1c\uee2a\uee23\uee2a\uee2c\uee3b\uee0c\uee2e\uee3c\uee27\uee2d\uee20\uee37", 60998), _E001);

		public static string SumIsOutOfRangeErrorMessage => ResourceManager.GetString(global::_E000._E000("\ue4ae\ue488\ue490\ue4b4\ue48e\ue4b2\ue488\ue489\ue4b2\ue49b\ue4af\ue49c\ue493\ue49a\ue498\ue4b8\ue48f\ue48f\ue492\ue48f\ue4b0\ue498\ue48e\ue48e\ue49c\ue49a\ue498", 58613), _E001);

		public static string TradePointDeleteFailedBecauseOfCashbox => ResourceManager.GetString(global::_E000._E000("\uf139\uf11f\uf10c\uf109\uf108\uf13d\uf102\uf104\uf103\uf119\uf129\uf108\uf101\uf108\uf119\uf108\uf12b\uf10c\uf104\uf101\uf108\uf109\uf12f\uf108\uf10e\uf10c\uf118\uf11e\uf108\uf122\uf10b\uf12e\uf10c\uf11e\uf105\uf10f\uf102\uf115", 61733), _E001);

		public static string TradePointDoesNotExist => ResourceManager.GetString(global::_E000._E000("\uf1eb\uf1cd\uf1de\uf1db\uf1da\uf1ef\uf1d0\uf1d6\uf1d1\uf1cb\uf1fb\uf1d0\uf1da\uf1cc\uf1f1\uf1d0\uf1cb\uf1fa\uf1c7\uf1d6\uf1cc\uf1cb", 61883), _E001);

		public static string TransferPacketHasNotAllowedStatus => ResourceManager.GetString(global::_E000._E000("\ue6bb\ue69d\ue68e\ue681\ue69c\ue689\ue68a\ue69d\ue6bf\ue68e\ue68c\ue684\ue68a\ue69b\ue6a7\ue68e\ue69c\ue6a1\ue680\ue69b\ue6ae\ue683\ue683\ue680\ue698\ue68a\ue68b\ue6bc\ue69b\ue68e\ue69b\ue69a\ue69c", 59110), _E001);

		internal ExceptionResource()
		{
		}
	}
}
