using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace WebCash.Resources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class CommonResource
	{
		private static ResourceManager _E000;

		private static CultureInfo _E001;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (_E000 == null)
				{
					_E000 = new ResourceManager(global::_E000._E000("\uf8a0\uf892\uf895\uf8b4\uf896\uf884\uf89f\uf8d9\uf8a5\uf892\uf884\uf898\uf882\uf885\uf894\uf892\uf884\uf8d9\uf8b4\uf898\uf89a\uf89a\uf898\uf899\uf8a5\uf892\uf884\uf898\uf882\uf885\uf894\uf892", 63540), typeof(CommonResource).Assembly);
				}
				return _E000;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return _E001;
			}
			set
			{
				_E001 = value;
			}
		}

		public static string AbortDownload => ResourceManager.GetString(global::_E000._E000("\uf333\uf310\uf31d\uf300\uf306\uf336\uf31d\uf305\uf31c\uf31e\uf31d\uf313\uf316", 62288), _E001);

		public static string AccessDeniedForOperation => ResourceManager.GetString(global::_E000._E000("\uedfa\uedd8\uedd8\uedde\uedc8\uedc8\uedff\uedde\uedd5\uedd2\uedde\ueddf\uedfd\uedd4\uedc9\uedf4\uedcb\uedde\uedc9\uedda\uedcf\uedd2\uedd4\uedd5", 60689), _E001);

		public static string AccessDeniedOpenedShift => ResourceManager.GetString(global::_E000._E000("\uedae\ued8c\ued8c\ued8a\ued9c\ued9c\uedab\ued8a\ued81\ued86\ued8a\ued8b\ueda0\ued9f\ued8a\ued81\ued8a\ued8b\uedbc\ued87\ued86\ued89\ued9b", 60838), _E001);

		public static string AccountChangePasswordViewTitle => ResourceManager.GetString(global::_E000._E000("\ue02c\ue00e\ue00e\ue002\ue018\ue003\ue019\ue02e\ue005\ue00c\ue003\ue00a\ue008\ue03d\ue00c\ue01e\ue01e\ue01a\ue002\ue01f\ue009\ue03b\ue004\ue008\ue01a\ue039\ue004\ue019\ue001\ue008", 57420), _E001);

		public static string AccountRegistrationConfirm => ResourceManager.GetString(global::_E000._E000("\uf0a3\uf081\uf081\uf08d\uf097\uf08c\uf096\uf0b0\uf087\uf085\uf08b\uf091\uf096\uf090\uf083\uf096\uf08b\uf08d\uf08c\uf0a1\uf08d\uf08c\uf084\uf08b\uf090\uf08f", 61632), _E001);

		public static string AccountRegistrationConfirmation => ResourceManager.GetString(global::_E000._E000("\uea63\uea41\uea41\uea4d\uea57\uea4c\uea56\uea70\uea47\uea45\uea4b\uea51\uea56\uea50\uea43\uea56\uea4b\uea4d\uea4c\uea61\uea4d\uea4c\uea44\uea4b\uea50\uea4f\uea43\uea56\uea4b\uea4d\uea4c", 59936), _E001);

		public static string Action => ResourceManager.GetString(global::_E000._E000("\uf7a6\uf784\uf793\uf78e\uf788\uf789", 63396), _E001);

		public static string Actions => ResourceManager.GetString(global::_E000._E000("\uf296\uf2b4\uf2a3\uf2be\uf2b8\uf2b9\uf2a4", 62036), _E001);

		public static string ActivationNumber => ResourceManager.GetString(global::_E000._E000("\ueeba\uee98\uee8f\uee92\uee8d\uee9a\uee8f\uee92\uee94\uee95\ueeb5\uee8e\uee96\uee99\uee9e\uee89", 61139), _E001);

		public static string ActivationNumbers => ResourceManager.GetString(global::_E000._E000("\ue6b6\ue694\ue683\ue69e\ue681\ue696\ue683\ue69e\ue698\ue699\ue6b9\ue682\ue69a\ue695\ue692\ue685\ue684", 58996), _E001);

		public static string ActivationPacketExpirationEmailHeader => ResourceManager.GetString(global::_E000._E000("\uf7bc\uf79e\uf789\uf794\uf78b\uf79c\uf789\uf794\uf792\uf793\uf7ad\uf79c\uf79e\uf796\uf798\uf789\uf7b8\uf785\uf78d\uf794\uf78f\uf79c\uf789\uf794\uf792\uf793\uf7b8\uf790\uf79c\uf794\uf791\uf7b5\uf798\uf79c\uf799\uf798\uf78f", 63413), _E001);

		public static string ActivationPacketExpirationEmailHeaderBkassa => ResourceManager.GetString(global::_E000._E000("\uefae\uef8c\uef9b\uef86\uef99\uef8e\uef9b\uef86\uef80\uef81\uefbf\uef8e\uef8c\uef84\uef8a\uef9b\uefaa\uef97\uef9f\uef86\uef9d\uef8e\uef9b\uef86\uef80\uef81\uefaa\uef82\uef8e\uef86\uef83\uefa7\uef8a\uef8e\uef8b\uef8a\uef9d\uefad\uef84\uef8e\uef9c\uef9c\uef8e", 61418), _E001);

		public static string ActivationPacketExpirationEmailSubject => ResourceManager.GetString(global::_E000._E000("\uf2bc\uf29e\uf289\uf294\uf28b\uf29c\uf289\uf294\uf292\uf293\uf2ad\uf29c\uf29e\uf296\uf298\uf289\uf2b8\uf285\uf28d\uf294\uf28f\uf29c\uf289\uf294\uf292\uf293\uf2b8\uf290\uf29c\uf294\uf291\uf2ae\uf288\uf29f\uf297\uf298\uf29e\uf289", 62197), _E001);

		public static string ActivationPacketExpirationEmailSubjectBkassa => ResourceManager.GetString(global::_E000._E000("\uf372\uf350\uf347\uf35a\uf345\uf352\uf347\uf35a\uf35c\uf35d\uf363\uf352\uf350\uf358\uf356\uf347\uf376\uf34b\uf343\uf35a\uf341\uf352\uf347\uf35a\uf35c\uf35d\uf376\uf35e\uf352\uf35a\uf35f\uf360\uf346\uf351\uf359\uf356\uf350\uf347\uf371\uf358\uf352\uf340\uf340\uf352", 62210), _E001);

		public static string ActivationPacketsExpireInCashboxes => ResourceManager.GetString(global::_E000._E000("\uf6fe\uf6dc\uf6cb\uf6d6\uf6c9\uf6de\uf6cb\uf6d6\uf6d0\uf6d1\uf6ef\uf6de\uf6dc\uf6d4\uf6da\uf6cb\uf6cc\uf6fa\uf6c7\uf6cf\uf6d6\uf6cd\uf6da\uf6f6\uf6d1\uf6fc\uf6de\uf6cc\uf6d7\uf6dd\uf6d0\uf6c7\uf6da\uf6cc", 63115), _E001);

		public static string Add => ResourceManager.GetString(global::_E000._E000("\ueef8\ueedd\ueedd", 60985), _E001);

		public static string AddMPVersion => ResourceManager.GetString(global::_E000._E000("\uec1f\uec3a\uec3a\uec13\uec0e\uec08\uec3b\uec2c\uec2d\uec37\uec31\uec30", 60510), _E001);

		public static string AddPosition => ResourceManager.GetString(global::_E000._E000("\ue9f8\ue9dd\ue9dd\ue9e9\ue9d6\ue9ca\ue9d0\ue9cd\ue9d0\ue9d6\ue9d7", 59705), _E001);

		public static string AddTaxFromFile => ResourceManager.GetString(global::_E000._E000("\ue6de\ue6fb\ue6fb\ue6cb\ue6fe\ue6e7\ue6d9\ue6ed\ue6f0\ue6f2\ue6d9\ue6f6\ue6f3\ue6fa", 58903), _E001);

		public static string Administration => ResourceManager.GetString(global::_E000._E000("\ue3ae\ue38b\ue382\ue386\ue381\ue386\ue39c\ue39b\ue39d\ue38e\ue39b\ue386\ue380\ue381", 58317), _E001);

		public static string Advertising => ResourceManager.GetString(global::_E000._E000("\ue9f2\ue9d7\ue9c5\ue9d6\ue9c1\ue9c7\ue9da\ue9c0\ue9da\ue9dd\ue9d4", 59810), _E001);

		public static string AfterDeleteCashboxNotificate => ResourceManager.GetString(global::_E000._E000("\uf0f8\uf0df\uf0cd\uf0dc\uf0cb\uf0fd\uf0dc\uf0d5\uf0dc\uf0cd\uf0dc\uf0fa\uf0d8\uf0ca\uf0d1\uf0db\uf0d6\uf0c1\uf0f7\uf0d6\uf0cd\uf0d0\uf0df\uf0d0\uf0da\uf0d8\uf0cd\uf0dc", 61625), _E001);

		public static string AfterSavingContactWillBeChanged => ResourceManager.GetString(global::_E000._E000("\uf1f8\uf1df\uf1cd\uf1dc\uf1cb\uf1ea\uf1d8\uf1cf\uf1d0\uf1d7\uf1de\uf1fa\uf1d6\uf1d7\uf1cd\uf1d8\uf1da\uf1cd\uf1ee\uf1d0\uf1d5\uf1d5\uf1fb\uf1dc\uf1fa\uf1d1\uf1d8\uf1d7\uf1de\uf1dc\uf1dd", 61753), _E001);

		public static string All => ResourceManager.GetString(global::_E000._E000("\uf0ae\uf083\uf083", 61606), _E001);

		public static string All1CCashboxesCount => ResourceManager.GetString(global::_E000._E000("\ueeb2\uee9f\uee9f\ueec2\ueeb0\ueeb0\uee92\uee80\uee9b\uee91\uee9c\uee8b\uee96\uee80\ueeb0\uee9c\uee86\uee9d\uee87", 61122), _E001);

		public static string AnalyticLicenses => ResourceManager.GetString(global::_E000._E000("\ue9e8\ue9c7\ue9c8\ue9c5\ue9d0\ue9dd\ue9c0\ue9ca\ue9e5\ue9c0\ue9ca\ue9cc\ue9c7\ue9da\ue9cc\ue9da", 59817), _E001);

		public static string AnalyticMonitoring => ResourceManager.GetString(global::_E000._E000("\uf8aa\uf885\uf88a\uf887\uf892\uf89f\uf882\uf888\uf8a6\uf884\uf885\uf882\uf89f\uf884\uf899\uf882\uf885\uf88c", 63555), _E001);

		public static string Analytics => ResourceManager.GetString(global::_E000._E000("\ue0ae\ue081\ue08e\ue083\ue096\ue09b\ue086\ue08c\ue09c", 57546), _E001);

		public static string AnErrorHasOccurredWhileProcessingYourRequestOperatorFiscalDataCashBlocked => ResourceManager.GetString(global::_E000._E000("\uf5ea\uf5c5\uf5ee\uf5d9\uf5d9\uf5c4\uf5d9\uf5e3\uf5ca\uf5d8\uf5e4\uf5c8\uf5c8\uf5de\uf5d9\uf5d9\uf5ce\uf5cf\uf5fc\uf5c3\uf5c2\uf5c7\uf5ce\uf5fb\uf5d9\uf5c4\uf5c8\uf5ce\uf5d8\uf5d8\uf5c2\uf5c5\uf5cc\uf5f2\uf5c4\uf5de\uf5d9\uf5f9\uf5ce\uf5da\uf5de\uf5ce\uf5d8\uf5df\uf5e4\uf5db\uf5ce\uf5d9\uf5ca\uf5df\uf5c4\uf5d9\uf5ed\uf5c2\uf5d8\uf5c8\uf5ca\uf5c7\uf5ef\uf5ca\uf5df\uf5ca\uf5e8\uf5ca\uf5d8\uf5c3\uf5e9\uf5c7\uf5c4\uf5c8\uf5c0\uf5ce\uf5cf", 62883), _E001);

		public static string AnErrorOccurredWhileChangingPIN => ResourceManager.GetString(global::_E000._E000("\uf132\uf11d\uf136\uf101\uf101\uf11c\uf101\uf13c\uf110\uf110\uf106\uf101\uf101\uf116\uf117\uf124\uf11b\uf11a\uf11f\uf116\uf130\uf11b\uf112\uf11d\uf114\uf11a\uf11d\uf114\uf123\uf13a\uf13d", 61778), _E001);

		public static string AnErrorOccurredWhileProcessingTheRequestServer => ResourceManager.GetString(global::_E000._E000("\ue62e\ue601\ue62a\ue61d\ue61d\ue600\ue61d\ue620\ue60c\ue60c\ue61a\ue61d\ue61d\ue60a\ue60b\ue638\ue607\ue606\ue603\ue60a\ue63f\ue61d\ue600\ue60c\ue60a\ue61c\ue61c\ue606\ue601\ue608\ue63b\ue607\ue60a\ue63d\ue60a\ue61e\ue61a\ue60a\ue61c\ue61b\ue63c\ue60a\ue61d\ue619\ue60a\ue61d", 58986), _E001);

		public static string ApplicationName => ResourceManager.GetString(global::_E000._E000("\ue9ac\ue99d\ue99d\ue981\ue984\ue98e\ue98c\ue999\ue984\ue982\ue983\ue9a3\ue98c\ue980\ue988", 59781), _E001);

		public static string ApplicationNameBKassa => ResourceManager.GetString(global::_E000._E000("\uf8fc\uf8cd\uf8cd\uf8d1\uf8d4\uf8de\uf8dc\uf8c9\uf8d4\uf8d2\uf8d3\uf8f3\uf8dc\uf8d0\uf8d8\uf8ff\uf8f6\uf8dc\uf8ce\uf8ce\uf8dc", 63676), _E001);

		public static string ApplyVatRateInSection => ResourceManager.GetString(global::_E000._E000("\ue6ff\ue6ce\ue6ce\ue6d2\ue6c7\ue6e8\ue6df\ue6ca\ue6ec\ue6df\ue6ca\ue6db\ue6f7\ue6d0\ue6ed\ue6db\ue6dd\ue6ca\ue6d7\ue6d1\ue6d0", 59070), _E001);

		public static string April => ResourceManager.GetString(global::_E000._E000("\uebbc\ueb8d\ueb8f\ueb94\ueb91", 60405), _E001);

		public static string AreYouSureToDeleteRecord => ResourceManager.GetString(global::_E000._E000("\uf01c\uf02f\uf038\uf004\uf032\uf028\uf00e\uf028\uf02f\uf038\uf009\uf032\uf019\uf038\uf031\uf038\uf029\uf038\uf00f\uf038\uf03e\uf032\uf02f\uf039", 61448), _E001);

		public static string AreYouSureToDeleteRecord1 => ResourceManager.GetString(global::_E000._E000("\uef1c\uef2f\uef38\uef04\uef32\uef28\uef0e\uef28\uef2f\uef38\uef09\uef32\uef19\uef38\uef31\uef38\uef29\uef38\uef0f\uef38\uef3e\uef32\uef2f\uef39\uef6c", 61256), _E001);

		public static string AreYouSureToSaveChanges => ResourceManager.GetString(global::_E000._E000("\ue2ac\ue29f\ue288\ue2b4\ue282\ue298\ue2be\ue298\ue29f\ue288\ue2b9\ue282\ue2be\ue28c\ue29b\ue288\ue2ae\ue285\ue28c\ue283\ue28a\ue288\ue29e", 58085), _E001);

		public static string AreYouSureToSaveChanges1 => ResourceManager.GetString(global::_E000._E000("\ue19f\ue1ac\ue1bb\ue187\ue1b1\ue1ab\ue18d\ue1ab\ue1ac\ue1bb\ue18a\ue1b1\ue18d\ue1bf\ue1a8\ue1bb\ue19d\ue1b6\ue1bf\ue1b0\ue1b9\ue1bb\ue1ad\ue1ef", 57806), _E001);

		public static string AtLeast1OneDigit => ResourceManager.GetString(global::_E000._E000("\uf63c\uf609\uf631\uf618\uf61c\uf60e\uf609\uf64c\uf632\uf613\uf618\uf639\uf614\uf61a\uf614\uf609", 63029), _E001);

		public static string AtLeast1OneSpecialSymbol => ResourceManager.GetString(global::_E000._E000("\uea3e\uea0b\uea33\uea1a\uea1e\uea0c\uea0b\uea4e\uea30\uea11\uea1a\uea2c\uea0f\uea1a\uea1c\uea16\uea1e\uea13\uea2c\uea06\uea12\uea1d\uea10\uea13", 59979), _E001);

		public static string AtLeast8Symbols => ResourceManager.GetString(global::_E000._E000("\uf2f2\uf2c7\uf2ff\uf2d6\uf2d2\uf2c0\uf2c7\uf28b\uf2e0\uf2ca\uf2de\uf2d1\uf2dc\uf2df\uf2c0", 62130), _E001);

		public static string AttemptsCount => ResourceManager.GetString(global::_E000._E000("\ue663\ue656\ue656\ue647\ue64f\ue652\ue656\ue651\ue661\ue64d\ue657\ue64c\ue656", 58912), _E001);

		public static string Attention => ResourceManager.GetString(global::_E000._E000("\uf4ea\uf4df\uf4df\uf4ce\uf4c5\uf4df\uf4c2\uf4c4\uf4c5", 62595), _E001);

		public static string Attention1 => ResourceManager.GetString(global::_E000._E000("\uf3ea\uf3df\uf3df\uf3ce\uf3c5\uf3df\uf3c2\uf3c4\uf3c5\uf39a", 62371), _E001);

		public static string Attention2 => ResourceManager.GetString(global::_E000._E000("\ue5f3\ue5c6\ue5c6\ue5d7\ue5dc\ue5c6\ue5db\ue5dd\ue5dc\ue580", 58768), _E001);

		public static string August => ResourceManager.GetString(global::_E000._E000("\ue2aa\ue29e\ue28c\ue29e\ue298\ue29f", 57923), _E001);

		public static string AutoCloseShift => ResourceManager.GetString(global::_E000._E000("\ue1aa\ue19e\ue19f\ue184\ue1a8\ue187\ue184\ue198\ue18e\ue1b8\ue183\ue182\ue18d\ue19f", 57825), _E001);

		public static string AutoGeneratePrice => ResourceManager.GetString(global::_E000._E000("\ueb2e\ueb1a\ueb1b\ueb00\ueb28\ueb0a\ueb01\ueb0a\ueb1d\ueb0e\ueb1b\ueb0a\ueb3f\ueb1d\ueb06\ueb0c\ueb0a", 60262), _E001);

		public static string AutonomousBills => ResourceManager.GetString(global::_E000._E000("\ue4fa\ue4ce\ue4cf\ue4d4\ue4d5\ue4d4\ue4d6\ue4d4\ue4ce\ue4c8\ue4f9\ue4d2\ue4d7\ue4d7\ue4c8", 58385), _E001);

		public static string AvailableWhenExistClosedShift => ResourceManager.GetString(global::_E000._E000("\uf286\uf2b1\uf2a6\uf2ae\uf2ab\uf2a6\uf2a5\uf2ab\uf2a2\uf290\uf2af\uf2a2\uf2a9\uf282\uf2bf\uf2ae\uf2b4\uf2b3\uf284\uf2ab\uf2a8\uf2b4\uf2a2\uf2a3\uf294\uf2af\uf2ae\uf2a1\uf2b3", 62084), _E001);

		public static string AvailableWhenHasLicense => ResourceManager.GetString(global::_E000._E000("\uecbe\uec89\uec9e\uec96\uec93\uec9e\uec9d\uec93\uec9a\ueca8\uec97\uec9a\uec91\uecb7\uec9e\uec8c\uecb3\uec96\uec9c\uec9a\uec91\uec8c\uec9a", 60669), _E001);

		public static string AvailableWhenNoOpenShiftExists => ResourceManager.GetString(global::_E000._E000("\ue4ea\ue4dd\ue4ca\ue4c2\ue4c7\ue4ca\ue4c9\ue4c7\ue4ce\ue4fc\ue4c3\ue4ce\ue4c5\ue4e5\ue4c4\ue4e4\ue4db\ue4ce\ue4c5\ue4f8\ue4c3\ue4c2\ue4cd\ue4df\ue4ee\ue4d3\ue4c2\ue4d8\ue4df\ue4d8", 58497), _E001);

		public static string AvailableWhenOffileModeOff => ResourceManager.GetString(global::_E000._E000("\uefec\uefdb\uefcc\uefc4\uefc1\uefcc\uefcf\uefc1\uefc8\ueffa\uefc5\uefc8\uefc3\uefe2\uefcb\uefcb\uefc4\uefc1\uefc8\uefe0\uefc2\uefc9\uefc8\uefe2\uefcb\uefcb", 61356), _E001);

		public static string AvailableWhenShiftClosed => ResourceManager.GetString(global::_E000._E000("\ue5be\ue589\ue59e\ue596\ue593\ue59e\ue59d\ue593\ue59a\ue5a8\ue597\ue59a\ue591\ue5ac\ue597\ue596\ue599\ue58b\ue5bc\ue593\ue590\ue58c\ue59a\ue59b", 58810), _E001);

		public static string BackToProfile => ResourceManager.GetString(global::_E000._E000("\ue1e9\ue1ca\ue1c8\ue1c0\ue1ff\ue1c4\ue1fb\ue1d9\ue1c4\ue1cd\ue1c2\ue1c7\ue1ce", 57731), _E001);

		public static string BIN => ResourceManager.GetString(global::_E000._E000("\uf3b1\uf3ba\uf3bd", 62434), _E001);

		public static string BINDescription => ResourceManager.GetString(global::_E000._E000("\ue9b5\ue9be\ue9b9\ue9b3\ue992\ue984\ue994\ue985\ue99e\ue987\ue983\ue99e\ue998\ue999", 59700), _E001);

		public static string BinIin => ResourceManager.GetString(global::_E000._E000("\uefb9\uef92\uef95\uefb2\uef92\uef95", 61265), _E001);

		public static string BookKeeping => ResourceManager.GetString(global::_E000._E000("\ue6fd\ue6d0\ue6d0\ue6d4\ue6f4\ue6da\ue6da\ue6cf\ue6d6\ue6d1\ue6d8", 58935), _E001);

		public static string BootlingDate => ResourceManager.GetString(global::_E000._E000("\uf471\uf45c\uf45c\uf447\uf45f\uf45a\uf45d\uf454\uf477\uf452\uf447\uf456", 62482), _E001);

		public static string Business => ResourceManager.GetString(global::_E000._E000("\uf8ff\uf8c8\uf8ce\uf8d4\uf8d3\uf8d8\uf8ce\uf8ce", 63676), _E001);

		public static string Buttons => ResourceManager.GetString(global::_E000._E000("\uf35c\uf36b\uf36a\uf36a\uf371\uf370\uf36d", 62238), _E001);

		public static string Buy => ResourceManager.GetString(global::_E000._E000("\uf820\uf817\uf81b", 63552), _E001);

		public static string CallCenter => ResourceManager.GetString(global::_E000._E000("\uf5fc\uf5de\uf5d3\uf5d3\uf5fc\uf5da\uf5d1\uf5cb\uf5da\uf5cd", 62887), _E001);

		public static string CallCenterPurchaseManagement => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf59e\uf593\uf593\uf5bc\uf59a\uf591\uf58b\uf59a\uf58d\uf5af\uf58a\uf58d\uf59c\uf597\uf59e\uf58c\uf59a\uf5b2\uf59e\uf591\uf59e\uf598\uf59a\uf592\uf59a\uf591\uf58b", 62938), _E001);

		public static string Cancel => ResourceManager.GetString(global::_E000._E000("\uef3e\uef1c\uef13\uef1e\uef18\uef11", 61288), _E001);

		public static string CanNotDeleteNotActualSection => ResourceManager.GetString(global::_E000._E000("\ue5b8\ue59a\ue595\ue5b5\ue594\ue58f\ue5bf\ue59e\ue597\ue59e\ue58f\ue59e\ue5b5\ue594\ue58f\ue5ba\ue598\ue58f\ue58e\ue59a\ue597\ue5a8\ue59e\ue598\ue58f\ue592\ue594\ue595", 58833), _E001);

		public static string CanNotDisableVatPayerIfHaveSectionVat => ResourceManager.GetString(global::_E000._E000("\uecba\uec98\uec97\uecb7\uec96\uec8d\uecbd\uec90\uec8a\uec98\uec9b\uec95\uec9c\uecaf\uec98\uec8d\ueca9\uec98\uec80\uec9c\uec8b\uecb0\uec9f\uecb1\uec98\uec8f\uec9c\uecaa\uec9c\uec9a\uec8d\uec90\uec96\uec97\uecaf\uec98\uec8d", 60665), _E001);

		public static string CanNotDisableVatRateIfUsedByCashbox => ResourceManager.GetString(global::_E000._E000("\uedfe\ueddc\uedd3\uedf3\uedd2\uedc9\uedf9\uedd4\uedce\ueddc\ueddf\uedd1\uedd8\uedeb\ueddc\uedc9\uedef\ueddc\uedc9\uedd8\uedf4\ueddb\uede8\uedce\uedd8\uedd9\uedff\uedc4\uedfe\ueddc\uedce\uedd5\ueddf\uedd2\uedc5", 60828), _E001);

		public static string CanNotDisableVatRateIfUsedByPriceOrSection => ResourceManager.GetString(global::_E000._E000("\uf0e8\uf0ca\uf0c5\uf0e5\uf0c4\uf0df\uf0ef\uf0c2\uf0d8\uf0ca\uf0c9\uf0c7\uf0ce\uf0fd\uf0ca\uf0df\uf0f9\uf0ca\uf0df\uf0ce\uf0e2\uf0cd\uf0fe\uf0d8\uf0ce\uf0cf\uf0e9\uf0d2\uf0fb\uf0d9\uf0c2\uf0c8\uf0ce\uf0e4\uf0d9\uf0f8\uf0ce\uf0c8\uf0df\uf0c2\uf0c4\uf0c5", 61443), _E001);

		public static string CanNotEditNotActualSection => ResourceManager.GetString(global::_E000._E000("\ue4b8\ue49a\ue495\ue4b5\ue494\ue48f\ue4be\ue49f\ue492\ue48f\ue4b5\ue494\ue48f\ue4ba\ue498\ue48f\ue48e\ue49a\ue497\ue4a8\ue49e\ue498\ue48f\ue492\ue494\ue495", 58481), _E001);

		public static string CanNotRestorActualSection => ResourceManager.GetString(global::_E000._E000("\uf2a8\uf28a\uf285\uf2a5\uf284\uf29f\uf2b9\uf28e\uf298\uf29f\uf284\uf299\uf2aa\uf288\uf29f\uf29e\uf28a\uf287\uf2b8\uf28e\uf288\uf29f\uf282\uf284\uf285", 62147), _E001);

		public static string CanNotRestoreSectionNotVatPayer => ResourceManager.GetString(global::_E000._E000("\ue23e\ue21c\ue213\ue233\ue212\ue209\ue22f\ue218\ue20e\ue209\ue212\ue20f\ue218\ue22e\ue218\ue21e\ue209\ue214\ue212\ue213\ue233\ue212\ue209\ue22b\ue21c\ue209\ue22d\ue21c\ue204\ue218\ue20f", 57941), _E001);

		public static string CanNotRestoreSectionWithoutSupportTax => ResourceManager.GetString(global::_E000._E000("\uef3c\uef1e\uef11\uef31\uef10\uef0b\uef2d\uef1a\uef0c\uef0b\uef10\uef0d\uef1a\uef2c\uef1a\uef1c\uef0b\uef16\uef10\uef11\uef28\uef16\uef0b\uef17\uef10\uef0a\uef0b\uef2c\uef0a\uef0f\uef0f\uef10\uef0d\uef0b\uef2b\uef1e\uef07", 61210), _E001);

		public static string CantDeleteSection => ResourceManager.GetString(global::_E000._E000("\ue1be\ue19c\ue193\ue189\ue1b9\ue198\ue191\ue198\ue189\ue198\ue1ae\ue198\ue19e\ue189\ue194\ue192\ue193", 57781), _E001);

		public static string CantFindCashbox => ResourceManager.GetString(global::_E000._E000("\ue3bc\ue39e\ue391\ue38b\ue3b9\ue396\ue391\ue39b\ue3bc\ue39e\ue38c\ue397\ue39d\ue390\ue387", 58215), _E001);

		public static string CapacityContainer => ResourceManager.GetString(global::_E000._E000("\ueefc\ueede\ueecf\ueede\ueedc\ueed6\ueecb\ueec6\ueefc\ueed0\ueed1\ueecb\ueede\ueed6\ueed1\ueeda\ueecd", 61087), _E001);

		public static string CaptchaInvalidInputResponse => ResourceManager.GetString(global::_E000._E000("\uf7dc\uf7fe\uf7ef\uf7eb\uf7fc\uf7f7\uf7fe\uf7d6\uf7f1\uf7e9\uf7fe\uf7f3\uf7f6\uf7fb\uf7d6\uf7f1\uf7ef\uf7ea\uf7eb\uf7cd\uf7fa\uf7ec\uf7ef\uf7f0\uf7f1\uf7ec\uf7fa", 63383), _E001);

		public static string CaptchaInvalidInputSecret => ResourceManager.GetString(global::_E000._E000("\uf8bc\uf89e\uf88f\uf88b\uf89c\uf897\uf89e\uf8b6\uf891\uf889\uf89e\uf893\uf896\uf89b\uf8b6\uf891\uf88f\uf88a\uf88b\uf8ac\uf89a\uf89c\uf88d\uf89a\uf88b", 63723), _E001);

		public static string CaptchaMissingInputResponse => ResourceManager.GetString(global::_E000._E000("\uedb0\ued92\ued83\ued87\ued90\ued9b\ued92\uedbe\ued9a\ued80\ued80\ued9a\ued9d\ued94\uedba\ued9d\ued83\ued86\ued87\ueda1\ued96\ued80\ued83\ued9c\ued9d\ued80\ued96", 60898), _E001);

		public static string CaptchaMissingInputSecret => ResourceManager.GetString(global::_E000._E000("\ue8dc\ue8fe\ue8ef\ue8eb\ue8fc\ue8f7\ue8fe\ue8d2\ue8f6\ue8ec\ue8ec\ue8f6\ue8f1\ue8f8\ue8d6\ue8f1\ue8ef\ue8ea\ue8eb\ue8cc\ue8fa\ue8fc\ue8ed\ue8fa\ue8eb", 59415), _E001);

		public static string CaptchaOccurredErrorTryAgain => ResourceManager.GetString(global::_E000._E000("\uedac\ued8e\ued9f\ued9b\ued8c\ued87\ued8e\ueda0\ued8c\ued8c\ued9a\ued9d\ued9d\ued8a\ued8b\uedaa\ued9d\ued9d\ued80\ued9d\uedbb\ued9d\ued96\uedae\ued88\ued8e\ued86\ued81", 60874), _E001);

		public static string Caption => ResourceManager.GetString(global::_E000._E000("\ue361\ue343\ue352\ue356\ue34b\ue34d\ue34c", 58144), _E001);

		public static string CardGeneration => ResourceManager.GetString(global::_E000._E000("\uf4f8\uf4da\uf4c9\uf4df\uf4fc\uf4de\uf4d5\uf4de\uf4c9\uf4da\uf4cf\uf4d2\uf4d4\uf4d5", 62515), _E001);

		public static string Cash => ResourceManager.GetString(global::_E000._E000("\uf030\uf012\uf000\uf01b", 61554), _E001);

		public static string CashBook => ResourceManager.GetString(global::_E000._E000("\uf72e\uf70c\uf71e\uf705\uf72f\uf702\uf702\uf706", 63308), _E001);

		public static string Cashbox => ResourceManager.GetString(global::_E000._E000("\ue0e8\ue0ca\ue0d8\ue0c3\ue0c9\ue0c4\ue0d3", 57347), _E001);

		public static string CashboxAccessDenied => ResourceManager.GetString(global::_E000._E000("\ue9f0\ue9d2\ue9c0\ue9db\ue9d1\ue9dc\ue9cb\ue9f2\ue9d0\ue9d0\ue9d6\ue9c0\ue9c0\ue9f7\ue9d6\ue9dd\ue9da\ue9d6\ue9d7", 59826), _E001);

		public static string CashboxActivation => ResourceManager.GetString(global::_E000._E000("\ue170\ue152\ue140\ue15b\ue151\ue15c\ue14b\ue172\ue150\ue147\ue15a\ue145\ue152\ue147\ue15a\ue15c\ue15d", 57618), _E001);

		public static string CashboxCard => ResourceManager.GetString(global::_E000._E000("\ue39c\ue3be\ue3ac\ue3b7\ue3bd\ue3b0\ue3a7\ue39c\ue3be\ue3ad\ue3bb", 58183), _E001);

		public static string CashboxChangeWorkModeToExitFromOfflineMode => ResourceManager.GetString(global::_E000._E000("\ue6ac\ue68e\ue69c\ue687\ue68d\ue680\ue697\ue6ac\ue687\ue68e\ue681\ue688\ue68a\ue6b8\ue680\ue69d\ue684\ue6a2\ue680\ue68b\ue68a\ue6bb\ue680\ue6aa\ue697\ue686\ue69b\ue6a9\ue69d\ue680\ue682\ue6a0\ue689\ue689\ue683\ue686\ue681\ue68a\ue6a2\ue680\ue68b\ue68a", 59053), _E001);

		public static string CashboxChangeWorkModeToOffline => ResourceManager.GetString(global::_E000._E000("\uf52c\uf50e\uf51c\uf507\uf50d\uf500\uf517\uf52c\uf507\uf50e\uf501\uf508\uf50a\uf538\uf500\uf51d\uf504\uf522\uf500\uf50b\uf50a\uf53b\uf500\uf520\uf509\uf509\uf503\uf506\uf501\uf50a", 62826), _E001);

		public static string CashboxChangeWorkModeToOnline => ResourceManager.GetString(global::_E000._E000("\ue83c\ue81e\ue80c\ue817\ue81d\ue810\ue807\ue83c\ue817\ue81e\ue811\ue818\ue81a\ue828\ue810\ue80d\ue814\ue832\ue810\ue81b\ue81a\ue82b\ue810\ue830\ue811\ue813\ue816\ue811\ue81a", 59446), _E001);

		public static string CashboxCloseShift => ResourceManager.GetString(global::_E000._E000("\ue5b4\ue596\ue584\ue59f\ue595\ue598\ue58f\ue5b4\ue59b\ue598\ue584\ue592\ue5a4\ue59f\ue59e\ue591\ue583", 58676), _E001);

		public static string CashboxControl => ResourceManager.GetString(global::_E000._E000("\ue79c\ue7be\ue7ac\ue7b7\ue7bd\ue7b0\ue7a7\ue79c\ue7b0\ue7b1\ue7ab\ue7ad\ue7b0\ue7b3", 59207), _E001);

		public static string CashboxDefaultDomainType => ResourceManager.GetString(global::_E000._E000("\ue8fc\ue8de\ue8cc\ue8d7\ue8dd\ue8d0\ue8c7\ue8fb\ue8da\ue8d9\ue8de\ue8ca\ue8d3\ue8cb\ue8fb\ue8d0\ue8d2\ue8de\ue8d6\ue8d1\ue8eb\ue8c6\ue8cf\ue8da", 59575), _E001);

		public static string CashBoxEdit => ResourceManager.GetString(global::_E000._E000("\uefb8\uef9a\uef88\uef93\uefb9\uef94\uef83\uefbe\uef9f\uef92\uef8f", 61427), _E001);

		public static string Cashboxes => ResourceManager.GetString(global::_E000._E000("\ue13e\ue11c\ue10e\ue115\ue11f\ue112\ue105\ue118\ue10e", 57640), _E001);

		public static string CashboxForMobileOnly => ResourceManager.GetString(global::_E000._E000("\ue62e\ue60c\ue61e\ue605\ue60f\ue602\ue615\ue62b\ue602\ue61f\ue620\ue602\ue60f\ue604\ue601\ue608\ue622\ue603\ue601\ue614", 58981), _E001);

		public static string CashboxHasRestrictedPacketForMobilePacket => ResourceManager.GetString(global::_E000._E000("\uf1a8\uf18a\uf198\uf183\uf189\uf184\uf193\uf1a3\uf18a\uf198\uf1b9\uf18e\uf198\uf19f\uf199\uf182\uf188\uf19f\uf18e\uf18f\uf1bb\uf18a\uf188\uf180\uf18e\uf19f\uf1ad\uf184\uf199\uf1a6\uf184\uf189\uf182\uf187\uf18e\uf1bb\uf18a\uf188\uf180\uf18e\uf19f", 61921), _E001);

		public static string CashboxInformation => ResourceManager.GetString(global::_E000._E000("\uf23c\uf21e\uf20c\uf217\uf21d\uf210\uf207\uf236\uf211\uf219\uf210\uf20d\uf212\uf21e\uf20b\uf216\uf210\uf211", 62059), _E001);

		public static string CashboxInitialization => ResourceManager.GetString(global::_E000._E000("\uf89c\uf8be\uf8ac\uf8b7\uf8bd\uf8b0\uf8a7\uf896\uf8b1\uf8b6\uf8ab\uf8b6\uf8be\uf8b3\uf8b6\uf8a5\uf8be\uf8ab\uf8b6\uf8b0\uf8b1", 63687), _E001);

		public static string CashboxIsNotActiveUnableToPerformTheOperation => ResourceManager.GetString(global::_E000._E000("\uebac\ueb8e\ueb9c\ueb87\ueb8d\ueb80\ueb97\ueba6\ueb9c\ueba1\ueb80\ueb9b\uebae\ueb8c\ueb9b\ueb86\ueb99\ueb8a\uebba\ueb81\ueb8e\ueb8d\ueb83\ueb8a\uebbb\ueb80\uebbf\ueb8a\ueb9d\ueb89\ueb80\ueb9d\ueb82\uebbb\ueb87\ueb8a\ueba0\ueb9f\ueb8a\ueb9d\ueb8e\ueb9b\ueb86\ueb80\ueb81", 60394), _E001);

		public static string CashboxList => ResourceManager.GetString(global::_E000._E000("\uf6fc\uf6de\uf6cc\uf6d7\uf6dd\uf6d0\uf6c7\uf6f3\uf6d6\uf6cc\uf6cb", 63115), _E001);

		public static string CashboxListRecovery => ResourceManager.GetString(global::_E000._E000("\uf03e\uf01c\uf00e\uf015\uf01f\uf012\uf005\uf031\uf014\uf00e\uf009\uf02f\uf018\uf01e\uf012\uf00b\uf018\uf00f\uf004", 61461), _E001);

		public static string CashboxLockedByRequiredTaxService => ResourceManager.GetString(global::_E000._E000("\uf5f8\uf5da\uf5c8\uf5d3\uf5d9\uf5d4\uf5c3\uf5f7\uf5d4\uf5d8\uf5d0\uf5de\uf5df\uf5f9\uf5c2\uf5e9\uf5de\uf5ca\uf5ce\uf5d2\uf5c9\uf5de\uf5df\uf5ef\uf5da\uf5c3\uf5e8\uf5de\uf5c9\uf5cd\uf5d2\uf5d8\uf5de", 62899), _E001);

		public static string CashboxManagement => ResourceManager.GetString(global::_E000._E000("\uf61e\uf63c\uf62e\uf635\uf63f\uf632\uf625\uf610\uf63c\uf633\uf63c\uf63a\uf638\uf630\uf638\uf633\uf629", 63000), _E001);

		public static string CashboxManagment => ResourceManager.GetString(global::_E000._E000("\uf1be\uf19c\uf18e\uf195\uf19f\uf192\uf185\uf1b0\uf19c\uf193\uf19c\uf19a\uf190\uf198\uf193\uf189", 61864), _E001);

		public static string CashboxModelType => ResourceManager.GetString(global::_E000._E000("\uecac\uec8e\uec9c\uec87\uec8d\uec80\uec97\ueca2\uec80\uec8b\uec8a\uec83\uecbb\uec96\uec9f\uec8a", 60586), _E001);

		public static string CashboxModelWorkMode => ResourceManager.GetString(global::_E000._E000("\uebea\uebc8\uebda\uebc1\uebcb\uebc6\uebd1\uebe4\uebc6\uebcd\uebcc\uebc5\uebfe\uebc6\uebdb\uebc2\uebe4\uebc6\uebcd\uebcc", 60201), _E001);

		public static string CashboxModelWorkModeLastChange => ResourceManager.GetString(global::_E000._E000("\uf4ae\uf48c\uf49e\uf485\uf48f\uf482\uf495\uf4a0\uf482\uf489\uf488\uf481\uf4ba\uf482\uf49f\uf486\uf4a0\uf482\uf489\uf488\uf4a1\uf48c\uf49e\uf499\uf4ae\uf485\uf48c\uf483\uf48a\uf488", 62661), _E001);

		public static string CashboxMonitoring => ResourceManager.GetString(global::_E000._E000("\ue2bc\ue29e\ue28c\ue297\ue29d\ue290\ue287\ue2b2\ue290\ue291\ue296\ue28b\ue290\ue28d\ue296\ue291\ue298", 58079), _E001);

		public static string CashboxName => ResourceManager.GetString(global::_E000._E000("\ued2c\ued0e\ued1c\ued07\ued0d\ued00\ued17\ued21\ued0e\ued02\ued0a", 60746), _E001);

		public static string CashboxNeedSection => ResourceManager.GetString(global::_E000._E000("\uf5da\uf5f8\uf5ea\uf5f1\uf5fb\uf5f6\uf5e1\uf5d7\uf5fc\uf5fc\uf5fd\uf5ca\uf5fc\uf5fa\uf5ed\uf5f0\uf5f6\uf5f7", 62745), _E001);

		public static string CashboxNotRegisteredOrUnavailable => ResourceManager.GetString(global::_E000._E000("\ue2dd\ue2ff\ue2ed\ue2f6\ue2fc\ue2f1\ue2e6\ue2d0\ue2f1\ue2ea\ue2cc\ue2fb\ue2f9\ue2f7\ue2ed\ue2ea\ue2fb\ue2ec\ue2fb\ue2fa\ue2d1\ue2ec\ue2cb\ue2f0\ue2ff\ue2e8\ue2ff\ue2f7\ue2f2\ue2ff\ue2fc\ue2f2\ue2fb", 57998), _E001);

		public static string CashboxProgramming => ResourceManager.GetString(global::_E000._E000("\ue230\ue212\ue200\ue21b\ue211\ue21c\ue20b\ue223\ue201\ue21c\ue214\ue201\ue212\ue21e\ue21e\ue21a\ue21d\ue214", 57922), _E001);

		public static string CashboxRegistration => ResourceManager.GetString(global::_E000._E000("\ue8fc\ue8de\ue8cc\ue8d7\ue8dd\ue8d0\ue8c7\ue8ed\ue8da\ue8d8\ue8d6\ue8cc\ue8cb\ue8cd\ue8de\ue8cb\ue8d6\ue8d0\ue8d1", 59583), _E001);

		public static string CashboxRenewal => ResourceManager.GetString(global::_E000._E000("\uf5fc\uf5de\uf5cc\uf5d7\uf5dd\uf5d0\uf5c7\uf5ed\uf5da\uf5d1\uf5da\uf5c8\uf5de\uf5d3", 62903), _E001);

		public static string CashBoxShort => ResourceManager.GetString(global::_E000._E000("\ue0ac\ue08e\ue09c\ue087\ue0ad\ue080\ue097\ue0bc\ue087\ue080\ue09d\ue09b", 57455), _E001);

		public static string CashboxStatusReport => ResourceManager.GetString(global::_E000._E000("\uf7ee\uf7cc\uf7de\uf7c5\uf7cf\uf7c2\uf7d5\uf7fe\uf7d9\uf7cc\uf7d9\uf7d8\uf7de\uf7ff\uf7c8\uf7dd\uf7c2\uf7df\uf7d9", 63404), _E001);

		public static string CashboxWithCurrentStatusCanNotActivate => ResourceManager.GetString(global::_E000._E000("\uf3ac\uf38e\uf39c\uf387\uf38d\uf380\uf397\uf3b8\uf386\uf39b\uf387\uf3ac\uf39a\uf39d\uf39d\uf38a\uf381\uf39b\uf3bc\uf39b\uf38e\uf39b\uf39a\uf39c\uf3ac\uf38e\uf381\uf3a1\uf380\uf39b\uf3ae\uf38c\uf39b\uf386\uf399\uf38e\uf39b\uf38a", 62287), _E001);

		public static string CashboxWithCurrentStatusCanNotDelete => ResourceManager.GetString(global::_E000._E000("\uee31\uee13\uee01\uee1a\uee10\uee1d\uee0a\uee25\uee1b\uee06\uee1a\uee31\uee07\uee00\uee00\uee17\uee1c\uee06\uee21\uee06\uee13\uee06\uee07\uee01\uee31\uee13\uee1c\uee3c\uee1d\uee06\uee36\uee17\uee1e\uee17\uee06\uee17", 61040), _E001);

		public static string CashboxWithCurrentStatusCanNotEdit => ResourceManager.GetString(global::_E000._E000("\ueb3c\ueb1e\ueb0c\ueb17\ueb1d\ueb10\ueb07\ueb28\ueb16\ueb0b\ueb17\ueb3c\ueb0a\ueb0d\ueb0d\ueb1a\ueb11\ueb0b\ueb2c\ueb0b\ueb1e\ueb0b\ueb0a\ueb0c\ueb3c\ueb1e\ueb11\ueb31\ueb10\ueb0b\ueb3a\ueb1b\ueb16\ueb0b", 60214), _E001);

		public static string CashboxWithCurrentStatusCanNotLock => ResourceManager.GetString(global::_E000._E000("\uf35d\uf37f\uf36d\uf376\uf37c\uf371\uf366\uf349\uf377\uf36a\uf376\uf35d\uf36b\uf36c\uf36c\uf37b\uf370\uf36a\uf34d\uf36a\uf37f\uf36a\uf36b\uf36d\uf35d\uf37f\uf370\uf350\uf371\uf36a\uf352\uf371\uf37d\uf375", 62238), _E001);

		public static string CashboxWithDeletedStatusCanNotUpdate => ResourceManager.GetString(global::_E000._E000("\ued70\ued52\ued40\ued5b\ued51\ued5c\ued4b\ued64\ued5a\ued47\ued5b\ued77\ued56\ued5f\ued56\ued47\ued56\ued57\ued60\ued47\ued52\ued47\ued46\ued40\ued70\ued52\ued5d\ued7d\ued5c\ued47\ued66\ued43\ued57\ued52\ued47\ued56", 60690), _E001);

		public static string CashboxWithDrawal => ResourceManager.GetString(global::_E000._E000("\uecb8\uec9a\uec88\uec93\uec99\uec94\uec83\uecac\uec92\uec8f\uec93\uecbf\uec89\uec9a\uec8c\uec9a\uec97", 60531), _E001);

		public static string CashboxWithOpenShiftCanNotEdit => ResourceManager.GetString(global::_E000._E000("\ued1c\ued3e\ued2c\ued37\ued3d\ued30\ued27\ued08\ued36\ued2b\ued37\ued10\ued2f\ued3a\ued31\ued0c\ued37\ued36\ued39\ued2b\ued1c\ued3e\ued31\ued11\ued30\ued2b\ued1a\ued3b\ued36\ued2b", 60694), _E001);

		public static string CashboxWithThisIDIsAlreadyRegistered => ResourceManager.GetString(global::_E000._E000("\ue9a8\ue98a\ue998\ue983\ue989\ue984\ue993\ue9bc\ue982\ue99f\ue983\ue9bf\ue983\ue982\ue998\ue9a2\ue9af\ue9a2\ue998\ue9aa\ue987\ue999\ue98e\ue98a\ue98f\ue992\ue9b9\ue98e\ue98c\ue982\ue998\ue99f\ue98e\ue999\ue98e\ue98f", 59745), _E001);

		public static string Cashier => ResourceManager.GetString(global::_E000._E000("\ue730\ue712\ue700\ue71b\ue71a\ue716\ue701", 59202), _E001);

		public static string Cashiers => ResourceManager.GetString(global::_E000._E000("\uee9a\ueeb8\ueeaa\ueeb1\ueeb0\ueebc\ueeab\ueeaa", 61017), _E001);

		public static string CashiersReport => ResourceManager.GetString(global::_E000._E000("\ue321\ue303\ue311\ue30a\ue30b\ue307\ue310\ue311\ue330\ue307\ue312\ue30d\ue310\ue316", 58176), _E001);

		public static string CashiersTotal => ResourceManager.GetString(global::_E000._E000("\uebbc\ueb9e\ueb8c\ueb97\ueb96\ueb9a\ueb8d\ueb8c\uebab\ueb90\ueb8b\ueb9e\ueb93", 60415), _E001);

		public static string CashInCashbox => ResourceManager.GetString(global::_E000._E000("\uf5b0\uf592\uf580\uf59b\uf5ba\uf59d\uf5b0\uf592\uf580\uf59b\uf591\uf59c\uf58b", 62962), _E001);

		public static string CashSum => ResourceManager.GetString(global::_E000._E000("\uebfd\uebdf\uebcd\uebd6\uebed\uebcb\uebd3", 60334), _E001);

		public static string CaspiTransactionReports => ResourceManager.GetString(global::_E000._E000("\ue61d\ue63f\ue62d\ue62e\ue637\ue60a\ue62c\ue63f\ue630\ue62d\ue63f\ue63d\ue62a\ue637\ue631\ue630\ue60c\ue63b\ue62e\ue631\ue62c\ue62a\ue62d", 58958), _E001);

		public static string ChangeDate => ResourceManager.GetString(global::_E000._E000("\ue38c\ue3a7\ue3ae\ue3a1\ue3a8\ue3aa\ue38b\ue3ae\ue3bb\ue3aa", 58310), _E001);

		public static string ChangePassword => ResourceManager.GetString(global::_E000._E000("\uee3d\uee16\uee1f\uee10\uee19\uee1b\uee2e\uee1f\uee0d\uee0d\uee09\uee11\uee0c\uee1a", 61038), _E001);

		public static string ChangePasswordForAllEmployees => ResourceManager.GetString(global::_E000._E000("\ue4ae\ue485\ue48c\ue483\ue48a\ue488\ue4bd\ue48c\ue49e\ue49e\ue49a\ue482\ue49f\ue489\ue4ab\ue482\ue49f\ue4ac\ue481\ue481\ue4a8\ue480\ue49d\ue481\ue482\ue494\ue488\ue488\ue49e", 58572), _E001);

		public static string ChangePinCode => ResourceManager.GetString(global::_E000._E000("\uf8f0\uf8db\uf8d2\uf8dd\uf8d4\uf8d6\uf8e3\uf8da\uf8dd\uf8f0\uf8dc\uf8d7\uf8d6", 63650), _E001);

		public static string ChangeProgrammingPINCode => ResourceManager.GetString(global::_E000._E000("\ue1fa\ue1d1\ue1d8\ue1d7\ue1de\ue1dc\ue1e9\ue1cb\ue1d6\ue1de\ue1cb\ue1d8\ue1d4\ue1d4\ue1d0\ue1d7\ue1de\ue1e9\ue1f0\ue1f7\ue1fa\ue1d6\ue1dd\ue1dc", 57657), _E001);

		public static string ChangeSaved => ResourceManager.GetString(global::_E000._E000("\ue4a8\ue483\ue48a\ue485\ue48c\ue48e\ue4b8\ue48a\ue49d\ue48e\ue48f", 58593), _E001);

		public static string ChangeToken => ResourceManager.GetString(global::_E000._E000("\uebea\uebc1\uebc8\uebc7\uebce\uebcc\uebfd\uebc6\uebc2\uebcc\uebc7", 60201), _E001);

		public static string CharSymbolsAndHeight => ResourceManager.GetString(global::_E000._E000("\uec3e\uec15\uec1c\uec0f\uec2e\uec04\uec10\uec1f\uec12\uec11\uec0e\uec3c\uec13\uec19\uec35\uec18\uec14\uec1a\uec15\uec09", 60472), _E001);

		public static string Check => ResourceManager.GetString(global::_E000._E000("\ue80c\ue827\ue82a\ue82c\ue824", 59398), _E001);

		public static string CheckCanceled => ResourceManager.GetString(global::_E000._E000("\uf0b4\uf09f\uf092\uf094\uf09c\uf0b4\uf096\uf099\uf094\uf092\uf09b\uf092\uf093", 61556), _E001);

		public static string CheckClient => ResourceManager.GetString(global::_E000._E000("\ue2ac\ue287\ue28a\ue28c\ue284\ue2ac\ue283\ue286\ue28a\ue281\ue29b", 58090), _E001);

		public static string CheckCount => ResourceManager.GetString(global::_E000._E000("\uf32e\uf305\uf308\uf30e\uf306\uf32e\uf302\uf318\uf303\uf319", 62213), _E001);

		public static string CheckDateTime => ResourceManager.GetString(global::_E000._E000("\ue0ec\ue0c7\ue0ca\ue0cc\ue0c4\ue0eb\ue0ce\ue0db\ue0ca\ue0fb\ue0c6\ue0c2\ue0ca", 57359), _E001);

		public static string CheckDomainType => ResourceManager.GetString(global::_E000._E000("\ue03e\ue015\ue018\ue01e\ue016\ue039\ue012\ue010\ue01c\ue014\ue013\ue029\ue004\ue00d\ue018", 57468), _E001);

		public static string CheckDownloadAvailableWithin3DaysPart1 => ResourceManager.GetString(global::_E000._E000("\uf22e\uf205\uf208\uf20e\uf206\uf229\uf202\uf21a\uf203\uf201\uf202\uf20c\uf209\uf22c\uf21b\uf20c\uf204\uf201\uf20c\uf20f\uf201\uf208\uf23a\uf204\uf219\uf205\uf204\uf203\uf25e\uf229\uf20c\uf214\uf21e\uf23d\uf20c\uf21f\uf219\uf25c", 61989), _E001);

		public static string CheckDownloadAvailableWithin3DaysPart2 => ResourceManager.GetString(global::_E000._E000("\ueaac\uea87\uea8a\uea8c\uea84\ueaab\uea80\uea98\uea81\uea83\uea80\uea8e\uea8b\ueaae\uea99\uea8e\uea86\uea83\uea8e\uea8d\uea83\uea8a\ueab8\uea86\uea9b\uea87\uea86\uea81\ueadc\ueaab\uea8e\uea96\uea9c\ueabf\uea8e\uea9d\uea9b\ueadd", 60106), _E001);

		public static string CheckEdit => ResourceManager.GetString(global::_E000._E000("\uf0bc\uf097\uf09a\uf09c\uf094\uf0ba\uf09b\uf096\uf08b", 61663), _E001);

		public static string CheckExcise => ResourceManager.GetString(global::_E000._E000("\uefbc\uef97\uef9a\uef9c\uef94\uefba\uef87\uef9c\uef96\uef8c\uef9a", 61402), _E001);

		public static string CheckFooter => ResourceManager.GetString(global::_E000._E000("\uec9a\uecb1\uecbc\uecba\uecb2\uec9f\uecb6\uecb6\uecad\uecbc\uecab", 60633), _E001);

		public static string CheckHasNoPosition => ResourceManager.GetString(global::_E000._E000("\ue2bc\ue297\ue29a\ue29c\ue294\ue2b7\ue29e\ue28c\ue2b1\ue290\ue2af\ue290\ue28c\ue296\ue28b\ue296\ue290\ue291", 57975), _E001);

		public static string CheckHasPositionWithAmountOfZero => ResourceManager.GetString(global::_E000._E000("\ue594\ue5bf\ue5b2\ue5b4\ue5bc\ue59f\ue5b6\ue5a4\ue587\ue5b8\ue5a4\ue5be\ue5a3\ue5be\ue5b8\ue5b9\ue580\ue5be\ue5a3\ue5bf\ue596\ue5ba\ue5b8\ue5a2\ue5b9\ue5a3\ue598\ue5b1\ue58d\ue5b2\ue5a5\ue5b8", 58772), _E001);

		public static string CheckHistory => ResourceManager.GetString(global::_E000._E000("\ue0be\ue095\ue098\ue09e\ue096\ue0b5\ue094\ue08e\ue089\ue092\ue08f\ue084", 57525), _E001);

		public static string CheckingDate => ResourceManager.GetString(global::_E000._E000("\uf47d\uf456\uf45b\uf45d\uf455\uf457\uf450\uf459\uf47a\uf45f\uf44a\uf45b", 62526), _E001);

		public static string CheckNotFound => ResourceManager.GetString(global::_E000._E000("\uf79e\uf7b5\uf7b8\uf7be\uf7b6\uf793\uf7b2\uf7a9\uf79b\uf7b2\uf7a8\uf7b3\uf7b9", 63384), _E001);

		public static string CheckNumber => ResourceManager.GetString(global::_E000._E000("\ue57e\ue555\ue558\ue55e\ue556\ue573\ue548\ue550\ue55f\ue558\ue54f", 58684), _E001);

		public static string Checkout => ResourceManager.GetString(global::_E000._E000("\ue67d\ue656\ue65b\ue65d\ue655\ue651\ue64b\ue64a", 58942), _E001);

		public static string CheckoutTape => ResourceManager.GetString(global::_E000._E000("\uf7dd\uf7f6\uf7fb\uf7fd\uf7f5\uf7f1\uf7eb\uf7ea\uf7ca\uf7ff\uf7ee\uf7fb", 63374), _E001);

		public static string CheckoutValue => ResourceManager.GetString(global::_E000._E000("\uf37c\uf357\uf35a\uf35c\uf354\uf350\uf34a\uf34b\uf369\uf35e\uf353\uf34a\uf35a", 62219), _E001);

		public static string CheckPrinter => ResourceManager.GetString(global::_E000._E000("\ue370\ue35b\ue356\ue350\ue358\ue363\ue341\ue35a\ue35d\ue347\ue356\ue341", 58162), _E001);

		public static string CheckRegistrationDate => ResourceManager.GetString(global::_E000._E000("\ueb3c\ueb17\ueb1a\ueb1c\ueb14\ueb2d\ueb1a\ueb18\ueb16\ueb0c\ueb0b\ueb0d\ueb1e\ueb0b\ueb16\ueb10\ueb11\ueb3b\ueb1e\ueb0b\ueb1a", 60283), _E001);

		public static string CheckReport => ResourceManager.GetString(global::_E000._E000("\ue41e\ue435\ue438\ue43e\ue436\ue40f\ue438\ue42d\ue432\ue42f\ue429", 58392), _E001);

		public static string ChecksOperationsPluralMessage => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf597\uf59a\uf59c\uf594\uf58c\uf5b0\uf58f\uf59a\uf58d\uf59e\uf58b\uf596\uf590\uf591\uf58c\uf5af\uf593\uf58a\uf58d\uf59e\uf593\uf5b2\uf59a\uf58c\uf58c\uf59e\uf598\uf59a", 62847), _E001);

		public static string CheckSum => ResourceManager.GetString(global::_E000._E000("\uf770\uf75b\uf756\uf750\uf758\uf760\uf746\uf75e", 63250), _E001);

		public static string CheckSumCantBeMore => ResourceManager.GetString(global::_E000._E000("\ue1e8\ue1c3\ue1ce\ue1c8\ue1c0\ue1f8\ue1de\ue1c6\ue1e8\ue1ca\ue1c5\ue1df\ue1e9\ue1ce\ue1e6\ue1c4\ue1d9\ue1ce", 57635), _E001);

		public static string CheckTicketInOfd => ResourceManager.GetString(global::_E000._E000("\uee5d\uee76\uee7b\uee7d\uee75\uee4a\uee77\uee7d\uee75\uee7b\uee6a\uee57\uee70\uee51\uee78\uee7a", 60942), _E001);

		public static string CheckView => ResourceManager.GetString(global::_E000._E000("\ue6fc\ue6d7\ue6da\ue6dc\ue6d4\ue6e9\ue6d6\ue6da\ue6c8", 59019), _E001);

		public static string CheckWithThisTypeCanNotReturn => ResourceManager.GetString(global::_E000._E000("\ueb3e\ueb15\ueb18\ueb1e\ueb16\ueb2a\ueb14\ueb09\ueb15\ueb29\ueb15\ueb14\ueb0e\ueb29\ueb04\ueb0d\ueb18\ueb3e\ueb1c\ueb13\ueb33\ueb12\ueb09\ueb2f\ueb18\ueb09\ueb08\ueb0f\ueb13", 60277), _E001);

		public static string CheckYourEmailToCompleteTheRegistrationAccount => ResourceManager.GetString(global::_E000._E000("\uf8b8\uf893\uf89e\uf898\uf890\uf8a2\uf894\uf88e\uf889\uf8be\uf896\uf89a\uf892\uf897\uf8af\uf894\uf8b8\uf894\uf896\uf88b\uf897\uf89e\uf88f\uf89e\uf8af\uf893\uf89e\uf8a9\uf89e\uf89c\uf892\uf888\uf88f\uf889\uf89a\uf88f\uf892\uf894\uf895\uf8ba\uf898\uf898\uf894\uf88e\uf895\uf88f", 63729), _E001);

		public static string CheckYourEmailToResetPassword => ResourceManager.GetString(global::_E000._E000("\uef1c\uef37\uef3a\uef3c\uef34\uef06\uef30\uef2a\uef2d\uef1a\uef32\uef3e\uef36\uef33\uef0b\uef30\uef0d\uef3a\uef2c\uef3a\uef2b\uef0f\uef3e\uef2c\uef2c\uef28\uef30\uef2d\uef3b", 61206), _E001);

		public static string ChoiceColumns => ResourceManager.GetString(global::_E000._E000("\uf6f0\uf6db\uf6dc\uf6da\uf6d0\uf6d6\uf6f0\uf6dc\uf6df\uf6c6\uf6de\uf6dd\uf6c0", 63138), _E001);

		public static string ChooseElement => ResourceManager.GetString(global::_E000._E000("\uf1b4\uf19f\uf198\uf198\uf184\uf192\uf1b2\uf19b\uf192\uf19a\uf192\uf199\uf183", 61812), _E001);

		public static string ChooseExciseSeries => ResourceManager.GetString(global::_E000._E000("\ue9b8\ue993\ue994\ue994\ue988\ue99e\ue9be\ue983\ue998\ue992\ue988\ue99e\ue9a8\ue99e\ue989\ue992\ue99e\ue988", 59889), _E001);

		public static string ChooseOptionDropDown => ResourceManager.GetString(global::_E000._E000("\ue1fa\ue1d1\ue1d6\ue1d6\ue1ca\ue1dc\ue1f6\ue1c9\ue1cd\ue1d0\ue1d6\ue1d7\ue1fd\ue1cb\ue1d6\ue1c9\ue1fd\ue1d6\ue1ce\ue1d7", 57785), _E001);

		public static string ChoosingContactPerson => ResourceManager.GetString(global::_E000._E000("\uecbc\uec97\uec90\uec90\uec8c\uec96\uec91\uec98\uecbc\uec90\uec91\uec8b\uec9e\uec9c\uec8b\uecaf\uec9a\uec8d\uec8c\uec90\uec91", 60662), _E001);

		public static string ClearOldPriceList => ResourceManager.GetString(global::_E000._E000("\ue39e\ue3b1\ue3b8\ue3bc\ue3af\ue392\ue3b1\ue3b9\ue38d\ue3af\ue3b4\ue3be\ue3b8\ue391\ue3b4\ue3ae\ue3a9", 58312), _E001);

		public static string ClearPriceList => ResourceManager.GetString(global::_E000._E000("\uf6bc\uf693\uf69a\uf69e\uf68d\uf6af\uf68d\uf696\uf69c\uf69a\uf6b3\uf696\uf68c\uf68b", 63222), _E001);

		public static string ClickHereToEnter => ResourceManager.GetString(global::_E000._E000("\ue83c\ue813\ue816\ue81c\ue814\ue837\ue81a\ue80d\ue81a\ue82b\ue810\ue83a\ue811\ue80b\ue81a\ue80d", 59510), _E001);

		public static string ClickLinkForResetPassword => ResourceManager.GetString(global::_E000._E000("\ue0bc\ue093\ue096\ue09c\ue094\ue0b3\ue096\ue091\ue094\ue0b9\ue090\ue08d\ue0ad\ue09a\ue08c\ue09a\ue08b\ue0af\ue09e\ue08c\ue08c\ue088\ue090\ue08d\ue09b", 57447), _E001);

		public static string ClientInfo => ResourceManager.GetString(global::_E000._E000("\ue5e8\ue5c7\ue5c2\ue5ce\ue5c5\ue5df\ue5e2\ue5c5\ue5cd\ue5c4", 58627), _E001);

		public static string ClientInformation => ResourceManager.GetString(global::_E000._E000("\ue6a4\ue68b\ue68e\ue682\ue689\ue693\ue6ae\ue689\ue681\ue688\ue695\ue68a\ue686\ue693\ue68e\ue688\ue689", 59108), _E001);

		public static string Close => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf593\uf590\uf58c\uf59a", 62967), _E001);

		public static string Code => ResourceManager.GetString(global::_E000._E000("\uef84\uefa8\uefa3\uefa2", 61188), _E001);

		public static string Code1 => ResourceManager.GetString(global::_E000._E000("\uefb8\uef94\uef9f\uef9e\uefca", 61427), _E001);

		public static string CodeDublicatesError => ResourceManager.GetString(global::_E000._E000("\uf2bc\uf290\uf29b\uf29a\uf2bb\uf28a\uf29d\uf293\uf296\uf29c\uf29e\uf28b\uf29a\uf28c\uf2ba\uf28d\uf28d\uf290\uf28d", 62071), _E001);

		public static string Comment => ResourceManager.GetString(global::_E000._E000("\ue72c\ue700\ue702\ue702\ue70a\ue701\ue71b", 59238), _E001);

		public static string CompanyGroup => ResourceManager.GetString(global::_E000._E000("\ue1f8\ue1d4\ue1d6\ue1cb\ue1da\ue1d5\ue1c2\ue1fc\ue1c9\ue1d4\ue1ce\ue1cb", 57745), _E001);

		public static string ConfirmPasswordIfForgotten => ResourceManager.GetString(global::_E000._E000("\uf4ac\uf480\uf481\uf489\uf486\uf49d\uf482\uf4bf\uf48e\uf49c\uf49c\uf498\uf480\uf49d\uf48b\uf4a6\uf489\uf4a9\uf480\uf49d\uf488\uf480\uf49b\uf49b\uf48a\uf481", 62543), _E001);

		public static string ConfirmPasswordReset => ResourceManager.GetString(global::_E000._E000("\uf5bc\uf590\uf591\uf599\uf596\uf58d\uf592\uf5af\uf59e\uf58c\uf58c\uf588\uf590\uf58d\uf59b\uf5ad\uf59a\uf58c\uf59a\uf58b", 62781), _E001);

		public static string ConnectionToString => ResourceManager.GetString(global::_E000._E000("\ue7e8\ue7c4\ue7c5\ue7c5\ue7ce\ue7c8\ue7df\ue7c2\ue7c4\ue7c5\ue7ff\ue7c4\ue7f8\ue7df\ue7d9\ue7c2\ue7c5\ue7cc", 59267), _E001);

		public static string ContactToAdministrator => ResourceManager.GetString(global::_E000._E000("\ue7da\ue7f6\ue7f7\ue7ed\ue7f8\ue7fa\ue7ed\ue7cd\ue7f6\ue7d8\ue7fd\ue7f4\ue7f0\ue7f7\ue7f0\ue7ea\ue7ed\ue7eb\ue7f8\ue7ed\ue7f6\ue7eb", 59289), _E001);

		public static string ContactUs => ResourceManager.GetString(global::_E000._E000("\ueeaa\uee86\uee87\uee9d\uee88\uee8a\uee9d\ueebc\uee9a", 61033), _E001);

		public static string Continue => ResourceManager.GetString(global::_E000._E000("\uf7be\uf792\uf793\uf789\uf794\uf793\uf788\uf798", 63464), _E001);

		public static string Controller => ResourceManager.GetString(global::_E000._E000("\uf8b8\uf894\uf895\uf88f\uf889\uf894\uf897\uf897\uf89e\uf889", 63697), _E001);

		public static string Copy => ResourceManager.GetString(global::_E000._E000("\ue55d\ue571\ue56e\ue567", 58654), _E001);

		public static string Corporation => ResourceManager.GetString(global::_E000._E000("\ue3bc\ue390\ue38d\ue38f\ue390\ue38d\ue39e\ue38b\ue396\ue390\ue391", 58331), _E001);

		public static string Count => ResourceManager.GetString(global::_E000._E000("\ue23c\ue210\ue20a\ue211\ue20b", 57910), _E001);

		public static string CountAndSomeMoreOne => ResourceManager.GetString(global::_E000._E000("\ueffc\uefd0\uefca\uefd1\uefcb\ueffe\uefd1\uefdb\uefec\uefd0\uefd2\uefda\ueff2\uefd0\uefcd\uefda\ueff0\uefd1\uefda", 61375), _E001);

		public static string CountAndSum => ResourceManager.GetString(global::_E000._E000("\uebb8\ueb94\ueb8e\ueb95\ueb8f\uebba\ueb95\ueb9f\ueba8\ueb8e\ueb96", 60403), _E001);

		public static string CountAndSumOne => ResourceManager.GetString(global::_E000._E000("\uf23d\uf211\uf20b\uf210\uf20a\uf23f\uf210\uf21a\uf22d\uf20b\uf213\uf231\uf210\uf21b", 62078), _E001);

		public static string CountShort => ResourceManager.GetString(global::_E000._E000("\uf03d\uf011\uf00b\uf010\uf00a\uf02d\uf016\uf011\uf00c\uf00a", 61550), _E001);

		public static string CourierOrderControl => ResourceManager.GetString(global::_E000._E000("\ue6bc\ue690\ue68a\ue68d\ue696\ue69a\ue68d\ue6b0\ue68d\ue69b\ue69a\ue68d\ue6bc\ue690\ue691\ue68b\ue68d\ue690\ue693", 59037), _E001);

		public static string Create => ResourceManager.GetString(global::_E000._E000("\ueebc\uee8d\uee9a\uee9e\uee8b\uee9a", 61085), _E001);

		public static string CreateOrRestoreSection => ResourceManager.GetString(global::_E000._E000("\uf0e1\uf0d0\uf0c7\uf0c3\uf0d6\uf0c7\uf0ed\uf0d0\uf0f0\uf0c7\uf0d1\uf0d6\uf0cd\uf0d0\uf0c7\uf0f1\uf0c7\uf0c1\uf0d6\uf0cb\uf0cd\uf0cc", 61568), _E001);

		public static string CreateSectionFromFile => ResourceManager.GetString(global::_E000._E000("\ue7f8\ue7c9\ue7de\ue7da\ue7cf\ue7de\ue7e8\ue7de\ue7d8\ue7cf\ue7d2\ue7d4\ue7d5\ue7fd\ue7c9\ue7d4\ue7d6\ue7fd\ue7d2\ue7d7\ue7de", 59155), _E001);

		public static string CurrentSessionLogs => ResourceManager.GetString(global::_E000._E000("\uf7ba\uf78c\uf78b\uf78b\uf79c\uf797\uf78d\uf7aa\uf79c\uf78a\uf78a\uf790\uf796\uf797\uf7b5\uf796\uf79e\uf78a", 63481), _E001);

		public static string CustomerCabinet => ResourceManager.GetString(global::_E000._E000("\ue22c\ue21a\ue21c\ue21b\ue200\ue202\ue20a\ue21d\ue22c\ue20e\ue20d\ue206\ue201\ue20a\ue21b", 57962), _E001);

		public static string CustomerInfo => ResourceManager.GetString(global::_E000._E000("\ueee1\ueed7\ueed1\ueed6\ueecd\ueecf\ueec7\ueed0\ueeeb\ueecc\ueec4\ueecd", 61056), _E001);

		public static string CustomerXIN => ResourceManager.GetString(global::_E000._E000("\ue2aa\ue29c\ue29a\ue29d\ue286\ue284\ue28c\ue29b\ue2b1\ue2a0\ue2a7", 58089), _E001);

		public static string Date => ResourceManager.GetString(global::_E000._E000("\ue8b7\ue892\ue887\ue896", 59586), _E001);

		public static string Day => ResourceManager.GetString(global::_E000._E000("\ueecd\ueee8\ueef0", 61065), _E001);

		public static string Debug => ResourceManager.GetString(global::_E000._E000("\uefbb\uef9a\uef9d\uef8a\uef98", 61435), _E001);

		public static string December => ResourceManager.GetString(global::_E000._E000("\uf2fb\uf2da\uf2dc\uf2da\uf2d2\uf2dd\uf2da\uf2cd", 62119), _E001);

		public static string DefaultVatRateChangeToWithoutVatHtml => ResourceManager.GetString(global::_E000._E000("\uecf6\uecd7\uecd4\uecd3\uecc7\uecde\uecc6\uece4\uecd3\uecc6\uece0\uecd3\uecc6\uecd7\uecf1\uecda\uecd3\uecdc\uecd5\uecd7\uece6\uecdd\uece5\uecdb\uecc6\uecda\uecdd\uecc7\uecc6\uece4\uecd3\uecc6\uecfa\uecc6\uecdf\uecde", 60560), _E001);

		public static string Delete => ResourceManager.GetString(global::_E000._E000("\uf3ef\uf3ce\uf3c7\uf3ce\uf3df\uf3ce", 62337), _E001);

		public static string DeleteCashbox => ResourceManager.GetString(global::_E000._E000("\ue5ab\ue58a\ue583\ue58a\ue59b\ue58a\ue5ac\ue58e\ue59c\ue587\ue58d\ue580\ue597", 58637), _E001);

		public static string DeleteContactPersonModalMessageHtml => ResourceManager.GetString(global::_E000._E000("\ue0ef\ue0ce\ue0c7\ue0ce\ue0df\ue0ce\ue0e8\ue0c4\ue0c5\ue0df\ue0ca\ue0c8\ue0df\ue0fb\ue0ce\ue0d9\ue0d8\ue0c4\ue0c5\ue0e6\ue0c4\ue0cf\ue0ca\ue0c7\ue0e6\ue0ce\ue0d8\ue0d8\ue0ca\ue0cc\ue0ce\ue0e3\ue0df\ue0c6\ue0c7", 57507), _E001);

		public static string Deleted => ResourceManager.GetString(global::_E000._E000("\ue0dd\ue0fc\ue0f5\ue0fc\ue0ed\ue0fc\ue0fd", 57497), _E001);

		public static string DeleteLower => ResourceManager.GetString(global::_E000._E000("\ue4bb\ue49a\ue493\ue49a\ue48b\ue49a\ue4b3\ue490\ue488\ue49a\ue48d", 58471), _E001);

		public static string Demo => ResourceManager.GetString(global::_E000._E000("\ueb39\ueb18\ueb10\ueb12", 60200), _E001);

		public static string DemoAccountLogin => ResourceManager.GetString(global::_E000._E000("\uf2ab\uf28a\uf282\uf280\uf2ae\uf28c\uf28c\uf280\uf29a\uf281\uf29b\uf2a3\uf280\uf288\uf286\uf281", 61997), _E001);

		public static string DemoAccountPassword => ResourceManager.GetString(global::_E000._E000("\ue6ab\ue68a\ue682\ue680\ue6ae\ue68c\ue68c\ue680\ue69a\ue681\ue69b\ue6bf\ue68e\ue69c\ue69c\ue698\ue680\ue69d\ue68b", 59117), _E001);

		public static string DemoAccountRedirectUrl => ResourceManager.GetString(global::_E000._E000("\ueef7\ueed6\ueede\ueedc\ueef2\ueed0\ueed0\ueedc\ueec6\ueedd\ueec7\ueee1\ueed6\ueed7\ueeda\ueec1\ueed6\ueed0\ueec7\ueee6\ueec1\ueedf", 61106), _E001);

		public static string DemoAccountRegistrationInfo => ResourceManager.GetString(global::_E000._E000("\uf0f9\uf0d8\uf0d0\uf0d2\uf0fc\uf0de\uf0de\uf0d2\uf0c8\uf0d3\uf0c9\uf0ef\uf0d8\uf0da\uf0d4\uf0ce\uf0c9\uf0cf\uf0dc\uf0c9\uf0d4\uf0d2\uf0d3\uf0f4\uf0d3\uf0db\uf0d2", 61628), _E001);

		public static string DemoMode => ResourceManager.GetString(global::_E000._E000("\uecfb\uecda\uecd2\uecd0\uecf2\uecd0\uecdb\uecda", 60583), _E001);

		public static string Demonstration => ResourceManager.GetString(global::_E000._E000("\uf8fd\uf8dc\uf8d4\uf8d6\uf8d7\uf8ca\uf8cd\uf8cb\uf8d8\uf8cd\uf8d0\uf8d6\uf8d7", 63673), _E001);

		public static string DepartmentCodeAlreadyExistsError => ResourceManager.GetString(global::_E000._E000("\uee3b\uee1a\uee0f\uee1e\uee0d\uee0b\uee12\uee1a\uee11\uee0b\uee3c\uee10\uee1b\uee1a\uee3e\uee13\uee0d\uee1a\uee1e\uee1b\uee06\uee3a\uee07\uee16\uee0c\uee0b\uee0c\uee3a\uee0d\uee0d\uee10\uee0d", 60986), _E001);

		public static string DepartmentIsUsingIn => ResourceManager.GetString(global::_E000._E000("\ueffb\uefda\uefcf\uefde\uefcd\uefcb\uefd2\uefda\uefd1\uefcb\ueff6\uefcc\uefea\uefcc\uefd6\uefd1\uefd8\ueff6\uefd1", 61247), _E001);

		public static string DepartmentIsUsingIn1 => ResourceManager.GetString(global::_E000._E000("\uf1b7\uf196\uf183\uf192\uf181\uf187\uf19e\uf196\uf19d\uf187\uf1ba\uf180\uf1a6\uf180\uf19a\uf19d\uf194\uf1ba\uf19d\uf1c2", 61938), _E001);

		public static string Deposits => ResourceManager.GetString(global::_E000._E000("\uf5ab\uf58a\uf59f\uf580\uf59c\uf586\uf59b\uf59c", 62890), _E001);

		public static string DepositsOf => ResourceManager.GetString(global::_E000._E000("\ue93b\ue91a\ue90f\ue910\ue90c\ue916\ue90b\ue90c\ue930\ue919", 59771), _E001);

		public static string Deregister => ResourceManager.GetString(global::_E000._E000("\uf68d\uf6ac\uf6bb\uf6ac\uf6ae\uf6a0\uf6ba\uf6bd\uf6ac\uf6bb", 63177), _E001);

		public static string DeregisteredDate => ResourceManager.GetString(global::_E000._E000("\uf499\uf4b8\uf4af\uf4b8\uf4ba\uf4b4\uf4ae\uf4a9\uf4b8\uf4af\uf4b8\uf4b9\uf499\uf4bc\uf4a9\uf4b8", 62680), _E001);

		public static string Details => ResourceManager.GetString(global::_E000._E000("\uecbb\uec9a\uec8b\uec9e\uec96\uec93\uec8c", 60519), _E001);

		public static string Disabled => ResourceManager.GetString(global::_E000._E000("\uebb9\ueb94\ueb8e\ueb9c\ueb9f\ueb91\ueb98\ueb99", 60412), _E001);

		public static string Discount => ResourceManager.GetString(global::_E000._E000("\uec29\uec04\uec1e\uec0e\uec02\uec18\uec03\uec19", 60453), _E001);

		public static string Discounts => ResourceManager.GetString(global::_E000._E000("\uf5bb\uf596\uf58c\uf59c\uf590\uf58a\uf591\uf58b\uf58c", 62970), _E001);

		public static string DiscountText => ResourceManager.GetString(global::_E000._E000("\ueabb\uea96\uea8c\uea9c\uea90\uea8a\uea91\uea8b\ueaab\uea9a\uea87\uea8b", 60159), _E001);

		public static string Document => ResourceManager.GetString(global::_E000._E000("\ue7cd\ue7e6\ue7ea\ue7fc\ue7e4\ue7ec\ue7e7\ue7fd", 59273), _E001);

		public static string DocumentGeneratedOffline => ResourceManager.GetString(global::_E000._E000("\ue7fb\ue7d0\ue7dc\ue7ca\ue7d2\ue7da\ue7d1\ue7cb\ue7f8\ue7da\ue7d1\ue7da\ue7cd\ue7de\ue7cb\ue7da\ue7db\ue7f0\ue7d9\ue7d9\ue7d3\ue7d6\ue7d1\ue7da", 59199), _E001);

		public static string Download => ResourceManager.GetString(global::_E000._E000("\uf729\uf702\uf71a\uf703\uf701\uf702\uf70c\uf709", 63340), _E001);

		public static string Downloadn => ResourceManager.GetString(global::_E000._E000("\ueffd\uefd6\uefce\uefd7\uefd5\uefd6\uefd8\uefdd\uefd7", 61369), _E001);

		public static string DownloadTemplate => ResourceManager.GetString(global::_E000._E000("\ue6fb\ue6d0\ue6c8\ue6d1\ue6d3\ue6d0\ue6de\ue6db\ue6eb\ue6da\ue6d2\ue6cf\ue6d3\ue6de\ue6cb\ue6da", 58935), _E001);

		public static string DriverFor => ResourceManager.GetString(global::_E000._E000("\ue2ff\ue2c9\ue2d2\ue2cd\ue2de\ue2c9\ue2fd\ue2d4\ue2c9", 58033), _E001);

		public static string DriverForRongtaRP326USE => ResourceManager.GetString(global::_E000._E000("\ue9bf\ue989\ue992\ue98d\ue99e\ue989\ue9bd\ue994\ue989\ue9a9\ue994\ue995\ue99c\ue98f\ue99a\ue9a9\ue9ab\ue9c8\ue9c9\ue9cd\ue9ae\ue9a8\ue9be", 59729), _E001);

		public static string DriverForRongtaRP58U => ResourceManager.GetString(global::_E000._E000("\ue1ab\ue19d\ue186\ue199\ue18a\ue19d\ue1a9\ue180\ue19d\ue1bd\ue180\ue181\ue188\ue19b\ue18e\ue1bd\ue1bf\ue1da\ue1d7\ue1ba", 57802), _E001);

		public static string DriverForRongtaRP80W => ResourceManager.GetString(global::_E000._E000("\uf3da\uf3ec\uf3f7\uf3e8\uf3fb\uf3ec\uf3d8\uf3f1\uf3ec\uf3cc\uf3f1\uf3f0\uf3f9\uf3ea\uf3ff\uf3cc\uf3ce\uf3a6\uf3ae\uf3c9", 62366), _E001);

		public static string DueRespect => ResourceManager.GetString(global::_E000._E000("\uecb9\uec88\uec98\uecaf\uec98\uec8e\uec8d\uec98\uec9e\uec89", 60597), _E001);

		public static string Duplicate => ResourceManager.GetString(global::_E000._E000("\uf2bb\uf28a\uf28f\uf293\uf296\uf29c\uf29e\uf28b\uf29a", 62183), _E001);

		public static string DurationOfShiftMoreThan24HoursCloseShift => ResourceManager.GetString(global::_E000._E000("\ue2fd\ue2cc\ue2cb\ue2d8\ue2cd\ue2d0\ue2d6\ue2d7\ue2f6\ue2df\ue2ea\ue2d1\ue2d0\ue2df\ue2cd\ue2f4\ue2d6\ue2cb\ue2dc\ue2ed\ue2d1\ue2d8\ue2d7\ue28b\ue28d\ue2f1\ue2d6\ue2cc\ue2cb\ue2ca\ue2fa\ue2d5\ue2d6\ue2ca\ue2dc\ue2ea\ue2d1\ue2d0\ue2df\ue2cd", 58041), _E001);

		public static string DxAll => ResourceManager.GetString(global::_E000._E000("\uee26\uee1a\uee23\uee0e\uee0e", 61024), _E001);

		public static string DxBlanks => ResourceManager.GetString(global::_E000._E000("\uf8ab\uf897\uf8ad\uf883\uf88e\uf881\uf884\uf89c", 63626), _E001);

		public static string DxSelect => ResourceManager.GetString(global::_E000._E000("\uecfb\uecc7\uecec\uecda\uecd3\uecda\uecdc\ueccb", 60575), _E001);

		public static string Edit => ResourceManager.GetString(global::_E000._E000("\uf1db\uf1fa\uf1f7\uf1ea", 61838), _E001);

		public static string EditLower => ResourceManager.GetString(global::_E000._E000("\uf3da\uf3fb\uf3f6\uf3eb\uf3d3\uf3f0\uf3e8\uf3fa\uf3ed", 62215), _E001);

		public static string EditProfileError => ResourceManager.GetString(global::_E000._E000("\ue22a\ue20b\ue206\ue21b\ue23f\ue21d\ue200\ue209\ue206\ue203\ue20a\ue22a\ue21d\ue21d\ue200\ue21d", 57894), _E001);

		public static string EmailConfirmation => ResourceManager.GetString(global::_E000._E000("\ue376\ue35e\ue352\ue35a\ue35f\ue370\ue35c\ue35d\ue355\ue35a\ue341\ue35e\ue352\ue347\ue35a\ue35c\ue35d", 58146), _E001);

		public static string Employee => ResourceManager.GetString(global::_E000._E000("\ueb3a\ueb12\ueb0f\ueb13\ueb10\ueb06\ueb1a\ueb1a", 60218), _E001);

		public static string EmployeeAdd => ResourceManager.GetString(global::_E000._E000("\ueb38\ueb10\ueb0d\ueb11\ueb12\ueb04\ueb18\ueb18\ueb3c\ueb19\ueb19", 60245), _E001);

		public static string EmployeeCloseShift => ResourceManager.GetString(global::_E000._E000("\ue5fe\ue5d6\ue5cb\ue5d7\ue5d4\ue5c2\ue5de\ue5de\ue5f8\ue5d7\ue5d4\ue5c8\ue5de\ue5e8\ue5d3\ue5d2\ue5dd\ue5cf", 58673), _E001);

		public static string EmployeeEdit => ResourceManager.GetString(global::_E000._E000("\ue22a\ue202\ue21f\ue203\ue200\ue216\ue20a\ue20a\ue22a\ue20b\ue206\ue21b", 57894), _E001);

		public static string EmployeeRegistration => ResourceManager.GetString(global::_E000._E000("\ue8e8\ue8c0\ue8dd\ue8c1\ue8c2\ue8d4\ue8c8\ue8c8\ue8ff\ue8c8\ue8ca\ue8c4\ue8de\ue8d9\ue8df\ue8cc\ue8d9\ue8c4\ue8c2\ue8c3", 59532), _E001);

		public static string EmployeesManage => ResourceManager.GetString(global::_E000._E000("\ueab6\uea9e\uea83\uea9f\uea9c\uea8a\uea96\uea96\uea80\ueabe\uea92\uea9d\uea92\uea94\uea96", 60146), _E001);

		public static string Empty => ResourceManager.GetString(global::_E000._E000("\uf5b8\uf590\uf58d\uf589\uf584", 62888), _E001);

		public static string EmulatorIsStopping => ResourceManager.GetString(global::_E000._E000("\uf49c\uf4b4\uf4ac\uf4b5\uf4b8\uf4ad\uf4b6\uf4ab\uf490\uf4aa\uf48a\uf4ad\uf4b6\uf4a9\uf4a9\uf4b0\uf4b7\uf4be", 62681), _E001);

		public static string EmulatorStartedSuccess => ResourceManager.GetString(global::_E000._E000("\ue136\ue11e\ue106\ue11f\ue112\ue107\ue11c\ue101\ue120\ue107\ue112\ue101\ue107\ue116\ue117\ue120\ue106\ue110\ue110\ue116\ue100\ue100", 57714), _E001);

		public static string EmulatorStopped => ResourceManager.GetString(global::_E000._E000("\ue2f8\ue2d0\ue2c8\ue2d1\ue2dc\ue2c9\ue2d2\ue2cf\ue2ee\ue2c9\ue2d2\ue2cd\ue2cd\ue2d8\ue2d9", 58044), _E001);

		public static string Enabled => ResourceManager.GetString(global::_E000._E000("\uf0fb\uf0d0\uf0df\uf0dc\uf0d2\uf0db\uf0da", 61614), _E001);

		public static string EndPeriod => ResourceManager.GetString(global::_E000._E000("\ue3fa\ue3d1\ue3db\ue3ef\ue3da\ue3cd\ue3d6\ue3d0\ue3db", 58271), _E001);

		public static string English => ResourceManager.GetString(global::_E000._E000("\uf0da\uf0f1\uf0f8\uf0f3\uf0f6\uf0ec\uf0f7", 61463), _E001);

		public static string EnterExciseCode => ResourceManager.GetString(global::_E000._E000("\uebac\ueb87\ueb9d\ueb8c\ueb9b\uebac\ueb91\ueb8a\ueb80\ueb9a\ueb8c\uebaa\ueb86\ueb8d\ueb8c", 60265), _E001);

		public static string EnterTicketNumberForSearch => ResourceManager.GetString(global::_E000._E000("\uf5db\uf5f0\uf5ea\uf5fb\uf5ec\uf5ca\uf5f7\uf5fd\uf5f5\uf5fb\uf5ea\uf5d0\uf5eb\uf5f3\uf5fc\uf5fb\uf5ec\uf5d8\uf5f1\uf5ec\uf5cd\uf5fb\uf5ff\uf5ec\uf5fd\uf5f6", 62862), _E001);

		public static string EnterYourPhoneNumber => ResourceManager.GetString(global::_E000._E000("\ue41b\ue430\ue42a\ue43b\ue42c\ue407\ue431\ue42b\ue42c\ue40e\ue436\ue431\ue430\ue43b\ue410\ue42b\ue433\ue43c\ue43b\ue42c", 58446), _E001);

		public static string EnteYourEmailAddress => ResourceManager.GetString(global::_E000._E000("\ueca2\uec89\uec93\uec82\uecbe\uec88\uec92\uec95\ueca2\uec8a\uec86\uec8e\uec8b\ueca6\uec83\uec83\uec95\uec82\uec94\uec94", 60580), _E001);

		public static string Error => ResourceManager.GetString(global::_E000._E000("\uf5ea\uf5dd\uf5dd\uf5c0\uf5dd", 62863), _E001);

		public static string ErrorOccurred => ResourceManager.GetString(global::_E000._E000("\uf89a\uf8ad\uf8ad\uf8b0\uf8ad\uf890\uf8bc\uf8bc\uf8aa\uf8ad\uf8ad\uf8ba\uf8bb", 63703), _E001);

		public static string Errors => ResourceManager.GetString(global::_E000._E000("\uf692\uf6a5\uf6a5\uf6b8\uf6a5\uf6a4", 63124), _E001);

		public static string ErrorText => ResourceManager.GetString(global::_E000._E000("\ueffb\uefcc\uefcc\uefd1\uefcc\uefea\uefdb\uefc6\uefca", 61374), _E001);

		public static string Example => ResourceManager.GetString(global::_E000._E000("\uf87a\uf847\uf85e\uf852\uf84f\uf853\uf85a", 63499), _E001);

		public static string Exception => ResourceManager.GetString(global::_E000._E000("\ueb37\ueb0a\ueb11\ueb17\ueb02\ueb06\ueb1b\ueb1d\ueb1c", 60272), _E001);

		public static string ExchangeMode => ResourceManager.GetString(global::_E000._E000("\uf4aa\uf497\uf48c\uf487\uf48e\uf481\uf488\uf48a\uf4a2\uf480\uf48b\uf48a", 62671), _E001);

		public static string ExchangeModePriceList => ResourceManager.GetString(global::_E000._E000("\uf6ae\uf693\uf688\uf683\uf68a\uf685\uf68c\uf68e\uf6a6\uf684\uf68f\uf68e\uf6bb\uf699\uf682\uf688\uf68e\uf6a7\uf682\uf698\uf69f", 63073), _E001);

		public static string ExciseCode => ResourceManager.GetString(global::_E000._E000("\uf2dc\uf2e1\uf2fa\uf2f0\uf2ea\uf2fc\uf2da\uf2f6\uf2fd\uf2fc", 61977), _E001);

		public static string ExciseLicenses => ResourceManager.GetString(global::_E000._E000("\ue1ba\ue187\ue19c\ue196\ue18c\ue19a\ue1b3\ue196\ue19c\ue19a\ue191\ue18c\ue19a\ue18c", 57851), _E001);

		public static string Excises => ResourceManager.GetString(global::_E000._E000("\uf4a8\uf495\uf48e\uf484\uf49e\uf488\uf49e", 62629), _E001);

		public static string ExciseSerial => ResourceManager.GetString(global::_E000._E000("\uf276\uf24b\uf250\uf25a\uf240\uf256\uf260\uf256\uf241\uf25a\uf252\uf25f", 62002), _E001);

		public static string Exit => ResourceManager.GetString(global::_E000._E000("\uecba\uec87\uec96\uec8b", 60666), _E001);

		public static string ExpirationOfLicenses => ResourceManager.GetString(global::_E000._E000("\ue97b\ue946\ue94e\ue957\ue94c\ue95f\ue94a\ue957\ue951\ue950\ue971\ue958\ue972\ue957\ue95d\ue95b\ue950\ue94d\ue95b\ue94d", 59694), _E001);

		public static string ExpiringPacketsCount => ResourceManager.GetString(global::_E000._E000("\uef38\uef05\uef0d\uef14\uef0f\uef14\uef13\uef1a\uef2d\uef1c\uef1e\uef16\uef18\uef09\uef0e\uef3e\uef12\uef08\uef13\uef09", 61276), _E001);

		public static string Export => ResourceManager.GetString(global::_E000._E000("\uf61b\uf626\uf62e\uf631\uf62c\uf62a", 63054), _E001);

		public static string ExternalCashboxes => ResourceManager.GetString(global::_E000._E000("\ueebe\uee83\uee8f\uee9e\uee89\uee95\uee9a\uee97\ueeb8\uee9a\uee88\uee93\uee99\uee94\uee83\uee9e\uee88", 61139), _E001);

		public static string ExternalOrderNumber => ResourceManager.GetString(global::_E000._E000("\ue9b2\ue98f\ue983\ue992\ue985\ue999\ue996\ue99b\ue9b8\ue985\ue993\ue992\ue985\ue9b9\ue982\ue99a\ue995\ue992\ue985", 59828), _E001);

		public static string ExternalOrganizationCashboxes => ResourceManager.GetString(global::_E000._E000("\ue238\ue205\ue209\ue218\ue20f\ue213\ue21c\ue211\ue232\ue20f\ue21a\ue21c\ue213\ue214\ue207\ue21c\ue209\ue214\ue212\ue213\ue23e\ue21c\ue20e\ue215\ue21f\ue212\ue205\ue218\ue20e", 57941), _E001);

		public static string ExternalOrganizationTitle => ResourceManager.GetString(global::_E000._E000("\uea0a\uea37\uea3b\uea2a\uea3d\uea21\uea2e\uea23\uea00\uea3d\uea28\uea2e\uea21\uea26\uea35\uea2e\uea3b\uea26\uea20\uea21\uea1b\uea26\uea3b\uea23\uea2a", 59910), _E001);

		public static string Fails => ResourceManager.GetString(global::_E000._E000("\ueda9\ued8e\ued86\ued83\ued9c", 60749), _E001);

		public static string Fatal => ResourceManager.GetString(global::_E000._E000("\uf8b1\uf896\uf883\uf896\uf89b", 63668), _E001);

		public static string Fdo => ResourceManager.GetString(global::_E000._E000("\ue118\ue13a\ue131", 57694), _E001);

		public static string February => ResourceManager.GetString(global::_E000._E000("\ue6ed\ue6ce\ue6c9\ue6d9\ue6de\ue6ca\ue6d9\ue6d2", 59009), _E001);

		public static string FillXinField => ResourceManager.GetString(global::_E000._E000("\ue1bb\ue194\ue191\ue191\ue1a5\ue194\ue193\ue1bb\ue194\ue198\ue191\ue199", 57784), _E001);

		public static string FindTicketsByOrderNumber => ResourceManager.GetString(global::_E000._E000("\ue71b\ue734\ue733\ue739\ue709\ue734\ue73e\ue736\ue738\ue729\ue72e\ue71f\ue724\ue712\ue72f\ue739\ue738\ue72f\ue713\ue728\ue730\ue73f\ue738\ue72f", 59208), _E001);

		public static string FirstOperationMessage => ResourceManager.GetString(global::_E000._E000("\ueeb1\uee9e\uee85\uee84\uee83\ueeb8\uee87\uee92\uee85\uee96\uee83\uee9e\uee98\uee99\ueeba\uee92\uee84\uee84\uee96\uee90\uee92", 60980), _E001);

		public static string Fiscal => ResourceManager.GetString(global::_E000._E000("\uf21b\uf234\uf22e\uf23e\uf23c\uf231", 62040), _E001);

		public static string FiscalAttribute => ResourceManager.GetString(global::_E000._E000("\uedf9\uedd6\uedcc\ueddc\uedde\uedd3\uedfe\uedcb\uedcb\uedcd\uedd6\ueddd\uedca\uedcb\uedda", 60711), _E001);

		public static string FiscalCheck => ResourceManager.GetString(global::_E000._E000("\uef1b\uef34\uef2e\uef3e\uef3c\uef31\uef1e\uef35\uef38\uef3e\uef36", 61192), _E001);

		public static string FiscalDataOperator => ResourceManager.GetString(global::_E000._E000("\ue5bb\ue594\ue58e\ue59e\ue59c\ue591\ue5b9\ue59c\ue589\ue59c\ue5b2\ue58d\ue598\ue58f\ue59c\ue589\ue592\ue58f", 58869), _E001);

		public static string FiscalSign => ResourceManager.GetString(global::_E000._E000("\ue8ed\ue8c2\ue8d8\ue8c8\ue8ca\ue8c7\ue8f8\ue8c2\ue8cc\ue8c5", 59427), _E001);

		public static string ForCheckGoToTheWebsite => ResourceManager.GetString(global::_E000._E000("\uf1a4\uf18d\uf190\uf1a1\uf18a\uf187\uf181\uf189\uf1a5\uf18d\uf1b6\uf18d\uf1b6\uf18a\uf187\uf1b5\uf187\uf180\uf191\uf18b\uf196\uf187", 61888), _E001);

		public static string ForContinuePressOk => ResourceManager.GetString(global::_E000._E000("\uec9f\uecb6\uecab\uec9a\uecb6\uecb7\uecad\uecb0\uecb7\uecac\uecbc\uec89\uecab\uecbc\uecaa\uecaa\uec96\uecb2", 60505), _E001);

		public static string ForgotPassword => ResourceManager.GetString(global::_E000._E000("\uee64\uee4d\uee50\uee45\uee4d\uee56\uee72\uee43\uee51\uee51\uee55\uee4d\uee50\uee46", 60960), _E001);

		public static string FormatNotSupported => ResourceManager.GetString(global::_E000._E000("\ue674\ue65d\ue640\ue65f\ue653\ue646\ue67c\ue65d\ue646\ue661\ue647\ue642\ue642\ue65d\ue640\ue646\ue657\ue656", 58896), _E001);

		public static string FP => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue7bf", 59373), _E001);

		public static string FullName => ResourceManager.GetString(global::_E000._E000("\uf3b1\uf382\uf39b\uf39b\uf3b9\uf396\uf39a\uf392", 62324), _E001);

		public static string GeneratedByFdo => ResourceManager.GetString(global::_E000._E000("\ue3b8\ue39a\ue391\ue39a\ue38d\ue39e\ue38b\ue39a\ue39b\ue3bd\ue386\ue3b9\ue39b\ue390", 58363), _E001);

		public static string GetCashbox => ResourceManager.GetString(global::_E000._E000("\ue090\ue0b2\ue0a3\ue094\ue0b6\ue0a4\ue0bf\ue0b5\ue0b8\ue0af", 57556), _E001);

		public static string GetDemoAccount => ResourceManager.GetString(global::_E000._E000("\ue3b5\ue397\ue386\ue3b6\ue397\ue39f\ue39d\ue3b3\ue391\ue391\ue39d\ue387\ue39c\ue386", 58320), _E001);

		public static string GetPassword => ResourceManager.GetString(global::_E000._E000("\uf190\uf1b2\uf1a3\uf187\uf1b6\uf1a4\uf1a4\uf1a0\uf1b8\uf1a5\uf1b3", 61780), _E001);

		public static string GoToBack => ResourceManager.GetString(global::_E000._E000("\uf190\uf1b8\uf183\uf1b8\uf195\uf1b6\uf1b4\uf1bc", 61908), _E001);

		public static string HasNoOperation => ResourceManager.GetString(global::_E000._E000("\ueab7\uea9e\uea8c\ueab1\uea90\ueab0\uea8f\uea9a\uea8d\uea9e\uea8b\uea96\uea90\uea91", 60123), _E001);

		public static string HaveQuestions => ResourceManager.GetString(global::_E000._E000("\ue9b5\ue99c\ue98b\ue998\ue9ac\ue988\ue998\ue98e\ue989\ue994\ue992\ue993\ue98e", 59880), _E001);

		public static string Help => ResourceManager.GetString(global::_E000._E000("\ue875\ue858\ue851\ue84d", 59452), _E001);

		public static string HistoryChecks => ResourceManager.GetString(global::_E000._E000("\uf315\uf334\uf32e\uf329\uf332\uf32f\uf324\uf31e\uf335\uf338\uf33e\uf336\uf32e", 62232), _E001);

		public static string HistoryOfCheckups => ResourceManager.GetString(global::_E000._E000("\uefa7\uef86\uef9c\uef9b\uef80\uef9d\uef96\uefa0\uef89\uefac\uef87\uef8a\uef8c\uef84\uef9a\uef9f\uef9c", 61386), _E001);

		public static string Home => ResourceManager.GetString(global::_E000._E000("\uec6a\uec4d\uec4f\uec47", 60416), _E001);

		public static string Hour => ResourceManager.GetString(global::_E000._E000("\ue1fb\ue1dc\ue1c6\ue1c1", 57762), _E001);

		public static string Identity => ResourceManager.GetString(global::_E000._E000("\ueaf6\ueadb\ueada\uead1\ueacb\uead6\ueacb\ueac6", 59959), _E001);

		public static string IgnorePositionWithNewSection => ResourceManager.GetString(global::_E000._E000("\ue3ba\ue394\ue39d\ue39c\ue381\ue396\ue3a3\ue39c\ue380\ue39a\ue387\ue39a\ue39c\ue39d\ue3a4\ue39a\ue387\ue39b\ue3bd\ue396\ue384\ue3a0\ue396\ue390\ue387\ue39a\ue39c\ue39d", 58354), _E001);

		public static string IIN => ResourceManager.GetString(global::_E000._E000("\uf5ba\uf5ba\uf5bd", 62946), _E001);

		public static string IINDescription => ResourceManager.GetString(global::_E000._E000("\uea57\uea57\uea50\uea5a\uea7b\uea6d\uea7d\uea6c\uea77\uea6e\uea6a\uea77\uea71\uea70", 59918), _E001);

		public static string ImpossibleFindTheVatRate => ResourceManager.GetString(global::_E000._E000("\ue3a6\ue382\ue39f\ue380\ue39c\ue39c\ue386\ue38d\ue383\ue38a\ue3a9\ue386\ue381\ue38b\ue3bb\ue387\ue38a\ue3b9\ue38e\ue39b\ue3bd\ue38e\ue39b\ue38a", 58282), _E001);

		public static string ImpossibleFindTheVatRate1 => ResourceManager.GetString(global::_E000._E000("\uf036\uf012\uf00f\uf010\uf00c\uf00c\uf016\uf01d\uf013\uf01a\uf039\uf016\uf011\uf01b\uf02b\uf017\uf01a\uf029\uf01e\uf00b\uf02d\uf01e\uf00b\uf01a\uf04e", 61547), _E001);

		public static string IncorrectCodeField => ResourceManager.GetString(global::_E000._E000("\ue29e\ue2b9\ue2b4\ue2b8\ue2a5\ue2a5\ue2b2\ue2b4\ue2a3\ue294\ue2b8\ue2b3\ue2b2\ue291\ue2be\ue2b2\ue2bb\ue2b3", 58004), _E001);

		public static string IncorrectlyFilledDataByTemplate => ResourceManager.GetString(global::_E000._E000("\ued24\ued03\ued0e\ued02\ued1f\ued1f\ued08\ued0e\ued19\ued01\ued14\ued2b\ued04\ued01\ued01\ued08\ued09\ued29\ued0c\ued19\ued0c\ued2f\ued14\ued39\ued08\ued00\ued1d\ued01\ued0c\ued19\ued08", 60748), _E001);

		public static string IncorrectMarkingRequiredField => ResourceManager.GetString(global::_E000._E000("\ue936\ue911\ue91c\ue910\ue90d\ue90d\ue91a\ue91c\ue90b\ue932\ue91e\ue90d\ue914\ue916\ue911\ue918\ue92d\ue91a\ue90e\ue90a\ue916\ue90d\ue91a\ue91b\ue939\ue916\ue91a\ue913\ue91b", 59770), _E001);

		public static string IncorrectPriceField => ResourceManager.GetString(global::_E000._E000("\ue234\ue213\ue21e\ue212\ue20f\ue20f\ue218\ue21e\ue209\ue22d\ue20f\ue214\ue21e\ue218\ue23b\ue214\ue218\ue211\ue219", 57980), _E001);

		public static string IncorrectUnitField => ResourceManager.GetString(global::_E000._E000("\uf7b6\uf791\uf79c\uf790\uf78d\uf78d\uf79a\uf79c\uf78b\uf7aa\uf791\uf796\uf78b\uf7b9\uf796\uf79a\uf793\uf79b", 63435), _E001);

		public static string IncorrectVatField => ResourceManager.GetString(global::_E000._E000("\uea7a\uea5d\uea50\uea5c\uea41\uea41\uea56\uea50\uea47\uea65\uea52\uea47\uea75\uea5a\uea56\uea5f\uea57", 59922), _E001);

		public static string Info => ResourceManager.GetString(global::_E000._E000("\ue224\ue203\ue20b\ue202", 57932), _E001);

		public static string Information => ResourceManager.GetString(global::_E000._E000("\uf4e6\uf4c1\uf4c9\uf4c0\uf4dd\uf4c2\uf4ce\uf4db\uf4c6\uf4c0\uf4c1", 62607), _E001);

		public static string InspectorCabinet => ResourceManager.GetString(global::_E000._E000("\uf574\uf553\uf54e\uf54d\uf558\uf55e\uf549\uf552\uf54f\uf57e\uf55c\uf55f\uf554\uf553\uf558\uf549", 62748), _E001);

		public static string InspectorCabinetShort => ResourceManager.GetString(global::_E000._E000("\ueabb\uea9c\uea81\uea82\uea97\uea91\uea86\uea9d\uea80\ueab1\uea93\uea90\uea9b\uea9c\uea97\uea86\ueaa1\uea9a\uea9d\uea80\uea86", 60112), _E001);

		public static string Integrators => ResourceManager.GetString(global::_E000._E000("\ue0ae\ue089\ue093\ue082\ue080\ue095\ue086\ue093\ue088\ue095\ue094", 57380), _E001);

		public static string InternalAnalytic => ResourceManager.GetString(global::_E000._E000("\uf68e\uf6a9\uf6b3\uf6a2\uf6b5\uf6a9\uf6a6\uf6ab\uf686\uf6a9\uf6a6\uf6ab\uf6be\uf6b3\uf6ae\uf6a4", 62980), _E001);

		public static string IsPartner1C => ResourceManager.GetString(global::_E000._E000("\uf3a6\uf39c\uf3bf\uf38e\uf39d\uf39b\uf381\uf38a\uf39d\uf3de\uf3ac", 62346), _E001);

		public static string IssueYear => ResourceManager.GetString(global::_E000._E000("\ue6e0\ue6da\ue6da\ue6dc\ue6cc\ue6f0\ue6cc\ue6c8\ue6db", 59049), _E001);

		public static string January => ResourceManager.GetString(global::_E000._E000("\ue3a7\ue38c\ue383\ue398\ue38c\ue39f\ue394", 58341), _E001);

		public static string July => ResourceManager.GetString(global::_E000._E000("\ueb34\ueb0b\ueb12\ueb07", 60286), _E001);

		public static string June => ResourceManager.GetString(global::_E000._E000("\ue105\ue13a\ue121\ue12a", 57606), _E001);

		public static string JusanOffer => ResourceManager.GetString(global::_E000._E000("\uecb1\uec8e\uec88\uec9a\uec95\uecb4\uec9d\uec9d\uec9e\uec89", 60659), _E001);

		public static string KaspiLicenses => ResourceManager.GetString(global::_E000._E000("\ue9e2\ue9c8\ue9da\ue9d9\ue9c0\ue9e5\ue9c0\ue9ca\ue9cc\ue9c7\ue9da\ue9cc\ue9da", 59689), _E001);

		public static string Kazakh => ResourceManager.GetString(global::_E000._E000("\uf6e0\uf6ca\uf6d1\uf6ca\uf6c0\uf6c3", 63009), _E001);

		public static string KeruenCashboxes => ResourceManager.GetString(global::_E000._E000("\ue4b4\ue49a\ue48d\ue48a\ue49a\ue491\ue4bc\ue49e\ue48c\ue497\ue49d\ue490\ue487\ue49a\ue48c", 58397), _E001);

		public static string KgdRegistrationForm => ResourceManager.GetString(global::_E000._E000("\uf69c\uf6b0\uf6b3\uf685\uf6b2\uf6b0\uf6be\uf6a4\uf6a3\uf6a5\uf6b6\uf6a3\uf6be\uf6b8\uf6b9\uf691\uf6b8\uf6a5\uf6ba", 62996), _E001);

		public static string KnokoutCheck => ResourceManager.GetString(global::_E000._E000("\uedf0\uedd5\uedd4\uedd0\uedd4\uedce\uedcf\uedf8\uedd3\uedde\uedd8\uedd0", 60691), _E001);

		public static string KOfdServiceCenterActivity => ResourceManager.GetString(global::_E000._E000("\uf515\uf511\uf538\uf53a\uf50d\uf53b\uf52c\uf528\uf537\uf53d\uf53b\uf51d\uf53b\uf530\uf52a\uf53b\uf52c\uf51f\uf53d\uf52a\uf537\uf528\uf537\uf52a\uf527", 62798), _E001);

		public static string LablePrintDate => ResourceManager.GetString(global::_E000._E000("\ue031\ue01c\ue01f\ue011\ue018\ue02d\ue00f\ue014\ue013\ue009\ue039\ue01c\ue009\ue018", 57400), _E001);

		public static string LanguageShortKz => ResourceManager.GetString(global::_E000._E000("\ue86e\ue843\ue84c\ue845\ue857\ue843\ue845\ue847\ue871\ue84a\ue84d\ue850\ue856\ue869\ue858", 59424), _E001);

		public static string LanguageShortRus => ResourceManager.GetString(global::_E000._E000("\uf093\uf0be\uf0b1\uf0b8\uf0aa\uf0be\uf0b8\uf0ba\uf08c\uf0b7\uf0b0\uf0ad\uf0ab\uf08d\uf0aa\uf0ac", 61590), _E001);

		public static string Licenses => ResourceManager.GetString(global::_E000._E000("\ueaa3\uea86\uea8c\uea8a\uea81\uea9c\uea8a\uea9c", 60143), _E001);

		public static string LinkForCheck => ResourceManager.GetString(global::_E000._E000("\uf6b3\uf696\uf691\uf694\uf6b9\uf690\uf68d\uf6bc\uf697\uf69a\uf69c\uf694", 63069), _E001);

		public static string LinkToCashboxRegistration => ResourceManager.GetString(global::_E000._E000("\ue1f3\ue1d6\ue1d1\ue1d4\ue1eb\ue1d0\ue1fc\ue1de\ue1cc\ue1d7\ue1dd\ue1d0\ue1c7\ue1ed\ue1da\ue1d8\ue1d6\ue1cc\ue1cb\ue1cd\ue1de\ue1cb\ue1d6\ue1d0\ue1d1", 57755), _E001);

		public static string LitePackets => ResourceManager.GetString(global::_E000._E000("\ue0a1\ue084\ue099\ue088\ue0bd\ue08c\ue08e\ue086\ue088\ue099\ue09e", 57477), _E001);

		public static string Load => ResourceManager.GetString(global::_E000._E000("\ueff7\uefd4\uefda\uefdf", 61331), _E001);

		public static string LoadFileVatValueErrorFull => ResourceManager.GetString(global::_E000._E000("\ue7d3\ue7f0\ue7fe\ue7fb\ue7d9\ue7f6\ue7f3\ue7fa\ue7c9\ue7fe\ue7eb\ue7c9\ue7fe\ue7f3\ue7ea\ue7fa\ue7da\ue7ed\ue7ed\ue7f0\ue7ed\ue7d9\ue7ea\ue7f3\ue7f3", 59271), _E001);

		public static string LoadFileVatValueErrorShort => ResourceManager.GetString(global::_E000._E000("\uebf7\uebd4\uebda\uebdf\uebfd\uebd2\uebd7\uebde\uebed\uebda\uebcf\uebed\uebda\uebd7\uebce\uebde\uebfe\uebc9\uebc9\uebd4\uebc9\uebe8\uebd3\uebd4\uebc9\uebcf", 60179), _E001);

		public static string Loading => ResourceManager.GetString(global::_E000._E000("\uedb1\ued92\ued9c\ued99\ued94\ued93\ued9a", 60885), _E001);

		public static string LoadingWait => ResourceManager.GetString(global::_E000._E000("\ue3b3\ue390\ue39e\ue39b\ue396\ue391\ue398\ue3a8\ue39e\ue396\ue38b", 58237), _E001);

		public static string LoadOrder => ResourceManager.GetString(global::_E000._E000("\uf0f3\uf0d0\uf0de\uf0db\uf0f0\uf0cd\uf0db\uf0da\uf0cd", 61611), _E001);

		public static string LoadPricelist => ResourceManager.GetString(global::_E000._E000("\uec85\ueca6\ueca8\uecad\uec99\uecbb\ueca0\uecaa\uecac\ueca5\ueca0\uecba\uecbd", 60617), _E001);

		public static string Locked => ResourceManager.GetString(global::_E000._E000("\ue731\ue712\ue71e\ue716\ue718\ue719", 59189), _E001);

		public static string Login => ResourceManager.GetString(global::_E000._E000("\ueab3\uea90\uea98\uea96\uea91", 59933), _E001);

		public static string LoginSlogan1 => ResourceManager.GetString(global::_E000._E000("\ue4a3\ue480\ue488\ue486\ue481\ue4bc\ue483\ue480\ue488\ue48e\ue481\ue4de", 58534), _E001);

		public static string LoginSlogan2 => ResourceManager.GetString(global::_E000._E000("\ueeb5\uee96\uee9e\uee90\uee97\ueeaa\uee95\uee96\uee9e\uee98\uee97\ueecb", 61177), _E001);

		public static string Logon => ResourceManager.GetString(global::_E000._E000("\ue1a3\ue180\ue188\ue180\ue181", 57766), _E001);

		public static string ManagerCabint => ResourceManager.GetString(global::_E000._E000("\uf0fe\uf0d2\uf0dd\uf0d2\uf0d4\uf0d6\uf0c1\uf0f0\uf0d2\uf0d1\uf0da\uf0dd\uf0c7", 61570), _E001);

		public static string ManageServiceCenter => ResourceManager.GetString(global::_E000._E000("\ue712\ue73e\ue731\ue73e\ue738\ue73a\ue70c\ue73a\ue72d\ue729\ue736\ue73c\ue73a\ue71c\ue73a\ue731\ue72b\ue73a\ue72d", 59222), _E001);

		public static string Manual => ResourceManager.GetString(global::_E000._E000("\ueba2\ueb8e\ueb81\ueb9a\ueb8e\ueb83", 60394), _E001);

		public static string March => ResourceManager.GetString(global::_E000._E000("\uf57e\uf552\uf541\uf550\uf55b", 62738), _E001);

		public static string Marketing => ResourceManager.GetString(global::_E000._E000("\ue1b4\ue198\ue18b\ue192\ue19c\ue18d\ue190\ue197\ue19e", 57721), _E001);

		public static string Markup => ResourceManager.GetString(global::_E000._E000("\uec32\uec1e\uec0d\uec14\uec0a\uec0f", 60442), _E001);

		public static string Markups => ResourceManager.GetString(global::_E000._E000("\uf4a6\uf48a\uf499\uf480\uf49e\uf49b\uf498", 62563), _E001);

		public static string MarkupText => ResourceManager.GetString(global::_E000._E000("\uf390\uf3bc\uf3af\uf3b6\uf3a8\uf3ad\uf389\uf3b8\uf3a5\uf3a9", 62344), _E001);

		public static string May => ResourceManager.GetString(global::_E000._E000("\uf810\uf83c\uf824", 63512), _E001);

		public static string Message => ResourceManager.GetString(global::_E000._E000("\ue49a\ue4b2\ue4a4\ue4a4\ue4b6\ue4b0\ue4b2", 58516), _E001);

		public static string Minute => ResourceManager.GetString(global::_E000._E000("\uf3b2\uf396\uf391\uf38a\uf38b\uf39a", 62411), _E001);

		public static string Mixed => ResourceManager.GetString(global::_E000._E000("\ue1b0\ue194\ue185\ue198\ue199", 57749), _E001);

		public static string MobilePacketOperationRestriction => ResourceManager.GetString(global::_E000._E000("\ue68a\ue6a8\ue6a5\ue6ae\ue6ab\ue6a2\ue697\ue6a6\ue6a4\ue6ac\ue6a2\ue6b3\ue688\ue6b7\ue6a2\ue6b5\ue6a6\ue6b3\ue6ae\ue6a8\ue6a9\ue695\ue6a2\ue6b4\ue6b3\ue6b5\ue6ae\ue6a4\ue6b3\ue6ae\ue6a8\ue6a9", 59076), _E001);

		public static string ModuleStatus => ResourceManager.GetString(global::_E000._E000("\ue6b2\ue690\ue69b\ue68a\ue693\ue69a\ue6ac\ue68b\ue69e\ue68b\ue68a\ue68c", 59101), _E001);

		public static string Month => ResourceManager.GetString(global::_E000._E000("\uf1d3\uf1f1\uf1f0\uf1ea\uf1f6", 61854), _E001);

		public static string MoreInfo => ResourceManager.GetString(global::_E000._E000("\uf010\uf032\uf02f\uf038\uf014\uf033\uf03b\uf032", 61512), _E001);

		public static string MyProfile => ResourceManager.GetString(global::_E000._E000("\uf0d2\uf0e6\uf0cf\uf0ed\uf0f0\uf0f9\uf0f6\uf0f3\uf0fa", 61575), _E001);

		public static string Name => ResourceManager.GetString(global::_E000._E000("\uf0d0\uf0ff\uf0f3\uf0fb", 61598), _E001);

		public static string NameMoreThan255CharactersError => ResourceManager.GetString(global::_E000._E000("\ue9a1\ue98e\ue982\ue98a\ue9a2\ue980\ue99d\ue98a\ue9bb\ue987\ue98e\ue981\ue9dd\ue9da\ue9da\ue9ac\ue987\ue98e\ue99d\ue98e\ue98c\ue99b\ue98a\ue99d\ue99c\ue9aa\ue99d\ue99d\ue980\ue99d", 59882), _E001);

		public static string NegarivePriceError => ResourceManager.GetString(global::_E000._E000("\uf031\uf01a\uf018\uf01e\uf00d\uf016\uf009\uf01a\uf02f\uf00d\uf016\uf01c\uf01a\uf03a\uf00d\uf00d\uf010\uf00d", 61530), _E001);

		public static string NewClients => ResourceManager.GetString(global::_E000._E000("\uf1ec\uf1c7\uf1d5\uf1e1\uf1ce\uf1cb\uf1c7\uf1cc\uf1d6\uf1d1", 61824), _E001);

		public static string NewPasswordOldPassword => ResourceManager.GetString(global::_E000._E000("\uf82c\uf807\uf815\uf832\uf803\uf811\uf811\uf815\uf80d\uf810\uf806\uf82d\uf80e\uf806\uf832\uf803\uf811\uf811\uf815\uf80d\uf810\uf806", 63552), _E001);

		public static string NewPriceListUploading => ResourceManager.GetString(global::_E000._E000("\ue2f1\ue2da\ue2c8\ue2ef\ue2cd\ue2d6\ue2dc\ue2da\ue2f3\ue2d6\ue2cc\ue2cb\ue2ea\ue2cf\ue2d3\ue2d0\ue2de\ue2db\ue2d6\ue2d1\ue2d8", 58043), _E001);

		public static string No => ResourceManager.GetString(global::_E000._E000("\ueee1\ueec0", 61103), _E001);

		public static string NoAccess => ResourceManager.GetString(global::_E000._E000("\uf2b1\uf290\uf2be\uf29c\uf29c\uf29a\uf28c\uf28c", 62013), _E001);

		public static string NoDataAvailable => ResourceManager.GetString(global::_E000._E000("\uf87c\uf85d\uf876\uf853\uf846\uf853\uf873\uf844\uf853\uf85b\uf85e\uf853\uf850\uf85e\uf857", 63504), _E001);

		public static string NoInformation => ResourceManager.GetString(global::_E000._E000("\uf2a3\uf282\uf2a4\uf283\uf28b\uf282\uf29f\uf280\uf28c\uf299\uf284\uf282\uf283", 62085), _E001);

		public static string NoInterceptorType => ResourceManager.GetString(global::_E000._E000("\ue5a9\ue588\ue5ae\ue589\ue593\ue582\ue595\ue584\ue582\ue597\ue593\ue588\ue595\ue5b3\ue59e\ue597\ue582", 58788), _E001);

		public static string Nomenclature => ResourceManager.GetString(global::_E000._E000("\uf1a5\uf184\uf186\uf18e\uf185\uf188\uf187\uf18a\uf19f\uf19e\uf199\uf18e", 61921), _E001);

		public static byte[] Nomenclature_Template => (byte[])ResourceManager.GetObject(global::_E000._E000("\ue8b1\ue890\ue892\ue89a\ue891\ue89c\ue893\ue89e\ue88b\ue88a\ue88d\ue89a\ue8a0\ue8ab\ue89a\ue892\ue88f\ue893\ue89e\ue88b\ue89a", 59623), _E001);

		public static string NomenclatureCodeDublicates => ResourceManager.GetString(global::_E000._E000("\uf333\uf312\uf310\uf318\uf313\uf31e\uf311\uf31c\uf309\uf308\uf30f\uf318\uf33e\uf312\uf319\uf318\uf339\uf308\uf31f\uf311\uf314\uf31e\uf31c\uf309\uf318\uf30e", 62332), _E001);

		public static string NomenclatureManage => ResourceManager.GetString(global::_E000._E000("\uf0b0\uf091\uf093\uf09b\uf090\uf09d\uf092\uf09f\uf08a\uf08b\uf08c\uf09b\uf0b3\uf09f\uf090\uf09f\uf099\uf09b", 61678), _E001);

		public static string NomenclatureSectionNotActual => ResourceManager.GetString(global::_E000._E000("\ue6e5\ue6c4\ue6c6\ue6ce\ue6c5\ue6c8\ue6c7\ue6ca\ue6df\ue6de\ue6d9\ue6ce\ue6f8\ue6ce\ue6c8\ue6df\ue6c2\ue6c4\ue6c5\ue6e5\ue6c4\ue6df\ue6ea\ue6c8\ue6df\ue6de\ue6ca\ue6c7", 58913), _E001);

		public static string NomenclatureSectionNotFound => ResourceManager.GetString(global::_E000._E000("\uf331\uf310\uf312\uf31a\uf311\uf31c\uf313\uf31e\uf30b\uf30a\uf30d\uf31a\uf32c\uf31a\uf31c\uf30b\uf316\uf310\uf311\uf331\uf310\uf30b\uf339\uf310\uf30a\uf311\uf31b", 62315), _E001);

		public static string NomenclatureUnitNotFound => ResourceManager.GetString(global::_E000._E000("\ueaa1\uea80\uea82\uea8a\uea81\uea8c\uea83\uea8e\uea9b\uea9a\uea9d\uea8a\ueaba\uea81\uea86\uea9b\ueaa1\uea80\uea9b\ueaa9\uea80\uea9a\uea81\uea8b", 60134), _E001);

		public static string NomenclatureWithCodeAlreadyExists => ResourceManager.GetString(global::_E000._E000("\ue1b0\ue191\ue193\ue19b\ue190\ue19d\ue192\ue19f\ue18a\ue18b\ue18c\ue19b\ue1a9\ue197\ue18a\ue196\ue1bd\ue191\ue19a\ue19b\ue1bf\ue192\ue18c\ue19b\ue19f\ue19a\ue187\ue1bb\ue186\ue197\ue18d\ue18a\ue18d", 57854), _E001);

		public static string NonFiscalCheck => ResourceManager.GetString(global::_E000._E000("\ue2d0\ue2f1\ue2f0\ue2d8\ue2f7\ue2ed\ue2fd\ue2ff\ue2f2\ue2dd\ue2f6\ue2fb\ue2fd\ue2f5", 57998), _E001);

		public static string NonZeroedSumsAtBeginningShift => ResourceManager.GetString(global::_E000._E000("\ue5d1\ue5f0\ue5f1\ue5c5\ue5fa\ue5ed\ue5f0\ue5fa\ue5fb\ue5cc\ue5ea\ue5f2\ue5ec\ue5de\ue5eb\ue5dd\ue5fa\ue5f8\ue5f6\ue5f1\ue5f1\ue5f6\ue5f1\ue5f8\ue5cc\ue5f7\ue5f6\ue5f9\ue5eb", 58647), _E001);

		public static string NonZeroedSumsAtEndingShift => ResourceManager.GetString(global::_E000._E000("\uedbc\ued9d\ued9c\ueda8\ued97\ued80\ued9d\ued97\ued96\ueda1\ued87\ued9f\ued81\uedb3\ued86\uedb7\ued9c\ued96\ued9b\ued9c\ued95\ueda1\ued9a\ued9b\ued94\ued86", 60912), _E001);

		public static string NoOfdPayment => ResourceManager.GetString(global::_E000._E000("\ue513\ue532\ue512\ue53b\ue539\ue50d\ue53c\ue524\ue530\ue538\ue533\ue529", 58712), _E001);

		public static string NotAvailableInDemo => ResourceManager.GetString(global::_E000._E000("\ue171\ue150\ue14b\ue17e\ue149\ue15e\ue156\ue153\ue15e\ue15d\ue153\ue15a\ue176\ue151\ue17b\ue15a\ue152\ue150", 57659), _E001);

		public static string NotClearPriceList => ResourceManager.GetString(global::_E000._E000("\ue5b1\ue590\ue58b\ue5bc\ue593\ue59a\ue59e\ue58d\ue5af\ue58d\ue596\ue59c\ue59a\ue5b3\ue596\ue58c\ue58b", 58685), _E001);

		public static string NotFoundCashbox => ResourceManager.GetString(global::_E000._E000("\ue713\ue732\ue729\ue71b\ue732\ue728\ue733\ue739\ue71e\ue73c\ue72e\ue735\ue73f\ue732\ue725", 59144), _E001);

		public static string NotFoundCashboxDetail => ResourceManager.GetString(global::_E000._E000("\ue599\ue5b8\ue5a3\ue591\ue5b8\ue5a2\ue5b9\ue5b3\ue594\ue5b6\ue5a4\ue5bf\ue5b5\ue5b8\ue5af\ue593\ue5b2\ue5a3\ue5b6\ue5be\ue5bb", 58836), _E001);

		public static string NotFoundOpenShift => ResourceManager.GetString(global::_E000._E000("\uf371\uf350\uf34b\uf379\uf350\uf34a\uf351\uf35b\uf370\uf34f\uf35a\uf351\uf36c\uf357\uf356\uf359\uf34b", 62251), _E001);

		public static string NotFoundSettingsToAccessTheServer => ResourceManager.GetString(global::_E000._E000("\ue5fc\ue5dd\ue5c6\ue5f4\ue5dd\ue5c7\ue5dc\ue5d6\ue5e1\ue5d7\ue5c6\ue5c6\ue5db\ue5dc\ue5d5\ue5c1\ue5e6\ue5dd\ue5f3\ue5d1\ue5d1\ue5d7\ue5c1\ue5c1\ue5e6\ue5da\ue5d7\ue5e1\ue5d7\ue5c0\ue5c4\ue5d7\ue5c0", 58800), _E001);

		public static string NotFoundShift => ResourceManager.GetString(global::_E000._E000("\uf6a1\uf680\uf69b\uf6a9\uf680\uf69a\uf681\uf68b\uf6bc\uf687\uf686\uf689\uf69b", 62989), _E001);

		public static string NotFountUser => ResourceManager.GetString(global::_E000._E000("\uf297\uf2b6\uf2ad\uf29f\uf2b6\uf2ac\uf2b7\uf2ad\uf28c\uf2aa\uf2bc\uf2ab", 62169), _E001);

		public static string Notificate => ResourceManager.GetString(global::_E000._E000("\uef90\uefb1\uefaa\uefb7\uefb8\uefb7\uefbd\uefbf\uefaa\uefbb", 61406), _E001);

		public static string NotificateMissing => ResourceManager.GetString(global::_E000._E000("\ueca7\uec86\uec9d\uec80\uec8f\uec80\uec8a\uec88\uec9d\uec8c\ueca4\uec80\uec9a\uec9a\uec80\uec87\uec8e", 60649), _E001);

		public static string NotValidGuidValue => ResourceManager.GetString(global::_E000._E000("\ue2f1\ue2d0\ue2cb\ue2e9\ue2de\ue2d3\ue2d6\ue2db\ue2f8\ue2ca\ue2d6\ue2db\ue2e9\ue2de\ue2d3\ue2ca\ue2da", 57919), _E001);

		public static string November => ResourceManager.GetString(global::_E000._E000("\uf1b1\uf190\uf189\uf19a\uf192\uf19d\uf19a\uf18d", 61878), _E001);

		public static string October => ResourceManager.GetString(global::_E000._E000("\uf5a0\uf58c\uf59b\uf580\uf58d\uf58a\uf59d", 62927), _E001);

		public static string OfdCheckConnect => ResourceManager.GetString(global::_E000._E000("\uf1e2\uf1cb\uf1c9\uf1ee\uf1c5\uf1c8\uf1ce\uf1c6\uf1ee\uf1c2\uf1c3\uf1c3\uf1c8\uf1ce\uf1d9", 61836), _E001);

		public static string OfdNotAvailable => ResourceManager.GetString(global::_E000._E000("\uefd1\ueff8\ueffa\uefd0\ueff1\uefea\uefdf\uefe8\uefff\ueff7\ueff2\uefff\ueffc\ueff2\ueffb", 61326), _E001);

		public static string OfdServicesNotAvailable => ResourceManager.GetString(global::_E000._E000("\ue730\ue719\ue71b\ue72c\ue71a\ue70d\ue709\ue716\ue71c\ue71a\ue70c\ue731\ue710\ue70b\ue73e\ue709\ue71e\ue716\ue713\ue71e\ue71d\ue713\ue71a", 59259), _E001);

		public static string OfdServicesNotAvailableForCashbox => ResourceManager.GetString(global::_E000._E000("\ueeb2\uee9b\uee99\ueeae\uee98\uee8f\uee8b\uee94\uee9e\uee98\uee8e\ueeb3\uee92\uee89\ueebc\uee8b\uee9c\uee94\uee91\uee9c\uee9f\uee91\uee98\ueebb\uee92\uee8f\ueebe\uee9c\uee8e\uee95\uee9f\uee92\uee85", 61112), _E001);

		public static string OfflineModeDurationMore72Hours => ResourceManager.GetString(global::_E000._E000("\uf43d\uf414\uf414\uf41e\uf41b\uf41c\uf417\uf43f\uf41d\uf416\uf417\uf436\uf407\uf400\uf413\uf406\uf41b\uf41d\uf41c\uf43f\uf41d\uf400\uf417\uf445\uf440\uf43a\uf41d\uf407\uf400\uf401", 62576), _E001);

		public static string OfflineTime => ResourceManager.GetString(global::_E000._E000("\ue5e6\ue5cf\ue5cf\ue5c5\ue5c0\ue5c7\ue5cc\ue5fd\ue5c0\ue5c4\ue5cc", 58665), _E001);

		public static string OfWhich1CCashboxes => ResourceManager.GetString(global::_E000._E000("\uf790\uf7b9\uf788\uf7b7\uf7b6\uf7bc\uf7b7\uf7ee\uf79c\uf79c\uf7be\uf7ac\uf7b7\uf7bd\uf7b0\uf7a7\uf7ba\uf7ac", 63319), _E001);

		public static string OK => ResourceManager.GetString(global::_E000._E000("\uebf0\uebf4", 60351), _E001);

		public static string OneSCabinet => ResourceManager.GetString(global::_E000._E000("\ue280\ue2a1\ue2aa\ue29c\ue28c\ue2ae\ue2ad\ue2a6\ue2a1\ue2aa\ue2bb", 58054), _E001);

		public static string OnlineCheckBodyFormat => ResourceManager.GetString(global::_E000._E000("\ued10\ued31\ued33\ued36\ued31\ued3a\ued1c\ued37\ued3a\ued3c\ued34\ued1d\ued30\ued3b\ued26\ued19\ued30\ued2d\ued32\ued3e\ued2b", 60758), _E001);

		public static string OnlineCheckSubject => ResourceManager.GetString(global::_E000._E000("\ue0d0\ue0f1\ue0f3\ue0f6\ue0f1\ue0fa\ue0dc\ue0f7\ue0fa\ue0fc\ue0f4\ue0cc\ue0ea\ue0fd\ue0f5\ue0fa\ue0fc\ue0eb", 57351), _E001);

		public static string OpenShift => ResourceManager.GetString(global::_E000._E000("\uf651\uf66e\uf67b\uf670\uf64d\uf676\uf677\uf678\uf66a", 62990), _E001);

		public static string OpenShiftDate => ResourceManager.GetString(global::_E000._E000("\ue6f2\ue6cd\ue6d8\ue6d3\ue6ee\ue6d5\ue6d4\ue6db\ue6c9\ue6f9\ue6dc\ue6c9\ue6d8", 59036), _E001);

		public static string Operation => ResourceManager.GetString(global::_E000._E000("\uf3f0\uf3cf\uf3da\uf3cd\uf3de\uf3cb\uf3d6\uf3d0\uf3d1", 62375), _E001);

		public static string OperationFailedTryAgain => ResourceManager.GetString(global::_E000._E000("\uefb0\uef8f\uef9a\uef8d\uef9e\uef8b\uef96\uef90\uef91\uefb9\uef9e\uef96\uef93\uef9a\uef9b\uefab\uef8d\uef86\uefbe\uef98\uef9e\uef96\uef91", 61415), _E001);

		public static string OperationGoods => ResourceManager.GetString(global::_E000._E000("\ue291\ue2ae\ue2bb\ue2ac\ue2bf\ue2aa\ue2b7\ue2b1\ue2b0\ue299\ue2b1\ue2b1\ue2ba\ue2ad", 58062), _E001);

		public static string OperationsHistory => ResourceManager.GetString(global::_E000._E000("\ue1b4\ue18b\ue19e\ue189\ue19a\ue18f\ue192\ue194\ue195\ue188\ue1b3\ue192\ue188\ue18f\ue194\ue189\ue182", 57809), _E001);

		public static string OperationsPin => ResourceManager.GetString(global::_E000._E000("\uf4a0\uf49f\uf48a\uf49d\uf48e\uf49b\uf486\uf480\uf481\uf49c\uf4bf\uf486\uf481", 62703), _E001);

		public static string OperationTaxes => ResourceManager.GetString(global::_E000._E000("\uedb4\ued8b\ued9e\ued89\ued9a\ued8f\ued92\ued94\ued95\uedaf\ued9a\ued83\ued9e\ued88", 60913), _E001);

		public static string OperationType => ResourceManager.GetString(global::_E000._E000("\uf83c\uf803\uf816\uf801\uf812\uf807\uf81a\uf81c\uf81d\uf827\uf80a\uf803\uf816", 63570), _E001);

		public static string OrdersCourier => ResourceManager.GetString(global::_E000._E000("\ue8a0\ue89d\ue88b\ue88a\ue89d\ue89c\ue8ac\ue880\ue89a\ue89d\ue886\ue88a\ue89d", 59471), _E001);

		public static string OrdersManagement => ResourceManager.GetString(global::_E000._E000("\ue900\ue93d\ue92b\ue92a\ue93d\ue93c\ue902\ue92e\ue921\ue92e\ue928\ue92a\ue922\ue92a\ue921\ue93b", 59654), _E001);

		public static string OrderTickets => ResourceManager.GetString(global::_E000._E000("\uea22\uea1f\uea09\uea08\uea1f\uea39\uea04\uea0e\uea06\uea08\uea19\uea1e", 59980), _E001);

		public static string Organization => ResourceManager.GetString(global::_E000._E000("\uf6b0\uf68d\uf698\uf69e\uf691\uf696\uf685\uf69e\uf68b\uf696\uf690\uf691", 63223), _E001);

		public static string OrganizationCanHaveOnlyOneContact => ResourceManager.GetString(global::_E000._E000("\uf491\uf4ac\uf4b9\uf4bf\uf4b0\uf4b7\uf4a4\uf4bf\uf4aa\uf4b7\uf4b1\uf4b0\uf49d\uf4bf\uf4b0\uf496\uf4bf\uf4a8\uf4bb\uf491\uf4b0\uf4b2\uf4a7\uf491\uf4b0\uf4bb\uf49d\uf4b1\uf4b0\uf4aa\uf4bf\uf4bd\uf4aa", 62670), _E001);

		public static string OrganizationControl => ResourceManager.GetString(global::_E000._E000("\ueeb0\uee8d\uee98\uee9e\uee91\uee96\uee85\uee9e\uee8b\uee96\uee90\uee91\ueebc\uee90\uee91\uee8b\uee8d\uee90\uee93", 61053), _E001);

		public static string OrganizationData => ResourceManager.GetString(global::_E000._E000("\uef88\uefb5\uefa0\uefa6\uefa9\uefae\uefbd\uefa6\uefb3\uefae\uefa8\uefa9\uef83\uefa6\uefb3\uefa6", 61252), _E001);

		public static string OrganizationHasMobilePacket => ResourceManager.GetString(global::_E000._E000("\ue6b0\ue68d\ue698\ue69e\ue691\ue696\ue685\ue69e\ue68b\ue696\ue690\ue691\ue6b7\ue69e\ue68c\ue6b2\ue690\ue69d\ue696\ue693\ue69a\ue6af\ue69e\ue69c\ue694\ue69a\ue68b", 59037), _E001);

		public static string OrganizationIsSameAddress => ResourceManager.GetString(global::_E000._E000("\ueff0\uefcd\uefd8\uefde\uefd1\uefd6\uefc5\uefde\uefcb\uefd6\uefd0\uefd1\ueff6\uefcc\uefec\uefde\uefd2\uefda\ueffe\uefdb\uefdb\uefcd\uefda\uefcc\uefcc", 61247), _E001);

		public static string OrganizationList => ResourceManager.GetString(global::_E000._E000("\uf611\uf62c\uf639\uf63f\uf630\uf637\uf624\uf63f\uf62a\uf637\uf631\uf630\uf612\uf637\uf62d\uf62a", 63054), _E001);

		public static string OrganizationManagement => ResourceManager.GetString(global::_E000._E000("\ueb12\ueb2f\ueb3a\ueb3c\ueb33\ueb34\ueb27\ueb3c\ueb29\ueb34\ueb32\ueb33\ueb10\ueb3c\ueb33\ueb3c\ueb3a\ueb38\ueb30\ueb38\ueb33\ueb29", 60168), _E001);

		public static string OrganizationProfile => ResourceManager.GetString(global::_E000._E000("\uf0b0\uf08d\uf098\uf09e\uf091\uf096\uf085\uf09e\uf08b\uf096\uf090\uf091\uf0af\uf08d\uf090\uf099\uf096\uf093\uf09a", 61533), _E001);

		public static string OrganizationProfileEdit => ResourceManager.GetString(global::_E000._E000("\ue5e2\ue5df\ue5ca\ue5cc\ue5c3\ue5c4\ue5d7\ue5cc\ue5d9\ue5c4\ue5c2\ue5c3\ue5fd\ue5df\ue5c2\ue5cb\ue5c4\ue5c1\ue5c8\ue5e8\ue5c9\ue5c4\ue5d9", 58764), _E001);

		public static string OrganizationRegistration => ResourceManager.GetString(global::_E000._E000("\uf7c6\uf7fb\uf7ee\uf7e8\uf7e7\uf7e0\uf7f3\uf7e8\uf7fd\uf7e0\uf7e6\uf7e7\uf7db\uf7ec\uf7ee\uf7e0\uf7fa\uf7fd\uf7fb\uf7e8\uf7fd\uf7e0\uf7e6\uf7e7", 63369), _E001);

		public static string OrganizationRevenue => ResourceManager.GetString(global::_E000._E000("\uf7a0\uf79d\uf788\uf78e\uf781\uf786\uf795\uf78e\uf79b\uf786\uf780\uf781\uf7bd\uf78a\uf799\uf78a\uf781\uf79a\uf78a", 63245), _E001);

		public static string Organizations => ResourceManager.GetString(global::_E000._E000("\uecb2\uec8f\uec9a\uec9c\uec93\uec94\uec87\uec9c\uec89\uec94\uec92\uec93\uec8e", 60597), _E001);

		public static string Other => ResourceManager.GetString(global::_E000._E000("\uf030\uf00b\uf017\uf01a\uf00d", 61494), _E001);

		public static string PacketsLeftToNewCto => ResourceManager.GetString(global::_E000._E000("\uedad\ued9c\ued9e\ued96\ued98\ued89\ued8e\uedb1\ued98\ued9b\ued89\ueda9\ued92\uedb3\ued98\ued8a\uedbe\ued89\ued92", 60920), _E001);

		public static string Page => ResourceManager.GetString(global::_E000._E000("\uf4af\uf49e\uf498\uf49a", 62714), _E001);

		public static string Partners => ResourceManager.GetString(global::_E000._E000("\ue8af\ue89e\ue88d\ue88b\ue891\ue89a\ue88d\ue88c", 59421), _E001);

		public static string PasswordChangeError => ResourceManager.GetString(global::_E000._E000("\uecab\uec9a\uec88\uec88\uec8c\uec94\uec89\uec9f\uecb8\uec93\uec9a\uec95\uec9c\uec9e\uecbe\uec89\uec89\uec94\uec89", 60497), _E001);

		public static string PasswordExpired => ResourceManager.GetString(global::_E000._E000("\uf08d\uf0bc\uf0ae\uf0ae\uf0aa\uf0b2\uf0af\uf0b9\uf098\uf0a5\uf0ad\uf0b4\uf0af\uf0b8\uf0b9", 61656), _E001);

		public static string PasswordMustContain => ResourceManager.GetString(global::_E000._E000("\uf0ab\uf09a\uf088\uf088\uf08c\uf094\uf089\uf09f\uf0b6\uf08e\uf088\uf08f\uf0b8\uf094\uf095\uf08f\uf09a\uf092\uf095", 61651), _E001);

		public static string PaymentBill => ResourceManager.GetString(global::_E000._E000("\ue1a3\ue192\ue18a\ue19e\ue196\ue19d\ue187\ue1b1\ue19a\ue19f\ue19f", 57842), _E001);

		public static string PersonFullName => ResourceManager.GetString(global::_E000._E000("\uebe2\uebd7\uebc0\uebc1\uebdd\uebdc\uebf4\uebc7\uebde\uebde\uebfc\uebd3\uebdf\uebd7", 60304), _E001);

		public static string PersonShortName => ResourceManager.GetString(global::_E000._E000("\ue21f\ue22a\ue23d\ue23c\ue220\ue221\ue21c\ue227\ue220\ue23d\ue23b\ue201\ue22e\ue222\ue22a", 57862), _E001);

		public static string PilotWithoutOFD => ResourceManager.GetString(global::_E000._E000("\uf50e\uf537\uf532\uf531\uf52a\uf509\uf537\uf52a\uf536\uf531\uf52b\uf52a\uf511\uf518\uf51a", 62798), _E001);

		public static string PinChange => ResourceManager.GetString(global::_E000._E000("\ue7fb\ue7c2\ue7c5\ue7e8\ue7c3\ue7ca\ue7c5\ue7cc\ue7ce", 59299), _E001);

		public static string PinInput => ResourceManager.GetString(global::_E000._E000("\uf0a7\uf09e\uf099\uf0be\uf099\uf087\uf082\uf083", 61620), _E001);

		public static string PinInspector => ResourceManager.GetString(global::_E000._E000("\ue989\ue9b0\ue9b7\ue990\ue9b7\ue9aa\ue9a9\ue9bc\ue9ba\ue9ad\ue9b6\ue9ab", 59865), _E001);

		public static string Position => ResourceManager.GetString(global::_E000._E000("\uec63\uec5c\uec40\uec5a\uec47\uec5a\uec5c\uec5d", 60418), _E001);

		public static string PositionReturnedEarlier => ResourceManager.GetString(global::_E000._E000("\uf4a3\uf49c\uf480\uf49a\uf487\uf49a\uf49c\uf49d\uf4a1\uf496\uf487\uf486\uf481\uf49d\uf496\uf497\uf4b6\uf492\uf481\uf49f\uf49a\uf496\uf481", 62690), _E001);

		public static string Positions => ResourceManager.GetString(global::_E000._E000("\ue6bf\ue680\ue69c\ue686\ue69b\ue686\ue680\ue681\ue69c", 59117), _E001);

		public static string PosPaymentHistoryConsolidated => ResourceManager.GetString(global::_E000._E000("\ue5af\ue590\ue58c\ue5af\ue59e\ue586\ue592\ue59a\ue591\ue58b\ue5b7\ue596\ue58c\ue58b\ue590\ue58d\ue586\ue5bc\ue590\ue591\ue58c\ue590\ue593\ue596\ue59b\ue59e\ue58b\ue59a\ue59b", 58827), _E001);

		public static string PosPaymentHistoryOperations => ResourceManager.GetString(global::_E000._E000("\ue46f\ue450\ue44c\ue46f\ue45e\ue446\ue452\ue45a\ue451\ue44b\ue477\ue456\ue44c\ue44b\ue450\ue44d\ue446\ue470\ue44f\ue45a\ue44d\ue45e\ue44b\ue456\ue450\ue451\ue44c", 58411), _E001);

		public static string POSPrinterCOM => ResourceManager.GetString(global::_E000._E000("\ue0ef\ue0f0\ue0ec\ue0ef\ue0cd\ue0d6\ue0d1\ue0cb\ue0da\ue0cd\ue0fc\ue0f0\ue0f2", 57527), _E001);

		public static string POSPrinterUSB => ResourceManager.GetString(global::_E000._E000("\uf1bf\uf1a0\uf1bc\uf1bf\uf19d\uf186\uf181\uf19b\uf18a\uf19d\uf1ba\uf1bc\uf1ad", 61933), _E001);

		public static string Price => ResourceManager.GetString(global::_E000._E000("\ue2cf\ue2ed\ue2f6\ue2fc\ue2fa", 57879), _E001);

		public static string PriceFieldDoubleFractionalAllowedMessage => ResourceManager.GetString(global::_E000._E000("\ue7ef\ue7cd\ue7d6\ue7dc\ue7da\ue7f9\ue7d6\ue7da\ue7d3\ue7db\ue7fb\ue7d0\ue7ca\ue7dd\ue7d3\ue7da\ue7f9\ue7cd\ue7de\ue7dc\ue7cb\ue7d6\ue7d0\ue7d1\ue7de\ue7d3\ue7fe\ue7d3\ue7d3\ue7d0\ue7c8\ue7da\ue7db\ue7f2\ue7da\ue7cc\ue7cc\ue7de\ue7d8\ue7da", 59291), _E001);

		public static byte[] PriceList_Template => (byte[])ResourceManager.GetObject(global::_E000._E000("\ue087\ue0a5\ue0be\ue0b4\ue0b2\ue09b\ue0be\ue0a4\ue0a3\ue088\ue083\ue0b2\ue0ba\ue0a7\ue0bb\ue0b6\ue0a3\ue0b2", 57492), _E001);

		public static byte[] PriceList_Template_eng => (byte[])ResourceManager.GetObject(global::_E000._E000("\ue2e3\ue2c1\ue2da\ue2d0\ue2d6\ue2ff\ue2da\ue2c0\ue2c7\ue2ec\ue2e7\ue2d6\ue2de\ue2c3\ue2df\ue2d2\ue2c7\ue2d6\ue2ec\ue2d6\ue2dd\ue2d4", 58034), _E001);

		public static byte[] PriceList_Tobacco => (byte[])ResourceManager.GetObject(global::_E000._E000("\ue83f\ue81d\ue806\ue80c\ue80a\ue823\ue806\ue81c\ue81b\ue830\ue83b\ue800\ue80d\ue80e\ue80c\ue80c\ue800", 59434), _E001);

		public static string PriceListManage => ResourceManager.GetString(global::_E000._E000("\uf01f\uf03d\uf026\uf02c\uf02a\uf003\uf026\uf03c\uf03b\uf002\uf02e\uf021\uf02e\uf028\uf02a", 61510), _E001);

		public static string PricePerOneWithNds => ResourceManager.GetString(global::_E000._E000("\uf1fb\uf1d9\uf1c2\uf1c8\uf1ce\uf1fb\uf1ce\uf1d9\uf1e4\uf1c5\uf1ce\uf1fc\uf1c2\uf1df\uf1c3\uf1e5\uf1cf\uf1d8", 61825), _E001);

		public static string Print => ResourceManager.GetString(global::_E000._E000("\uf5b7\uf595\uf58e\uf589\uf593", 62820), _E001);

		public static string PrinterSettings => ResourceManager.GetString(global::_E000._E000("\ue3ff\ue3dd\ue3c6\ue3c1\ue3db\ue3ca\ue3dd\ue3fc\ue3ca\ue3db\ue3db\ue3c6\ue3c1\ue3c8\ue3dc", 58127), _E001);

		public static string PrintingError => ResourceManager.GetString(global::_E000._E000("\ued0e\ued2c\ued37\ued30\ued2a\ued37\ued30\ued39\ued1b\ued2c\ued2c\ued31\ued2c", 60750), _E001);

		public static string PrintingService => ResourceManager.GetString(global::_E000._E000("\uee63\uee41\uee5a\uee5d\uee47\uee5a\uee5d\uee54\uee60\uee56\uee41\uee45\uee5a\uee50\uee56", 60978), _E001);

		public static string PrintingToFile => ResourceManager.GetString(global::_E000._E000("\uf8cf\uf8ed\uf8f6\uf8f1\uf8eb\uf8f6\uf8f1\uf8f8\uf8cb\uf8f0\uf8d9\uf8f6\uf8f3\uf8fa", 63495), _E001);

		public static string PrintModule => ResourceManager.GetString(global::_E000._E000("\uf1bf\uf19d\uf186\uf181\uf19b\uf1a2\uf180\uf18b\uf19a\uf183\uf18a", 61709), _E001);

		public static string PrintModuleDescription => ResourceManager.GetString(global::_E000._E000("\ue3bf\ue39d\ue386\ue381\ue39b\ue3a2\ue380\ue38b\ue39a\ue383\ue38a\ue3ab\ue38a\ue39c\ue38c\ue39d\ue386\ue39f\ue39b\ue386\ue380\ue381", 58253), _E001);

		public static string PrintModuleUpdate => ResourceManager.GetString(global::_E000._E000("\uf7af\uf78d\uf796\uf791\uf78b\uf7b2\uf790\uf79b\uf78a\uf793\uf79a\uf7aa\uf78f\uf79b\uf79e\uf78b\uf79a", 63325), _E001);

		public static string PrintTestCheck => ResourceManager.GetString(global::_E000._E000("\uf0bd\uf09f\uf084\uf083\uf099\uf0b9\uf088\uf09e\uf099\uf0ae\uf085\uf088\uf08e\uf086", 61573), _E001);

		public static string ProductAlreadyExistsError => ResourceManager.GetString(global::_E000._E000("\uefe2\uefc0\uefdd\uefd6\uefc7\uefd1\uefc6\ueff3\uefde\uefc0\uefd7\uefd3\uefd6\uefcb\ueff7\uefca\uefdb\uefc1\uefc6\uefc1\ueff7\uefc0\uefc0\uefdd\uefc0", 61360), _E001);

		public static string ProductCode => ResourceManager.GetString(global::_E000._E000("\ue7bf\ue79d\ue780\ue78b\ue79a\ue78c\ue79b\ue7ac\ue780\ue78b\ue78a", 59181), _E001);

		public static string ProductCode1 => ResourceManager.GetString(global::_E000._E000("\ue1b9\ue19b\ue186\ue18d\ue19c\ue18a\ue19d\ue1aa\ue186\ue18d\ue18c\ue1d8", 57833), _E001);

		public static string ProductCodeAlreadyExistsError => ResourceManager.GetString(global::_E000._E000("\ueefd\ueedf\ueec2\ueec9\ueed8\ueece\ueed9\ueeee\ueec2\ueec9\ueec8\ueeec\ueec1\ueedf\ueec8\ueecc\ueec9\ueed4\ueee8\ueed5\ueec4\ueede\ueed9\ueede\ueee8\ueedf\ueedf\ueec2\ueedf", 61068), _E001);

		public static string ProductEmptyNameError => ResourceManager.GetString(global::_E000._E000("\uebb2\ueb90\ueb8d\ueb86\ueb97\ueb81\ueb96\ueba7\ueb8f\ueb92\ueb96\ueb9b\uebac\ueb83\ueb8f\ueb87\ueba7\ueb90\ueb90\ueb8d\ueb90", 60384), _E001);

		public static string ProductGroup => ResourceManager.GetString(global::_E000._E000("\ue1bd\ue19f\ue182\ue189\ue198\ue18e\ue199\ue1aa\ue19f\ue182\ue198\ue19d", 57836), _E001);

		public static string ProductName => ResourceManager.GetString(global::_E000._E000("\ue823\ue801\ue81c\ue817\ue806\ue810\ue807\ue83d\ue812\ue81e\ue816", 59506), _E001);

		public static string Products => ResourceManager.GetString(global::_E000._E000("\ue2bd\ue29f\ue282\ue289\ue298\ue28e\ue299\ue29e", 58021), _E001);

		public static string ProductShortName => ResourceManager.GetString(global::_E000._E000("\ue8bd\ue89f\ue882\ue889\ue898\ue88e\ue899\ue8be\ue885\ue882\ue89f\ue899\ue8a3\ue88c\ue880\ue888", 59621), _E001);

		public static string Profile => ResourceManager.GetString(global::_E000._E000("\ue199\ue1bb\ue1a6\ue1af\ue1a0\ue1a5\ue1ac", 57801), _E001);

		public static string ProfileEdit => ResourceManager.GetString(global::_E000._E000("\ueea7\uee85\uee98\uee91\uee9e\uee9b\uee92\ueeb2\uee93\uee9e\uee83", 61044), _E001);

		public static string Profiles => ResourceManager.GetString(global::_E000._E000("\uf62d\uf60f\uf612\uf61b\uf614\uf611\uf618\uf60e", 63068), _E001);

		public static string Programming => ResourceManager.GetString(global::_E000._E000("\uee1f\uee3d\uee20\uee28\uee3d\uee2e\uee22\uee22\uee26\uee21\uee28", 60998), _E001);

		public static string ProgrammingCashboxPossibleOnlyInClosedShift => ResourceManager.GetString(global::_E000._E000("\uf5af\uf58d\uf590\uf598\uf58d\uf59e\uf592\uf592\uf596\uf591\uf598\uf5bc\uf59e\uf58c\uf597\uf59d\uf590\uf587\uf5af\uf590\uf58c\uf58c\uf596\uf59d\uf593\uf59a\uf5b0\uf591\uf593\uf586\uf5b6\uf591\uf5bc\uf593\uf590\uf58c\uf59a\uf59b\uf5ac\uf597\uf596\uf599\uf58b", 62973), _E001);

		public static string ProgrammingCheck => ResourceManager.GetString(global::_E000._E000("\ue3b7\ue395\ue388\ue380\ue395\ue386\ue38a\ue38a\ue38e\ue389\ue380\ue3a4\ue38f\ue382\ue384\ue38c", 58212), _E001);

		public static string ProgrammingOrReportsInstruction => ResourceManager.GetString(global::_E000._E000("\ue7bf\ue79d\ue780\ue788\ue79d\ue78e\ue782\ue782\ue786\ue781\ue788\ue7a0\ue79d\ue7bd\ue78a\ue79f\ue780\ue79d\ue79b\ue79c\ue7a6\ue781\ue79c\ue79b\ue79d\ue79a\ue78c\ue79b\ue786\ue780\ue781", 59149), _E001);

		public static string ProgrammingPin => ResourceManager.GetString(global::_E000._E000("\uf80d\uf82f\uf832\uf83a\uf82f\uf83c\uf830\uf830\uf834\uf833\uf83a\uf80d\uf834\uf833", 63512), _E001);

		public static string ProgrammingPINManage => ResourceManager.GetString(global::_E000._E000("\ue93f\ue91d\ue900\ue908\ue91d\ue90e\ue902\ue902\ue906\ue901\ue908\ue93f\ue926\ue921\ue922\ue90e\ue901\ue90e\ue908\ue90a", 59750), _E001);

		public static string ProgrammingXZReport => ResourceManager.GetString(global::_E000._E000("\ue3eb\ue3c9\ue3d4\ue3dc\ue3c9\ue3da\ue3d6\ue3d6\ue3d2\ue3d5\ue3dc\ue3e3\ue3e1\ue3e9\ue3de\ue3cb\ue3d4\ue3c9\ue3cf", 58289), _E001);

		public static string Promo500kOFD => ResourceManager.GetString(global::_E000._E000("\ue8ab\ue889\ue894\ue896\ue894\ue8ce\ue8cb\ue8cb\ue890\ue8b4\ue8bd\ue8bf", 59473), _E001);

		public static string PurchasesPlural => ResourceManager.GetString(global::_E000._E000("\uf4e2\uf4c7\uf4c0\uf4d1\uf4da\uf4d3\uf4c1\uf4d7\uf4c1\uf4e2\uf4de\uf4c7\uf4c0\uf4d3\uf4de", 62640), _E001);

		public static string PutCash => ResourceManager.GetString(global::_E000._E000("\uf6e9\uf6cc\uf6cd\uf6fa\uf6d8\uf6ca\uf6d1", 63161), _E001);

		public static string QRLarge => ResourceManager.GetString(global::_E000._E000("\ue0ac\ue0af\ue0b1\ue09c\ue08f\ue09a\ue098", 57512), _E001);

		public static string QRMedium => ResourceManager.GetString(global::_E000._E000("\ue2ba\ue2b9\ue2a6\ue28e\ue28f\ue282\ue29e\ue286", 57921), _E001);

		public static string QRSmall => ResourceManager.GetString(global::_E000._E000("\uecba\uecb9\uecb8\uec86\uec8a\uec87\uec87", 60515), _E001);

		public static string QRXLarge => ResourceManager.GetString(global::_E000._E000("\uf1ea\uf1e9\uf1e3\uf1f7\uf1da\uf1c9\uf1dc\uf1de", 61745), _E001);

		public static string QRXXLarge => ResourceManager.GetString(global::_E000._E000("\ue3fa\ue3f9\ue3f3\ue3f3\ue3e7\ue3ca\ue3d9\ue3cc\ue3ce", 58241), _E001);

		public static string Readed => ResourceManager.GetString(global::_E000._E000("\uebbf\ueb88\ueb8c\ueb89\ueb88\ueb89", 60357), _E001);

		public static string ReadStatusMarkedAsRead => ResourceManager.GetString(global::_E000._E000("\uecef\uecd8\uecdc\uecd9\uecee\uecc9\uecdc\uecc9\uecc8\uecce\uecf0\uecdc\ueccf\uecd6\uecd8\uecd9\uecfc\uecce\uecef\uecd8\uecdc\uecd9", 60604), _E001);

		public static string ReadStatusMarkedUnread => ResourceManager.GetString(global::_E000._E000("\ue5bd\ue58a\ue58e\ue58b\ue5bc\ue59b\ue58e\ue59b\ue59a\ue59c\ue5a2\ue58e\ue59d\ue584\ue58a\ue58b\ue5ba\ue581\ue59d\ue58a\ue58e\ue58b", 58797), _E001);

		public static string ReadStatusRead => ResourceManager.GetString(global::_E000._E000("\ue8ad\ue89a\ue89e\ue89b\ue8ac\ue88b\ue89e\ue88b\ue88a\ue88c\ue8ad\ue89a\ue89e\ue89b", 59645), _E001);

		public static string ReadStatusUnread => ResourceManager.GetString(global::_E000._E000("\ueae0\uead7\uead3\uead6\ueae1\ueac6\uead3\ueac6\ueac7\ueac1\ueae7\ueadc\ueac0\uead7\uead3\uead6", 60048), _E001);

		public static string Recovering => ResourceManager.GetString(global::_E000._E000("\uee0f\uee38\uee3e\uee32\uee2b\uee38\uee2f\uee34\uee33\uee3a", 60952), _E001);

		public static string Recovery => ResourceManager.GetString(global::_E000._E000("\ue9e9\ue9de\ue9d8\ue9d4\ue9cd\ue9de\ue9c9\ue9c2", 59793), _E001);

		public static string Refresh => ResourceManager.GetString(global::_E000._E000("\uf6ad\uf69a\uf699\uf68d\uf69a\uf68c\uf697", 63158), _E001);

		public static string RegionName => ResourceManager.GetString(global::_E000._E000("\uf7b9\uf78e\uf78c\uf782\uf784\uf785\uf7a5\uf78a\uf786\uf78e", 63299), _E001);

		public static string RegisterNewOrganization => ResourceManager.GetString(global::_E000._E000("\uf7ad\uf79a\uf798\uf796\uf78c\uf78b\uf79a\uf78d\uf7b1\uf79a\uf788\uf7b0\uf78d\uf798\uf79e\uf791\uf796\uf785\uf79e\uf78b\uf796\uf790\uf791", 63451), _E001);

		public static string RegisterService => ResourceManager.GetString(global::_E000._E000("\ue9f9\ue9ce\ue9cc\ue9c2\ue9d8\ue9df\ue9ce\ue9d9\ue9f8\ue9ce\ue9d9\ue9dd\ue9c2\ue9c8\ue9ce", 59683), _E001);

		public static string Registration => ResourceManager.GetString(global::_E000._E000("\uf6a1\uf696\uf694\uf69a\uf680\uf687\uf681\uf692\uf687\uf69a\uf69c\uf69d", 63202), _E001);

		public static string ReleaseDevice => ResourceManager.GetString(global::_E000._E000("\ue16c\ue15b\ue152\ue15b\ue15f\ue14d\ue15b\ue17a\ue15b\ue148\ue157\ue15d\ue15b", 57646), _E001);

		public static string Remember => ResourceManager.GetString(global::_E000._E000("\uebf9\uebce\uebc6\uebce\uebc6\uebc9\uebce\uebd9", 60291), _E001);

		public static string RememberBrowser => ResourceManager.GetString(global::_E000._E000("\uedff\uedc8\uedc0\uedc8\uedc0\uedcf\uedc8\ueddf\uedef\ueddf\uedc2\uedda\uedde\uedc8\ueddf", 60812), _E001);

		public static string RemindPinCodes => ResourceManager.GetString(global::_E000._E000("\ue4ad\ue49a\ue492\ue496\ue491\ue49b\ue4af\ue496\ue491\ue4bc\ue490\ue49b\ue49a\ue48c", 58550), _E001);

		public static string Remove => ResourceManager.GetString(global::_E000._E000("\ue72d\ue71a\ue712\ue710\ue709\ue71a", 59226), _E001);

		public static string RemoveDiscount => ResourceManager.GetString(global::_E000._E000("\ue5fb\ue5cc\ue5c4\ue5c6\ue5df\ue5cc\ue5ed\ue5c0\ue5da\ue5ca\ue5c6\ue5dc\ue5c7\ue5dd", 58793), _E001);

		public static string RemoveMarkup => ResourceManager.GetString(global::_E000._E000("\uf6bd\uf68a\uf682\uf680\uf699\uf68a\uf6a2\uf68e\uf69d\uf684\uf69a\uf69f", 63087), _E001);

		public static string Removing => ResourceManager.GetString(global::_E000._E000("\ue1a5\ue192\ue19a\ue198\ue181\ue19e\ue199\ue190", 57652), _E001);

		public static string Report500Sale => ResourceManager.GetString(global::_E000._E000("\ue0eb\ue0dc\ue0c9\ue0d6\ue0cb\ue0cd\ue08c\ue089\ue089\ue0ea\ue0d8\ue0d5\ue0dc", 57529), _E001);

		public static string ReportActiveCashboxes => ResourceManager.GetString(global::_E000._E000("\uf76d\uf75a\uf74f\uf750\uf74d\uf74b\uf77e\uf75c\uf74b\uf756\uf749\uf75a\uf77c\uf75e\uf74c\uf757\uf75d\uf750\uf747\uf75a\uf74c", 63243), _E001);

		public static string ReportBalanceOperations => ResourceManager.GetString(global::_E000._E000("\ue98d\ue9ba\ue9af\ue9b0\ue9ad\ue9ab\ue99d\ue9be\ue9b3\ue9be\ue9b1\ue9bc\ue9ba\ue990\ue9af\ue9ba\ue9ad\ue9be\ue9ab\ue9b6\ue9b0\ue9b1\ue9ac", 59862), _E001);

		public static string ReportByOperations => ResourceManager.GetString(global::_E000._E000("\ue18c\ue1bb\ue1ae\ue1b1\ue1ac\ue1aa\ue19c\ue1a7\ue191\ue1ae\ue1bb\ue1ac\ue1bf\ue1aa\ue1b7\ue1b1\ue1b0\ue1ad", 57822), _E001);

		public static string ReportCancellation => ResourceManager.GetString(global::_E000._E000("\uede1\uedd6\uedc3\ueddc\uedc1\uedc7\uedf0\uedd2\ueddd\uedd0\uedd6\ueddf\ueddf\uedd2\uedc7\uedda\ueddc\ueddd", 60850), _E001);

		public static string ReportCashboxRegistrations => ResourceManager.GetString(global::_E000._E000("\uebb5\ueb82\ueb97\ueb88\ueb95\ueb93\ueba4\ueb86\ueb94\ueb8f\ueb85\ueb88\ueb9f\uebb5\ueb82\ueb80\ueb8e\ueb94\ueb93\ueb95\ueb86\ueb93\ueb8e\ueb88\ueb89\ueb94", 60260), _E001);

		public static string ReportCashiers => ResourceManager.GetString(global::_E000._E000("\ued6d\ued5a\ued4f\ued50\ued4d\ued4b\ued7c\ued5e\ued4c\ued57\ued56\ued5a\ued4d\ued4c", 60731), _E001);

		public static string ReportCheckoutTape => ResourceManager.GetString(global::_E000._E000("\ueea0\uee97\uee82\uee9d\uee80\uee86\ueeb1\uee9a\uee97\uee91\uee99\uee9d\uee87\uee86\ueea6\uee93\uee82\uee97", 61136), _E001);

		public static string ReportFooter => ResourceManager.GetString(global::_E000._E000("\uede0\uedd7\uedc2\ueddd\uedc0\uedc6\uedf4\ueddd\ueddd\uedc6\uedd7\uedc0", 60816), _E001);

		public static string ReportGeneratedOffline => ResourceManager.GetString(global::_E000._E000("\uf03d\uf00a\uf01f\uf000\uf01d\uf01b\uf028\uf00a\uf001\uf00a\uf01d\uf00e\uf01b\uf00a\uf00b\uf020\uf009\uf009\uf003\uf006\uf001\uf00a", 61514), _E001);

		public static string ReportIntegratedPOS => ResourceManager.GetString(global::_E000._E000("\uf0ed\uf0da\uf0cf\uf0d0\uf0cd\uf0cb\uf0f6\uf0d1\uf0cb\uf0da\uf0d8\uf0cd\uf0de\uf0cb\uf0da\uf0db\uf0ef\uf0f0\uf0ec", 61595), _E001);

		public static string ReportNonCancellation => ResourceManager.GetString(global::_E000._E000("\uedb0\ued87\ued92\ued8d\ued90\ued96\uedac\ued8d\ued8c\ueda1\ued83\ued8c\ued81\ued87\ued8e\ued8e\ued83\ued96\ued8b\ued8d\ued8c", 60896), _E001);

		public static string ReportOrganizationRegistrations => ResourceManager.GetString(global::_E000._E000("\ue8b9\ue88e\ue89b\ue884\ue899\ue89f\ue8a4\ue899\ue88c\ue88a\ue885\ue882\ue891\ue88a\ue89f\ue882\ue884\ue885\ue8b9\ue88e\ue88c\ue882\ue898\ue89f\ue899\ue88a\ue89f\ue882\ue884\ue885\ue898", 59489), _E001);

		public static string ReportPurchasedLicense => ResourceManager.GetString(global::_E000._E000("\uee95\ueea2\ueeb7\ueea8\ueeb5\ueeb3\uee97\ueeb2\ueeb5\ueea4\ueeaf\ueea6\ueeb4\ueea2\ueea3\uee8b\ueeae\ueea4\ueea2\ueea9\ueeb4\ueea2", 60932), _E001);

		public static string ReportPurchasedLicenseByTypes => ResourceManager.GetString(global::_E000._E000("\ue28f\ue2b8\ue2ad\ue2b2\ue2af\ue2a9\ue28d\ue2a8\ue2af\ue2be\ue2b5\ue2bc\ue2ae\ue2b8\ue2b9\ue291\ue2b4\ue2be\ue2b8\ue2b3\ue2ae\ue2b8\ue29f\ue2a4\ue289\ue2a4\ue2ad\ue2b8\ue2ae", 58008), _E001);

		public static string Reports => ResourceManager.GetString(global::_E000._E000("\ue1b9\ue18e\ue19b\ue184\ue199\ue19f\ue198", 57793), _E001);

		public static string ReportSections => ResourceManager.GetString(global::_E000._E000("\ue4b9\ue48e\ue49b\ue484\ue499\ue49f\ue4b8\ue48e\ue488\ue49f\ue482\ue484\ue485\ue498", 58563), _E001);

		public static string ReportShifts => ResourceManager.GetString(global::_E000._E000("\uf4ad\uf49a\uf48f\uf490\uf48d\uf48b\uf4ac\uf497\uf496\uf499\uf48b\uf48c", 62567), _E001);

		public static string ReportTaxes => ResourceManager.GetString(global::_E000._E000("\uf1ad\uf19a\uf18f\uf190\uf18d\uf18b\uf1ab\uf19e\uf187\uf19a\uf18c", 61899), _E001);

		public static string ReportView => ResourceManager.GetString(global::_E000._E000("\ue960\ue957\ue942\ue95d\ue940\ue946\ue964\ue95b\ue957\ue945", 59696), _E001);

		public static string ReportX => ResourceManager.GetString(global::_E000._E000("\uf4ad\uf49a\uf48f\uf490\uf48d\uf48b\uf4a7", 62583), _E001);

		public static string ReportZ => ResourceManager.GetString(global::_E000._E000("\uf7bf\uf788\uf79d\uf782\uf79f\uf799\uf7b7", 63468), _E001);

		public static string Request => ResourceManager.GetString(global::_E000._E000("\uf5a9\uf59e\uf58a\uf58e\uf59e\uf588\uf58f", 62803), _E001);

		public static string RequestConfirmCode => ResourceManager.GetString(global::_E000._E000("\ue4ec\ue4db\ue4cf\ue4cb\ue4db\ue4cd\ue4ca\ue4fd\ue4d1\ue4d0\ue4d8\ue4d7\ue4cc\ue4d3\ue4fd\ue4d1\ue4da\ue4db", 58542), _E001);

		public static string RequestForCheckFrom => ResourceManager.GetString(global::_E000._E000("\uf6cc\uf6fb\uf6ef\uf6eb\uf6fb\uf6ed\uf6ea\uf6d8\uf6f1\uf6ec\uf6dd\uf6f6\uf6fb\uf6fd\uf6f5\uf6d8\uf6ec\uf6f1\uf6f3", 63118), _E001);

		public static string Requesting => ResourceManager.GetString(global::_E000._E000("\ue62d\ue61a\ue60e\ue60a\ue61a\ue60c\ue60b\ue616\ue611\ue618", 59003), _E001);

		public static string RequestNotFound => ResourceManager.GetString(global::_E000._E000("\ue43d\ue40a\ue41e\ue41a\ue40a\ue41c\ue41b\ue421\ue400\ue41b\ue429\ue400\ue41a\ue401\ue40b", 58410), _E001);

		public static string RequestType => ResourceManager.GetString(global::_E000._E000("\ue72f\ue718\ue70c\ue708\ue718\ue70e\ue709\ue729\ue704\ue70d\ue718", 59256), _E001);

		public static string Required => ResourceManager.GetString(global::_E000._E000("\ue94c\ue97b\ue96f\ue96b\ue977\ue96c\ue97b\ue97a", 59662), _E001);

		public static string Reset => ResourceManager.GetString(global::_E000._E000("\ueddb\uedec\uedfa\uedec\uedfd", 60681), _E001);

		public static string ResetPassword => ResourceManager.GetString(global::_E000._E000("\ue42d\ue41a\ue40c\ue41a\ue40b\ue42f\ue41e\ue40c\ue40c\ue408\ue410\ue40d\ue41b", 58490), _E001);

		public static string Response => ResourceManager.GetString(global::_E000._E000("\uf6a0\uf697\uf681\uf682\uf69d\uf69c\uf681\uf697", 63216), _E001);

		public static string RestartNotify => ResourceManager.GetString(global::_E000._E000("\ue960\ue957\ue941\ue946\ue953\ue940\ue946\ue97c\ue95d\ue946\ue95b\ue954\ue94b", 59696), _E001);

		public static string Result => ResourceManager.GetString(global::_E000._E000("\uf5f9\uf5ce\uf5d8\uf5de\uf5c7\uf5df", 62849), _E001);

		public static string ReTryPhoneCode => ResourceManager.GetString(global::_E000._E000("\ue7af\ue798\ue7a9\ue78f\ue784\ue7ad\ue795\ue792\ue793\ue798\ue7be\ue792\ue799\ue798", 59368), _E001);

		public static string Return => ResourceManager.GetString(global::_E000._E000("\uf4bf\uf488\uf499\uf498\uf49f\uf483", 62693), _E001);

		public static string ReturnBuy => ResourceManager.GetString(global::_E000._E000("\uf3ad\uf39a\uf38b\uf38a\uf38d\uf391\uf3bd\uf38a\uf386", 62303), _E001);

		public static string ReturnByCheckNumber => ResourceManager.GetString(global::_E000._E000("\ue9b5\ue982\ue993\ue992\ue995\ue989\ue9a5\ue99e\ue9a4\ue98f\ue982\ue984\ue98c\ue9a9\ue992\ue98a\ue985\ue982\ue995", 59812), _E001);

		public static string ReturnCheck => ResourceManager.GetString(global::_E000._E000("\uefad\uef9a\uef8b\uef8a\uef8d\uef91\uefbc\uef97\uef9a\uef9c\uef94", 61439), _E001);

		public static string ReturnOperation => ResourceManager.GetString(global::_E000._E000("\ue4bf\ue488\ue499\ue498\ue49f\ue483\ue4a2\ue49d\ue488\ue49f\ue48c\ue499\ue484\ue482\ue483", 58604), _E001);

		public static string ReturnPurchasesPlural => ResourceManager.GetString(global::_E000._E000("\uf561\uf556\uf547\uf546\uf541\uf55d\uf563\uf546\uf541\uf550\uf55b\uf552\uf540\uf556\uf540\uf563\uf55f\uf546\uf541\uf552\uf55f", 62770), _E001);

		public static string ReturnSalesPlural => ResourceManager.GetString(global::_E000._E000("\ue89b\ue8ac\ue8bd\ue8bc\ue8bb\ue8a7\ue89a\ue8a8\ue8a5\ue8ac\ue8ba\ue899\ue8a5\ue8bc\ue8bb\ue8a8\ue8a5", 59593), _E001);

		public static string ReturnSell => ResourceManager.GetString(global::_E000._E000("\ue3a0\ue397\ue386\ue387\ue380\ue39c\ue3a1\ue397\ue39e\ue39e", 58352), _E001);

		public static string ReviewCashboxes => ResourceManager.GetString(global::_E000._E000("\ue9e1\ue9d6\ue9c5\ue9da\ue9d6\ue9c4\ue9f0\ue9d2\ue9c0\ue9db\ue9d1\ue9dc\ue9cb\ue9d6\ue9c0", 59778), _E001);

		public static string RmneManage => ResourceManager.GetString(global::_E000._E000("\uef7f\uef40\uef43\uef48\uef60\uef4c\uef43\uef4c\uef4a\uef48", 61228), _E001);

		public static string RNMIManage => ResourceManager.GetString(global::_E000._E000("\ue8cb\ue8d7\ue8d4\ue8d0\ue8d4\ue8f8\ue8f7\ue8f8\ue8fe\ue8fc", 59545), _E001);

		public static string Running => ResourceManager.GetString(global::_E000._E000("\ue92f\ue908\ue913\ue913\ue914\ue913\ue91a", 59740), _E001);

		public static string Russian => ResourceManager.GetString(global::_E000._E000("\ue7ad\ue78a\ue78c\ue78c\ue796\ue79e\ue791", 59357), _E001);

		public static string SalesCount => ResourceManager.GetString(global::_E000._E000("\ue50e\ue53c\ue531\ue538\ue52e\ue51e\ue532\ue528\ue533\ue529", 58648), _E001);

		public static string SalesPlural => ResourceManager.GetString(global::_E000._E000("\ue2a8\ue29a\ue297\ue29e\ue288\ue2ab\ue297\ue28e\ue289\ue29a\ue297", 57969), _E001);

		public static string SalesSum => ResourceManager.GetString(global::_E000._E000("\ue62e\ue61c\ue611\ue618\ue60e\ue62e\ue608\ue610", 59000), _E001);

		public static string Save => ResourceManager.GetString(global::_E000._E000("\ue5a0\ue592\ue585\ue596", 58818), _E001);

		public static string SaveCheck => ResourceManager.GetString(global::_E000._E000("\ue72e\ue71c\ue70b\ue718\ue73e\ue715\ue718\ue71e\ue716", 59228), _E001);

		public static string Saving => ResourceManager.GetString(global::_E000._E000("\uf4ca\uf4f8\uf4ef\uf4f0\uf4f7\uf4fe", 62489), _E001);

		public static string SC => ResourceManager.GetString(global::_E000._E000("\ued9c\ued8c", 60870), _E001);

		public static string SCCabinet => ResourceManager.GetString(global::_E000._E000("\ue4ae\ue4be\ue4be\ue49c\ue49f\ue494\ue493\ue498\ue489", 58536), _E001);

		public static string SCContracts => ResourceManager.GetString(global::_E000._E000("\uf5a1\uf5b1\uf5b1\uf59d\uf59c\uf586\uf580\uf593\uf591\uf586\uf581", 62960), _E001);

		public static string Search => ResourceManager.GetString(global::_E000._E000("\ue8a8\ue89e\ue89a\ue889\ue898\ue893", 59507), _E001);

		public static string Second => ResourceManager.GetString(global::_E000._E000("\uf3bc\uf38a\uf38c\uf380\uf381\uf38b", 62378), _E001);

		public static string Section => ResourceManager.GetString(global::_E000._E000("\uf42c\uf41a\uf41c\uf40b\uf416\uf410\uf411", 62555), _E001);

		public static string SectionNameFieldEmptyError => ResourceManager.GetString(global::_E000._E000("\ue80e\ue838\ue83e\ue829\ue834\ue832\ue833\ue813\ue83c\ue830\ue838\ue81b\ue834\ue838\ue831\ue839\ue818\ue830\ue82d\ue829\ue824\ue818\ue82f\ue82f\ue832\ue82f", 59400), _E001);

		public static string SectionNotFound => ResourceManager.GetString(global::_E000._E000("\uf2a8\uf29e\uf298\uf28f\uf292\uf294\uf295\uf2b5\uf294\uf28f\uf2bd\uf294\uf28e\uf295\uf29f", 62193), _E001);

		public static string SectionNotFoundInOrganization => ResourceManager.GetString(global::_E000._E000("\uf3bc\uf38a\uf38c\uf39b\uf386\uf380\uf381\uf3a1\uf380\uf39b\uf3a9\uf380\uf39a\uf381\uf38b\uf3a6\uf381\uf3a0\uf39d\uf388\uf38e\uf381\uf386\uf395\uf38e\uf39b\uf386\uf380\uf381", 62442), _E001);

		public static string SectionOperations => ResourceManager.GetString(global::_E000._E000("\uf6f8\uf6ce\uf6c8\uf6df\uf6c2\uf6c4\uf6c5\uf6e4\uf6db\uf6ce\uf6d9\uf6ca\uf6df\uf6c2\uf6c4\uf6c5\uf6d8", 63107), _E001);

		public static string Sections => ResourceManager.GetString(global::_E000._E000("\uedac\ued9a\ued9c\ued8b\ued96\ued90\ued91\ued8c", 60893), _E001);

		public static string SectionsManage => ResourceManager.GetString(global::_E000._E000("\ue131\ue107\ue101\ue116\ue10b\ue10d\ue10c\ue111\ue12f\ue103\ue10c\ue103\ue105\ue107", 57696), _E001);

		public static string Select => ResourceManager.GetString(global::_E000._E000("\ue7e0\ue7d6\ue7df\ue7d6\ue7d0\ue7c7", 59298), _E001);

		public static string SelectAll => ResourceManager.GetString(global::_E000._E000("\ueabc\uea8a\uea83\uea8a\uea8c\uea9b\ueaae\uea83\uea83", 59917), _E001);

		public static string SelectAvailableCashbox => ResourceManager.GetString(global::_E000._E000("\uf24d\uf27b\uf272\uf27b\uf27d\uf26a\uf25f\uf268\uf27f\uf277\uf272\uf27f\uf27c\uf272\uf27b\uf25d\uf27f\uf26d\uf276\uf27c\uf271\uf266", 61982), _E001);

		public static string SelectAvailableCashboxInTheDropDownListOrGoTo => ResourceManager.GetString(global::_E000._E000("\ue28a\ue2bc\ue2b5\ue2bc\ue2ba\ue2ad\ue298\ue2af\ue2b8\ue2b0\ue2b5\ue2b8\ue2bb\ue2b5\ue2bc\ue29a\ue2b8\ue2aa\ue2b1\ue2bb\ue2b6\ue2a1\ue290\ue2b7\ue28d\ue2b1\ue2bc\ue29d\ue2ab\ue2b6\ue2a9\ue29d\ue2b6\ue2ae\ue2b7\ue295\ue2b0\ue2aa\ue2ad\ue296\ue2ab\ue29e\ue2b6\ue28d\ue2b6", 57945), _E001);

		public static string SelectCurrency => ResourceManager.GetString(global::_E000._E000("\uf0a8\uf09e\uf097\uf09e\uf098\uf08f\uf0b8\uf08e\uf089\uf089\uf09e\uf095\uf098\uf082", 61521), _E001);

		public static string SelectElectronicSignature => ResourceManager.GetString(global::_E000._E000("\ue4e8\ue4de\ue4d7\ue4de\ue4d8\ue4cf\ue4fe\ue4d7\ue4de\ue4d8\ue4cf\ue4c9\ue4d4\ue4d5\ue4d2\ue4d8\ue4e8\ue4d2\ue4dc\ue4d5\ue4da\ue4cf\ue4ce\ue4c9\ue4de", 58387), _E001);

		public static string SelectSectionDefault => ResourceManager.GetString(global::_E000._E000("\uf06d\uf05b\uf052\uf05b\uf05d\uf04a\uf06d\uf05b\uf05d\uf04a\uf057\uf051\uf050\uf07a\uf05b\uf058\uf05f\uf04b\uf052\uf04a", 61486), _E001);

		public static string SelectСryptoKey => ResourceManager.GetString(global::_E000._E000("\ue43c\ue40a\ue403\ue40a\ue40c\ue41b\ue04e\ue41d\ue416\ue41f\ue41b\ue400\ue424\ue40a\ue416", 58378), _E001);

		public static string Sell => ResourceManager.GetString(global::_E000._E000("\uecbc\uec8a\uec83\uec83", 60525), _E001);

		public static string Send => ResourceManager.GetString(global::_E000._E000("\ue28a\ue2bc\ue2b7\ue2bd", 57945), _E001);

		public static string Sender => ResourceManager.GetString(global::_E000._E000("\ue82e\ue818\ue813\ue819\ue818\ue80f", 59516), _E001);

		public static string SendLinkByEmail => ResourceManager.GetString(global::_E000._E000("\uf7be\uf788\uf783\uf789\uf7a1\uf784\uf783\uf786\uf7af\uf794\uf7a8\uf780\uf78c\uf784\uf781", 63429), _E001);

		public static string SendOfflineMessageInProgress => ResourceManager.GetString(global::_E000._E000("\uf5b8\uf58e\uf585\uf58f\uf5a4\uf58d\uf58d\uf587\uf582\uf585\uf58e\uf5a6\uf58e\uf598\uf598\uf58a\uf58c\uf58e\uf5a2\uf585\uf5bb\uf599\uf584\uf58c\uf599\uf58e\uf598\uf598", 62945), _E001);

		public static string SendPinCode => ResourceManager.GetString(global::_E000._E000("\ue72c\ue71a\ue711\ue71b\ue72f\ue716\ue711\ue73c\ue710\ue71b\ue71a", 59162), _E001);

		public static string SendToEmailDemoAccount => ResourceManager.GetString(global::_E000._E000("\ue7ec\ue7da\ue7d1\ue7db\ue7eb\ue7d0\ue7fa\ue7d2\ue7de\ue7d6\ue7d3\ue7fb\ue7da\ue7d2\ue7d0\ue7fe\ue7dc\ue7dc\ue7d0\ue7ca\ue7d1\ue7cb", 59319), _E001);

		public static string SendToPhoneConfirmCode => ResourceManager.GetString(global::_E000._E000("\uea0d\uea3b\uea30\uea3a\uea0a\uea31\uea0e\uea36\uea31\uea30\uea3b\uea1d\uea31\uea30\uea38\uea37\uea2c\uea33\uea1d\uea31\uea3a\uea3b", 59998), _E001);

		public static string September => ResourceManager.GetString(global::_E000._E000("\uf27e\uf248\uf25d\uf259\uf248\uf240\uf24f\uf248\uf25f", 61964), _E001);

		public static string ServerDidNotResponse => ResourceManager.GetString(global::_E000._E000("\ue821\ue817\ue800\ue804\ue817\ue800\ue836\ue81b\ue816\ue83c\ue81d\ue806\ue820\ue817\ue801\ue802\ue81d\ue81c\ue801\ue817", 59504), _E001);

		public static string ServerExchangesHistory => ResourceManager.GetString(global::_E000._E000("\uf6bc\uf68a\uf69d\uf699\uf68a\uf69d\uf6aa\uf697\uf68c\uf687\uf68e\uf681\uf688\uf68a\uf69c\uf6a7\uf686\uf69c\uf69b\uf680\uf69d\uf696", 63181), _E001);

		public static string ServerIncorrectDateTime => ResourceManager.GetString(global::_E000._E000("\uf8ac\uf89a\uf88d\uf889\uf89a\uf88d\uf8b6\uf891\uf89c\uf890\uf88d\uf88d\uf89a\uf89c\uf88b\uf8bb\uf89e\uf88b\uf89a\uf8ab\uf896\uf892\uf89a", 63735), _E001);

		public static string ServerInternalErrorContactSupport => ResourceManager.GetString(global::_E000._E000("\ue2aa\ue29c\ue28b\ue28f\ue29c\ue28b\ue2b0\ue297\ue28d\ue29c\ue28b\ue297\ue298\ue295\ue2bc\ue28b\ue28b\ue296\ue28b\ue2ba\ue296\ue297\ue28d\ue298\ue29a\ue28d\ue2aa\ue28c\ue289\ue289\ue296\ue28b\ue28d", 57977), _E001);

		public static string ServerSettingsEdit => ResourceManager.GetString(global::_E000._E000("\ueafe\ueac8\ueadf\ueadb\ueac8\ueadf\ueafe\ueac8\uead9\uead9\ueac4\ueac3\ueaca\ueade\ueae8\ueac9\ueac4\uead9", 60076), _E001);

		public static string ServiceCenterBelongCashboxes => ResourceManager.GetString(global::_E000._E000("\ue32c\ue31a\ue30d\ue309\ue316\ue31c\ue31a\ue33c\ue31a\ue311\ue30b\ue31a\ue30d\ue33d\ue31a\ue313\ue310\ue311\ue318\ue33c\ue31e\ue30c\ue317\ue31d\ue310\ue307\ue31a\ue30c", 58230), _E001);

		public static string ServiceCenterBelongCashboxesActive => ResourceManager.GetString(global::_E000._E000("\uf0f8\uf0ce\uf0d9\uf0dd\uf0c2\uf0c8\uf0ce\uf0e8\uf0ce\uf0c5\uf0df\uf0ce\uf0d9\uf0e9\uf0ce\uf0c7\uf0c4\uf0c5\uf0cc\uf0e8\uf0ca\uf0d8\uf0c3\uf0c9\uf0c4\uf0d3\uf0ce\uf0d8\uf0ea\uf0c8\uf0df\uf0c2\uf0dd\uf0ce", 61443), _E001);

		public static string ServiceCenterBelongCashboxesConnectButExpired => ResourceManager.GetString(global::_E000._E000("\ue3ae\ue398\ue38f\ue38b\ue394\ue39e\ue398\ue3be\ue398\ue393\ue389\ue398\ue38f\ue3bf\ue398\ue391\ue392\ue393\ue39a\ue3be\ue39c\ue38e\ue395\ue39f\ue392\ue385\ue398\ue38e\ue3be\ue392\ue393\ue393\ue398\ue39e\ue389\ue3bf\ue388\ue389\ue3b8\ue385\ue38d\ue394\ue38f\ue398\ue399", 58344), _E001);

		public static string ServiceCenterCurrentLevel => ResourceManager.GetString(global::_E000._E000("\ue98c\ue9ba\ue9ad\ue9a9\ue9b6\ue9bc\ue9ba\ue99c\ue9ba\ue9b1\ue9ab\ue9ba\ue9ad\ue99c\ue9aa\ue9ad\ue9ad\ue9ba\ue9b1\ue9ab\ue993\ue9ba\ue9a9\ue9ba\ue9b3", 59862), _E001);

		public static string ServiceCenterFreeServiceCashboxes => ResourceManager.GetString(global::_E000._E000("\ue87e\ue848\ue85f\ue85b\ue844\ue84e\ue848\ue86e\ue848\ue843\ue859\ue848\ue85f\ue86b\ue85f\ue848\ue848\ue87e\ue848\ue85f\ue85b\ue844\ue84e\ue848\ue86e\ue84c\ue85e\ue845\ue84f\ue842\ue855\ue848\ue85e", 59404), _E001);

		public static string ServiceCenterKOfdCashboxes => ResourceManager.GetString(global::_E000._E000("\ue2ec\ue2da\ue2cd\ue2c9\ue2d6\ue2dc\ue2da\ue2fc\ue2da\ue2d1\ue2cb\ue2da\ue2cd\ue2f4\ue2f0\ue2d9\ue2db\ue2fc\ue2de\ue2cc\ue2d7\ue2dd\ue2d0\ue2c7\ue2da\ue2cc", 58039), _E001);

		public static string ServiceCenterLevelAtDate => ResourceManager.GetString(global::_E000._E000("\uf031\uf007\uf010\uf014\uf00b\uf001\uf007\uf021\uf007\uf00c\uf016\uf007\uf010\uf02e\uf007\uf014\uf007\uf00e\uf023\uf016\uf026\uf003\uf016\uf007", 61536), _E001);

		public static string ServiceCenterLevelHistory => ResourceManager.GetString(global::_E000._E000("\uebbc\ueb8a\ueb9d\ueb99\ueb86\ueb8c\ueb8a\uebac\ueb8a\ueb81\ueb9b\ueb8a\ueb9d\ueba3\ueb8a\ueb99\ueb8a\ueb83\ueba7\ueb86\ueb9c\ueb9b\ueb80\ueb9d\ueb96", 60173), _E001);

		public static string ServiceCenterLevelHistoryView => ResourceManager.GetString(global::_E000._E000("\ueaac\uea9a\uea8d\uea89\uea96\uea9c\uea9a\ueabc\uea9a\uea91\uea8b\uea9a\uea8d\ueab3\uea9a\uea89\uea9a\uea93\ueab7\uea96\uea8c\uea8b\uea90\uea8d\uea86\ueaa9\uea96\uea9a\uea88", 60029), _E001);

		public static string ServiceCenterName => ResourceManager.GetString(global::_E000._E000("\ued1c\ued2a\ued3d\ued39\ued26\ued2c\ued2a\ued0c\ued2a\ued21\ued3b\ued2a\ued3d\ued01\ued2e\ued22\ued2a", 60742), _E001);

		public static string ServiceCenterPaidServiceCashboxes => ResourceManager.GetString(global::_E000._E000("\ue27e\ue248\ue25f\ue25b\ue244\ue24e\ue248\ue26e\ue248\ue243\ue259\ue248\ue25f\ue27d\ue24c\ue244\ue249\ue27e\ue248\ue25f\ue25b\ue244\ue24e\ue248\ue26e\ue24c\ue25e\ue245\ue24f\ue242\ue255\ue248\ue25e", 57900), _E001);

		public static string ServiceCenterServicedCashboxes => ResourceManager.GetString(global::_E000._E000("\uefac\uef9a\uef8d\uef89\uef96\uef9c\uef9a\uefbc\uef9a\uef91\uef8b\uef9a\uef8d\uefac\uef9a\uef8d\uef89\uef96\uef9c\uef9a\uef9b\uefbc\uef9e\uef8c\uef97\uef9d\uef90\uef87\uef9a\uef8c", 61431), _E001);

		public static string ServiceCenterServiceDereregisterCashboxes => ResourceManager.GetString(global::_E000._E000("\uf4a4\uf492\uf485\uf481\uf49e\uf494\uf492\uf4b4\uf492\uf499\uf483\uf492\uf485\uf4a4\uf492\uf485\uf481\uf49e\uf494\uf492\uf4b3\uf492\uf485\uf492\uf485\uf492\uf490\uf49e\uf484\uf483\uf492\uf485\uf4b4\uf496\uf484\uf49f\uf495\uf498\uf48f\uf492\uf484", 62580), _E001);

		public static string ServiceCenterServiceFreeCashboxes => ResourceManager.GetString(global::_E000._E000("\ue62c\ue61a\ue60d\ue609\ue616\ue61c\ue61a\ue63c\ue61a\ue611\ue60b\ue61a\ue60d\ue62c\ue61a\ue60d\ue609\ue616\ue61c\ue61a\ue639\ue60d\ue61a\ue61a\ue63c\ue61e\ue60c\ue617\ue61d\ue610\ue607\ue61a\ue60c", 58987), _E001);

		public static string ServiceCentersReportOnCurrentDate => ResourceManager.GetString(global::_E000._E000("\ue06c\ue05a\ue04d\ue049\ue056\ue05c\ue05a\ue07c\ue05a\ue051\ue04b\ue05a\ue04d\ue04c\ue06d\ue05a\ue04f\ue050\ue04d\ue04b\ue070\ue051\ue07c\ue04a\ue04d\ue04d\ue05a\ue051\ue04b\ue07b\ue05e\ue04b\ue05a", 57371), _E001);

		public static string ServiceCenterXin => ResourceManager.GetString(global::_E000._E000("\ue2b1\ue287\ue290\ue294\ue28b\ue281\ue287\ue2a1\ue287\ue28c\ue296\ue287\ue290\ue2ba\ue28b\ue28c", 58048), _E001);

		public static string SessionExpiredOn => ResourceManager.GetString(global::_E000._E000("\ue8cc\ue8fa\ue8ec\ue8ec\ue8f6\ue8f0\ue8f1\ue8da\ue8e7\ue8ef\ue8f6\ue8ed\ue8fa\ue8fb\ue8d0\ue8f1", 59527), _E001);

		public static string SetTaxFromSection => ResourceManager.GetString(global::_E000._E000("\uf7ac\uf79a\uf78b\uf7ab\uf79e\uf787\uf7b9\uf78d\uf790\uf792\uf7ac\uf79a\uf79c\uf78b\uf796\uf790\uf791", 63482), _E001);

		public static string Setting => ResourceManager.GetString(global::_E000._E000("\ue23c\ue20a\ue21b\ue21b\ue206\ue201\ue208", 57958), _E001);

		public static string SettingForAllCashbox => ResourceManager.GetString(global::_E000._E000("\uecca\uecfc\ueced\ueced\uecf0\uecf7\uecfe\uecdf\uecf6\ueceb\uecd8\uecf5\uecf5\uecda\uecf8\uecea\uecf1\uecfb\uecf6\uece1", 60569), _E001);

		public static string Settings => ResourceManager.GetString(global::_E000._E000("\uefed\uefdb\uefca\uefca\uefd7\uefd0\uefd9\uefcd", 61358), _E001);

		public static string SettingsAbsent => ResourceManager.GetString(global::_E000._E000("\uf80d\uf83b\uf82a\uf82a\uf837\uf830\uf839\uf82d\uf81f\uf83c\uf82d\uf83b\uf830\uf82a", 63566), _E001);

		public static string SettingsSaved => ResourceManager.GetString(global::_E000._E000("\uf1ac\uf19a\uf18b\uf18b\uf196\uf191\uf198\uf18c\uf1ac\uf19e\uf189\uf19a\uf19b", 61949), _E001);

		public static string Shift => ResourceManager.GetString(global::_E000._E000("\uf0a8\uf093\uf092\uf09d\uf08f", 61523), _E001);

		public static string ShiftAlreadyClosed => ResourceManager.GetString(global::_E000._E000("\ueada\ueae1\ueae0\ueaef\ueafd\ueac8\ueae5\ueafb\ueaec\ueae8\ueaed\ueaf0\ueaca\ueae5\ueae6\ueafa\ueaec\ueaed", 60041), _E001);

		public static string ShiftClose => ResourceManager.GetString(global::_E000._E000("\uef0c\uef37\uef36\uef39\uef2b\uef1c\uef33\uef30\uef2c\uef3a", 61206), _E001);

		public static string ShiftCloseDates => ResourceManager.GetString(global::_E000._E000("\ue2a1\ue29a\ue29b\ue294\ue286\ue2b1\ue29e\ue29d\ue281\ue297\ue2b6\ue293\ue286\ue297\ue281", 58096), _E001);

		public static string ShiftClosedMessage => ResourceManager.GetString(global::_E000._E000("\uebad\ueb96\ueb97\ueb98\ueb8a\uebbd\ueb92\ueb91\ueb8d\ueb9b\ueb9a\uebb3\ueb9b\ueb8d\ueb8d\ueb9f\ueb99\ueb9b", 60414), _E001);

		public static string ShiftClosePin => ResourceManager.GetString(global::_E000._E000("\uf6ec\uf6d7\uf6d6\uf6d9\uf6cb\uf6fc\uf6d3\uf6d0\uf6cc\uf6da\uf6ef\uf6d6\uf6d1", 63147), _E001);

		public static string ShiftDataUpdateFailedTheServerReturnAnError => ResourceManager.GetString(global::_E000._E000("\uec6e\uec55\uec54\uec5b\uec49\uec79\uec5c\uec49\uec5c\uec68\uec4d\uec59\uec5c\uec49\uec58\uec7b\uec5c\uec54\uec51\uec58\uec59\uec69\uec55\uec58\uec6e\uec58\uec4f\uec4b\uec58\uec4f\uec6f\uec58\uec49\uec48\uec4f\uec53\uec7c\uec53\uec78\uec4f\uec4f\uec52\uec4f", 60444), _E001);

		public static string ShiftInformation => ResourceManager.GetString(global::_E000._E000("\ue9bc\ue987\ue986\ue989\ue99b\ue9a6\ue981\ue989\ue980\ue99d\ue982\ue98e\ue99b\ue986\ue980\ue981", 59818), _E001);

		public static string Shifts => ResourceManager.GetString(global::_E000._E000("\uf8f8\uf8c3\uf8c2\uf8cd\uf8df\uf8d8", 63491), _E001);

		public static string ShiftsNotFound => ResourceManager.GetString(global::_E000._E000("\ue884\ue8bf\ue8be\ue8b1\ue8a3\ue8a4\ue899\ue8b8\ue8a3\ue891\ue8b8\ue8a2\ue8b9\ue8b3", 59476), _E001);

		public static string ShortHour => ResourceManager.GetString(global::_E000._E000("\ue9ac\ue997\ue990\ue98d\ue98b\ue9b7\ue990\ue98a\ue98d", 59775), _E001);

		public static string ShortMin => ResourceManager.GetString(global::_E000._E000("\ueabc\uea87\uea80\uea9d\uea9b\ueaa2\uea86\uea81", 60070), _E001);

		public static string ShortTenge => ResourceManager.GetString(global::_E000._E000("\ue1ec\ue1d7\ue1d0\ue1cd\ue1cb\ue1eb\ue1da\ue1d1\ue1d8\ue1da", 57783), _E001);

		public static string Show => ResourceManager.GetString(global::_E000._E000("\ue7e8\ue7d3\ue7d4\ue7cc", 59155), _E001);

		public static string ShowReports => ResourceManager.GetString(global::_E000._E000("\uef3e\uef05\uef02\uef1a\uef3f\uef08\uef1d\uef02\uef1f\uef19\uef1e", 61189), _E001);

		public static string ShtrihCode => ResourceManager.GetString(global::_E000._E000("\ue4ec\ue4d7\ue4cb\ue4cd\ue4d6\ue4d7\ue4fc\ue4d0\ue4db\ue4da", 58407), _E001);

		public static string SignInToGetStarted => ResourceManager.GetString(global::_E000._E000("\ue5e8\ue5d2\ue5dc\ue5d5\ue5f2\ue5d5\ue5ef\ue5d4\ue5fc\ue5de\ue5cf\ue5e8\ue5cf\ue5da\ue5c9\ue5cf\ue5de\ue5df", 58803), _E001);

		public static string SimpleReturn => ResourceManager.GetString(global::_E000._E000("\uf16e\uf154\uf150\uf14d\uf151\uf158\uf16f\uf158\uf149\uf148\uf14f\uf153", 61724), _E001);

		public static string Site => ResourceManager.GetString(global::_E000._E000("\ueaf8\ueac2\ueadf\ueace", 60035), _E001);

		public static string SmartPlazaLoadCheckAndBonusPart1 => ResourceManager.GetString(global::_E000._E000("\uedac\ued92\ued9e\ued8d\ued8b\uedaf\ued93\ued9e\ued85\ued9e\uedb3\ued90\ued9e\ued9b\uedbc\ued97\ued9a\ued9c\ued94\uedbe\ued91\ued9b\uedbd\ued90\ued91\ued8a\ued8c\uedaf\ued9e\ued8d\ued8b\uedce", 60891), _E001);

		public static string SmartPlazaLoadCheckAndBonusPart2 => ResourceManager.GetString(global::_E000._E000("\ue9a0\ue99e\ue992\ue981\ue987\ue9a3\ue99f\ue992\ue989\ue992\ue9bf\ue99c\ue992\ue997\ue9b0\ue99b\ue996\ue990\ue998\ue9b2\ue99d\ue997\ue9b1\ue99c\ue99d\ue986\ue980\ue9a3\ue992\ue981\ue987\ue9c1", 59890), _E001);

		public static string SMTPConfigurationError => ResourceManager.GetString(global::_E000._E000("\uf1f8\uf1e6\uf1ff\uf1fb\uf1e8\uf1c4\uf1c5\uf1cd\uf1c2\uf1cc\uf1de\uf1d9\uf1ca\uf1df\uf1c2\uf1c4\uf1c5\uf1ee\uf1d9\uf1d9\uf1c4\uf1d9", 61859), _E001);

		public static string StartCashboxWithPort => ResourceManager.GetString(global::_E000._E000("\ue62e\ue609\ue61c\ue60f\ue609\ue63e\ue61c\ue60e\ue615\ue61f\ue612\ue605\ue62a\ue614\ue609\ue615\ue62d\ue612\ue60f\ue609", 58901), _E001);

		public static string StartPeriod => ResourceManager.GetString(global::_E000._E000("\uf771\uf756\uf743\uf750\uf756\uf772\uf747\uf750\uf74b\uf74d\uf746", 63232), _E001);

		public static string StateTypeNotSupported => ResourceManager.GetString(global::_E000._E000("\ue7ae\ue789\ue79c\ue789\ue798\ue7a9\ue784\ue78d\ue798\ue7b3\ue792\ue789\ue7ae\ue788\ue78d\ue78d\ue792\ue78f\ue789\ue798\ue799", 59317), _E001);

		public static string Status => ResourceManager.GetString(global::_E000._E000("\ue7cc\ue7eb\ue7fe\ue7eb\ue7ea\ue7ec", 59287), _E001);

		public static string StopCashboxWithPort => ResourceManager.GetString(global::_E000._E000("\uf8ac\uf88b\uf890\uf88f\uf8bc\uf89e\uf88c\uf897\uf89d\uf890\uf887\uf8a8\uf896\uf88b\uf897\uf8af\uf890\uf88d\uf88b", 63607), _E001);

		public static string Stopped => ResourceManager.GetString(global::_E000._E000("\uf5b8\uf59f\uf584\uf59b\uf59b\uf58e\uf58f", 62787), _E001);

		public static string StornoOperation => ResourceManager.GetString(global::_E000._E000("\ue00e\ue029\ue032\ue02f\ue033\ue032\ue012\ue02d\ue038\ue02f\ue03c\ue029\ue034\ue032\ue033", 57352), _E001);

		public static string String1 => ResourceManager.GetString(global::_E000._E000("\uf72c\uf70b\uf70d\uf716\uf711\uf718\uf74e", 63290), _E001);

		public static string String2 => ResourceManager.GetString(global::_E000._E000("\uf40c\uf42b\uf42d\uf436\uf431\uf438\uf46d", 62550), _E001);

		public static string Success => ResourceManager.GetString(global::_E000._E000("\ueba1\ueb87\ueb91\ueb91\ueb97\ueb81\ueb81", 60368), _E001);

		public static string Sum => ResourceManager.GetString(global::_E000._E000("\uf2da\uf2fc\uf2e4", 62089), _E001);

		public static string SumCard => ResourceManager.GetString(global::_E000._E000("\uf23c\uf21a\uf202\uf22c\uf20e\uf21d\uf20b", 61990), _E001);

		public static string SumInCashBox => ResourceManager.GetString(global::_E000._E000("\ue2a0\ue286\ue29e\ue2ba\ue29d\ue2b0\ue292\ue280\ue29b\ue2b1\ue29c\ue28b", 58082), _E001);

		public static string SummaryOfTheSelectedPeriod => ResourceManager.GetString(global::_E000._E000("\uf094\uf0b2\uf0aa\uf0aa\uf0a6\uf0b5\uf0be\uf088\uf0a1\uf093\uf0af\uf0a2\uf094\uf0a2\uf0ab\uf0a2\uf0a4\uf0b3\uf0a2\uf0a3\uf097\uf0a2\uf0b5\uf0ae\uf0a8\uf0a3", 61572), _E001);

		public static string SumTotal => ResourceManager.GetString(global::_E000._E000("\ue2a4\ue282\ue29a\ue2a3\ue298\ue283\ue296\ue29b", 58100), _E001);

		public static string SupervisingManager => ResourceManager.GetString(global::_E000._E000("\ue91c\ue93a\ue93f\ue92a\ue93d\ue939\ue926\ue93c\ue926\ue921\ue928\ue902\ue92e\ue921\ue92e\ue928\ue92a\ue93d", 59718), _E001);

		public static string SupportCabinet => ResourceManager.GetString(global::_E000._E000("\uf2e1\uf2c7\uf2c2\uf2c2\uf2dd\uf2c0\uf2c6\uf2f1\uf2d3\uf2d0\uf2db\uf2dc\uf2d7\uf2c6", 62128), _E001);

		public static string SystemDescription => ResourceManager.GetString(global::_E000._E000("\ue1cc\ue1e6\ue1ec\ue1eb\ue1fa\ue1f2\ue1db\ue1fa\ue1ec\ue1fc\ue1ed\ue1f6\ue1ef\ue1eb\ue1f6\ue1f0\ue1f1", 57735), _E001);

		public static string SystemMessage => ResourceManager.GetString(global::_E000._E000("\ue384\ue3ae\ue3a4\ue3a3\ue3b2\ue3ba\ue39a\ue3b2\ue3a4\ue3a4\ue3b6\ue3b0\ue3b2", 58196), _E001);

		public static string SystemPrinter => ResourceManager.GetString(global::_E000._E000("\uf4ac\uf486\uf48c\uf48b\uf49a\uf492\uf4af\uf48d\uf496\uf491\uf48b\uf49a\uf48d", 62525), _E001);

		public static string SystemTypeEnumComputerSystem => ResourceManager.GetString(global::_E000._E000("\ue4ac\ue486\ue48c\ue48b\ue49a\ue492\ue4ab\ue486\ue48f\ue49a\ue4ba\ue491\ue48a\ue492\ue4bc\ue490\ue492\ue48f\ue48a\ue48b\ue49a\ue48d\ue4ac\ue486\ue48c\ue48b\ue49a\ue492", 58463), _E001);

		public static string SystemTypeEnumComputerSystemWithoutOfd => ResourceManager.GetString(global::_E000._E000("\uf7ca\uf7e0\uf7ea\uf7ed\uf7fc\uf7f4\uf7cd\uf7e0\uf7e9\uf7fc\uf7dc\uf7f7\uf7ec\uf7f4\uf7da\uf7f6\uf7f4\uf7e9\uf7ec\uf7ed\uf7fc\uf7eb\uf7ca\uf7e0\uf7ea\uf7ed\uf7fc\uf7f4\uf7ce\uf7f0\uf7ed\uf7f1\uf7f6\uf7ec\uf7ed\uf7d6\uf7ff\uf7fd", 63385), _E001);

		public static string SystemTypeEnumWebCash => ResourceManager.GetString(global::_E000._E000("\ue72e\ue704\ue70e\ue709\ue718\ue710\ue729\ue704\ue70d\ue718\ue738\ue713\ue708\ue710\ue72a\ue718\ue71f\ue73e\ue71c\ue70e\ue715", 59157), _E001);

		public static string SystemTypeEnumWebCashDemo => ResourceManager.GetString(global::_E000._E000("\ue77e\ue754\ue75e\ue759\ue748\ue740\ue779\ue754\ue75d\ue748\ue768\ue743\ue758\ue740\ue77a\ue748\ue74f\ue76e\ue74c\ue75e\ue745\ue769\ue748\ue740\ue742", 59180), _E001);

		public static string Tagline => ResourceManager.GetString(global::_E000._E000("\uf26b\uf25e\uf258\uf253\uf256\uf251\uf25a", 61979), _E001);

		public static string TakeCash => ResourceManager.GetString(global::_E000._E000("\uf2eb\uf2de\uf2d4\uf2da\uf2fc\uf2de\uf2cc\uf2d7", 61983), _E001);

		public static string TarifLever => ResourceManager.GetString(global::_E000._E000("\ue76a\ue75f\ue74c\ue757\ue758\ue772\ue75b\ue748\ue75b\ue74c", 59182), _E001);

		public static string TaxDifferentFromSectionTax => ResourceManager.GetString(global::_E000._E000("\uf6ff\uf6ca\uf6d3\uf6ef\uf6c2\uf6cd\uf6cd\uf6ce\uf6d9\uf6ce\uf6c5\uf6df\uf6ed\uf6d9\uf6c4\uf6c6\uf6f8\uf6ce\uf6c8\uf6df\uf6c2\uf6c4\uf6c5\uf6ff\uf6ca\uf6d3", 63011), _E001);

		public static string Taxed => ResourceManager.GetString(global::_E000._E000("\ue06b\ue05e\ue047\ue05a\ue05b", 57371), _E001);

		public static string TaxPercentNotFoundInOrganization => ResourceManager.GetString(global::_E000._E000("\uedbb\ued8e\ued97\uedbf\ued8a\ued9d\ued8c\ued8a\ued81\ued9b\ueda1\ued80\ued9b\ueda9\ued80\ued9a\ued81\ued8b\ueda6\ued81\ueda0\ued9d\ued88\ued8e\ued81\ued86\ued95\ued8e\ued9b\ued86\ued80\ued81", 60813), _E001);

		public static string Template => ResourceManager.GetString(global::_E000._E000("\uf039\uf008\uf000\uf01d\uf001\uf00c\uf019\uf008", 61445), _E001);

		public static string Template1 => ResourceManager.GetString(global::_E000._E000("\uf44a\uf47b\uf473\uf46e\uf472\uf47f\uf46a\uf47b\uf42f", 62478), _E001);

		public static string ThankYouForYourEmailConfirmation => ResourceManager.GetString(global::_E000._E000("\ue6ab\ue697\ue69e\ue691\ue694\ue6a6\ue690\ue68a\ue6b9\ue690\ue68d\ue6a6\ue690\ue68a\ue68d\ue6ba\ue692\ue69e\ue696\ue693\ue6bc\ue690\ue691\ue699\ue696\ue68d\ue692\ue69e\ue68b\ue696\ue690\ue691", 59133), _E001);

		public static string TheAmountMustBeGreaterThanZero => ResourceManager.GetString(global::_E000._E000("\uf129\uf115\uf118\uf13c\uf110\uf112\uf108\uf113\uf109\uf130\uf108\uf10e\uf109\uf13f\uf118\uf13a\uf10f\uf118\uf11c\uf109\uf118\uf10f\uf129\uf115\uf11c\uf113\uf127\uf118\uf10f\uf112", 61788), _E001);

		public static string ThirtyDaysLeftFromLastChangePass => ResourceManager.GetString(global::_E000._E000("\uf1a3\uf19f\uf19e\uf185\uf183\uf18e\uf1b3\uf196\uf18e\uf184\uf1bb\uf192\uf191\uf183\uf1b1\uf185\uf198\uf19a\uf1bb\uf196\uf184\uf183\uf1b4\uf19f\uf196\uf199\uf190\uf192\uf1a7\uf196\uf184\uf184", 61940), _E001);

		public static string ThisAccountIsLockedTryAgainLater => ResourceManager.GetString(global::_E000._E000("\uf526\uf51a\uf51b\uf501\uf533\uf511\uf511\uf51d\uf507\uf51c\uf506\uf53b\uf501\uf53e\uf51d\uf511\uf519\uf517\uf516\uf526\uf500\uf50b\uf533\uf515\uf513\uf51b\uf51c\uf53e\uf513\uf506\uf517\uf500", 62800), _E001);

		public static string TicketLanguage => ResourceManager.GetString(global::_E000._E000("\uf2a3\uf29e\uf294\uf29c\uf292\uf283\uf2bb\uf296\uf299\uf290\uf282\uf296\uf290\uf292", 62068), _E001);

		public static string TicketsSearch => ResourceManager.GetString(global::_E000._E000("\ue693\ue6ae\ue6a4\ue6ac\ue6a2\ue6b3\ue6b4\ue694\ue6a2\ue6a6\ue6b5\ue6a4\ue6af", 58884), _E001);

		public static string Time => ResourceManager.GetString(global::_E000._E000("\uf1fd\uf1c0\uf1c4\uf1cc", 61737), _E001);

		public static string TimeAutoCloseShift => ResourceManager.GetString(global::_E000._E000("\uf889\uf8b4\uf8b0\uf8b8\uf89c\uf8a8\uf8a9\uf8b2\uf89e\uf8b1\uf8b2\uf8ae\uf8b8\uf88e\uf8b5\uf8b4\uf8bb\uf8a9", 63688), _E001);

		public static string TooLongPriceOrDiscount => ResourceManager.GetString(global::_E000._E000("\uf2ab\uf290\uf290\uf2b3\uf290\uf291\uf298\uf2af\uf28d\uf296\uf29c\uf29a\uf2b0\uf28d\uf2bb\uf296\uf28c\uf29c\uf290\uf28a\uf291\uf28b", 62055), _E001);

		public static string Total => ResourceManager.GetString(global::_E000._E000("\ueee9\ueed2\ueec9\ueedc\ueed1", 61084), _E001);

		public static string TotalBySections => ResourceManager.GetString(global::_E000._E000("\ue9bb\ue980\ue99b\ue98e\ue983\ue9ad\ue996\ue9bc\ue98a\ue98c\ue99b\ue986\ue980\ue981\ue99c", 59885), _E001);

		public static string TotalSum => ResourceManager.GetString(global::_E000._E000("\uf8ff\uf8c4\uf8df\uf8ca\uf8c7\uf8f8\uf8de\uf8c6", 63617), _E001);

		public static string Trace => ResourceManager.GetString(global::_E000._E000("\ueaab\uea8d\uea9e\uea9c\uea9a", 60058), _E001);

		public static string TradePoints => ResourceManager.GetString(global::_E000._E000("\uee39\uee1f\uee0c\uee09\uee08\uee3d\uee02\uee04\uee03\uee19\uee1e", 61036), _E001);

		public static string TradePointsManage => ResourceManager.GetString(global::_E000._E000("\uf4ff\uf4d9\uf4ca\uf4cf\uf4ce\uf4fb\uf4c4\uf4c2\uf4c5\uf4df\uf4d8\uf4e6\uf4ca\uf4c5\uf4ca\uf4cc\uf4ce", 62627), _E001);

		public static string TradepointsRevenue => ResourceManager.GetString(global::_E000._E000("\ue2af\ue289\ue29a\ue29f\ue29e\ue28b\ue294\ue292\ue295\ue28f\ue288\ue2a9\ue29e\ue28d\ue29e\ue295\ue28e\ue29e", 57969), _E001);

		public static string TryFiscalNumberChange => ResourceManager.GetString(global::_E000._E000("\uf8ef\uf8c9\uf8c2\uf8fd\uf8d2\uf8c8\uf8d8\uf8da\uf8d7\uf8f5\uf8ce\uf8d6\uf8d9\uf8de\uf8c9\uf8f8\uf8d3\uf8da\uf8d5\uf8dc\uf8de", 63507), _E001);

		public static string UnitType => ResourceManager.GetString(global::_E000._E000("\uf2ae\uf295\uf292\uf28f\uf2af\uf282\uf28b\uf29e", 62195), _E001);

		public static string UpdateCashbox => ResourceManager.GetString(global::_E000._E000("\ue82a\ue80f\ue81b\ue81e\ue80b\ue81a\ue83c\ue81e\ue80c\ue817\ue81d\ue810\ue807", 59514), _E001);

		public static string UpdateManagement => ResourceManager.GetString(global::_E000._E000("\ue1ac\ue189\ue19d\ue198\ue18d\ue19c\ue1b4\ue198\ue197\ue198\ue19e\ue19c\ue194\ue19c\ue197\ue18d", 57849), _E001);

		public static string UpdateShift => ResourceManager.GetString(global::_E000._E000("\uf6cc\uf6e9\uf6fd\uf6f8\uf6ed\uf6fc\uf6ca\uf6f1\uf6f0\uf6ff\uf6ed", 63001), _E001);

		public static string UpdateToken => ResourceManager.GetString(global::_E000._E000("\uf8ab\uf88e\uf89a\uf89f\uf88a\uf89b\uf8aa\uf891\uf895\uf89b\uf890", 63742), _E001);

		public static string UploadFile => ResourceManager.GetString(global::_E000._E000("\uf7aa\uf78f\uf793\uf790\uf79e\uf79b\uf7b9\uf796\uf793\uf79a", 63293), _E001);

		public static string UploadNewPriceList => ResourceManager.GetString(global::_E000._E000("\uf1be\uf19b\uf187\uf184\uf18a\uf18f\uf1a5\uf18e\uf19c\uf1bb\uf199\uf182\uf188\uf18e\uf1a7\uf182\uf198\uf19f", 61923), _E001);

		public static string UppercaseAndLowercaseLetters => ResourceManager.GetString(global::_E000._E000("\ueca7\uec82\uec82\uec97\uec80\uec91\uec93\uec81\uec97\uecb3\uec9c\uec96\uecbe\uec9d\uec85\uec97\uec80\uec91\uec93\uec81\uec97\uecbe\uec97\uec86\uec86\uec97\uec80\uec81", 60624), _E001);

		public static string UsefulLinks => ResourceManager.GetString(global::_E000._E000("\ue04b\ue06d\ue07b\ue078\ue06b\ue072\ue052\ue077\ue070\ue075\ue06d", 57374), _E001);

		public static string UseLogo => ResourceManager.GetString(global::_E000._E000("\uec6a\uec4c\uec5a\uec73\uec50\uec58\uec50", 60427), _E001);

		public static string User => ResourceManager.GetString(global::_E000._E000("\uf0b2\uf094\uf082\uf095", 61540), _E001);

		public static string UserData => ResourceManager.GetString(global::_E000._E000("\ue3fa\ue3dc\ue3ca\ue3dd\ue3eb\ue3ce\ue3db\ue3ce", 58287), _E001);

		public static string UserDataCheckSuccess => ResourceManager.GetString(global::_E000._E000("\uf5b8\uf59e\uf588\uf59f\uf5a9\uf58c\uf599\uf58c\uf5ae\uf585\uf588\uf58e\uf586\uf5be\uf598\uf58e\uf58e\uf588\uf59e\uf59e", 62949), _E001);

		public static string UserDoesNotHaveAccessToCashbox => ResourceManager.GetString(global::_E000._E000("\uf00a\uf02c\uf03a\uf02d\uf01b\uf030\uf03a\uf02c\uf011\uf030\uf02b\uf017\uf03e\uf029\uf03a\uf01e\uf03c\uf03c\uf03a\uf02c\uf02c\uf00b\uf030\uf01c\uf03e\uf02c\uf037\uf03d\uf030\uf027", 61462), _E001);

		public static string UserEmailAlreadyConfirmed => ResourceManager.GetString(global::_E000._E000("\uf408\uf42e\uf438\uf42f\uf418\uf430\uf43c\uf434\uf431\uf41c\uf431\uf42f\uf438\uf43c\uf439\uf424\uf41e\uf432\uf433\uf43b\uf434\uf42f\uf430\uf438\uf439", 62536), _E001);

		public static string UserEmailNotFound => ResourceManager.GetString(global::_E000._E000("\uf66b\uf64d\uf65b\uf64c\uf67b\uf653\uf65f\uf657\uf652\uf670\uf651\uf64a\uf678\uf651\uf64b\uf650\uf65a", 63038), _E001);

		public static string UserManagement => ResourceManager.GetString(global::_E000._E000("\uef82\uefa4\uefb2\uefa5\uef9a\uefb6\uefb9\uefb6\uefb0\uefb2\uefba\uefb2\uefb9\uefa3", 61332), _E001);

		public static string VAT => ResourceManager.GetString(global::_E000._E000("\ueb81\ueb96\ueb83", 60180), _E001);

		public static string VatAttributeIsChangingHtml => ResourceManager.GetString(global::_E000._E000("\ue7ad\ue79a\ue78f\ue7ba\ue78f\ue78f\ue789\ue792\ue799\ue78e\ue78f\ue79e\ue7b2\ue788\ue7b8\ue793\ue79a\ue795\ue79c\ue792\ue795\ue79c\ue7b3\ue78f\ue796\ue797", 59345), _E001);

		public static string VatCannotFilledIfNotVatLiableIndicated => ResourceManager.GetString(global::_E000._E000("\uf7ed\uf7da\uf7cf\uf7f8\uf7da\uf7d5\uf7d5\uf7d4\uf7cf\uf7fd\uf7d2\uf7d7\uf7d7\uf7de\uf7df\uf7f2\uf7dd\uf7f5\uf7d4\uf7cf\uf7ed\uf7da\uf7cf\uf7f7\uf7d2\uf7da\uf7d9\uf7d7\uf7de\uf7f2\uf7d5\uf7df\uf7d2\uf7d8\uf7da\uf7cf\uf7de\uf7df", 63283), _E001);

		public static string VatIndicateNotCorrespondError => ResourceManager.GetString(global::_E000._E000("\uf4ab\uf49c\uf489\uf4b4\uf493\uf499\uf494\uf49e\uf49c\uf489\uf498\uf4b3\uf492\uf489\uf4be\uf492\uf48f\uf48f\uf498\uf48e\uf48d\uf492\uf493\uf499\uf4b8\uf48f\uf48f\uf492\uf48f", 62632), _E001);

		public static string VatIsRequiredIfVatLiableIndicated => ResourceManager.GetString(global::_E000._E000("\uf809\uf83e\uf82b\uf816\uf82c\uf80d\uf83a\uf82e\uf82a\uf836\uf82d\uf83a\uf83b\uf816\uf839\uf809\uf83e\uf82b\uf813\uf836\uf83e\uf83d\uf833\uf83a\uf816\uf831\uf83b\uf836\uf83c\uf83e\uf82b\uf83a\uf83b", 63574), _E001);

		public static string VatOrganizationsSellError => ResourceManager.GetString(global::_E000._E000("\ueda9\ued9e\ued8b\uedb0\ued8d\ued98\ued9e\ued91\ued96\ued85\ued9e\ued8b\ued96\ued90\ued91\ued8c\uedac\ued9a\ued93\ued93\uedba\ued8d\ued8d\ued90\ued8d", 60826), _E001);

		public static string VATRate => ResourceManager.GetString(global::_E000._E000("\ue7a9\ue7be\ue7ab\ue7ad\ue79e\ue78b\ue79a", 59165), _E001);

		public static string VatRate1 => ResourceManager.GetString(global::_E000._E000("\ue1b9\ue18e\ue19b\ue1bd\ue18e\ue19b\ue18a\ue1de", 57773), _E001);

		public static string VatRateNotCorrespondError => ResourceManager.GetString(global::_E000._E000("\ue3e9\ue3de\ue3cb\ue3ed\ue3de\ue3cb\ue3da\ue3f1\ue3d0\ue3cb\ue3fc\ue3d0\ue3cd\ue3cd\ue3da\ue3cc\ue3cf\ue3d0\ue3d1\ue3db\ue3fa\ue3cd\ue3cd\ue3d0\ue3cd", 58295), _E001);

		public static string VATSeries => ResourceManager.GetString(global::_E000._E000("\uef8b\uef9c\uef89\uef8e\uefb8\uefaf\uefb4\uefb8\uefae", 61320), _E001);

		public static string VatValuesWillUpdateMessage => ResourceManager.GetString(global::_E000._E000("\ueb19\ueb2e\ueb3b\ueb19\ueb2e\ueb23\ueb3a\ueb2a\ueb3c\ueb18\ueb26\ueb23\ueb23\ueb1a\ueb3f\ueb2b\ueb2e\ueb3b\ueb2a\ueb02\ueb2a\ueb3c\ueb3c\ueb2e\ueb28\ueb2a", 60230), _E001);

		public static string VatValuesWillUpdateMessage1 => ResourceManager.GetString(global::_E000._E000("\ue8bb\ue88c\ue899\ue8bb\ue88c\ue881\ue898\ue888\ue89e\ue8ba\ue884\ue881\ue881\ue8b8\ue89d\ue889\ue88c\ue899\ue888\ue8a0\ue888\ue89e\ue89e\ue88c\ue88a\ue888\ue8dc", 59596), _E001);

		public static string Version => ResourceManager.GetString(global::_E000._E000("\ue191\ue1a2\ue1b5\ue1b4\ue1ae\ue1a8\ue1a9", 57668), _E001);

		public static string VersionConfirmCode => ResourceManager.GetString(global::_E000._E000("\ue699\ue6aa\ue6bd\ue6bc\ue6a6\ue6a0\ue6a1\ue68c\ue6a0\ue6a1\ue6a9\ue6a6\ue6bd\ue6a2\ue68c\ue6a0\ue6ab\ue6aa", 59014), _E001);

		public static string ViewCheck => ResourceManager.GetString(global::_E000._E000("\uf189\uf1b6\uf1ba\uf1a8\uf19c\uf1b7\uf1ba\uf1bc\uf1b4", 61846), _E001);

		public static string ViewKcellActivationCard => ResourceManager.GetString(global::_E000._E000("\ueb3b\ueb04\ueb08\ueb1a\ueb26\ueb0e\ueb08\ueb01\ueb01\ueb2c\ueb0e\ueb19\ueb04\ueb1b\ueb0c\ueb19\ueb04\ueb02\ueb03\ueb2e\ueb0c\ueb1f\ueb09", 60197), _E001);

		public static string Warn => ResourceManager.GetString(global::_E000._E000("\uecba\uec8c\uec9f\uec83", 60549), _E001);

		public static string WeAreWaitingForCheck => ResourceManager.GetString(global::_E000._E000("\uecb0\uec82\ueca6\uec95\uec82\uecb0\uec86\uec8e\uec93\uec8e\uec89\uec80\ueca1\uec88\uec95\ueca4\uec8f\uec82\uec84\uec8c", 60516), _E001);

		public static string WeAreWaitingForCheckDetail => ResourceManager.GetString(global::_E000._E000("\uf4ba\uf488\uf4ac\uf49f\uf488\uf4ba\uf48c\uf484\uf499\uf484\uf483\uf48a\uf4ab\uf482\uf49f\uf4ae\uf485\uf488\uf48e\uf486\uf4a9\uf488\uf499\uf48c\uf484\uf481", 62700), _E001);

		public static string WebkassaTeam => ResourceManager.GetString(global::_E000._E000("\ue62a\ue618\ue61f\ue616\ue61c\ue60e\ue60e\ue61c\ue629\ue618\ue61c\ue610", 59004), _E001);

		public static string Week => ResourceManager.GetString(global::_E000._E000("\ue564\ue556\ue556\ue558", 58626), _E001);

		public static string Welcome => ResourceManager.GetString(global::_E000._E000("\uecac\uec9e\uec97\uec98\uec94\uec96\uec9e", 60659), _E001);

		public static string WhenProcessingAQueryErrorContactSupport => ResourceManager.GetString(global::_E000._E000("\ueaa9\uea96\uea9b\uea90\ueaae\uea8c\uea91\uea9d\uea9b\uea8d\uea8d\uea97\uea90\uea99\ueabf\ueaaf\uea8b\uea9b\uea8c\uea87\ueabb\uea8c\uea8c\uea91\uea8c\ueabd\uea91\uea90\uea8a\uea9f\uea9d\uea8a\ueaad\uea8b\uea8e\uea8e\uea91\uea8c\uea8a", 60158), _E001);

		public static string WillStartedSendProccess => ResourceManager.GetString(global::_E000._E000("\uf2a4\uf29a\uf29f\uf29f\uf2a0\uf287\uf292\uf281\uf287\uf296\uf297\uf2a0\uf296\uf29d\uf297\uf2a3\uf281\uf29c\uf290\uf290\uf296\uf280\uf280", 62162), _E001);

		public static string Withdrawals => ResourceManager.GetString(global::_E000._E000("\uf028\uf016\uf00b\uf017\uf01b\uf00d\uf01e\uf008\uf01e\uf013\uf00c", 61515), _E001);

		public static string WithdrawalsOf => ResourceManager.GetString(global::_E000._E000("\ue028\ue016\ue00b\ue017\ue01b\ue00d\ue01e\ue008\ue01e\ue013\ue00c\ue030\ue019", 57370), _E001);

		public static string WithoutTax => ResourceManager.GetString(global::_E000._E000("\uf5aa\uf594\uf589\uf595\uf592\uf588\uf589\uf5a9\uf59c\uf585", 62888), _E001);

		public static string WorkModeEnumOfflineMode => ResourceManager.GetString(global::_E000._E000("\uf3a9\uf391\uf38c\uf395\uf3b3\uf391\uf39a\uf39b\uf3bb\uf390\uf38b\uf393\uf3b1\uf398\uf398\uf392\uf397\uf390\uf39b\uf3b3\uf391\uf39a\uf39b", 62462), _E001);

		public static string WorkModeEnumOnlineMode => ResourceManager.GetString(global::_E000._E000("\uf0a8\uf090\uf08d\uf094\uf0b2\uf090\uf09b\uf09a\uf0ba\uf091\uf08a\uf092\uf0b0\uf091\uf093\uf096\uf091\uf09a\uf0b2\uf090\uf09b\uf09a", 61597), _E001);

		public static string WottiLoginLabel => ResourceManager.GetString(global::_E000._E000("\ue629\ue611\ue60a\ue60a\ue617\ue632\ue611\ue619\ue617\ue610\ue632\ue61f\ue61c\ue61b\ue612", 58990), _E001);

		public static string WriteEmail => ResourceManager.GetString(global::_E000._E000("\ue090\ue0b5\ue0ae\ue0b3\ue0a2\ue082\ue0aa\ue0a6\ue0ae\ue0ab", 57412), _E001);

		public static string WrongFileFormat => ResourceManager.GetString(global::_E000._E000("\uf828\uf80d\uf810\uf811\uf818\uf839\uf816\uf813\uf81a\uf839\uf810\uf80d\uf812\uf81e\uf80b", 63595), _E001);

		public static string XINNewCto => ResourceManager.GetString(global::_E000._E000("\uf6b7\uf6a6\uf6a1\uf6a1\uf68a\uf698\uf6ac\uf69b\uf680", 63213), _E001);

		public static string XReport => ResourceManager.GetString(global::_E000._E000("\ue835\ue83f\ue808\ue81d\ue802\ue81f\ue819", 59429), _E001);

		public static string Year => ResourceManager.GetString(global::_E000._E000("\uf2f2\uf2ce\uf2ca\uf2d9", 61985), _E001);

		public static string Yes => ResourceManager.GetString(global::_E000._E000("\ueda7\ued9b\ued8d", 60910), _E001);

		public static string YesSave => ResourceManager.GetString(global::_E000._E000("\ue2e2\ue2de\ue2c8\ue2e8\ue2da\ue2cd\ue2de", 58001), _E001);

		public static string YesSave1 => ResourceManager.GetString(global::_E000._E000("\ue29e\ue2a2\ue2b4\ue294\ue2a6\ue2b1\ue2a2\ue2f6", 57924), _E001);

		public static string YouDoNotHaveAccessToThisFunctionality => ResourceManager.GetString(global::_E000._E000("\ue4a0\ue496\ue48c\ue4bd\ue496\ue4b7\ue496\ue48d\ue4b1\ue498\ue48f\ue49c\ue4b8\ue49a\ue49a\ue49c\ue48a\ue48a\ue4ad\ue496\ue4ad\ue491\ue490\ue48a\ue4bf\ue48c\ue497\ue49a\ue48d\ue490\ue496\ue497\ue498\ue495\ue490\ue48d\ue480", 58489), _E001);

		public static string YourPasswordHasBeenReset => ResourceManager.GetString(global::_E000._E000("\ue4b6\ue480\ue49a\ue49d\ue4bf\ue48e\ue49c\ue49c\ue498\ue480\ue49d\ue48b\ue4a7\ue48e\ue49c\ue4ad\ue48a\ue48a\ue481\ue4bd\ue48a\ue49c\ue48a\ue49b", 58541), _E001);

		public static string YourPurchaseTicket => ResourceManager.GetString(global::_E000._E000("\uece2\uecd4\uecce\uecc9\ueceb\uecce\uecc9\uecd8\uecd3\uecda\uecc8\uecde\uecef\uecd2\uecd8\uecd0\uecde\ueccf", 60465), _E001);

		internal CommonResource()
		{
		}
	}
}
