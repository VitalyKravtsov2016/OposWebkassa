using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace WebCash.Resources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class ValidationResource
	{
		private static ResourceManager _E000;

		private static CultureInfo _E001;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (_E000 == null)
				{
					_E000 = new ResourceManager(global::_E000._E000("\ue18e\ue1bc\ue1bb\ue19a\ue1b8\ue1aa\ue1b1\ue1f7\ue18b\ue1bc\ue1aa\ue1b6\ue1ac\ue1ab\ue1ba\ue1bc\ue1aa\ue1f7\ue18f\ue1b8\ue1b5\ue1b0\ue1bd\ue1b8\ue1ad\ue1b0\ue1b6\ue1b7\ue18b\ue1bc\ue1aa\ue1b6\ue1ac\ue1ab\ue1ba\ue1bc", 57689), typeof(ValidationResource).Assembly);
				}
				return _E000;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return _E001;
			}
			set
			{
				_E001 = value;
			}
		}

		public static string ActivationFailed => ResourceManager.GetString(global::_E000._E000("\uf4b6\uf494\uf483\uf49e\uf481\uf496\uf483\uf49e\uf498\uf499\uf4b1\uf496\uf49e\uf49b\uf492\uf493", 62644), _E001);

		public static string AngleBracketsRestricted => ResourceManager.GetString(global::_E000._E000("\ue31c\ue333\ue33a\ue331\ue338\ue31f\ue32f\ue33c\ue33e\ue336\ue338\ue329\ue32e\ue30f\ue338\ue32e\ue329\ue32f\ue334\ue33e\ue329\ue338\ue339", 58200), _E001);

		public static string AutoCloseEmployeeAccess => ResourceManager.GetString(global::_E000._E000("\ueec8\ueefc\ueefd\ueee6\ueeca\ueee5\ueee6\ueefa\ueeec\ueecc\ueee4\ueef9\ueee5\ueee6\ueef0\ueeec\ueeec\ueec8\ueeea\ueeea\ueeec\ueefa\ueefa", 60937), _E001);

		public static string AutoCloseEmployeeRequired => ResourceManager.GetString(global::_E000._E000("\ue2aa\ue29e\ue29f\ue284\ue2a8\ue287\ue284\ue298\ue28e\ue2ae\ue286\ue29b\ue287\ue284\ue292\ue28e\ue28e\ue2b9\ue28e\ue29a\ue29e\ue282\ue299\ue28e\ue28f", 58051), _E001);

		public static string AutomaticallyPrintReceiptAfterFormation => ResourceManager.GetString(global::_E000._E000("\uf4be\uf48a\uf48b\uf490\uf492\uf49e\uf48b\uf496\uf49c\uf49e\uf493\uf493\uf486\uf4af\uf48d\uf496\uf491\uf48b\uf4ad\uf49a\uf49c\uf49a\uf496\uf48f\uf48b\uf4be\uf499\uf48b\uf49a\uf48d\uf4b9\uf490\uf48d\uf492\uf49e\uf48b\uf496\uf490\uf491", 62525), _E001);

		public static string BankSumNotExceedTotalSum => ResourceManager.GetString(global::_E000._E000("\uf3a9\uf38a\uf385\uf380\uf3b8\uf39e\uf386\uf3a5\uf384\uf39f\uf3ae\uf393\uf388\uf38e\uf38e\uf38f\uf3bf\uf384\uf39f\uf38a\uf387\uf3b8\uf39e\uf386", 62307), _E001);

		public static string BlockInputWhenUsingPriceList => ResourceManager.GetString(global::_E000._E000("\uf7dd\uf7f3\uf7f0\uf7fc\uf7f4\uf7d6\uf7f1\uf7ef\uf7ea\uf7eb\uf7c8\uf7f7\uf7fa\uf7f1\uf7ca\uf7ec\uf7f6\uf7f1\uf7f8\uf7cf\uf7ed\uf7f6\uf7fc\uf7fa\uf7d3\uf7f6\uf7ec\uf7eb", 63255), _E001);

		public static string CannotBeMore255 => ResourceManager.GetString(global::_E000._E000("\uea3c\uea1e\uea11\uea11\uea10\uea0b\uea3d\uea1a\uea32\uea10\uea0d\uea1a\uea4d\uea4a\uea4a", 59979), _E001);

		public static string CannotBeMore500 => ResourceManager.GetString(global::_E000._E000("\ue4ac\ue48e\ue481\ue481\ue480\ue49b\ue4ad\ue48a\ue4a2\ue480\ue49d\ue48a\ue4da\ue4df\ue4df", 58506), _E001);

		public static string CannotBeMoreThan11 => ResourceManager.GetString(global::_E000._E000("\uf6bc\uf69e\uf691\uf691\uf690\uf68b\uf6bd\uf69a\uf6b2\uf690\uf68d\uf69a\uf6ab\uf697\uf69e\uf691\uf6ce\uf6ce", 63231), _E001);

		public static string CannotBeMoreThan17 => ResourceManager.GetString(global::_E000._E000("\ue1a8\ue18a\ue185\ue185\ue184\ue19f\ue1a9\ue18e\ue1a6\ue184\ue199\ue18e\ue1bf\ue183\ue18a\ue185\ue1da\ue1dc", 57697), _E001);

		public static string CannotBeMoreThan28 => ResourceManager.GetString(global::_E000._E000("\ue6b4\ue696\ue699\ue699\ue698\ue683\ue6b5\ue692\ue6ba\ue698\ue685\ue692\ue6a3\ue69f\ue696\ue699\ue6c5\ue6cf", 58932), _E001);

		public static string CannotBeMoreThan3 => ResourceManager.GetString(global::_E000._E000("\ue4fc\ue4de\ue4d1\ue4d1\ue4d0\ue4cb\ue4fd\ue4da\ue4f2\ue4d0\ue4cd\ue4da\ue4eb\ue4d7\ue4de\ue4d1\ue48c", 58527), _E001);

		public static string CannotBeMoreThan33 => ResourceManager.GetString(global::_E000._E000("\uf0dc\uf0fe\uf0f1\uf0f1\uf0f0\uf0eb\uf0dd\uf0fa\uf0d2\uf0f0\uf0ed\uf0fa\uf0cb\uf0f7\uf0fe\uf0f1\uf0ac\uf0ac", 61591), _E001);

		public static string CannotBeMoreThan4 => ResourceManager.GetString(global::_E000._E000("\ue5e8\ue5ca\ue5c5\ue5c5\ue5c4\ue5df\ue5e9\ue5ce\ue5e6\ue5c4\ue5d9\ue5ce\ue5ff\ue5c3\ue5ca\ue5c5\ue59f", 58625), _E001);

		public static string CannotBeMoreThan5 => ResourceManager.GetString(global::_E000._E000("\ue9a8\ue98a\ue985\ue985\ue984\ue99f\ue9a9\ue98e\ue9a6\ue984\ue999\ue98e\ue9bf\ue983\ue98a\ue985\ue9de", 59715), _E001);

		public static string CannotBeMoreThan55 => ResourceManager.GetString(global::_E000._E000("\ue17c\ue15e\ue151\ue151\ue150\ue14b\ue17d\ue15a\ue172\ue150\ue14d\ue15a\ue16b\ue157\ue15e\ue151\ue10a\ue10a", 57643), _E001);

		public static string CannotBeMoreThan71 => ResourceManager.GetString(global::_E000._E000("\uef3d\uef1f\uef10\uef10\uef11\uef0a\uef3c\uef1b\uef33\uef11\uef0c\uef1b\uef2a\uef16\uef1f\uef10\uef49\uef4f", 61310), _E001);

		public static string CannotBeMoreThan8 => ResourceManager.GetString(global::_E000._E000("\ue1f8\ue1da\ue1d5\ue1d5\ue1d4\ue1cf\ue1f9\ue1de\ue1f6\ue1d4\ue1c9\ue1de\ue1ef\ue1d3\ue1da\ue1d5\ue183", 57617), _E001);

		public static string CannotCreateCashbox => ResourceManager.GetString(global::_E000._E000("\ue3fa\ue3d8\ue3d7\ue3d7\ue3d6\ue3cd\ue3fa\ue3cb\ue3dc\ue3d8\ue3cd\ue3dc\ue3fa\ue3d8\ue3ca\ue3d1\ue3db\ue3d6\ue3c1", 58297), _E001);

		public static string CanNotEditAccessForCurrentEmployee => ResourceManager.GetString(global::_E000._E000("\uf1f1\uf1d3\uf1dc\uf1fc\uf1dd\uf1c6\uf1f7\uf1d6\uf1db\uf1c6\uf1f3\uf1d1\uf1d1\uf1d7\uf1c1\uf1c1\uf1f4\uf1dd\uf1c0\uf1f1\uf1c7\uf1c0\uf1c0\uf1d7\uf1dc\uf1c6\uf1f7\uf1df\uf1c2\uf1de\uf1dd\uf1cb\uf1d7\uf1d7", 61840), _E001);

		public static string CanNotEditForExternalSystem => ResourceManager.GetString(global::_E000._E000("\ue3ae\ue38c\ue383\ue3a3\ue382\ue399\ue3a8\ue389\ue384\ue399\ue3ab\ue382\ue39f\ue3a8\ue395\ue399\ue388\ue39f\ue383\ue38c\ue381\ue3be\ue394\ue39e\ue399\ue388\ue380", 58309), _E001);

		public static string CashboxAlreadyRegisteredSrc => ResourceManager.GetString(global::_E000._E000("\uea30\uea12\uea00\uea1b\uea11\uea1c\uea0b\uea32\uea1f\uea01\uea16\uea12\uea17\uea0a\uea21\uea16\uea14\uea1a\uea00\uea07\uea16\uea01\uea16\uea17\uea20\uea01\uea10", 59986), _E001);

		public static string CashboxCount => ResourceManager.GetString(global::_E000._E000("\ue93e\ue91c\ue90e\ue915\ue91f\ue912\ue905\ue93e\ue912\ue908\ue913\ue909", 59701), _E001);

		public static string CashboxErrorModel200 => ResourceManager.GetString(global::_E000._E000("\uf8b1\uf893\uf881\uf89a\uf890\uf89d\uf88a\uf8b7\uf880\uf880\uf89d\uf880\uf8bf\uf89d\uf896\uf897\uf89e\uf8c0\uf8c2\uf8c2", 63696), _E001);

		public static string CashboxHaveNotActivationPacket => ResourceManager.GetString(global::_E000._E000("\ueb1d\ueb3f\ueb2d\ueb36\ueb3c\ueb31\ueb26\ueb16\ueb3f\ueb28\ueb3b\ueb10\ueb31\ueb2a\ueb1f\ueb3d\ueb2a\ueb37\ueb28\ueb3f\ueb2a\ueb37\ueb31\ueb30\ueb0e\ueb3f\ueb3d\ueb35\ueb3b\ueb2a", 60254), _E001);

		public static string CashboxRegistrationNumberLength => ResourceManager.GetString(global::_E000._E000("\uea1c\uea3e\uea2c\uea37\uea3d\uea30\uea27\uea0d\uea3a\uea38\uea36\uea2c\uea2b\uea2d\uea3e\uea2b\uea36\uea30\uea31\uea11\uea2a\uea32\uea3d\uea3a\uea2d\uea13\uea3a\uea31\uea38\uea2b\uea37", 59926), _E001);

		public static string CashboxWithRegNumberExist => ResourceManager.GetString(global::_E000._E000("\ue09e\ue0bc\ue0ae\ue0b5\ue0bf\ue0b2\ue0a5\ue08a\ue0b4\ue0a9\ue0b5\ue08f\ue0b8\ue0ba\ue093\ue0a8\ue0b0\ue0bf\ue0b8\ue0af\ue098\ue0a5\ue0b4\ue0ae\ue0a9", 57544), _E001);

		public static string CashiersNotFound => ResourceManager.GetString(global::_E000._E000("\uf4b4\uf496\uf484\uf49f\uf49e\uf492\uf485\uf484\uf4b9\uf498\uf483\uf4b1\uf498\uf482\uf499\uf493", 62708), _E001);

		public static string CheckLogoRequired => ResourceManager.GetString(global::_E000._E000("\uf0b1\uf09a\uf097\uf091\uf099\uf0be\uf09d\uf095\uf09d\uf0a0\uf097\uf083\uf087\uf09b\uf080\uf097\uf096", 61680), _E001);

		public static string CheckSumIncorrect => ResourceManager.GetString(global::_E000._E000("\uf3ee\uf3c5\uf3c8\uf3ce\uf3c6\uf3fe\uf3d8\uf3c0\uf3e4\uf3c3\uf3ce\uf3c2\uf3df\uf3df\uf3c8\uf3ce\uf3d9", 62348), _E001);

		public static string CheckTimeZone => ResourceManager.GetString(global::_E000._E000("\ue561\ue54a\ue547\ue541\ue549\ue576\ue54b\ue54f\ue547\ue578\ue54d\ue54c\ue547", 58656), _E001);

		public static string CirilicSymbols => ResourceManager.GetString(global::_E000._E000("\ueb9c\uebb6\uebad\uebb6\uebb3\uebb6\uebbc\ueb8c\ueba6\uebb2\uebbd\uebb0\uebb3\uebac", 60231), _E001);

		public static string CompanyPermissions => ResourceManager.GetString(global::_E000._E000("\uf38c\uf3a0\uf3a2\uf3bf\uf3ae\uf3a1\uf3b6\uf39f\uf3aa\uf3bd\uf3a2\uf3a6\uf3bc\uf3bc\uf3a6\uf3a0\uf3a1\uf3bc", 62342), _E001);

		public static string ConfirmPhoneCodeIsConfirmed => ResourceManager.GetString(global::_E000._E000("\uf89a\uf8b6\uf8b7\uf8bf\uf8b0\uf8ab\uf8b4\uf889\uf8b1\uf8b6\uf8b7\uf8bc\uf89a\uf8b6\uf8bd\uf8bc\uf890\uf8aa\uf89a\uf8b6\uf8b7\uf8bf\uf8b0\uf8ab\uf8b4\uf8bc\uf8bd", 63705), _E001);

		public static string ConfirmPhoneCodeNotValid => ResourceManager.GetString(global::_E000._E000("\ue03e\ue012\ue013\ue01b\ue014\ue00f\ue010\ue02d\ue015\ue012\ue013\ue018\ue03e\ue012\ue019\ue018\ue033\ue012\ue009\ue02b\ue01c\ue011\ue014\ue019", 57461), _E001);

		public static string ConfirmPhoneCodeTimeExpired => ResourceManager.GetString(global::_E000._E000("\ue28c\ue2a0\ue2a1\ue2a9\ue2a6\ue2bd\ue2a2\ue29f\ue2a7\ue2a0\ue2a1\ue2aa\ue28c\ue2a0\ue2ab\ue2aa\ue29b\ue2a6\ue2a2\ue2aa\ue28a\ue2b7\ue2bf\ue2a6\ue2bd\ue2aa\ue2ab", 58054), _E001);

		public static string ConfirmPINNotCorrect => ResourceManager.GetString(global::_E000._E000("\uf33e\uf312\uf313\uf31b\uf314\uf30f\uf310\uf32d\uf334\uf333\uf333\uf312\uf309\uf33e\uf312\uf30f\uf30f\uf318\uf31e\uf309", 62328), _E001);

		public static string CouldNotFindOrganization => ResourceManager.GetString(global::_E000._E000("\uf42e\uf402\uf418\uf401\uf409\uf423\uf402\uf419\uf42b\uf404\uf403\uf409\uf422\uf41f\uf40a\uf40c\uf403\uf404\uf417\uf40c\uf419\uf404\uf402\uf403", 62533), _E001);

		public static string CountIsNotNegativeValue => ResourceManager.GetString(global::_E000._E000("\ue794\ue7b8\ue7a2\ue7b9\ue7a3\ue79e\ue7a4\ue799\ue7b8\ue7a3\ue799\ue7b2\ue7b0\ue7b6\ue7a3\ue7be\ue7a1\ue7b2\ue781\ue7b6\ue7bb\ue7a2\ue7b2", 59156), _E001);

		public static string CryptoKeyIsNotValid => ResourceManager.GetString(global::_E000._E000("\uefb0\uef81\uef8a\uef83\uef87\uef9c\uefb8\uef96\uef8a\uefba\uef80\uefbd\uef9c\uef87\uefa5\uef92\uef9f\uef9a\uef97", 61394), _E001);

		public static string CryptoKeyNotSuitableForThisOrganization => ResourceManager.GetString(global::_E000._E000("\uf40c\uf43d\uf436\uf43f\uf43b\uf420\uf404\uf42a\uf436\uf401\uf420\uf43b\uf41c\uf43a\uf426\uf43b\uf42e\uf42d\uf423\uf42a\uf409\uf420\uf43d\uf41b\uf427\uf426\uf43c\uf400\uf43d\uf428\uf42e\uf421\uf426\uf435\uf42e\uf43b\uf426\uf420\uf421", 62470), _E001);

		public static string CurrencyNotFound => ResourceManager.GetString(global::_E000._E000("\uf33d\uf30b\uf30c\uf30c\uf31b\uf310\uf31d\uf307\uf330\uf311\uf30a\uf338\uf311\uf30b\uf310\uf31a", 62318), _E001);

		public static string CustomerEmailIncorrect => ResourceManager.GetString(global::_E000._E000("\uf030\uf006\uf000\uf007\uf01c\uf01e\uf016\uf001\uf036\uf01e\uf012\uf01a\uf01f\uf03a\uf01d\uf010\uf01c\uf001\uf001\uf016\uf010\uf007", 61554), _E001);

		public static string CustomerPhoneIncorrect => ResourceManager.GetString(global::_E000._E000("\uf4fc\uf4ca\uf4cc\uf4cb\uf4d0\uf4d2\uf4da\uf4cd\uf4ef\uf4d7\uf4d0\uf4d1\uf4da\uf4f6\uf4d1\uf4dc\uf4d0\uf4cd\uf4cd\uf4da\uf4dc\uf4cb", 62647), _E001);

		public static string DateTimeInvalid => ResourceManager.GetString(global::_E000._E000("\uebe6\uebc3\uebd6\uebc7\uebf6\uebcb\uebcf\uebc7\uebeb\uebcc\uebd4\uebc3\uebce\uebcb\uebc6", 60320), _E001);

		public static string DateTimeRangeInvalid => ResourceManager.GetString(global::_E000._E000("\uecfa\uecdf\uecca\uecdb\uecea\uecd7\uecd3\uecdb\uecec\uecdf\uecd0\uecd9\uecdb\uecf7\uecd0\uecc8\uecdf\uecd2\uecd7\uecda", 60590), _E001);

		public static string DiscountIsIncorrect => ResourceManager.GetString(global::_E000._E000("\ueada\ueaf7\ueaed\ueafd\ueaf1\ueaeb\ueaf0\ueaea\uead7\ueaed\uead7\ueaf0\ueafd\ueaf1\ueaec\ueaec\ueafb\ueafd\ueaea", 60062), _E001);

		public static string DiscountIsNotNegativeValue => ResourceManager.GetString(global::_E000._E000("\uf3fb\uf3d6\uf3cc\uf3dc\uf3d0\uf3ca\uf3d1\uf3cb\uf3f6\uf3cc\uf3f1\uf3d0\uf3cb\uf3f1\uf3da\uf3d8\uf3de\uf3cb\uf3d6\uf3c9\uf3da\uf3e9\uf3de\uf3d3\uf3ca\uf3da", 62271), _E001);

		public static string DiscountSumIsIncorrect => ResourceManager.GetString(global::_E000._E000("\ueba3\ueb8e\ueb94\ueb84\ueb88\ueb92\ueb89\ueb93\uebb4\ueb92\ueb8a\uebae\ueb94\uebae\ueb89\ueb84\ueb88\ueb95\ueb95\ueb82\ueb84\ueb93", 60260), _E001);

		public static string DuringTheSigningOfTheErrorOccurredTryItAgain => ResourceManager.GetString(global::_E000._E000("\ue1f9\ue1c8\ue1cf\ue1d4\ue1d3\ue1da\ue1e9\ue1d5\ue1d8\ue1ee\ue1d4\ue1da\ue1d3\ue1d4\ue1d3\ue1da\ue1f2\ue1db\ue1e9\ue1d5\ue1d8\ue1f8\ue1cf\ue1cf\ue1d2\ue1cf\ue1f2\ue1de\ue1de\ue1c8\ue1cf\ue1cf\ue1d8\ue1d9\ue1e9\ue1cf\ue1c4\ue1f4\ue1c9\ue1fc\ue1da\ue1dc\ue1d4\ue1d3", 57788), _E001);

		public static string EmailCanBeMaximum50Symbols => ResourceManager.GetString(global::_E000._E000("\ue99a\ue9b2\ue9be\ue9b6\ue9b3\ue99c\ue9be\ue9b1\ue99d\ue9ba\ue992\ue9be\ue9a7\ue9b6\ue9b2\ue9aa\ue9b2\ue9ea\ue9ef\ue98c\ue9a6\ue9b2\ue9bd\ue9b0\ue9b3\ue9ac", 59798), _E001);

		public static string EmailIncorrect => ResourceManager.GetString(global::_E000._E000("\uf398\uf3b0\uf3bc\uf3b4\uf3b1\uf394\uf3b3\uf3be\uf3b2\uf3af\uf3af\uf3b8\uf3be\uf3a9", 62408), _E001);

		public static string EmployeeDoesNotBelongToTheOrganization => ResourceManager.GetString(global::_E000._E000("\ue4ea\ue4c2\ue4df\ue4c3\ue4c0\ue4d6\ue4ca\ue4ca\ue4eb\ue4c0\ue4ca\ue4dc\ue4e1\ue4c0\ue4db\ue4ed\ue4ca\ue4c3\ue4c0\ue4c1\ue4c8\ue4fb\ue4c0\ue4fb\ue4c7\ue4ca\ue4e0\ue4dd\ue4c8\ue4ce\ue4c1\ue4c6\ue4d5\ue4ce\ue4db\ue4c6\ue4c0\ue4c1", 58511), _E001);

		public static string EmployeeNotFound => ResourceManager.GetString(global::_E000._E000("\uf2b7\uf29f\uf282\uf29e\uf29d\uf28b\uf297\uf297\uf2bc\uf29d\uf286\uf2b4\uf29d\uf287\uf29c\uf296", 62192), _E001);

		public static string ExchangeModeRequired => ResourceManager.GetString(global::_E000._E000("\ue567\ue55a\ue541\ue54a\ue543\ue54c\ue545\ue547\ue56f\ue54d\ue546\ue547\ue570\ue547\ue553\ue557\ue54b\ue550\ue547\ue546", 58624), _E001);

		public static string ExchangePriceListNotFound => ResourceManager.GetString(global::_E000._E000("\uf038\uf005\uf01e\uf015\uf01c\uf013\uf01a\uf018\uf02d\uf00f\uf014\uf01e\uf018\uf031\uf014\uf00e\uf009\uf033\uf012\uf009\uf03b\uf012\uf008\uf013\uf019", 61496), _E001);

		public static string ExternalOrganizationNotFound => ResourceManager.GetString(global::_E000._E000("\uf61b\uf626\uf62a\uf63b\uf62c\uf630\uf63f\uf632\uf611\uf62c\uf639\uf63f\uf630\uf637\uf624\uf63f\uf62a\uf637\uf631\uf630\uf610\uf631\uf62a\uf618\uf631\uf62b\uf630\uf63a", 63054), _E001);

		public static string ExternalOrganizationRequired => ResourceManager.GetString(global::_E000._E000("\ue31b\ue326\ue32a\ue33b\ue32c\ue330\ue33f\ue332\ue311\ue32c\ue339\ue33f\ue330\ue337\ue324\ue33f\ue32a\ue337\ue331\ue330\ue30c\ue33b\ue32f\ue32b\ue337\ue32c\ue33b\ue33a", 58190), _E001);

		public static string FailedToLockNumber => ResourceManager.GetString(global::_E000._E000("\uf1bb\uf19c\uf194\uf191\uf198\uf199\uf1a9\uf192\uf1b1\uf192\uf19e\uf196\uf1b3\uf188\uf190\uf19f\uf198\uf18f", 61928), _E001);

		public static string FailedToRecallNumber => ResourceManager.GetString(global::_E000._E000("\uf824\uf803\uf80b\uf80e\uf807\uf806\uf836\uf80d\uf830\uf807\uf801\uf803\uf80e\uf80e\uf82c\uf817\uf80f\uf800\uf807\uf810", 63584), _E001);

		public static string FailedToUnlockNumber => ResourceManager.GetString(global::_E000._E000("\uf758\uf77f\uf777\uf772\uf77b\uf77a\uf74a\uf771\uf74b\uf770\uf772\uf771\uf77d\uf775\uf750\uf76b\uf773\uf77c\uf77b\uf76c", 63262), _E001);

		public static string FieldCanContainSymbols => ResourceManager.GetString(global::_E000._E000("\uf7b9\uf796\uf79a\uf793\uf79b\uf7bc\uf79e\uf791\uf7bc\uf790\uf791\uf78b\uf79e\uf796\uf791\uf7ac\uf786\uf792\uf79d\uf790\uf793\uf78c", 63482), _E001);

		public static string FormatError => ResourceManager.GetString(global::_E000._E000("\ued34\ued1d\ued00\ued1f\ued13\ued06\ued37\ued00\ued00\ued1d\ued00", 60784), _E001);

		public static string ImpossibleToDeleteOperationsForCash => ResourceManager.GetString(global::_E000._E000("\uf436\uf412\uf40f\uf410\uf40c\uf40c\uf416\uf41d\uf413\uf41a\uf42b\uf410\uf43b\uf41a\uf413\uf41a\uf40b\uf41a\uf430\uf40f\uf41a\uf40d\uf41e\uf40b\uf416\uf410\uf411\uf40c\uf439\uf410\uf40d\uf43c\uf41e\uf40c\uf417", 62539), _E001);

		public static string ImpossibleToDeleteOperationsForOrg => ResourceManager.GetString(global::_E000._E000("\ue9a6\ue982\ue99f\ue980\ue99c\ue99c\ue986\ue98d\ue983\ue98a\ue9bb\ue980\ue9ab\ue98a\ue983\ue98a\ue99b\ue98a\ue9a0\ue99f\ue98a\ue99d\ue98e\ue99b\ue986\ue980\ue981\ue99c\ue9a9\ue980\ue99d\ue9a0\ue99d\ue988", 59814), _E001);

		public static string IncorrectCryptoKey => ResourceManager.GetString(global::_E000._E000("\uf6b4\uf693\uf69e\uf692\uf68f\uf68f\uf698\uf69e\uf689\uf6be\uf68f\uf684\uf68d\uf689\uf692\uf6b6\uf698\uf684", 63160), _E001);

		public static string IncorrectEnum => ResourceManager.GetString(global::_E000._E000("\ueea2\uee85\uee88\uee84\uee99\uee99\uee8e\uee88\uee9f\ueeae\uee85\uee9e\uee86", 61153), _E001);

		public static string IncorrectIssueYear => ResourceManager.GetString(global::_E000._E000("\uebd0\uebf7\uebfa\uebf6\uebeb\uebeb\uebfc\uebfa\uebed\uebd0\uebea\uebea\uebec\uebfc\uebc0\uebfc\uebf8\uebeb", 60313), _E001);

		public static string IncorrectLoginOrPassword => ResourceManager.GetString(global::_E000._E000("\ue514\ue533\ue53e\ue532\ue52f\ue52f\ue538\ue53e\ue529\ue511\ue532\ue53a\ue534\ue533\ue512\ue52f\ue50d\ue53c\ue52e\ue52e\ue52a\ue532\ue52f\ue539", 58712), _E001);

		public static string IncorrectPassportNumber => ResourceManager.GetString(global::_E000._E000("\uef7b\uef5c\uef51\uef5d\uef40\uef40\uef57\uef51\uef46\uef62\uef53\uef41\uef41\uef42\uef5d\uef40\uef46\uef7c\uef47\uef5f\uef50\uef57\uef40", 61200), _E001);

		public static string IncorrectRegistrationDate => ResourceManager.GetString(global::_E000._E000("\ue9a6\ue981\ue98c\ue980\ue99d\ue99d\ue98a\ue98c\ue99b\ue9bd\ue98a\ue988\ue986\ue99c\ue99b\ue99d\ue98e\ue99b\ue986\ue980\ue981\ue9ab\ue98e\ue99b\ue98a", 59821), _E001);

		public static string IncorrectVersion => ResourceManager.GetString(global::_E000._E000("\ue0b6\ue091\ue09c\ue090\ue08d\ue08d\ue09a\ue09c\ue08b\ue0a9\ue09a\ue08d\ue08c\ue096\ue090\ue091", 57373), _E001);

		public static string IncorrectZNK => ResourceManager.GetString(global::_E000._E000("\ue226\ue201\ue20c\ue200\ue21d\ue21d\ue20a\ue20c\ue21b\ue235\ue221\ue224", 57898), _E001);

		public static string INShouldConsistOfTwelveDigits => ResourceManager.GetString(global::_E000._E000("\ue4d7\ue4d0\ue4cd\ue4f6\ue4f1\ue4eb\ue4f2\ue4fa\ue4dd\ue4f1\ue4f0\ue4ed\ue4f7\ue4ed\ue4ea\ue4d1\ue4f8\ue4ca\ue4e9\ue4fb\ue4f2\ue4e8\ue4fb\ue4da\ue4f7\ue4f9\ue4f7\ue4ea\ue4ed", 58510), _E001);

		public static string InspectorSettingsAlreadyExist => ResourceManager.GetString(global::_E000._E000("\uea2b\uea0c\uea11\uea12\uea07\uea01\uea16\uea0d\uea10\uea31\uea07\uea16\uea16\uea0b\uea0c\uea05\uea11\uea23\uea0e\uea10\uea07\uea03\uea06\uea1b\uea27\uea1a\uea0b\uea11\uea16", 59968), _E001);

		public static string IsServiceCenter => ResourceManager.GetString(global::_E000._E000("\ue914\ue92e\ue90e\ue938\ue92f\ue92b\ue934\ue93e\ue938\ue91e\ue938\ue933\ue929\ue938\ue92f", 59736), _E001);

		public static string LengthCanBeMaximum15Symbols => ResourceManager.GetString(global::_E000._E000("\ue5a7\ue58e\ue585\ue58c\ue59f\ue583\ue5a8\ue58a\ue585\ue5a9\ue58e\ue5a6\ue58a\ue593\ue582\ue586\ue59e\ue586\ue5da\ue5de\ue5b8\ue592\ue586\ue589\ue584\ue587\ue598", 58691), _E001);

		public static string LengthCanBeMaximum20Symbols => ResourceManager.GetString(global::_E000._E000("\uf7f3\uf7da\uf7d1\uf7d8\uf7cb\uf7d7\uf7fc\uf7de\uf7d1\uf7fd\uf7da\uf7f2\uf7de\uf7c7\uf7d6\uf7d2\uf7ca\uf7d2\uf78d\uf78f\uf7ec\uf7c6\uf7d2\uf7dd\uf7d0\uf7d3\uf7cc", 63387), _E001);

		public static string LengthCanBeMaximum255Symbols => ResourceManager.GetString(global::_E000._E000("\ueabe\uea97\uea9c\uea95\uea86\uea9a\ueab1\uea93\uea9c\ueab0\uea97\ueabf\uea93\uea8a\uea9b\uea9f\uea87\uea9f\ueac0\ueac7\ueac7\ueaa1\uea8b\uea9f\uea90\uea9d\uea9e\uea81", 60112), _E001);

		public static string LengthCanBeMaximum50Symbols => ResourceManager.GetString(global::_E000._E000("\uf0f7\uf0de\uf0d5\uf0dc\uf0cf\uf0d3\uf0f8\uf0da\uf0d5\uf0f9\uf0de\uf0f6\uf0da\uf0c3\uf0d2\uf0d6\uf0ce\uf0d6\uf08e\uf08b\uf0e8\uf0c2\uf0d6\uf0d9\uf0d4\uf0d7\uf0c8", 61491), _E001);

		public static string LengthCanBeMaximum50SymbolsAndMin2 => ResourceManager.GetString(global::_E000._E000("\uf6b2\uf69b\uf690\uf699\uf68a\uf696\uf6bd\uf69f\uf690\uf6bc\uf69b\uf6b3\uf69f\uf686\uf697\uf693\uf68b\uf693\uf6cb\uf6ce\uf6ad\uf687\uf693\uf69c\uf691\uf692\uf68d\uf6bf\uf690\uf69a\uf6b3\uf697\uf690\uf6cc", 63214), _E001);

		public static string LoginFailed => ResourceManager.GetString(global::_E000._E000("\uefb1\uef92\uef9a\uef94\uef93\uefbb\uef9c\uef94\uef91\uef98\uef99", 61333), _E001);

		public static string MarkupIsNotNegativeValue => ResourceManager.GetString(global::_E000._E000("\ue0f6\ue0da\ue0c9\ue0d0\ue0ce\ue0cb\ue0f2\ue0c8\ue0f5\ue0d4\ue0cf\ue0f5\ue0de\ue0dc\ue0da\ue0cf\ue0d2\ue0cd\ue0de\ue0ed\ue0da\ue0d7\ue0ce\ue0de", 57361), _E001);

		public static string MarkupNameIsRequired => ResourceManager.GetString(global::_E000._E000("\uf432\uf41e\uf40d\uf414\uf40a\uf40f\uf431\uf41e\uf412\uf41a\uf436\uf40c\uf42d\uf41a\uf40e\uf40a\uf416\uf40d\uf41a\uf41b", 62539), _E001);

		public static string MarkupSumIsIncorrect => ResourceManager.GetString(global::_E000._E000("\uecb4\uec98\uec8b\uec92\uec8c\uec89\uecaa\uec8c\uec94\uecb0\uec8a\uecb0\uec97\uec9a\uec96\uec8b\uec8b\uec9c\uec9a\uec8d", 60665), _E001);

		public static string MarkupValueIsRequired => ResourceManager.GetString(global::_E000._E000("\ue873\ue85f\ue84c\ue855\ue84b\ue84e\ue868\ue85f\ue852\ue84b\ue85b\ue877\ue84d\ue86c\ue85b\ue84f\ue84b\ue857\ue84c\ue85b\ue85a", 59438), _E001);

		public static string MarkupValueRangeValidate => ResourceManager.GetString(global::_E000._E000("\uf5b2\uf59e\uf58d\uf594\uf58a\uf58f\uf5a9\uf59e\uf593\uf58a\uf59a\uf5ad\uf59e\uf591\uf598\uf59a\uf5a9\uf59e\uf593\uf596\uf59b\uf59e\uf58b\uf59a", 62943), _E001);

		public static string MaxAuthorizedSum => ResourceManager.GetString(global::_E000._E000("\ue430\ue41c\ue405\ue43c\ue408\ue409\ue415\ue412\ue40f\ue414\ue407\ue418\ue419\ue42e\ue408\ue410", 58389), _E001);

		public static string MoneyPlacementSumMustBeDigital => ResourceManager.GetString(global::_E000._E000("\ue812\ue830\ue831\ue83a\ue826\ue80f\ue833\ue83e\ue83c\ue83a\ue832\ue83a\ue831\ue82b\ue80c\ue82a\ue832\ue812\ue82a\ue82c\ue82b\ue81d\ue83a\ue81b\ue836\ue838\ue836\ue82b\ue83e\ue833", 59478), _E001);

		public static string MoreThanTwoDecimalPoints => ResourceManager.GetString(global::_E000._E000("\uf1be\uf19c\uf181\uf196\uf1a7\uf19b\uf192\uf19d\uf1a7\uf184\uf19c\uf1b7\uf196\uf190\uf19a\uf19e\uf192\uf19f\uf1a3\uf19c\uf19a\uf19d\uf187\uf180", 61938), _E001);

		public static string NeddSetToken => ResourceManager.GetString(global::_E000._E000("\ue190\ue1bb\ue1ba\ue1ba\ue18d\ue1bb\ue1aa\ue18a\ue1b1\ue1b5\ue1bb\ue1b0", 57822), _E001);

		public static string NeedSetIdentityNumber => ResourceManager.GetString(global::_E000._E000("\ue8fc\ue8d7\ue8d7\ue8d6\ue8e1\ue8d7\ue8c6\ue8fb\ue8d6\ue8d7\ue8dc\ue8c6\ue8db\ue8c6\ue8cb\ue8fc\ue8c7\ue8df\ue8d0\ue8d7\ue8c0", 59568), _E001);

		public static string NewPasswordFail => ResourceManager.GetString(global::_E000._E000("\uf5d0\uf5fb\uf5e9\uf5ce\uf5ff\uf5ed\uf5ed\uf5e9\uf5f1\uf5ec\uf5fa\uf5d8\uf5ff\uf5f7\uf5f2", 62862), _E001);

		public static string NotAllowedGreaterOrLessForInput => ResourceManager.GetString(global::_E000._E000("\uf2b9\uf298\uf283\uf2b6\uf29b\uf29b\uf298\uf280\uf292\uf293\uf2b0\uf285\uf292\uf296\uf283\uf292\uf285\uf2b8\uf285\uf2bb\uf292\uf284\uf284\uf2b1\uf298\uf285\uf2be\uf299\uf287\uf282\uf283", 62068), _E001);

		public static string NotContainsAZ => ResourceManager.GetString(global::_E000._E000("\ue389\ue3a8\ue3b3\ue384\ue3a8\ue3a9\ue3b3\ue3a6\ue3ae\ue3a9\ue3b4\ue386\ue39d", 58308), _E001);

		public static string NotEnoughCashInCashbox => ResourceManager.GetString(global::_E000._E000("\uf2b1\uf290\uf28b\uf2ba\uf291\uf290\uf28a\uf298\uf297\uf2bc\uf29e\uf28c\uf297\uf2b6\uf291\uf2bc\uf29e\uf28c\uf297\uf29d\uf290\uf287", 62173), _E001);

		public static string NotEnoughCashInCashboxForWithdraw => ResourceManager.GetString(global::_E000._E000("\ue6b1\ue690\ue68b\ue6ba\ue691\ue690\ue68a\ue698\ue697\ue6bc\ue69e\ue68c\ue697\ue6b6\ue691\ue6bc\ue69e\ue68c\ue697\ue69d\ue690\ue687\ue6b9\ue690\ue68d\ue6a8\ue696\ue68b\ue697\ue69b\ue68d\ue69e\ue688", 58999), _E001);

		public static string NotEqPairRegNumberAndToken => ResourceManager.GetString(global::_E000._E000("\uf497\uf4b6\uf4ad\uf49c\uf4a8\uf489\uf4b8\uf4b0\uf4ab\uf48b\uf4bc\uf4be\uf497\uf4ac\uf4b4\uf4bb\uf4bc\uf4ab\uf498\uf4b7\uf4bd\uf48d\uf4b6\uf4b2\uf4bc\uf4b7", 62553), _E001);

		public static string NumberRequired => ResourceManager.GetString(global::_E000._E000("\uf2b1\uf28a\uf292\uf29d\uf29a\uf28d\uf2ad\uf29a\uf28e\uf28a\uf296\uf28d\uf29a\uf29b", 62205), _E001);

		public static string NumMustBeNatural => ResourceManager.GetString(global::_E000._E000("\ue8e1\ue8da\ue8c2\ue8e2\ue8da\ue8dc\ue8db\ue8ed\ue8ca\ue8e1\ue8ce\ue8db\ue8da\ue8dd\ue8ce\ue8c3", 59407), _E001);

		public static string OfflineCashboxOperationRestriction => ResourceManager.GetString(global::_E000._E000("\ueaa0\uea89\uea89\uea83\uea86\uea81\uea8a\ueaac\uea8e\uea9c\uea87\uea8d\uea80\uea97\ueaa0\uea9f\uea8a\uea9d\uea8e\uea9b\uea86\uea80\uea81\ueabd\uea8a\uea9c\uea9b\uea9d\uea86\uea8c\uea9b\uea86\uea80\uea81", 59949), _E001);

		public static string OldPINNotCorrect => ResourceManager.GetString(global::_E000._E000("\uf071\uf052\uf05a\uf06e\uf077\uf070\uf070\uf051\uf04a\uf07d\uf051\uf04c\uf04c\uf05b\uf05d\uf04a", 61486), _E001);

		public static string OneCPartner => ResourceManager.GetString(global::_E000._E000("\ue670\ue651\ue65a\ue67c\ue66f\ue65e\ue64d\ue64b\ue651\ue65a\ue64d", 58891), _E001);

		public static string OperationAccessDenied => ResourceManager.GetString(global::_E000._E000("\ue498\ue4a7\ue4b2\ue4a5\ue4b6\ue4a3\ue4be\ue4b8\ue4b9\ue496\ue4b4\ue4b4\ue4b2\ue4a4\ue4a4\ue493\ue4b2\ue4b9\ue4be\ue4b2\ue4b3", 58516), _E001);

		public static string OperationTypeNotExist => ResourceManager.GetString(global::_E000._E000("\uf0a8\uf097\uf082\uf095\uf086\uf093\uf08e\uf088\uf089\uf0b3\uf09e\uf097\uf082\uf0a9\uf088\uf093\uf0a2\uf09f\uf08e\uf094\uf093", 61540), _E001);

		public static string OrganizationAlreadyRegistered => ResourceManager.GetString(global::_E000._E000("\ue13c\ue101\ue114\ue112\ue11d\ue11a\ue109\ue112\ue107\ue11a\ue11c\ue11d\ue132\ue11f\ue101\ue116\ue112\ue117\ue10a\ue121\ue116\ue114\ue11a\ue100\ue107\ue116\ue101\ue116\ue117", 57714), _E001);

		public static string OrganizationHasAlreadyRegisteredEmployeeWithThisINN => ResourceManager.GetString(global::_E000._E000("\ue9e0\ue9dd\ue9c8\ue9ce\ue9c1\ue9c6\ue9d5\ue9ce\ue9db\ue9c6\ue9c0\ue9c1\ue9e7\ue9ce\ue9dc\ue9ee\ue9c3\ue9dd\ue9ca\ue9ce\ue9cb\ue9d6\ue9fd\ue9ca\ue9c8\ue9c6\ue9dc\ue9db\ue9ca\ue9dd\ue9ca\ue9cb\ue9ea\ue9c2\ue9df\ue9c3\ue9c0\ue9d6\ue9ca\ue9ca\ue9f8\ue9c6\ue9db\ue9c7\ue9fb\ue9c7\ue9c6\ue9dc\ue9e6\ue9e1\ue9e1", 59791), _E001);

		public static string OrganizationMustHaveAtLeastOneEmployeeWithAccessToEditingStaff => ResourceManager.GetString(global::_E000._E000("\uede4\uedd9\uedcc\uedca\uedc5\uedc2\uedd1\uedca\ueddf\uedc2\uedc4\uedc5\uede6\uedde\uedd8\ueddf\uede3\uedca\ueddd\uedce\uedea\ueddf\uede7\uedce\uedca\uedd8\ueddf\uede4\uedc5\uedce\uedee\uedc6\ueddb\uedc7\uedc4\uedd2\uedce\uedce\uedfc\uedc2\ueddf\uedc3\uedea\uedc8\uedc8\uedce\uedd8\uedd8\uedff\uedc4\uedee\uedcf\uedc2\ueddf\uedc2\uedc5\uedcc\uedf8\ueddf\uedca\uedcd\uedcd", 60675), _E001);

		public static string OrganizationVATNumberLength => ResourceManager.GetString(global::_E000._E000("\uf8b2\uf88f\uf89a\uf89c\uf893\uf894\uf887\uf89c\uf889\uf894\uf892\uf893\uf8ab\uf8bc\uf8a9\uf8b3\uf888\uf890\uf89f\uf898\uf88f\uf8b1\uf898\uf893\uf89a\uf889\uf895", 63708), _E001);

		public static string OrganizationVATSeriaLength => ResourceManager.GetString(global::_E000._E000("\ue2a8\ue295\ue280\ue286\ue289\ue28e\ue29d\ue286\ue293\ue28e\ue288\ue289\ue2b1\ue2a6\ue2b3\ue2b4\ue282\ue295\ue28e\ue286\ue2ab\ue282\ue289\ue280\ue293\ue28f", 57956), _E001);

		public static string OrganizationWithCurrentXinAlreadyRegistrated => ResourceManager.GetString(global::_E000._E000("\uf096\uf0ab\uf0be\uf0b8\uf0b7\uf0b0\uf0a3\uf0b8\uf0ad\uf0b0\uf0b6\uf0b7\uf08e\uf0b0\uf0ad\uf0b1\uf09a\uf0ac\uf0ab\uf0ab\uf0bc\uf0b7\uf0ad\uf081\uf0b0\uf0b7\uf098\uf0b5\uf0ab\uf0bc\uf0b8\uf0bd\uf0a0\uf08b\uf0bc\uf0be\uf0b0\uf0aa\uf0ad\uf0ab\uf0b8\uf0ad\uf0bc\uf0bd", 61529), _E001);

		public static string OrganizationWithCurrentXinNotRegistrated => ResourceManager.GetString(global::_E000._E000("\ue6b1\ue68c\ue699\ue69f\ue690\ue697\ue684\ue69f\ue68a\ue697\ue691\ue690\ue6a9\ue697\ue68a\ue696\ue6bd\ue68b\ue68c\ue68c\ue69b\ue690\ue68a\ue6a6\ue697\ue690\ue6b0\ue691\ue68a\ue6ac\ue69b\ue699\ue697\ue68d\ue68a\ue68c\ue69f\ue68a\ue69b\ue69a", 59134), _E001);

		public static string PartialAutoWithdrawalRequired => ResourceManager.GetString(global::_E000._E000("\uf0e3\uf0d2\uf0c1\uf0c7\uf0da\uf0d2\uf0df\uf0f2\uf0c6\uf0c7\uf0dc\uf0e4\uf0da\uf0c7\uf0db\uf0d7\uf0c1\uf0d2\uf0c4\uf0d2\uf0df\uf0e1\uf0d6\uf0c2\uf0c6\uf0da\uf0c1\uf0d6\uf0d7", 61618), _E001);

		public static string PartialAutoWithdrawalSumCanNotBeNegative => ResourceManager.GetString(global::_E000._E000("\uf823\uf812\uf801\uf807\uf81a\uf812\uf81f\uf832\uf806\uf807\uf81c\uf824\uf81a\uf807\uf81b\uf817\uf801\uf812\uf804\uf812\uf81f\uf820\uf806\uf81e\uf830\uf812\uf81d\uf83d\uf81c\uf807\uf831\uf816\uf83d\uf816\uf814\uf812\uf807\uf81a\uf805\uf816", 63570), _E001);

		public static string PartnerCode => ResourceManager.GetString(global::_E000._E000("\uf80e\uf83f\uf82c\uf82a\uf830\uf83b\uf82c\uf81d\uf831\uf83a\uf83b", 63566), _E001);

		public static string PaymentType => ResourceManager.GetString(global::_E000._E000("\ueeb9\uee88\uee90\uee84\uee8c\uee87\uee9d\ueebd\uee90\uee99\uee8c", 61033), _E001);

		public static string PaymentTypesRequired => ResourceManager.GetString(global::_E000._E000("\ued32\ued03\ued1b\ued0f\ued07\ued0c\ued16\ued36\ued1b\ued12\ued07\ued11\ued30\ued07\ued13\ued17\ued0b\ued10\ued07\ued06", 60736), _E001);

		public static string PhoneIncorrectFormat => ResourceManager.GetString(global::_E000._E000("\ue3ed\ue3d5\ue3d2\ue3d3\ue3d8\ue3f4\ue3d3\ue3de\ue3d2\ue3cf\ue3cf\ue3d8\ue3de\ue3c9\ue3fb\ue3d2\ue3cf\ue3d0\ue3dc\ue3c9", 58268), _E001);

		public static string PhoneNotFound => ResourceManager.GetString(global::_E000._E000("\ue9af\ue997\ue990\ue991\ue99a\ue9b1\ue990\ue98b\ue9b9\ue990\ue98a\ue991\ue99b", 59867), _E001);

		public static string PhoneNumberIncorrectFormat => ResourceManager.GetString(global::_E000._E000("\ue62e\ue616\ue611\ue610\ue61b\ue630\ue60b\ue613\ue61c\ue61b\ue60c\ue637\ue610\ue61d\ue611\ue60c\ue60c\ue61b\ue61d\ue60a\ue638\ue611\ue60c\ue613\ue61f\ue60a", 59006), _E001);

		public static string PhoneNumberIsEmpty => ResourceManager.GetString(global::_E000._E000("\ueca9\uec91\uec96\uec97\uec9c\uecb7\uec8c\uec94\uec9b\uec9c\uec8b\uecb0\uec8a\uecbc\uec94\uec89\uec8d\uec80", 60665), _E001);

		public static string PinEquals => ResourceManager.GetString(global::_E000._E000("\ueba2\ueb9b\ueb9c\uebb7\ueb83\ueb87\ueb93\ueb9e\ueb81", 60400), _E001);

		public static string PinInvalid => ResourceManager.GetString(global::_E000._E000("\uedee\uedd7\uedd0\uedf7\uedd0\uedc8\ueddf\uedd2\uedd7\uedda", 60862), _E001);

		public static string PinInvalidFormat => ResourceManager.GetString(global::_E000._E000("\uf5a7\uf59e\uf599\uf5be\uf599\uf581\uf596\uf59b\uf59e\uf593\uf5b1\uf598\uf585\uf59a\uf596\uf583", 62772), _E001);

		public static string PriceIsNotNegativeValue => ResourceManager.GetString(global::_E000._E000("\ue297\ue2b5\ue2ae\ue2a4\ue2a2\ue28e\ue2b4\ue289\ue2a8\ue2b3\ue289\ue2a2\ue2a0\ue2a6\ue2b3\ue2ae\ue2b1\ue2a2\ue291\ue2a6\ue2ab\ue2b2\ue2a2", 57860), _E001);

		public static string PrinterTypeNotFound => ResourceManager.GetString(global::_E000._E000("\uf3cf\uf3ed\uf3f6\uf3f1\uf3eb\uf3fa\uf3ed\uf3cb\uf3e6\uf3ef\uf3fa\uf3d1\uf3f0\uf3eb\uf3d9\uf3f0\uf3ea\uf3f1\uf3fb", 62359), _E001);

		public static string ProductExistsInPriceList => ResourceManager.GetString(global::_E000._E000("\ue7ae\ue78c\ue791\ue79a\ue78b\ue79d\ue78a\ue7bb\ue786\ue797\ue78d\ue78a\ue78d\ue7b7\ue790\ue7ae\ue78c\ue797\ue79d\ue79b\ue7b2\ue797\ue78d\ue78a", 59390), _E001);

		public static string RefKatoNotFound => ResourceManager.GetString(global::_E000._E000("\ue2ad\ue29a\ue299\ue2b4\ue29e\ue28b\ue290\ue2b1\ue290\ue28b\ue2b9\ue290\ue28a\ue291\ue29b", 58045), _E001);

		public static string Required => ResourceManager.GetString(global::_E000._E000("\ue94c\ue97b\ue96f\ue96b\ue977\ue96c\ue97b\ue97a", 59662), _E001);

		public static string RequiredDate => ResourceManager.GetString(global::_E000._E000("\ue761\ue756\ue742\ue746\ue75a\ue741\ue756\ue757\ue777\ue752\ue747\ue756", 59186), _E001);

		public static string RequiredField => ResourceManager.GetString(global::_E000._E000("\uf5bd\uf58a\uf59e\uf59a\uf586\uf59d\uf58a\uf58b\uf5a9\uf586\uf58a\uf583\uf58b", 62797), _E001);

		public static string RequiredFieldRadio => ResourceManager.GetString(global::_E000._E000("\ue2f0\ue2c7\ue2d3\ue2d7\ue2cb\ue2d0\ue2c7\ue2c6\ue2e4\ue2cb\ue2c7\ue2ce\ue2c6\ue2f0\ue2c3\ue2c6\ue2cb\ue2cd", 57984), _E001);

		public static string RequiredSectionName => ResourceManager.GetString(global::_E000._E000("\ue8a9\ue89e\ue88a\ue88e\ue892\ue889\ue89e\ue89f\ue8a8\ue89e\ue898\ue88f\ue892\ue894\ue895\ue8b5\ue89a\ue896\ue89e", 59475), _E001);

		public static string RequiredValue => ResourceManager.GetString(global::_E000._E000("\ue0ad\ue09a\ue08e\ue08a\ue096\ue08d\ue09a\ue09b\ue0a9\ue09e\ue093\ue08a\ue09a", 57405), _E001);

		public static string SectionAlreadyExist => ResourceManager.GetString(global::_E000._E000("\ueaa8\uea9e\uea98\uea8f\uea92\uea94\uea95\ueaba\uea97\uea89\uea9e\uea9a\uea9f\uea82\ueabe\uea83\uea92\uea88\uea8f", 60145), _E001);

		public static string SectionsHaveNotAnyOperations => ResourceManager.GetString(global::_E000._E000("\uf0b4\uf082\uf084\uf093\uf08e\uf088\uf089\uf094\uf0af\uf086\uf091\uf082\uf0a9\uf088\uf093\uf0a6\uf089\uf09e\uf0a8\uf097\uf082\uf095\uf086\uf093\uf08e\uf088\uf089\uf094", 61668), _E001);

		public static string SelectedElectronicSignatureCertificateIsInTheListOfRevoked => ResourceManager.GetString(global::_E000._E000("\uef9c\uefaa\uefa3\uefaa\uefac\uefbb\uefaa\uefab\uef8a\uefa3\uefaa\uefac\uefbb\uefbd\uefa0\uefa1\uefa6\uefac\uef9c\uefa6\uefa8\uefa1\uefae\uefbb\uefba\uefbd\uefaa\uef8c\uefaa\uefbd\uefbb\uefa6\uefa9\uefa6\uefac\uefae\uefbb\uefaa\uef86\uefbc\uef86\uefa1\uef9b\uefa7\uefaa\uef83\uefa6\uefbc\uefbb\uef80\uefa9\uef9d\uefaa\uefb9\uefa0\uefa4\uefaa\uefab", 61382), _E001);

		public static string SelectMoreCashbox => ResourceManager.GetString(global::_E000._E000("\uf6e1\uf6d7\uf6de\uf6d7\uf6d1\uf6c6\uf6ff\uf6dd\uf6c0\uf6d7\uf6f1\uf6d3\uf6c1\uf6da\uf6d0\uf6dd\uf6ca", 63120), _E001);

		public static string SelectOneOrMorePacket => ResourceManager.GetString(global::_E000._E000("\uee8a\ueebc\ueeb5\ueebc\ueeba\ueead\uee96\ueeb7\ueebc\uee96\ueeab\uee94\ueeb6\ueeab\ueebc\uee89\ueeb8\ueeba\ueeb2\ueebc\ueead", 61017), _E001);

		public static string SetAsContactPerson => ResourceManager.GetString(global::_E000._E000("\ue1e0\ue1d6\ue1c7\ue1f2\ue1c0\ue1f0\ue1dc\ue1dd\ue1c7\ue1d2\ue1d0\ue1c7\ue1e3\ue1d6\ue1c1\ue1c0\ue1dc\ue1dd", 57746), _E001);

		public static string ShiftAlreadyClose => ResourceManager.GetString(global::_E000._E000("\ue7ac\ue797\ue796\ue799\ue78b\ue7be\ue793\ue78d\ue79a\ue79e\ue79b\ue786\ue7bc\ue793\ue790\ue78c\ue79a", 59290), _E001);

		public static string ShiftNotFound => ResourceManager.GetString(global::_E000._E000("\uf0ac\uf097\uf096\uf099\uf08b\uf0b1\uf090\uf08b\uf0b9\uf090\uf08a\uf091\uf09b", 61533), _E001);

		public static string SumIsIncorrect => ResourceManager.GetString(global::_E000._E000("\uf0ee\uf0c8\uf0d0\uf0f4\uf0ce\uf0f4\uf0d3\uf0de\uf0d2\uf0cf\uf0cf\uf0d8\uf0de\uf0c9", 61596), _E001);

		public static string SystemHasAlreadyRegisteredEmoloyeeWithThisEmployeeEmail => ResourceManager.GetString(global::_E000._E000("\ueaa0\uea8a\uea80\uea87\uea96\uea9e\ueabb\uea92\uea80\ueab2\uea9f\uea81\uea96\uea92\uea97\uea8a\ueaa1\uea96\uea94\uea9a\uea80\uea87\uea96\uea81\uea96\uea97\ueab6\uea9e\uea9c\uea9f\uea9c\uea8a\uea96\uea96\ueaa4\uea9a\uea87\uea9b\ueaa7\uea9b\uea9a\uea80\ueab6\uea9e\uea83\uea9f\uea9c\uea8a\uea96\uea96\ueab6\uea9e\uea92\uea9a\uea9f", 60114), _E001);

		public static string TakenAmountShallNotBeLessThanTotalAmount => ResourceManager.GetString(global::_E000._E000("\ue289\ue2bc\ue2b6\ue2b8\ue2b3\ue29c\ue2b0\ue2b2\ue2a8\ue2b3\ue2a9\ue28e\ue2b5\ue2bc\ue2b1\ue2b1\ue293\ue2b2\ue2a9\ue29f\ue2b8\ue291\ue2b8\ue2ae\ue2ae\ue289\ue2b5\ue2bc\ue2b3\ue289\ue2b2\ue2a9\ue2bc\ue2b1\ue29c\ue2b0\ue2b2\ue2a8\ue2b3\ue2a9", 58008), _E001);

		public static string TariffLevel => ResourceManager.GetString(global::_E000._E000("\ue6ab\ue69e\ue68d\ue696\ue699\ue699\ue6b3\ue69a\ue689\ue69a\ue693", 59069), _E001);

		public static string TaxInspectorPassword => ResourceManager.GetString(global::_E000._E000("\uf08b\uf0be\uf0a7\uf096\uf0b1\uf0ac\uf0af\uf0ba\uf0bc\uf0ab\uf0b0\uf0ad\uf08f\uf0be\uf0ac\uf0ac\uf0a8\uf0b0\uf0ad\uf0bb", 61654), _E001);

		public static string TaxIsIncorrect => ResourceManager.GetString(global::_E000._E000("\ue029\ue01c\ue005\ue034\ue00e\ue034\ue013\ue01e\ue012\ue00f\ue00f\ue018\ue01e\ue009", 57461), _E001);

		public static string ThereAreDifferentEmailsForOrder => ResourceManager.GetString(global::_E000._E000("\ue1bb\ue187\ue18a\ue19d\ue18a\ue1ae\ue19d\ue18a\ue1ab\ue186\ue189\ue189\ue18a\ue19d\ue18a\ue181\ue19b\ue1aa\ue182\ue18e\ue186\ue183\ue19c\ue1a9\ue180\ue19d\ue1a0\ue19d\ue18b\ue18a\ue19d", 57613), _E001);

		public static string ThereAreDifferentPhonesForOrder => ResourceManager.GetString(global::_E000._E000("\uf6ab\uf697\uf69a\uf68d\uf69a\uf6be\uf68d\uf69a\uf6bb\uf696\uf699\uf699\uf69a\uf68d\uf69a\uf691\uf68b\uf6af\uf697\uf690\uf691\uf69a\uf68c\uf6b9\uf690\uf68d\uf6b0\uf68d\uf69b\uf69a\uf68d", 63005), _E001);

		public static string TheValidityOfTheSelectedCertificateSignatureExpired => ResourceManager.GetString(global::_E000._E000("\ue4ab\ue497\ue49a\ue4a9\ue49e\ue493\ue496\ue49b\ue496\ue48b\ue486\ue4b0\ue499\ue4ab\ue497\ue49a\ue4ac\ue49a\ue493\ue49a\ue49c\ue48b\ue49a\ue49b\ue4bc\ue49a\ue48d\ue48b\ue496\ue499\ue496\ue49c\ue49e\ue48b\ue49a\ue4ac\ue496\ue498\ue491\ue49e\ue48b\ue48a\ue48d\ue49a\ue4ba\ue487\ue48f\ue496\ue48d\ue49a\ue49b", 58586), _E001);

		public static string TotalMarkingNotAvailable => ResourceManager.GetString(global::_E000._E000("\uebe9\uebd2\uebc9\uebdc\uebd1\uebf0\uebdc\uebcf\uebd6\uebd4\uebd3\uebda\uebf3\uebd2\uebc9\uebfc\uebcb\uebdc\uebd4\uebd1\uebdc\uebdf\uebd1\uebd8", 60348), _E001);

		public static string TradePointNotFound => ResourceManager.GetString(global::_E000._E000("\uf636\uf610\uf603\uf606\uf607\uf632\uf60d\uf60b\uf60c\uf616\uf62c\uf60d\uf616\uf624\uf60d\uf617\uf60c\uf606", 63040), _E001);

		public static string UnknownDiscountValue => ResourceManager.GetString(global::_E000._E000("\ueb28\ueb13\ueb16\ueb13\ueb12\ueb0a\ueb13\ueb39\ueb14\ueb0e\ueb1e\ueb12\ueb08\ueb13\ueb09\ueb2b\ueb1c\ueb11\ueb08\ueb18", 60280), _E001);

		public static string UserNewPasswordMustContainAtLeastCharacters => ResourceManager.GetString(global::_E000._E000("\uecea\ueccc\uecda\ueccd\uecf1\uecda\uecc8\uecef\uecde\ueccc\ueccc\uecc8\uecd0\ueccd\uecdb\uecf2\uecca\ueccc\ueccb\uecfc\uecd0\uecd1\ueccb\uecde\uecd6\uecd1\uecfe\ueccb\uecf3\uecda\uecde\ueccc\ueccb\uecfc\uecd7\uecde\ueccd\uecde\uecdc\ueccb\uecda\ueccd\ueccc", 60587), _E001);

		public static string UserNotRegistratedInSystem => ResourceManager.GetString(global::_E000._E000("\ue02a\ue00c\ue01a\ue00d\ue031\ue010\ue00b\ue02d\ue01a\ue018\ue016\ue00c\ue00b\ue00d\ue01e\ue00b\ue01a\ue01b\ue036\ue011\ue02c\ue006\ue00c\ue00b\ue01a\ue012", 57462), _E001);

		public static string UserPasswordConfirm => ResourceManager.GetString(global::_E000._E000("\uf3ba\uf39c\uf38a\uf39d\uf3bf\uf38e\uf39c\uf39c\uf398\uf380\uf39d\uf38b\uf3ac\uf380\uf381\uf389\uf386\uf39d\uf382", 62445), _E001);

		public static string UserPasswordConfirmNotMatch => ResourceManager.GetString(global::_E000._E000("\uf088\uf0ae\uf0b8\uf0af\uf08d\uf0bc\uf0ae\uf0ae\uf0aa\uf0b2\uf0af\uf0b9\uf09e\uf0b2\uf0b3\uf0bb\uf0b4\uf0af\uf0b0\uf093\uf0b2\uf0a9\uf090\uf0bc\uf0a9\uf0be\uf0b5", 61592), _E001);

		public static string UserPasswordOldInvalid => ResourceManager.GetString(global::_E000._E000("\uebfa\uebdc\uebca\uebdd\uebff\uebce\uebdc\uebdc\uebd8\uebc0\uebdd\uebcb\uebe0\uebc3\uebcb\uebe6\uebc1\uebd9\uebce\uebc3\uebc6\uebcb", 60207), _E001);

		public static string UserPasswordWrong => ResourceManager.GetString(global::_E000._E000("\ue3ba\ue39c\ue38a\ue39d\ue3bf\ue38e\ue39c\ue39c\ue398\ue380\ue39d\ue38b\ue3b8\ue39d\ue380\ue381\ue388", 58157), _E001);

		public static string UserWithEmailAlreadyExist => ResourceManager.GetString(global::_E000._E000("\uee2a\uee0c\uee1a\uee0d\uee28\uee16\uee0b\uee17\uee3a\uee12\uee1e\uee16\uee13\uee3e\uee13\uee0d\uee1a\uee1e\uee1b\uee06\uee3a\uee07\uee16\uee0c\uee0b", 61050), _E001);

		public static string ValidationCode => ResourceManager.GetString(global::_E000._E000("\uf2e9\uf2de\uf2d3\uf2d6\uf2db\uf2de\uf2cb\uf2d6\uf2d0\uf2d1\uf2fc\uf2d0\uf2db\uf2da", 62107), _E001);

		public static string ValueShoulds => ResourceManager.GetString(global::_E000._E000("\ue38f\ue3b8\ue3b5\ue3ac\ue3bc\ue38a\ue3b1\ue3b6\ue3ac\ue3b5\ue3bd\ue3aa", 58329), _E001);

		public static string XinCannotBeSame => ResourceManager.GetString(global::_E000._E000("\ue0e7\ue0d6\ue0d1\ue0fc\ue0de\ue0d1\ue0d1\ue0d0\ue0cb\ue0fd\ue0da\ue0ec\ue0de\ue0d2\ue0da", 57503), _E001);

		public static string XinInvalid => ResourceManager.GetString(global::_E000._E000("\uefb5\uef84\uef83\uefa4\uef83\uef9b\uef8c\uef81\uef84\uef89", 61349), _E001);

		public static string XinInvalidBIN => ResourceManager.GetString(global::_E000._E000("\uf0f1\uf0c0\uf0c7\uf0e0\uf0c7\uf0df\uf0c8\uf0c5\uf0c0\uf0cd\uf0eb\uf0e0\uf0e7", 61609), _E001);

		public static string XinInvalidBirthDate => ResourceManager.GetString(global::_E000._E000("\ue235\ue204\ue203\ue224\ue203\ue21b\ue20c\ue201\ue204\ue209\ue22f\ue204\ue21f\ue219\ue205\ue229\ue20c\ue219\ue208", 57932), _E001);

		public static string XinInvalidControlDigit => ResourceManager.GetString(global::_E000._E000("\ue125\ue114\ue113\ue134\ue113\ue10b\ue11c\ue111\ue114\ue119\ue13e\ue112\ue113\ue109\ue10f\ue112\ue111\ue139\ue114\ue11a\ue114\ue109", 57724), _E001);

		public static string XinInvalidIIN => ResourceManager.GetString(global::_E000._E000("\uf7bf\uf78e\uf789\uf7ae\uf789\uf791\uf786\uf78b\uf78e\uf783\uf7ae\uf7ae\uf7a9", 63460), _E001);

		public static string XinnotcontaonsWithXinSignature => ResourceManager.GetString(global::_E000._E000("\uf5af\uf59e\uf599\uf599\uf598\uf583\uf594\uf598\uf599\uf583\uf596\uf598\uf599\uf584\uf5a0\uf59e\uf583\uf59f\uf5af\uf59e\uf599\uf5a4\uf59e\uf590\uf599\uf596\uf583\uf582\uf585\uf592", 62772), _E001);

		internal ValidationResource()
		{
		}
	}
}
