using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("WebCash.LocalServer.Abstractions")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("WebCash.LocalServer.Abstractions")]
[assembly: AssemblyTitle("WebCash.LocalServer.Abstractions")]
[assembly: AssemblyVersion("1.0.0.0")]
