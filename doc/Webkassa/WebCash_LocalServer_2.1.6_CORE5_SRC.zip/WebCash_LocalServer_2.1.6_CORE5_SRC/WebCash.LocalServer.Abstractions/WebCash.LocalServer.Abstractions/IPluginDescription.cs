using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace WebCash.LocalServer.Abstractions
{
	public interface IPluginDescription
	{
		void ConfigureServices(IServiceCollection services, IConfiguration configuration);

		void Validate(IServiceProvider serviceProvider);
	}
}
