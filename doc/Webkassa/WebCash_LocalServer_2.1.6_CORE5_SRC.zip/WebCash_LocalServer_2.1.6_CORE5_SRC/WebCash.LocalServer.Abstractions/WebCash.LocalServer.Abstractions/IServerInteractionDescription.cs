using System.Threading.Tasks;
using WebCash.ServiceContracts;

namespace WebCash.LocalServer.Abstractions
{
	public interface IServerInteractionDescription<in TRequest, TResponse>
	{
		string Url { get; }

		void PrepareRequestBeforeSend(TRequest request);

		string GetCashboxUniqueNumber(TRequest request);

		bool NeedPing();

		Task<TResponse> ValidateAsync(TRequest request);

		Task<TResponse> CreateOfflineResponseAsync(TRequest request);

		Task SaveToOfflineStoreAsync(TRequest request, TResponse response);

		Task UpdateLocalStorageAsync(TRequest request, TResponse response);

		ApiResult ConvertBeforeReply(TResponse response);

		Task<bool> MustBeRegisterOffline(TRequest request);

		Task<bool> HandleError(TRequest request, TResponse response);
	}
}
