using System.Threading.Tasks;
using WebCash.ServiceContracts;

namespace WebCash.LocalServer.Abstractions
{
	public interface IMediator
	{
		Task<ApiResult> GetResponse<TRequest, TResponse>(IServerInteractionDescription<TRequest, TResponse> description, TRequest request) where TResponse : ApiResult;
	}
}
