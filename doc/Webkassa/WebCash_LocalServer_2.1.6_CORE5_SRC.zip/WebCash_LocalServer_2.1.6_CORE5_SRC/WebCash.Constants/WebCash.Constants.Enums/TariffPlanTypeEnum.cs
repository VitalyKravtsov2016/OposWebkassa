using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum TariffPlanTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "Monthly")]
		Month = 1,
		[Display(ResourceType = typeof(NameResource), Name = "SemiAnnual")]
		HalfYear,
		[Display(ResourceType = typeof(NameResource), Name = "Annual")]
		Year,
		[Display(ResourceType = typeof(NameResource), Name = "Free")]
		FreeMonth
	}
}
