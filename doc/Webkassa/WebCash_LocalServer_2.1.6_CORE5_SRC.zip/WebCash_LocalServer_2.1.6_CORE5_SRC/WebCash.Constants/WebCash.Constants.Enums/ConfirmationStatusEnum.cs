namespace WebCash.Constants.Enums
{
	public enum ConfirmationStatusEnum
	{
		NeedConfirmation,
		Confirmed
	}
}
