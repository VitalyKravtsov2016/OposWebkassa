namespace WebCash.Constants.Enums
{
	public enum DownloadTypePriceEnum
	{
		PriceList = 1,
		Template,
		Tobacco
	}
}
