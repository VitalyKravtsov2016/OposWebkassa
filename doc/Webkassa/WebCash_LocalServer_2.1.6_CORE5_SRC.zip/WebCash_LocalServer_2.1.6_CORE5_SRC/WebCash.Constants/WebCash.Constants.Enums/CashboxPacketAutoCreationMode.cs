namespace WebCash.Constants.Enums
{
	public enum CashboxPacketAutoCreationMode : byte
	{
		Off,
		On
	}
}
