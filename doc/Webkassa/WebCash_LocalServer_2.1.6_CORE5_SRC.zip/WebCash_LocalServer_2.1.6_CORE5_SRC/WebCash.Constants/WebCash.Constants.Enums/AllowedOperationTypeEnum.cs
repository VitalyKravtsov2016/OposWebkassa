namespace WebCash.Constants.Enums
{
	public enum AllowedOperationTypeEnum : byte
	{
		All,
		MobileOnly
	}
}
