using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum OfdProtocolVersion
	{
		[Display(Name = "1.2.3")]
		Version123 = 123,
		[Display(Name = "1.2.4")]
		Version124 = 124,
		[Display(Name = "2.0.2")]
		Version202 = 202
	}
}
