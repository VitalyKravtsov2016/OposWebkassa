namespace WebCash.Constants.Enums
{
	public enum ApplicationNameEnum
	{
		Webkassa,
		BKassa,
		Wk3CFR
	}
}
