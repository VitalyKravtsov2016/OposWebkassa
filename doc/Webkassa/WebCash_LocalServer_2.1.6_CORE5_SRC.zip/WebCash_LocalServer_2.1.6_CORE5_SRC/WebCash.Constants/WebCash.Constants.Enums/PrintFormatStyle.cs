using System;

namespace WebCash.Constants.Enums
{
	[Flags]
	public enum PrintFormatStyle : byte
	{
		Normal = 0,
		Bold = 1,
		Center = 2
	}
}
