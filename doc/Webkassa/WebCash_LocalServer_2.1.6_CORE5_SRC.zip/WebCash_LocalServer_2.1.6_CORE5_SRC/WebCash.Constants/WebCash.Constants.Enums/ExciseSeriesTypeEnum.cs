namespace WebCash.Constants.Enums
{
	public enum ExciseSeriesTypeEnum : byte
	{
		None,
		Cyrillic,
		Latin
	}
}
