namespace WebCash.Constants.Enums
{
	public enum AuthResultTypeEnum
	{
		RESULT_TYPE_OK,
		RESULT_TYPE_INVALID_LOGIN_PASSWORD
	}
}
