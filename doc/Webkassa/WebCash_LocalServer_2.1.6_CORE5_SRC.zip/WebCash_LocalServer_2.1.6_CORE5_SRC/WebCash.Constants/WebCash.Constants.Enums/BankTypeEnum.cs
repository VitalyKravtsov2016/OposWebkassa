namespace WebCash.Constants.Enums
{
	public enum BankTypeEnum
	{
		Halyk,
		Kazkom
	}
}
