using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum OcpStateCodeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeProtokolError")]
		ValidationError = 400,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeUnknownError")]
		UnknownError = 500,
		[Display(ResourceType = typeof(NameResource), Name = "AwaitUserConfirm")]
		None = 0,
		[Display(ResourceType = typeof(NameResource), Name = "ServiceProvided")]
		Ok = 4444,
		[Display(ResourceType = typeof(NameResource), Name = "AwaitUserConfirm")]
		AwaitContinue = 0
	}
}
