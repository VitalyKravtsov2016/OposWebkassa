namespace WebCash.Constants.Enums
{
	public enum ExternalDataPrefixTypeEnum : byte
	{
		None,
		ExternalData,
		ExternalTransferData
	}
}
