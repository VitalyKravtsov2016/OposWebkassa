namespace WebCash.Constants.Enums
{
	public enum OfflineModeEnum : byte
	{
		None,
		Server,
		Client
	}
}
