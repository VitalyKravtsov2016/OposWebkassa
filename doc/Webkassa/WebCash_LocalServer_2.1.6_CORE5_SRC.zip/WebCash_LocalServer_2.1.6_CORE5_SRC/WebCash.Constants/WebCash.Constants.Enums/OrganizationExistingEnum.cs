namespace WebCash.Constants.Enums
{
	public enum OrganizationExistingEnum
	{
		NotExist,
		Exist,
		NotConfirmed
	}
}
