namespace WebCash.Constants.Enums
{
	public enum OfflineRequestTableTypeEnum : byte
	{
		None,
		OfflineRequest,
		TransferOfflineRequest
	}
}
