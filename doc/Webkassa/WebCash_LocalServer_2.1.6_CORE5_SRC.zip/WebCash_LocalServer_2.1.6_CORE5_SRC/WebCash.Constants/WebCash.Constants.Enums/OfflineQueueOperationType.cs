namespace WebCash.Constants.Enums
{
	public enum OfflineQueueOperationType
	{
		None,
		Money,
		Check,
		XzReport,
		TicketCancellation
	}
}
