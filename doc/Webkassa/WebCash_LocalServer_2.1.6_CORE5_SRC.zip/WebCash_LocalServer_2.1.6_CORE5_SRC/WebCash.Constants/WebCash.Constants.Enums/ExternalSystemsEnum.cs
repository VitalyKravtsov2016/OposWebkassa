using System;
using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum ExternalSystemsEnum
	{
		[Display(Name = "1С")]
		Company1C,
		[Obsolete("Функционал удален")]
		[Display(Name = "Kcell")]
		Kcell,
		[Display(Name = "ОЦП Казахтелеком")]
		OcpTelecom,
		[Display(Name = "Webkassa-покупки с сайта")]
		WebKassa,
		[Display(Name = "Kaspi")]
		Kaspi
	}
}
