namespace WebCash.Constants.Enums
{
	public enum EmployeeCashboxAccessEnum
	{
		All = 1,
		ProgrammingUsers,
		Nobody
	}
}
