namespace WebCash.Constants.Enums
{
	public enum InvoiceDocumentType
	{
		Default,
		KaspiClient,
		AlphaBank,
		Acquiring
	}
}
