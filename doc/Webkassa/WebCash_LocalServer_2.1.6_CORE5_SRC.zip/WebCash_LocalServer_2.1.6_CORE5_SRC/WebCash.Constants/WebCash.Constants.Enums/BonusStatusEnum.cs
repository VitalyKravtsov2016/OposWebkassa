using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum BonusStatusEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "AwaitingOperation")]
		AwaitingOperation,
		[Display(ResourceType = typeof(NameResource), Name = "AwaitingIssuance")]
		AwaitingIssuance,
		[Display(ResourceType = typeof(NameResource), Name = "Issued")]
		Issued,
		[Display(ResourceType = typeof(NameResource), Name = "NotMatch")]
		NotMatch,
		[Display(ResourceType = typeof(NameResource), Name = "Completed")]
		Completed
	}
}
