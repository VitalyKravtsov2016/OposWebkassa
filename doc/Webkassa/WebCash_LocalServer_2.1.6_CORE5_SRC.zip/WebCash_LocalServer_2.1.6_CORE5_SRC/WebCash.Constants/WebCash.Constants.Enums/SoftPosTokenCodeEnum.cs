namespace WebCash.Constants.Enums
{
	public enum SoftPosTokenCodeEnum
	{
		None = -1,
		Success = 0,
		InvalidMessageFormat = 30,
		UnknownOperatorLogin = 40,
		InvalidPassword = 41,
		TechnicalError = 99,
		UnknownExternalSystemAdministratorLogin = 150,
		ConnectionErrorWithExternalSystem = 160,
		AccessDenied = 403
	}
}
