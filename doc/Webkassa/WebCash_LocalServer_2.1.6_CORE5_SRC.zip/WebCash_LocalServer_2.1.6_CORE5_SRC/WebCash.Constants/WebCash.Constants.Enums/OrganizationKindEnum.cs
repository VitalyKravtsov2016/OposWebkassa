using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum OrganizationKindEnum : byte
	{
		[Display(Name = "")]
		Client,
		[Display(Name = "ЦТО")]
		ServiceCenter
	}
}
