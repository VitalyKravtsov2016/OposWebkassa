namespace WebCash.Constants.Enums
{
	public enum NotificationCreationRecipientType
	{
		None,
		CurrentUser,
		AllUsers
	}
}
