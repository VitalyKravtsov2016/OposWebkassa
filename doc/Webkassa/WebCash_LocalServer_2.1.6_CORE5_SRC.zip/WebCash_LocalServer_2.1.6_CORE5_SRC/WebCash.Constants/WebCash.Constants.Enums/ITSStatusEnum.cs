using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum ITSStatusEnum
	{
		[Display(Name = "Договор 1С:ИТС оформлен")]
		Success = 1,
		[Display(Name = "Договор 1С:ИТС не оформлен")]
		AgreementNotExists = 101,
		[Display(Name = "Срок действия договора 1С:ИТС завершился")]
		OldContract = 104
	}
}
