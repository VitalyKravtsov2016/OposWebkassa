using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum UsePlaceTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "TravelSell")]
		TravelSell,
		[Display(ResourceType = typeof(NameResource), Name = "StationSell")]
		StationSell,
		[Display(ResourceType = typeof(NameResource), Name = "TerminalSell")]
		TerminalSell
	}
}
