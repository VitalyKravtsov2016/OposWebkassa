namespace WebCash.Constants.Enums
{
	public enum UserRoleEnum
	{
		USER_ROLE_PAYMASTER = 1,
		USER_ROLE_CHIEF_PAYMASTER,
		USER_ROLE_ADMINISTRATOR
	}
}
