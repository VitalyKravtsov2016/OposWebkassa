namespace WebCash.Constants.Enums
{
	public enum NonNullableTypeEnum : byte
	{
		None,
		Start,
		End
	}
}
