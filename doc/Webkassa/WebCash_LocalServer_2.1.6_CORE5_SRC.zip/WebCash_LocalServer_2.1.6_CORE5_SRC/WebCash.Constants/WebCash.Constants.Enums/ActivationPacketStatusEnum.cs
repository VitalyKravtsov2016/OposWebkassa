using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ActivationPacketStatusEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "Created")]
		Created,
		[Display(ResourceType = typeof(NameResource), Name = "AwaitActivation")]
		Await,
		[Display(ResourceType = typeof(NameResource), Name = "PacketActive")]
		Active,
		[Display(ResourceType = typeof(NameResource), Name = "PacketExpired")]
		Expired,
		[Display(ResourceType = typeof(NameResource), Name = "Withdrawn")]
		Revoked
	}
}
