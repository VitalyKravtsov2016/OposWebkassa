using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum CashboxStatusEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusCreated")]
		Created,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusActive")]
		Active,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusLocked")]
		Locked,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusInvalid")]
		Invalid,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusRMNILocked")]
		RMNILocked,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxStatusDeregistered")]
		Deregistered,
		[Display(Name = "НЕФИСКАЛЬНЫЙ РЕЖИМ")]
		NonFiscalMode
	}
}
