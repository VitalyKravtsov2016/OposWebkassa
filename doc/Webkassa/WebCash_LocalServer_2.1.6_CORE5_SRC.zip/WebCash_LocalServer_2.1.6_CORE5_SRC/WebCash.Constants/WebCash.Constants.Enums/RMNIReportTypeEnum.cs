using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum RMNIReportTypeEnum
	{
		[Display(Name = "Х-отчет по секциям")]
		SectionReportX = 1,
		[Display(Name = "Х-отчет по кассирам")]
		CashierReportX,
		[Display(Name = "Х-отчет по кассам")]
		CashboxReportX,
		[Display(Name = "Отчет по операциям за период по кассе")]
		OperationReport,
		[Display(Name = "Отчет по валютам за период по кассе")]
		CurrencyReport,
		[Display(Name = "Доп. отчет по кассам")]
		CashboxReportXAdditional,
		[Display(Name = "Фискальный отчет за период")]
		FiscalReport,
		[Display(Name = "Журнал отчетов")]
		HistoryReport
	}
}
