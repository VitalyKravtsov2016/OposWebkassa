namespace WebCash.Constants.Enums
{
	public enum TaxationTypeEnum : byte
	{
		STS = 100,
		RTS,
		TRFF,
		TRBP
	}
}
