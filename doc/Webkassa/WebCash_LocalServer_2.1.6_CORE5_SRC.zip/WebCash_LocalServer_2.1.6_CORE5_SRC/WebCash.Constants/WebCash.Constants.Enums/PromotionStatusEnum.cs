namespace WebCash.Constants.Enums
{
	public enum PromotionStatusEnum : byte
	{
		InActive,
		Active
	}
}
