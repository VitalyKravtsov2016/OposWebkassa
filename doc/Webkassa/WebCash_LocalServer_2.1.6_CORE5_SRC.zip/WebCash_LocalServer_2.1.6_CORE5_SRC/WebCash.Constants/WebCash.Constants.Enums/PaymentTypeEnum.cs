using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	[Serializable]
	public enum PaymentTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "Cash")]
		[XmlEnum("0")]
		PAYMENT_CASH,
		[Display(ResourceType = typeof(NameResource), Name = "BankCard")]
		[XmlEnum("1")]
		PAYMENT_CARD,
		[Display(ResourceType = typeof(NameResource), Name = "Credit")]
		[XmlEnum("2")]
		PAYMENT_CREDIT,
		[Display(ResourceType = typeof(NameResource), Name = "Tara")]
		[XmlEnum("3")]
		PAYMENT_TARE,
		[Display(ResourceType = typeof(NameResource), Name = "Mobile")]
		[XmlEnum("4")]
		PAYMENT_MOBILE
	}
}
