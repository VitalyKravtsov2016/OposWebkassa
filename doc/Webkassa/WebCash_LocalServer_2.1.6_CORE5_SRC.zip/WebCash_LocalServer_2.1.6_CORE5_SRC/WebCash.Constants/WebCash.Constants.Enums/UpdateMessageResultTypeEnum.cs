namespace WebCash.Constants.Enums
{
	public enum UpdateMessageResultTypeEnum
	{
		RESULT_OK,
		RESULT_UNKNOWN_REQUEST,
		RESULT_UNREGISTERED_KKM,
		RESULT_SYSTEM_ERROR
	}
}
