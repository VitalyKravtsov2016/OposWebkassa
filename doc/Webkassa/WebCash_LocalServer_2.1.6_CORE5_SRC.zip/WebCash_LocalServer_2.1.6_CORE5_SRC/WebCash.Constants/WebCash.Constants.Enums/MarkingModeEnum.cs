using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum MarkingModeEnum : byte
	{
		[Display(ResourceType = typeof(JsResource), Name = "WithoutMarking")]
		None,
		[Display(ResourceType = typeof(JsResource), Name = "Marking")]
		Marking,
		[Display(ResourceType = typeof(JsResource), Name = "TotalMarking")]
		TotalMarking
	}
}
