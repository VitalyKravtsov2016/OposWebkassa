namespace WebCash.Constants.Enums
{
	public enum PermissionKindEnum
	{
		Default,
		Privileged
	}
}
