namespace WebCash.Constants.Enums
{
	public enum PrintFormatTypeEnum : byte
	{
		Text,
		Image,
		QrCode,
		Line,
		TwoSideText
	}
}
