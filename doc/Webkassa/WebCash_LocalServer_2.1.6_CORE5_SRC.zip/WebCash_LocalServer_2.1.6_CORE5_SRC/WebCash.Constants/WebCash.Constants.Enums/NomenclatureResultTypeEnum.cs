namespace WebCash.Constants.Enums
{
	public enum NomenclatureResultTypeEnum
	{
		RESULT_TYPE_OK,
		RESULT_TYPE_VERSION_IS_ACTUAL,
		RESULT_TYPE_NO_VERSION
	}
}
