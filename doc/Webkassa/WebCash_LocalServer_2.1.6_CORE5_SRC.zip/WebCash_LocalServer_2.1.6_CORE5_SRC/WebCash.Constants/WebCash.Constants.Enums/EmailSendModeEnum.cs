using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum EmailSendModeEnum : byte
	{
		[Display(ResourceType = typeof(JsResource), Name = "EmailSendModeNone")]
		None,
		[Display(ResourceType = typeof(JsResource), Name = "EmailSendModeShiftClose")]
		OnlyAutoClosingShift,
		[Display(ResourceType = typeof(JsResource), Name = "EmailSendModeAlways")]
		Always
	}
}
