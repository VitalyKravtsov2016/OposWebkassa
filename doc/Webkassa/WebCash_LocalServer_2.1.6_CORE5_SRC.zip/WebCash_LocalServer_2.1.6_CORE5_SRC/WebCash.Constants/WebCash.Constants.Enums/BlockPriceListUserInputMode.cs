namespace WebCash.Constants.Enums
{
	public enum BlockPriceListUserInputMode
	{
		Disabled,
		NameAndPrice,
		NameOnly
	}
}
