using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum NotificationTypeEnum : byte
	{
		None,
		[Display(ResourceType = typeof(CommonResource), Name = "ExpirationOfLicenses")]
		ExpirationOfLicenses,
		[Display(ResourceType = typeof(CommonResource), Name = "Advertising")]
		Advertising
	}
}
