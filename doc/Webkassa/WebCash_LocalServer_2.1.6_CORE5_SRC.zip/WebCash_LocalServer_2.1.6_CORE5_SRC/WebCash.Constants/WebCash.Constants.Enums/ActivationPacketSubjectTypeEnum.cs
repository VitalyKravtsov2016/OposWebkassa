namespace WebCash.Constants.Enums
{
	public enum ActivationPacketSubjectTypeEnum : byte
	{
		Cashbox,
		Analytics,
		Excise
	}
}
