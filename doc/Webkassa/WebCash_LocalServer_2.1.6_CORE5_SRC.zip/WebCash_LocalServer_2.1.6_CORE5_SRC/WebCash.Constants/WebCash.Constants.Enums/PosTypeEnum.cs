namespace WebCash.Constants.Enums
{
	public enum PosTypeEnum
	{
		WithoutPos = 0,
		SmartPos = 1,
		Ingenico = 2,
		AlfaSmartPos = 3,
		AlfaSoftPos = 4,
		InpasPos = 5,
		HalykSoftPos = 6,
		KaspiQR = 7,
		Undefined = -1
	}
}
