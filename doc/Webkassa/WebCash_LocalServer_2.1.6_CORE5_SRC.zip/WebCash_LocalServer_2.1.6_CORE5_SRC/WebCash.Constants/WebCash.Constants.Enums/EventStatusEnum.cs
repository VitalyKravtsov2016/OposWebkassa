namespace WebCash.Constants.Enums
{
	public enum EventStatusEnum : byte
	{
		NotConfirmed,
		Success,
		Failure
	}
}
