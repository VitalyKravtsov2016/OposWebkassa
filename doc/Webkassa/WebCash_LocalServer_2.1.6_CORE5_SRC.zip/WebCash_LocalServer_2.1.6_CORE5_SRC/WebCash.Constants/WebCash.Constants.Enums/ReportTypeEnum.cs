using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ReportTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "ReportZ")]
		ReportZ,
		[Display(ResourceType = typeof(NameResource), Name = "ReportX")]
		ReportX
	}
}
