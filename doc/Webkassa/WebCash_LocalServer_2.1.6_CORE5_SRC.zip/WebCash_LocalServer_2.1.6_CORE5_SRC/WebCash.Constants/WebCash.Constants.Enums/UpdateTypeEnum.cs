namespace WebCash.Constants.Enums
{
	public enum UpdateTypeEnum
	{
		UPDATE_TYPE_NOTHING = 1,
		UPDATE_TYPE_UPDATE,
		UPDATE_TYPE_ROLLBACK
	}
}
