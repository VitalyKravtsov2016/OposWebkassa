using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum OperationTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "OperationTypeBuy")]
		[XmlEnum("0")]
		Buy,
		[Display(ResourceType = typeof(NameResource), Name = "OperationTypeReturnBuy")]
		[XmlEnum("1")]
		ReturnBuy,
		[Display(ResourceType = typeof(NameResource), Name = "OperationTypeSell")]
		[XmlEnum("2")]
		Sell,
		[Display(ResourceType = typeof(NameResource), Name = "OperationTypeReturnSell")]
		[XmlEnum("3")]
		ReturnSell
	}
}
