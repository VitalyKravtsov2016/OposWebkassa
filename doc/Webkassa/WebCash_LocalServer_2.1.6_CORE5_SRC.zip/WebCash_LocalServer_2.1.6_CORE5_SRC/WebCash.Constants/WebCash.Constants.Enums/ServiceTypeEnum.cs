using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ServiceTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "PaidService")]
		Paid = 1,
		[Display(ResourceType = typeof(NameResource), Name = "FreeService")]
		Free
	}
}
