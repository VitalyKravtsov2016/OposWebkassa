namespace WebCash.Constants.Enums
{
	public enum SyncStateWithOfdMode
	{
		Never,
		Once,
		Always
	}
}
