using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum PinType
	{
		[Display(ResourceType = typeof(NameResource), Name = "PinProgramming")]
		Programming,
		[Display(ResourceType = typeof(NameResource), Name = "PinOperations")]
		PinOperations,
		[Display(ResourceType = typeof(NameResource), Name = "PinShiftClose")]
		PinShiftClose,
		[Display(ResourceType = typeof(CommonResource), Name = "PinInspector")]
		PinInspector
	}
}
