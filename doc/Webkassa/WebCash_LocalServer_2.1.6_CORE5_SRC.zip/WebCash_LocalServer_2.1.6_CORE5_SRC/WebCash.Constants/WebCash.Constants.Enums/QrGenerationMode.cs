using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum QrGenerationMode : byte
	{
		[Display(Name = "Нет")]
		None,
		[Display(Name = "QR-код Webkassa")]
		Webkassa,
		[Display(Name = "QR-код ОФД")]
		Ofd
	}
}
