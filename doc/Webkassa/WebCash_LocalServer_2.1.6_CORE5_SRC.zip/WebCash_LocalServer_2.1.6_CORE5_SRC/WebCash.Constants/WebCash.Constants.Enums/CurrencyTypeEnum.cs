namespace WebCash.Constants.Enums
{
	public enum CurrencyTypeEnum
	{
		KZT = 398,
		USD = 840,
		CNY = 156,
		RUB = 643,
		GBP = 826,
		EUR = 978,
		KGS = 417,
		UZS = 860
	}
}
