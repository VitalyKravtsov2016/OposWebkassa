namespace WebCash.Constants.Enums
{
	public enum RequestTypeEnum
	{
		REQUEST_CHECK_UPDATES = 1,
		REQUEST_POST_UPDATE_STATUS
	}
}
