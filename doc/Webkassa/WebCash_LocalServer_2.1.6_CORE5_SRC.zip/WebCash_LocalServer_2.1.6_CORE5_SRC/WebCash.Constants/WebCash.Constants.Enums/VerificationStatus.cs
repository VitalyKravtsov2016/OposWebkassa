namespace WebCash.Constants.Enums
{
	public enum VerificationStatus
	{
		Success,
		InProcess,
		Error,
		NotCheckedYet
	}
}
