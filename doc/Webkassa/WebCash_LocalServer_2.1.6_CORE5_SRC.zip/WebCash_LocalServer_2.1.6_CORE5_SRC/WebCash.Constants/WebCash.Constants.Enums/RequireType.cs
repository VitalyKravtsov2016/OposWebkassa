namespace WebCash.Constants.Enums
{
	public enum RequireType
	{
		All,
		Any
	}
}
