using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum CashboxModelTypeEnum : byte
	{
		[Display(Name = "АПК ККМ Webkassa 1.0")]
		Model188,
		[Display(Name = "Webkassa 1.0")]
		Model176,
		[Display(Name = "АПК ККМ Webkassa 1.0 без ФПД")]
		Model200,
		[Display(Name = "АПК Webkassa 2.0")]
		Model208,
		[Display(Name = "BKassa")]
		Model242,
		[Display(Name = "АПК WK-3C-FR")]
		Model238,
		[Display(Name = "АПК Webkassa 3.0")]
		Model241
	}
}
