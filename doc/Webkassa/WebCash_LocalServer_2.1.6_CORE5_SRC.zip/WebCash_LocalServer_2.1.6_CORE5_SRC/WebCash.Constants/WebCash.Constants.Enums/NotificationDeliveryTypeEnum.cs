namespace WebCash.Constants.Enums
{
	public enum NotificationDeliveryTypeEnum : byte
	{
		None,
		Email,
		Push
	}
}
