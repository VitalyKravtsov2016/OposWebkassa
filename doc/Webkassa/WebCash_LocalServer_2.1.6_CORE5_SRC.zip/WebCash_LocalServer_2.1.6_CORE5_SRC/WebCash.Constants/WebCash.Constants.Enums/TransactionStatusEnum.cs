namespace WebCash.Constants.Enums
{
	public enum TransactionStatusEnum
	{
		InProcess,
		Success,
		Error
	}
}
