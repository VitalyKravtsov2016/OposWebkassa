namespace WebCash.Constants.Enums
{
	public enum PasswordVerificationEnum
	{
		Failed,
		Success,
		SuccessRehashNeeded
	}
}
