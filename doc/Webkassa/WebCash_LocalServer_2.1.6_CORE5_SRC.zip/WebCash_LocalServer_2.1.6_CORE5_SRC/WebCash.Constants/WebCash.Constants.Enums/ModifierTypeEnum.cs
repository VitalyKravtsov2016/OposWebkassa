using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ModifierTypeEnum : byte
	{
		[Display(Name = "CheckDiscount", ResourceType = typeof(NameResource))]
		Discount = 1,
		[Display(Name = "CheckMarkup", ResourceType = typeof(NameResource))]
		Markup
	}
}
