namespace WebCash.Constants.Enums
{
	public enum QueueStateEnum : byte
	{
		Await,
		InProcess,
		Error
	}
}
