using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum OfflineSupportMode : byte
	{
		[Display(Name = "Выключен")]
		Disabled,
		[Display(Name = "Включен")]
		Enabled,
		[Display(Name = "Включён")]
		Special,
		[Display(Name = "Товарный")]
		Trade
	}
}
