namespace WebCash.Constants.Enums
{
	public enum TicketAdTypeEnum
	{
		TICKET_AD_OFD,
		TICKET_AD_ORG,
		TICKET_AD_POS,
		TICKET_AD_KKM,
		TICKET_AD_INFO
	}
}
