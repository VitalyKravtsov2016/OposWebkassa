using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum ActivationCodeStatusEnum : byte
	{
		[Display(Name = "Не отправлен клиенту")]
		NotSent,
		[Display(Name = "Отправлен клиенту")]
		SentToCustomer,
		[Display(Name = "Активирован")]
		Activated,
		[Display(Name = " Шаг 1 Регистрации выполнен")]
		InRegistration,
		[Display(Name = "Шаг 2 Регистрации выполнен (Завершено)")]
		RegistrationComplited,
		[Display(Name = "Готово к работе")]
		AvailableToWork
	}
}
