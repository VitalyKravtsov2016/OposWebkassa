namespace WebCash.Constants.Enums
{
	public enum ViewTextTypeEnum : byte
	{
		PlainText,
		Html
	}
}
