using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum WorkModeEnum : byte
	{
		[Display(ResourceType = typeof(CommonResource), Name = "WorkModeEnumOnlineMode")]
		OnlineMode,
		[Display(ResourceType = typeof(CommonResource), Name = "WorkModeEnumOfflineMode")]
		OfflineMode,
		[Display(ResourceType = typeof(NameResource), Name = "ExitFromOfflineMode")]
		ExitFromOfflineMode
	}
}
