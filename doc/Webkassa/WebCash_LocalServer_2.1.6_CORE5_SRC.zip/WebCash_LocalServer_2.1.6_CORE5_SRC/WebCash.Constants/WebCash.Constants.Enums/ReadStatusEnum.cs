using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ReadStatusEnum : byte
	{
		[Display(ResourceType = typeof(CommonResource), Name = "ReadStatusUnread")]
		Unread,
		[Display(ResourceType = typeof(CommonResource), Name = "ReadStatusRead")]
		Read,
		[Display(ResourceType = typeof(CommonResource), Name = "ReadStatusMarkedUnread")]
		MarkedUnread,
		[Display(ResourceType = typeof(CommonResource), Name = "ReadStatusMarkedAsRead")]
		MarkedAsRead
	}
}
