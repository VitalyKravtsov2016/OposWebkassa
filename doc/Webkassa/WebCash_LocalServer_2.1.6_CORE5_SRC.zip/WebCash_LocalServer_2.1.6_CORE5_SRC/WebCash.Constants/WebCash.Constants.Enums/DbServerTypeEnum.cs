namespace WebCash.Constants.Enums
{
	public enum DbServerTypeEnum : byte
	{
		None,
		Archiv,
		Operational
	}
}
