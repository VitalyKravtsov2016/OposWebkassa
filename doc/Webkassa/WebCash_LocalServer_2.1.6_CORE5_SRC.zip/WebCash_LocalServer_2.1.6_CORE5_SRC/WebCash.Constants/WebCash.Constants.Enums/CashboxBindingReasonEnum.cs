namespace WebCash.Constants.Enums
{
	public enum CashboxBindingReasonEnum
	{
		Creator,
		License
	}
}
