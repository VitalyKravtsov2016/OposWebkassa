namespace WebCash.Constants.Enums
{
	public enum DashboardWiggetEnum
	{
		None,
		CashboxRevenueCompare
	}
}
