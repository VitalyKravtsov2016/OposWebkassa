namespace WebCash.Constants.Enums
{
	public enum PrintPaperKind
	{
		CashTape80 = 0,
		CashTape57 = 3,
		A4 = 12,
		A4Landscape = 13
	}
}
