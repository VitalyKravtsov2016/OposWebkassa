namespace WebCash.Constants.Enums
{
	public enum SMSCErrorCodes
	{
		ArgumentError = -1,
		WrongUserNameOrPassword = -2,
		InsufficientFunds = -3,
		IPAddressBlocked = -4,
		WrongDateFormat = -5,
		MessageRestricted = -6,
		WrongNumberFormat = -7,
		CantSendToSelectedNumber = -8,
		TooManyRequests = -9
	}
}
