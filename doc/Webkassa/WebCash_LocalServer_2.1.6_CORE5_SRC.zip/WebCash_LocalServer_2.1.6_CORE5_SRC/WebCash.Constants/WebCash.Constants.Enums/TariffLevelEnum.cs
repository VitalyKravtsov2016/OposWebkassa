namespace WebCash.Constants.Enums
{
	public enum TariffLevelEnum : byte
	{
		Level1 = 1,
		Level2,
		Level3,
		Level4,
		Level5
	}
}
