using System;
using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum MessageResultTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeOk")]
		Ok = 0,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeUnknownID")]
		UnknownID = 1,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeInvalidToken")]
		InvalidToken = 2,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeProtokolError")]
		ProtocolError = 3,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeUnknownCommand")]
		UnknownCommand = 4,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeUnsupportedCommand")]
		UnsupportedCommand = 5,
		[Obsolete("Устарело", true)]
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeInvalidConfiguration")]
		InvalidConfiguration = 6,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeSslIsNotAllowed")]
		SslIsNotAllowed = 7,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeInvalidRequestNumber")]
		InvalidRequestNumber = 8,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeInvalidRetryRequest")]
		InvalidRetryRequest = 9,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeCantCancelTicket")]
		CantCancelTicket = 10,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeOpenShiftTimeoutExpired")]
		OpenShiftTimeoutExpired = 11,
		[Obsolete("Устарело", true)]
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeInvalidLoginPassword")]
		InvalidLoginPassword = 12,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeIncorrectRequestData")]
		IncorrectRequestData = 13,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeNotEnoughCash")]
		NotEnoughCash = 14,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeBlocked")]
		Blocked = 15,
		[Display(Name = "Поле ИИН\\БИН покупателя не должно быть равно ИИН\\БИН продавца")]
		SAME_TAXPAYER_AND_CUSTOMER = 17,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeServiceTemporarilyUnavailable")]
		ServiceTemporarilyUnavailable = 254,
		[Display(ResourceType = typeof(NameResource), Name = "MessageResultTypeUnknownError")]
		UnknownError = 255,
		[Display(ResourceType = typeof(CommonResource), Name = "OfdServicesNotAvailableForCashbox")]
		OfdServicesNotAvailableForCashbox = 10000,
		[Display(ResourceType = typeof(CommonResource), Name = "OfdServicesNotAvailable")]
		OfdServicesNotAvailable = 10001
	}
}
