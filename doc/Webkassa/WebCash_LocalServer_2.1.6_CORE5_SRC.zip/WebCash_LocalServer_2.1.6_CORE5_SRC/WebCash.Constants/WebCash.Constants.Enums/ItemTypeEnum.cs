using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum ItemTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "Commodity")]
		[XmlEnum("1")]
		Commodity = 1,
		[Display(ResourceType = typeof(NameResource), Name = "CommodityStorno")]
		[XmlEnum("2")]
		StornoCommodity,
		[Display(ResourceType = typeof(NameResource), Name = "CheckMarkup")]
		[XmlEnum("3")]
		Markup,
		[Display(ResourceType = typeof(NameResource), Name = "MarkupStorno")]
		[XmlEnum("4")]
		StornoMarkup,
		[Display(ResourceType = typeof(NameResource), Name = "CheckDiscount")]
		[XmlEnum("5")]
		Discount,
		[Display(ResourceType = typeof(NameResource), Name = "DiscountStorno")]
		[XmlEnum("6")]
		StornoDiscount
	}
}
