namespace WebCash.Constants.Enums
{
	public static class CashboxModelTypeConst
	{
		public const string Model176 = "0x006500008604";

		public const string Model188 = "0x0065000087fa";

		public const string Model208 = "0x006500008b23";

		public const string Model241 = "0x00650000962e";
	}
}
