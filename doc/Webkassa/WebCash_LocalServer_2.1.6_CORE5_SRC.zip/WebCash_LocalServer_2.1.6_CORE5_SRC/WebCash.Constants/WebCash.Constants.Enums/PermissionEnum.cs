using System;
using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum PermissionEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsSales")]
		Sales = 0,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsPurchases")]
		Purchases = 1,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsSaleReturns")]
		ReturnSales = 2,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsDepositCash")]
		DepositCash = 3,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsWithdrawalCash")]
		WidthrawalCash = 4,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsCloseShift")]
		CloseShift = 5,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsCreateXReport")]
		CreateXReport = 6,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsVewZXReport")]
		VewXZReport = 7,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsProgramming")]
		Programming = 8,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsEditEmployees")]
		EditEmployees = 9,
		[Display(ResourceType = typeof(NameResource), Name = "Administrator")]
		Administrator = 10,
		[Display(ResourceType = typeof(NameResource), Name = "SystemLicensesManagement")]
		SystemCabinet = 11,
		[Display(ResourceType = typeof(NameResource), Name = "ServiceCenterCabinet")]
		ServiceCenterCabinet = 12,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionCheckHistory")]
		CheckHistory = 13,
		[Display(Name = "Доступ в кабинет 1С")]
		Cabinet1C = 14,
		[Display(Name = "Просмотр партнеров 1С")]
		View1CPartners = 15,
		[Display(Name = "Корп. инстанс: Список организаций")]
		[Obsolete("Не используется в системе", true)]
		CorpOrganizationList = 16,
		[Display(Name = "Корп. инстанс: Список касс")]
		[Obsolete("Не используется в системе", true)]
		CorpCashboxList = 17,
		[Display(Name = "Доступ только к API")]
		ApiOnly = 18,
		[Display(Name = "Корп. инстанс: Восстановление касс")]
		[Obsolete("Не используется в системе", true)]
		CorpCashboxListRecovery = 19,
		[Display(Name = "Кабинет ЦТО. Регистрация новой организации\\кассы")]
		ServiceCenterCabinetRegisterNewOrganization = 20,
		[Display(Name = "Кабинет ЦТО. Активация кассы")]
		ServiceCenterCabinetActivateCashbox = 21,
		[Display(Name = "Кабинет техподдержки")]
		SupportCabinet = 22,
		[Display(Name = "Доступ в раздел мониторинга касс")]
		CashboxMonitoring = 23,
		[Obsolete("Отчёт удалён")]
		[Display(Name = "Доступ к просмотру аннулированных чеков")]
		CancelledTicketsView = 25,
		[Display(Name = "Кабинет ЦТО. Возможность активации Упрощенной лицензии")]
		ServiceCenterAccessToLitePacket = 26,
		[Display(Name = "Доступ к редактированию пароля")]
		[Obsolete("Не используется в системе", true)]
		EditEmployeePassword = 27,
		[Display(Name = "Просмотр организаций")]
		ViewOrganization = 28,
		[Display(Name = "Управление доверенными организациями")]
		ManageTrustedOrganization = 29,
		[Display(Name = "Кабинет ЦТО. Кассы Альфа")]
		ServiceCenterCabinetAlfaCashboxes = 30,
		[Obsolete("Функционал удален")]
		[Display(Name = "Просмотр состояния промокодов Kcell")]
		ViewPromocodeKcellStatus = 31,
		[Obsolete("Функционал удален")]
		[Display(Name = "Проверка организации Kcell")]
		CheckKcellOrganizationStatus = 32,
		[Display(Name = "Возможность печати QR-кода от Достык-Плазы")]
		AllowPrintDostykPlazaQr = 33,
		[Display(Name = "ТП: Снятие кассы с учета")]
		SupportCabinetDeregisterCashbox = 34,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionBookKeeping")]
		BookKeeping = 35,
		[Display(ResourceType = typeof(NameResource), Name = "TSPermissionsTransferPacket")]
		SupportCabinetTransferPacket = 36,
		[Display(Name = "Регистрация QR-кода")]
		QRCodeRegistration = 37,
		[Display(ResourceType = typeof(NameResource), Name = "WOTTIAccess")]
		WOTTIAccess = 38,
		[Display(ResourceType = typeof(NameResource), Name = "PermissionsContractManagement")]
		SupportCabinetContractManagement = 40,
		[Display(ResourceType = typeof(NameResource), Name = "TSPermissionsOrganizationRegistration")]
		SupportCabinetOrganizationRegistration = 41,
		[Display(ResourceType = typeof(NameResource), Name = "ManageExternalOrganizationsDataTransfer")]
		ManageExternalOrganizationsDataTransfer = 42,
		[Display(ResourceType = typeof(NameResource), Name = "ViewExternalOrganizationsCashboxes")]
		ViewExternalOrganizationsCashboxes = 43,
		[Display(Name = "Кабинет ЦТО. Возможность активации Пакетов x10")]
		ServiceCenterAccessToX10Packets = 44,
		[Display(Name = "Модуль Аналитика")]
		Analytic = 45,
		[Display(Name = "Отчет по операциям")]
		Defacto = 46,
		[Display(Name = "Кабинет ЦТО. Активация пакетов аналитики")]
		ServiceCenterCabinetActivateAnalytic = 47,
		[Display(ResourceType = typeof(NameResource), Name = "CallCenter")]
		CallCenter = 49,
		[Display(ResourceType = typeof(NameResource), Name = "SystemCabinetBalanceReplenishment")]
		SystemCabinetBalanceReplenishment = 50,
		[Display(ResourceType = typeof(NameResource), Name = "AnalyticMonitoring")]
		AnalyticMonitoring = 51,
		[Display(Name = "Кабинет ЦТО. Акцизы")]
		ServiceCenterCabinetExcise = 52,
		[Display(Name = "Кабинет ТП. Акцизы")]
		SupportCabinetExcise = 53,
		[Display(Name = "Кабинет ЦТО. Получение уведомлений об истекающих пакетах")]
		ServiceCenterCabinetPacketExpirationReceive = 54,
		[Display(Name = "Sulpak. Курьер")]
		SulpakCourier = 56,
		[Display(Name = "История чека по QR-коду ОФД")]
		TicketHistoryByOfdUrl = 57,
		[Display(Name = "Формирование отчета по Акцизам")]
		FormingReportByExcises = 58,
		[Display(Name = "Просмотр Акцизы. История проверок")]
		ExciseCheckHistoryForOrganizations = 59,
		[Display(Name = "Управление режимом курьера")]
		CourierModeControl = 60,
		[Display(Name = "Просмотр истории уровней ЦТО")]
		ServiceCenterLevelHistory = 61,
		[Display(Name = "Доступ к возвратам Покупки")]
		ReturnBuys = 62,
		[Display(Name = "Пользователь Trinity")]
		TrinityUser = 63,
		[Display(Name = "Система Trinity")]
		TrinitySystem = 64,
		[Display(Name = "Кабинет ЦТО. Доступ к ценам")]
		ServiceCenterCabinetAccessToPrices = 65,
		[Display(Name = "Бухгалтерия WK. Генерация активационных карт")]
		BookkeepingLitePackets = 67,
		[Display(Name = "ТП: Регистрация новой организации (ЦТО)")]
		SupportCabinetServiceCenterRegister = 68,
		[Display(Name = "ТП: Удаление кассы")]
		SupportCabinetDeletingCashbox = 69,
		[Display(Name = "ТП: Безлимитный пробный")]
		SupportCabinetUnlimitedFreePackets = 70,
		[Display(Name = "ТП: Управление пробной лицензией")]
		SupportCabinetFreePacketsManage = 71,
		[Display(Name = "ТП: Отзыв лицензий")]
		SupportCabinetRevokePackets = 72,
		[Display(Name = "ТП: Закрытие смены")]
		SupportCabinetCloseShift = 73,
		[Display(Name = "ТП: Сброс кассы на Создана")]
		SupportCabinetResetCashboxToCreated = 74,
		[Display(Name = "Маркетинг. Просмотр касс")]
		MarketingCashboxView = 75,
		[Display(Name = "Маркетинг. Управление покупками call-центра")]
		MarketingBuyManage = 76,
		[Display(Name = "Кабинет ЦТО. Автодобавление лицензии")]
		ServiceCenterAutoAddLicense = 77,
		[Display(Name = "Система. Просмотр сведений об организации кассы")]
		SystemViewInformationAboutOrganization = 78,
		[Display(Name = "Кабинет ЦТО. Просмотр приобретенных лицензий")]
		ServiceCenterViewPurchasedLicenses = 79,
		[Display(Name = "Уведомления. Просмотр")]
		UserNotificationView = 80,
		[Display(Name = "Уведомления. Настройка")]
		UserNotificationsettings = 81,
		[Display(Name = "Кабинет ЦТО. Отчеты")]
		ServiceCenterReports = 82,
		[Display(Name = "Уведомления. Создание")]
		UserNotificationCreation = 83,
		[Display(Name = "Кабинет ЦТО. Управление обновлениями клиентов")]
		UpdateManagement = 85,
		[Display(Name = "Акцизы. Настройки")]
		ExciseSettings = 86,
		[Display(Name = "Акцизы. Управление торговыми точками.")]
		ExciseManageTradePoints = 87,
		[Display(Name = "Кабинет ЦТО. Просмотр акции «500 за кассу в kOFD")]
		PromotionView = 88,
		[Display(Name = "Доступ к возвратам по оплатам через Kaspi QR без создания чека")]
		KaspiSalesReturn = 89,
		[Display(Name = "Доступ к отчетам по транзакциям Kaspi QR")]
		KaspiReportsView = 90,
		[Display(Name = "Кабинет ЦТО. Отзыв лицензии")]
		ServiceCentertRevokePackets = 91,
		[Display(Name = "Менеджер ЦТО")]
		ServiceCenterSupervisor = 92,
		[Display(Name = "Кабинет ЦТО. Создание актив. кодов упрощенных лицензий")]
		ServiceCenterActivationCardCreation = 93,
		[Display(Name = "Кабинет ЦТО. Просмотр актив. кодов упрощенных лицензий")]
		ServiceCenterActivationCardView = 94,
		[Display(Name = "Кабинет ЦТО. Автопродление касс")]
		ServiceCenterCabinetAutoRenewals = 99,
		[Display(Name = "Кабинет СП. Настройка автономного режима")]
		SupportCabinetOfflineMode = 100,
		[Display(Name = "Кабинет СП. Просмотр интеграторов")]
		SupportCabinetApiKeyView = 101,
		[Display(Name = "Кабинет СП. Сгенерировать API-KEY")]
		SupportCabinetApiKeyCreate = 102
	}
}
