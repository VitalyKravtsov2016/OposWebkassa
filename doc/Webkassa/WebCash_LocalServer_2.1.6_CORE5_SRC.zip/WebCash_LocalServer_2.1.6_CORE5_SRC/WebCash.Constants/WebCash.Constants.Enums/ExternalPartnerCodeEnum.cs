using System;

namespace WebCash.Constants.Enums
{
	public enum ExternalPartnerCodeEnum : byte
	{
		None,
		Expo,
		OneC,
		AlfaBankComboProduct,
		[Obsolete("Функционал удален")]
		Kcell,
		Webkassa,
		OcpTelecom,
		TradeIn
	}
}
