using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum CommandTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeSystem")]
		COMMAND_SYSTEM = 0,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeTicket")]
		COMMAND_TICKET = 1,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeCloseShift")]
		COMMAND_CLOSE_SHIFT = 2,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeReport")]
		COMMAND_REPORT = 3,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeNomenclature")]
		COMMAND_NOMENCLATURE = 4,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeInfo")]
		COMMAND_INFO = 5,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeMoneyPlacement")]
		COMMAND_MONEY_PLACEMENT = 6,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeCancelTicket")]
		COMMAND_CANCEL_TICKET = 7,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeAuth")]
		COMMAND_AUTH = 8,
		[Display(ResourceType = typeof(NameResource), Name = "CommandTypeReserved")]
		COMMAND_RESERVED = 127
	}
}
