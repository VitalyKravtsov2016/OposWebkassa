namespace WebCash.Constants.Enums
{
	public enum QRPaymentStatus
	{
		Created,
		Accepted,
		Declined,
		Completed
	}
}
