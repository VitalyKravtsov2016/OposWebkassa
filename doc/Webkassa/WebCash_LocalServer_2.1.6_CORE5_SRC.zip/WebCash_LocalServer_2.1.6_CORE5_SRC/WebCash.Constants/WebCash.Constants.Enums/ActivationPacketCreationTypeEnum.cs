using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum ActivationPacketCreationTypeEnum : byte
	{
		[Display(Name = "Ручной")]
		Manual,
		[Display(Name = "Автодобавление")]
		Auto
	}
}
