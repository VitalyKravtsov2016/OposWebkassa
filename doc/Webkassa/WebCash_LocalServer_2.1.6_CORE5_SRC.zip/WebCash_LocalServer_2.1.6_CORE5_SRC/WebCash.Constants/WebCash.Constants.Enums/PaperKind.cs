using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum PaperKind
	{
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80")]
		CashTape80,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape57Rongta")]
		CashTape57Rongta,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape57Lite")]
		CashTape57Lite,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape57Shtrikh")]
		CashTape57Shtrikh,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape57ShtrikhLite")]
		CashTape57ShtrikhLite,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80ShtrikhM")]
		CashTape80ShtrikhM,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80Aura")]
		CashTape80Aura,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80Posiflex")]
		CashTape80Posiflex,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80Prim")]
		CashTape80Prim,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80Sam4s")]
		CashTape80Sam4s,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80XTerm")]
		CashTape80XTerm,
		[Display(ResourceType = typeof(NameResource), Name = "CashTape80Rongta")]
		CashTape80Rongta,
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeA4")]
		A4,
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeA4Rotate")]
		A4Landscape,
		[Display(ResourceType = typeof(NameResource), Name = "Other")]
		Other
	}
}
