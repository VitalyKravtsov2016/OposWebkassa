using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum OfdEnum
	{
		[Display(Name = "Казахтелеком")]
		KazakhTelecom = 1,
		[Display(Name = "Транстелеком")]
		TransTelecom,
		[Display(Name = "Jusan Mobile")]
		KazTranscom
	}
}
