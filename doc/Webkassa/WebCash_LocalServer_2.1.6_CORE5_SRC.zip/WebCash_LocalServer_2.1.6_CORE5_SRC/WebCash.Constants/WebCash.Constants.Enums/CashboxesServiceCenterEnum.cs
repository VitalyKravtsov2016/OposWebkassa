namespace WebCash.Constants.Enums
{
	public enum CashboxesServiceCenterEnum : byte
	{
		Wait,
		Active,
		InActive
	}
}
