using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum SoftPosTypeEnum : byte
	{
		[Display(Name = "Альфа-банк")]
		AlphaBank,
		[Display(Name = "Халык-банк")]
		Halyk
	}
}
