using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum BonusCountOperationTypeEnum : byte
	{
		[Display(Name = "Пополнение")]
		Deposit,
		[Display(Name = "Списание")]
		WithDrawal
	}
}
