using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum CashboxTimeZoneEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "CashboxTimeZoneAstanaUTC06")]
		Astana,
		[Display(ResourceType = typeof(NameResource), Name = "CashboxTimeZoneUralUTC05")]
		Ural
	}
}
