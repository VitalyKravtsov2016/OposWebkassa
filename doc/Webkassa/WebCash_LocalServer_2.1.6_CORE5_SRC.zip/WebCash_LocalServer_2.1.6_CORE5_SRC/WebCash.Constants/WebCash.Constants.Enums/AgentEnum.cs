using System;
using System.ComponentModel.DataAnnotations;

namespace WebCash.Constants.Enums
{
	public enum AgentEnum : byte
	{
		[Display(Name = "Без признака")]
		None,
		[Display(Name = "Покупки с сайта")]
		WebKassaSite,
		[Display(Name = "Покупки с call-центра")]
		WebkassaCallCenter,
		[Obsolete("Функционал удален")]
		[Display(Name = "Kcell")]
		Kcell,
		[Display(Name = "ОЦП Казахтелеком")]
		OcpTelecom
	}
}
