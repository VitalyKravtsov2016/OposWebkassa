using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum SystemTypeEnum
	{
		[Display(ResourceType = typeof(CommonResource), Name = "SystemTypeEnumWebCashDemo")]
		WebCashDemo,
		[Display(ResourceType = typeof(CommonResource), Name = "SystemTypeEnumComputerSystem")]
		WebCashProduction
	}
}
