namespace WebCash.Constants.Enums
{
	public enum TicketTableTypeEnum : byte
	{
		None,
		Ticket,
		TransferTicket
	}
}
