using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum HouseTypeEnum : byte
	{
		[Display(ResourceType = typeof(JsResource), Name = "House")]
		House,
		[Display(ResourceType = typeof(JsResource), Name = "Structure")]
		Structure,
		[Display(ResourceType = typeof(JsResource), Name = "Building")]
		Building
	}
}
