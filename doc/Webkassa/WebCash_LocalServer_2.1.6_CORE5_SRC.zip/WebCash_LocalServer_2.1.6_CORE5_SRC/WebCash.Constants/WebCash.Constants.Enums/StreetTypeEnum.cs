using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum StreetTypeEnum : byte
	{
		[Display(ResourceType = typeof(JsResource), Name = "Street")]
		Street,
		[Display(ResourceType = typeof(JsResource), Name = "Boulevard")]
		Boulevard,
		[Display(ResourceType = typeof(JsResource), Name = "Avenue")]
		Avenue,
		[Display(ResourceType = typeof(JsResource), Name = "Lane")]
		Lane,
		[Display(ResourceType = typeof(JsResource), Name = "Microdistrict")]
		Microdistrict,
		[Display(ResourceType = typeof(JsResource), Name = "Quarter")]
		Quarter,
		[Display(ResourceType = typeof(JsResource), Name = "HousingArea")]
		HousingArea,
		[Display(ResourceType = typeof(JsResource), Name = "Area")]
		Area
	}
}
