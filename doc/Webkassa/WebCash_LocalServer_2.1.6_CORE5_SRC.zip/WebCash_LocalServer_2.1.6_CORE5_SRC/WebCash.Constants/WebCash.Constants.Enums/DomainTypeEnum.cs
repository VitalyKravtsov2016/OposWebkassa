using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum DomainTypeEnum : byte
	{
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeTrading")]
		[XmlEnum("0")]
		Trading,
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeServices")]
		[XmlEnum("1")]
		Services,
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeGasoil")]
		[XmlEnum("2")]
		Gasoil,
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeHotels")]
		[XmlEnum("3")]
		Hotels,
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeTaxi")]
		[XmlEnum("4")]
		Taxi,
		[Display(ResourceType = typeof(NameResource), Name = "DomainTypeParking")]
		[XmlEnum("5")]
		Parking
	}
}
