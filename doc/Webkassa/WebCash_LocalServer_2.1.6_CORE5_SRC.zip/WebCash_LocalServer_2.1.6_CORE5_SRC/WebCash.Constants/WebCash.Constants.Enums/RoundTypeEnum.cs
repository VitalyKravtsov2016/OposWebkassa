using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum RoundTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "RoundTypeNone")]
		None,
		[Display(ResourceType = typeof(NameResource), Name = "RoundTypeTotal")]
		Total,
		[Display(ResourceType = typeof(NameResource), Name = "RoundTypeEveryItem")]
		EveryItem,
		[Display(ResourceType = typeof(NameResource), Name = "RoundTypeTotalOnly")]
		TotalOnly
	}
}
