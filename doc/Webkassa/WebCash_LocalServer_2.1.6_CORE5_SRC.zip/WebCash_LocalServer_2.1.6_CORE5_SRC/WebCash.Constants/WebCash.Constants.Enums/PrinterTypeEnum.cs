using System.ComponentModel.DataAnnotations;
using WebCash.Resources;

namespace WebCash.Constants.Enums
{
	public enum PrinterTypeEnum
	{
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeCashTape")]
		CashTape80,
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeA4")]
		A4,
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeCashTape57")]
		CashTape57,
		[Display(ResourceType = typeof(NameResource), Name = "PrinterTypeA4Rotate")]
		A4Landscape
	}
}
