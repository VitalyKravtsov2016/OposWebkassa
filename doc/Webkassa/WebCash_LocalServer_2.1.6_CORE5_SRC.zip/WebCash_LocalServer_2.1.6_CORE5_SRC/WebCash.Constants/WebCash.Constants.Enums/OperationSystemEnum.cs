namespace WebCash.Constants.Enums
{
	public enum OperationSystemEnum
	{
		Windows,
		Linux,
		WindowsInstaller
	}
}
