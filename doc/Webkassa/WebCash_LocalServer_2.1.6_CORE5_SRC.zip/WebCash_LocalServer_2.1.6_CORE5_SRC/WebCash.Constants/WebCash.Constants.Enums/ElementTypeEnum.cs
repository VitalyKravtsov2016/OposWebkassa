namespace WebCash.Constants.Enums
{
	public enum ElementTypeEnum
	{
		GROUP,
		ITEM
	}
}
