namespace WebCash.Constants.Enums
{
	public enum TaxPercentTypeEnum
	{
		Zero = 0,
		Eight = 8,
		Twelve = 12,
		WithoutVat = 255
	}
}
