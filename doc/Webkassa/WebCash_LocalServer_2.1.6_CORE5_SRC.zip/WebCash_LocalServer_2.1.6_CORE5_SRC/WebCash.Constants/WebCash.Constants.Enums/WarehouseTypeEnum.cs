namespace WebCash.Constants.Enums
{
	public enum WarehouseTypeEnum : byte
	{
		None,
		VirtualWarehouseProduct
	}
}
