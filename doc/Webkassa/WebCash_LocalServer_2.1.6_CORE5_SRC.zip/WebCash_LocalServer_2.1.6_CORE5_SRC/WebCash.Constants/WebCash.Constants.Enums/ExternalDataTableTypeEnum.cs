namespace WebCash.Constants.Enums
{
	public enum ExternalDataTableTypeEnum : byte
	{
		None,
		Ticket,
		Money,
		XReport,
		ZReport
	}
}
