namespace WebCash.Constants.Enums
{
	public enum OrderTypeEnum : byte
	{
		Webkassa,
		Webscan
	}
}
