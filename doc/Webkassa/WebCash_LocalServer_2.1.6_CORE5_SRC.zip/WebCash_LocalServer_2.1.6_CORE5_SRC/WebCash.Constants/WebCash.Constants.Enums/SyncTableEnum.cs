namespace WebCash.Constants.Enums
{
	public enum SyncTableEnum : byte
	{
		Cashbox,
		Organization,
		Employee,
		Section
	}
}
