using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Webkassa")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("\r\n      Constants библиотека констант для внутренних модулей\r\n    ")]
[assembly: AssemblyFileVersion("1.1.2.0")]
[assembly: AssemblyInformationalVersion("1.1.2")]
[assembly: AssemblyProduct("WebCash.Constants")]
[assembly: AssemblyTitle("WebCash.Constants")]
[assembly: AssemblyVersion("1.1.2.0")]
