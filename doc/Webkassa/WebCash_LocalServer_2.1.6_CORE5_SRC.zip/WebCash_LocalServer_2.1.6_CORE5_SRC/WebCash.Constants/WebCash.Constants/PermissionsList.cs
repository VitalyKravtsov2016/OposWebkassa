namespace WebCash.Constants
{
	public static class PermissionsList
	{
	}
}
