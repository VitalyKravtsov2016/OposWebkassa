namespace WebCash.Constants
{
	public static class MimeTypes
	{
		public const string Pdf = "application/pdf";

		public const string Excel = "application/ms-excel";

		public const string Json = "application/json";

		public const string Binary = "application/octet-stream";

		public const string FormUrlencoded = "application/x-www-form-urlencoded";
	}
}
