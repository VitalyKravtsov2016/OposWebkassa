namespace WebCash.Constants
{
	public static class Timers
	{
		public static class Groups
		{
			public const string AutocloseShift = "AutocloseShift";

			public const string AutocloseShiftNotification = "AutocloseShiftNotification";

			public const string OcpTelecomNotification = "OcpTelecomNotification";

			public const string AutozeroOverdraft = "AutozeroOverdraft";
		}
	}
}
