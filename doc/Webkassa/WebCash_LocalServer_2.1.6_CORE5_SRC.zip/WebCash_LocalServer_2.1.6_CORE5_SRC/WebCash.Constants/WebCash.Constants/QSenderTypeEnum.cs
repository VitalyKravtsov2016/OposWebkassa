namespace WebCash.Constants
{
	public enum QSenderTypeEnum
	{
		None = -1,
		BI = 0,
		Archive = 2,
		Email = 3,
		ZReport = 4,
		Sulpak = 5,
		Ibd = 6,
		CashboxCache = 7,
		Advertising = 8
	}
}
