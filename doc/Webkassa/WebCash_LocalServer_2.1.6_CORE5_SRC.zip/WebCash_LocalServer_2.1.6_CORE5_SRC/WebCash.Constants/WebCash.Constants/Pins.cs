namespace WebCash.Constants
{
	public static class Pins
	{
		public const string InspectorPin = "1234";
	}
}
