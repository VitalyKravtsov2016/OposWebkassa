namespace WebCash.Constants
{
	public static class Time
	{
		public const int SecondsInDay = 86400;

		public const int HoursInDay = 24;

		public const int MinutesInHour = 60;

		public const int SecondsInMinute = 60;
	}
}
