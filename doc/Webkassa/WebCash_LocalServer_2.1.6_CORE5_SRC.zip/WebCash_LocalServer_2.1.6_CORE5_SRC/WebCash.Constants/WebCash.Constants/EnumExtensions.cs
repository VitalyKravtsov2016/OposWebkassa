using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;

namespace WebCash.Constants
{
	public static class EnumExtensions<T>
	{
		private static readonly Dictionary<T, DisplayAttribute> m__E000;

		public static ReferenceItem<T>[] ToDictionary()
		{
			return Enum.GetValues(typeof(T)).OfType<T>().Select(delegate(T _E001)
			{
				ReferenceItem<T> result = default(ReferenceItem<T>);
				result.Id = _E001;
				result.Text = GetDisplayName(_E001);
				return result;
			})
				.ToArray();
		}

		static EnumExtensions()
		{
			EnumExtensions<T>._E000 = new Dictionary<T, DisplayAttribute>();
			Type typeFromHandle = typeof(T);
			FieldInfo[] fields = typeFromHandle.GetFields();
			foreach (FieldInfo fieldInfo in fields)
			{
				object[] customAttributes = fieldInfo.GetCustomAttributes(typeof(DisplayAttribute), inherit: false);
				if (customAttributes.Any())
				{
					EnumExtensions<T>._E000[(T)Enum.Parse(typeFromHandle, fieldInfo.Name)] = (DisplayAttribute)customAttributes.First();
				}
			}
		}

		private static DisplayAttribute _E000(T _E000)
		{
			EnumExtensions<T>._E000.TryGetValue(_E000, out var value);
			return value;
		}

		public static string GetDisplayAttributeNonLocalized(T value)
		{
			return _E000(value).Name;
		}

		public static string GetDisplayName(T value)
		{
			DisplayAttribute displayAttribute = _E000(value);
			if (displayAttribute != null)
			{
				return displayAttribute.GetName();
			}
			return value.ToString();
		}

		public static string GetDisplayName(T value, string lang)
		{
			DisplayAttribute displayAttribute = _E000(value);
			if (displayAttribute == null)
			{
				return value.ToString();
			}
			return new ResourceManager(displayAttribute.ResourceType).GetResourceSet(new CultureInfo(lang), createIfNotExists: true, tryParents: true).GetString(displayAttribute.Name);
		}
	}
	public static class EnumExtensions
	{
		public static string GetDisplayNameSlim<T>(T value) where T : struct, IConvertible, IComparable, IFormattable
		{
			if (!typeof(T).IsEnum)
			{
				throw new ArgumentException(_E002._E000("\uf1f3\uf187\uf1ca\uf1d2\uf1d4\uf1d3\uf187\uf1c5\uf1c2\uf187\uf1c6\uf1c9\uf187\uf1c2\uf1c9\uf1d2\uf1ca\uf189", 61857));
			}
			return EnumExtensions<T>.GetDisplayName(value);
		}

		public static string GetDisplayNameLocalizationSlim<T>(T value, string lang) where T : struct, IConvertible, IComparable, IFormattable
		{
			if (!typeof(T).IsEnum)
			{
				throw new ArgumentException(_E002._E000("\uf1f3\uf187\uf1ca\uf1d2\uf1d4\uf1d3\uf187\uf1c5\uf1c2\uf187\uf1c6\uf1c9\uf187\uf1c2\uf1c9\uf1d2\uf1ca\uf189", 61857));
			}
			return EnumExtensions<T>.GetDisplayName(value, lang);
		}

		public static string GetDisplayName(this Enum value)
		{
			return (string)typeof(EnumExtensions).GetMethod(_E002._E000("\ue0b8\ue09a\ue08b\ue0bb\ue096\ue08c\ue08f\ue093\ue09e\ue086\ue0b1\ue09e\ue092\ue09a\ue0ac\ue093\ue096\ue092", 57389)).MakeGenericMethod(value.GetType()).Invoke(null, new object[1] { value });
		}

		public static string GetDisplayNameLocalization(this Enum value, string lang)
		{
			return (string)typeof(EnumExtensions).GetMethod(_E002._E000("\uec9d\uecbf\uecae\uec9e\uecb3\ueca9\uecaa\uecb6\uecbb\ueca3\uec94\uecbb\uecb7\uecbf\uec96\uecb5\uecb9\uecbb\uecb6\uecb3\ueca0\uecbb\uecae\uecb3\uecb5\uecb4\uec89\uecb6\uecb3\uecb7", 60634)).MakeGenericMethod(value.GetType()).Invoke(null, new object[2] { value, lang });
		}

		public static T ToEnum<T>(this string value) where T : struct, IConvertible, IComparable, IFormattable
		{
			return (T)Enum.Parse(typeof(T), value);
		}

		public static T ToCurrentType<T>(this Enum value)
		{
			return (T)Convert.ChangeType(value, typeof(T));
		}
	}
}
