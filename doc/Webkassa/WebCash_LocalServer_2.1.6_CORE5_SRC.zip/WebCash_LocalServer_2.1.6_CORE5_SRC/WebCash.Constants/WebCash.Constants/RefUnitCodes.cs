namespace WebCash.Constants
{
	public static class RefUnitCodes
	{
		public static readonly int DefaultUnitCode = 796;

		public static readonly int DefaultPriority = 1;
	}
}
