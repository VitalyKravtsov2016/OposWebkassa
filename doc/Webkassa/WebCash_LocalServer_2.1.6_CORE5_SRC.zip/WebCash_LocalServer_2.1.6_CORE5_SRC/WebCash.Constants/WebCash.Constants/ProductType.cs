namespace WebCash.Constants
{
	public static class ProductType
	{
		public const string WebType = "WEB";
	}
}
