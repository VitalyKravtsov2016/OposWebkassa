namespace WebCash.Constants
{
	public static class CustomHeaders
	{
		public const string UserAgentVersion = "User-Agent-Version";

		public const string XRequestId = "X-Request-Id";

		public const string XForwardedFor = "X-Forwarded-For";

		public const string XApiKey = "X-API-KEY";

		public const string InternalToken = "Internal-Token";

		public const string TokenType = "Token-Type";

		public const string AcceptLanguage = "Accept-Language";

		public const string XForwardedHost = "X-Forwarded-Host";

		public const string XForwardedProto = "X-Forwarded-Proto";
	}
}
