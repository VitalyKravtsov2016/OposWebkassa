using WebCash.Constants.Enums;

namespace WebCash.Constants
{
	public static class OfdStatuses
	{
		public static readonly MessageResultTypeEnum[] Offline = new MessageResultTypeEnum[4]
		{
			MessageResultTypeEnum.ServiceTemporarilyUnavailable,
			MessageResultTypeEnum.OfdServicesNotAvailable,
			MessageResultTypeEnum.OfdServicesNotAvailableForCashbox,
			MessageResultTypeEnum.InvalidToken
		};
	}
}
