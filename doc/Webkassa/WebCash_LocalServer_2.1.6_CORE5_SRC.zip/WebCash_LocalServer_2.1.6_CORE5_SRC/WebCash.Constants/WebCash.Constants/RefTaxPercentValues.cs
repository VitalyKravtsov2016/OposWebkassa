namespace WebCash.Constants
{
	public static class RefTaxPercentValues
	{
		public static readonly byte TaxEight = 8;
	}
}
