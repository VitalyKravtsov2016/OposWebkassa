using WebCash.Constants.Enums;

namespace WebCash.Constants
{
	public static class CashboxStatuses
	{
		public static readonly CashboxStatusEnum[] AvailableForProgramming = new CashboxStatusEnum[3]
		{
			CashboxStatusEnum.Created,
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Locked
		};

		public static readonly CashboxStatusEnum[] AvailableForInspector = new CashboxStatusEnum[6]
		{
			CashboxStatusEnum.Created,
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Locked,
			CashboxStatusEnum.RMNILocked,
			CashboxStatusEnum.Invalid,
			CashboxStatusEnum.Deregistered
		};

		public static readonly CashboxStatusEnum[] AvailableForWork = new CashboxStatusEnum[3]
		{
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Locked,
			CashboxStatusEnum.RMNILocked
		};

		public static readonly CashboxStatusEnum[] AvailableForWorkInMobile = new CashboxStatusEnum[3]
		{
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Locked,
			CashboxStatusEnum.RMNILocked
		};

		public static readonly CashboxStatusEnum[] Invalid = new CashboxStatusEnum[4]
		{
			CashboxStatusEnum.Deregistered,
			CashboxStatusEnum.RMNILocked,
			CashboxStatusEnum.Invalid,
			CashboxStatusEnum.Locked
		};

		public static readonly CashboxStatusEnum[] ForCTOGrid = new CashboxStatusEnum[6]
		{
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Created,
			CashboxStatusEnum.Deregistered,
			CashboxStatusEnum.NonFiscalMode,
			CashboxStatusEnum.RMNILocked,
			CashboxStatusEnum.Locked
		};

		public static readonly CashboxStatusEnum[] ForShiftCashboxSelector = new CashboxStatusEnum[6]
		{
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Locked,
			CashboxStatusEnum.Invalid,
			CashboxStatusEnum.RMNILocked,
			CashboxStatusEnum.Deregistered,
			CashboxStatusEnum.NonFiscalMode
		};

		public static readonly CashboxStatusEnum[] UnavailableForChangeMarkingMode = new CashboxStatusEnum[2]
		{
			CashboxStatusEnum.Created,
			CashboxStatusEnum.Deregistered
		};

		public static readonly CashboxStatusEnum[] AvailableForProtocolChange = new CashboxStatusEnum[2]
		{
			CashboxStatusEnum.Active,
			CashboxStatusEnum.Created
		};
	}
}
