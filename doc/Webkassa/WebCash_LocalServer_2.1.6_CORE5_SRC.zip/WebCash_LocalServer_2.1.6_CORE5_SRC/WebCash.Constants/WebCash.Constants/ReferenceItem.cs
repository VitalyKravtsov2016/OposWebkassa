using System.Runtime.CompilerServices;

namespace WebCash.Constants
{
	public struct ReferenceItem<T>
	{
		[CompilerGenerated]
		private T _E000;

		[CompilerGenerated]
		private string _E001;

		public T Id
		{
			[CompilerGenerated]
			get
			{
				return _E000;
			}
			[CompilerGenerated]
			set
			{
				_E000 = value;
			}
		}

		public string Text
		{
			[CompilerGenerated]
			get
			{
				return _E001;
			}
			[CompilerGenerated]
			set
			{
				_E001 = value;
			}
		}
	}
}
