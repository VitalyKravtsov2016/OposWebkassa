namespace WebCash.Constants
{
	public class Limits
	{
		public const long MaxPrice = 999999999L;

		public const long MaxDiscount = 999999999L;

		public const long MaxMarkup = 999999999L;

		public const long MaxSum = 999999999L;

		public static readonly int MaxPriceDigitsCount = 999999999L.ToString().Length;

		public static int MaxDiscountDigitsCount = 999999999L.ToString().Length;

		public static int MaxMarkupDigitsCount = 999999999L.ToString().Length;
	}
}
