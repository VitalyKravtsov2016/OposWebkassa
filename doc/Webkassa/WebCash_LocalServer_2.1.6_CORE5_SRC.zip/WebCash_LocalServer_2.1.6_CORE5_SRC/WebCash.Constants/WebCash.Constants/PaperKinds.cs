using WebCash.Constants.Enums;

namespace WebCash.Constants
{
	public static class PaperKinds
	{
		public static readonly PaperKind[] ShtrikhPaper = new PaperKind[4]
		{
			PaperKind.CashTape57ShtrikhLite,
			PaperKind.CashTape80ShtrikhM,
			PaperKind.CashTape57Shtrikh,
			PaperKind.Other
		};

		public static readonly PaperKind[] PrinterPaper = new PaperKind[6]
		{
			PaperKind.CashTape80Rongta,
			PaperKind.CashTape57Rongta,
			PaperKind.CashTape80Sam4s,
			PaperKind.CashTape80XTerm,
			PaperKind.CashTape80Posiflex,
			PaperKind.Other
		};

		public static readonly PaperKind[] PrimPaper = new PaperKind[2]
		{
			PaperKind.CashTape80Prim,
			PaperKind.Other
		};

		public static readonly PaperKind[] AuraPaper = new PaperKind[2]
		{
			PaperKind.CashTape80Aura,
			PaperKind.Other
		};
	}
}
