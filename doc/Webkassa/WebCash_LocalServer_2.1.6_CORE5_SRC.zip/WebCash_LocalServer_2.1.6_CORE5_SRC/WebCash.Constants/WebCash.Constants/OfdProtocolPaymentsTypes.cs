using System.Collections.Generic;
using WebCash.Constants.Enums;

namespace WebCash.Constants
{
	public static class OfdProtocolPaymentsTypes
	{
		public static readonly Dictionary<OfdProtocolVersion, PaymentTypeEnum[]> payments = new Dictionary<OfdProtocolVersion, PaymentTypeEnum[]>
		{
			{
				OfdProtocolVersion.Version123,
				new PaymentTypeEnum[4]
				{
					PaymentTypeEnum.PAYMENT_CASH,
					PaymentTypeEnum.PAYMENT_CARD,
					PaymentTypeEnum.PAYMENT_CREDIT,
					PaymentTypeEnum.PAYMENT_TARE
				}
			},
			{
				OfdProtocolVersion.Version124,
				new PaymentTypeEnum[4]
				{
					PaymentTypeEnum.PAYMENT_CASH,
					PaymentTypeEnum.PAYMENT_CARD,
					PaymentTypeEnum.PAYMENT_CREDIT,
					PaymentTypeEnum.PAYMENT_TARE
				}
			},
			{
				OfdProtocolVersion.Version202,
				new PaymentTypeEnum[3]
				{
					PaymentTypeEnum.PAYMENT_CASH,
					PaymentTypeEnum.PAYMENT_CARD,
					PaymentTypeEnum.PAYMENT_MOBILE
				}
			}
		};
	}
}
