using System;

namespace WebCash.Constants
{
	public static class QueueNames
	{
		public const string AnalyticMoneyQueue = "analytic_wkmoney";

		public const string AnalyticTicketQueue = "analytic_wktickets";

		public const string AnalyticNewTicketItemsQueue = "analytic_wktcitems";

		public const string AnalyticTicketAuditQueue = "analytic_ticket_audit";

		public const string AnalyticTicketItemsAuditQueue = "analytic_ticket_items_audit";

		public const string AnalyticMoneyAuditQueue = "analytic_money_audit";

		public const string ArchiveMoneyPlacementQueue = "archive_money";

		public const string ArchiveMoneyAuditQueue = "archive_money_audit";

		public const string ArchiveZReportQueue = "archive_zreport";

		public const string ArchiveZReportUpdateQueue = "archive_update_zreport";

		public const string ArchiveZReportCallbackQueue = "archive_callback_zreport";

		public const string ArchiveTicketQueue = "archive_tickets";

		public const string ArchiveTicketUpdateFiscalQueue = "archive_ticket_upd_fiscal";

		public const string ArchiveTicketLotteryInformationQueue = "archive_ticket_lottery";

		public const string ArchiveTicketCardPaymentQueue = "archive_ticket_card_payment";

		public const string ArchiveTicketAuditQueue = "archive_ticket_audit";

		public const string EmailZReportQueue = "email_zreport_queue";

		public const string ZReportEmailSenderQueue = "z_report_email_queue";

		public const string SulpakTicketSenderQueue = "sulpak_ticket_queue";

		public const string EmailSenderQueue = "emails";

		public const string IbdTicketsQueue = "ibd_tickets";

		public const string IbdZReportsQueue = "ibd_zreports";

		[Obsolete("Удалить после полного перезда на portal-api")]
		public const string AutoCloseShiftQueueOld = "auto_close_shift";

		public const string AutoCloseShiftQueue = "auto_close_shift_rpc";

		public const string CloseShiftQueue = "close_shift_rpc";

		[Obsolete("Удалить после полного перезда на portal-api")]
		public const string BillingActivateAvailableQueue = "billing_activate_available";

		public const string ClearEmployeeCacheQueue = "clear_employee_cache";

		public const string ClearCashboxCacheQueue = "clear_cashbox_cache";

		public const string CashboxActivateOfdQueue = "cashbox_activate_ofd_rpc";

		public const string CashboxPingOfdQueue = "cashbox_ping_ofd_rpc";

		public const string CashboxChangeOfdTokenQueue = "cashbox_change_ofd_token_rpc";

		public const string BillingCreatedTicketsQueue = "billing_created_tickets";

		public const string BillingApiKeyRequestQueue = "billing_apikey_request";

		public const string EmailsTicketCustomerQueue = "emails_tickets_customer";

		public const string EmailsZReportCustomerQueue = "emails_zreport_customer";

		public const string SulpakTicketCreatedQueue = "sulpak_ticket_created";

		public const string AnalyticTicketCreatedQueue = "analytic_ticket_created";

		public const string AnalyticMoneyOperationCreatedQueue = "analytic_money_operation_created";

		public const string PosPaymentCreatedQueue = "pos_payment_created";

		public const string ChangeCashboxProtocolQueue = "change_cashbox_protocol";

		public const string CreateCashboxStateQueue = "create_cashbox_state";

		public const string CreateOrderTicketQueue = "create_order_ticket";

		public const string CreateTicketExternalLinkQueue = "create_ticket_link_id";

		public const string CreateTradeTicketQueue = "create_trade_ticket";

		public const string WebScanCreateLicenseQueue = "webscan_create_license_rpc";

		public const string WebScanGetLicenseQueue = "webscan_get_license_rpc";

		[Obsolete("replaced by billing-create-license-batch")]
		public const string BillingCreateLicenseQueue = "billing-create-license";

		public const string BillingCreateLicenseBatchQueue = "billing-create-license-batch";

		public const string BillingMigrateLicenseQueue = "billing-migrate-license";

		public const string UpdateModuleVersionQueue = "update_module_version";

		public const string BillingRevokeLicenseQueue = "billing-revoke-license";

		public const string BillingCancelLicenseQueue = "billing-cancel-license";

		public const string AdvertisingCashboxSenderQueue = "advertising_cashbox_change";

		public const string AdvertisingTicketConfirmQueue = "advertising_ticket_confirm";
	}
}
