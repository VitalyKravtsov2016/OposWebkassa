namespace WebCash.Constants
{
	public static class Cookies
	{
		public const string WhoWasHereKey = "WhoWasHere";
	}
}
