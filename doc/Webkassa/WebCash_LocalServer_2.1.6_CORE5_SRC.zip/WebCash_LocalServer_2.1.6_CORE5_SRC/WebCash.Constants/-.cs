using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class _E000
{
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 12)]
	private struct _E000
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	private struct _E001
	{
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 24)]
	private struct _E002
	{
	}

	internal static readonly int _E000/* Not supported: data(00 01 02 03) */;

	internal static readonly _E001 _E001/* Not supported: data(04 00 00 00 05 00 00 00 03 00 00 00 0E 00 00 00) */;

	internal static readonly _E002 _E002/* Not supported: data(00 00 00 00 01 00 00 00 02 00 00 00 04 00 00 00 03 00 00 00 05 00 00 00) */;

	internal static readonly _E001 _E003/* Not supported: data(FE 00 00 00 11 27 00 00 10 27 00 00 02 00 00 00) */;

	internal static readonly _E002 _E004/* Not supported: data(0B 00 00 00 01 00 00 00 09 00 00 00 0A 00 00 00 07 00 00 00 0E 00 00 00) */;

	internal static readonly _E002 _E005/* Not supported: data(01 00 00 00 02 00 00 00 03 00 00 00 04 00 00 00 05 00 00 00 06 00 00 00) */;

	internal static readonly _E002 _E006/* Not supported: data(01 00 00 00 00 00 00 00 05 00 00 00 06 00 00 00 04 00 00 00 02 00 00 00) */;

	internal static readonly _E000 _E007/* Not supported: data(01 00 00 00 02 00 00 00 04 00 00 00) */;

	internal static readonly _E001 _E008/* Not supported: data(05 00 00 00 04 00 00 00 03 00 00 00 02 00 00 00) */;
}
internal sealed class _E002
{
	private delegate string _E000();

	private sealed class _E001
	{
		private static readonly _E000 m__E001;

		public static readonly _E001 _E004;

		private byte[] _E005;

		static _E001()
		{
			m__E001 = _E002._E001;
			_E004 = new _E001();
		}

		private _E001()
		{
			Stream manifestResourceStream = typeof(_E001).GetTypeInfo().Assembly.GetManifestResourceStream(m__E001());
			if (((manifestResourceStream == null) ? ((0x686A8C9 ^ 0xB0E456C) + -227077540) : (-503750458 ^ -503750458)) == 0)
			{
				_E005 = new byte[538340530 + -538340514];
				manifestResourceStream.Read(_E005, ((~(-(-(742731508 + -273419460) + 185819035)) ^ -40005301) + 56008703 - 109664255) ^ 0xF54F421, _E005.Length);
			}
		}

		public string _E000(string _E006, int _E007)
		{
			int num = _E006.Length;
			char[] array = _E006.ToCharArray();
			while (--num >= -(~541808457 - -541808458 >> 4))
			{
				array[num] = (char)(array[num] ^ (_E005[_E007 & 0xF] | _E007));
			}
			return new string(array);
		}
	}

	public static string _E000(string _E002, int _E003)
	{
		return global::_E002._E001._E004._E000(_E002, _E003);
	}

	public static string _E001()
	{
		char[] array = "ÌîûÝ".ToCharArray();
		int num = array.Length;
		while ((num -= ~(-(-10700417 ^ -140048080) - -150712391 >> 2)) >= -(~(-789424472 - -691115976 + 98308495)) << 7)
		{
			array[num] = (char)(array[num] ^ -(72683638 + -72683786));
		}
		return new string(array);
	}
}
