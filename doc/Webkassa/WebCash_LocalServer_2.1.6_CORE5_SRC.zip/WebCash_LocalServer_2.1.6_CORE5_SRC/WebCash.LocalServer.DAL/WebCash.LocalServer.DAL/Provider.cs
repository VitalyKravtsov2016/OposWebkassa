namespace WebCash.LocalServer.DAL
{
	public static class Provider
	{
		private static string _password;

		private static string _contentRoot;

		public static MainDbContext GetContext()
		{
			MainDbContext mainDbContext = new MainDbContext();
			mainDbContext.Setup(_password, _contentRoot);
			return mainDbContext;
		}

		public static void Setup(string password, string contentRoot)
		{
			_password = password;
			_contentRoot = contentRoot;
		}
	}
}
