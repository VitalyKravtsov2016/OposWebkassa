using System;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Serilog;
using WebCash.Constants.Enums;
using WebCash.LocalServer.DAL.Entities;

namespace WebCash.LocalServer.DAL
{
	public class MainDbContext : DbContext
	{
		private string _password;

		private string _contentRoot;

		private readonly string _dbFileName = "fiscal.db";

		public DbSet<Cashbox> Cashboxes { get; set; }

		public DbSet<OfflineRequest> OfflineRequests { get; set; }

		public DbSet<User> Users { get; set; }

		public DbSet<OperationSummary> OperationSummaries { get; set; }

		public DbSet<PaymentSummary> PaymentSummaries { get; set; }

		public DbSet<CashboxState> CashboxStates { get; set; }

		public DbSet<OperationData> LastOperations { get; set; }

		public MainDbContext()
		{
		}

		public MainDbContext(DbContextOptions options)
			: base(options)
		{
		}

		internal void Setup(string password, string contentRoot)
		{
			_password = password;
			_contentRoot = contentRoot;
		}

		protected override void OnConfiguring(DbContextOptionsBuilder builder)
		{
			SqliteConnection connection = new SqliteConnection(new SqliteConnectionStringBuilder
			{
				DataSource = Path.Combine(_contentRoot, _dbFileName)
			}.ConnectionString);
			Log.Debug("Opening v3 connection...");
			connection.Open();
			Log.Debug("v3 connection opened");
			using (SqliteCommand migrateCommand = connection.CreateCommand())
			{
				migrateCommand.CommandText = "PRAGMA key='" + _password + "';PRAGMA cipher_page_size = 1024;PRAGMA kdf_iter = 64000;PRAGMA cipher_hmac_algorithm = HMAC_SHA1;PRAGMA cipher_kdf_algorithm = PBKDF2_HMAC_SHA1;";
				migrateCommand.ExecuteNonQuery();
			}
			Log.Debug("v3 opened with key");
			Log.Debug("Setup connection...");
			using (SqliteCommand setupCommand = connection.CreateCommand())
			{
				setupCommand.CommandText = "PRAGMA TEMP_STORE='MEMORY';PRAGMA JOURNAL_MODE='MEMORY';";
				setupCommand.ExecuteNonQuery();
			}
			Log.Debug("Setup connection completed");
			builder.UseSqlite(connection);
		}

		protected override void OnModelCreating(ModelBuilder builder)
		{
			base.OnModelCreating(builder);
			MapEntity(builder.Entity<Cashbox>());
			MapEntity(builder.Entity<CashboxState>());
			MapEntity(builder.Entity<User>());
			MapEntity(builder.Entity<OfflineRequest>());
			MapEntity(builder.Entity<UserToCashbox>());
		}

		private void MapEntity(EntityTypeBuilder<UserToCashbox> userToCashbox)
		{
			userToCashbox.HasKey((UserToCashbox x) => new { x.UserId, x.CashboxId });
			userToCashbox.HasOne((UserToCashbox x) => x.Cashbox).WithMany((Cashbox x) => x.Users).HasForeignKey((UserToCashbox x) => x.CashboxId);
			userToCashbox.HasOne((UserToCashbox x) => x.User).WithMany((User x) => x.Cashboxes).HasForeignKey((UserToCashbox x) => x.UserId);
		}

		private void MapEntity(EntityTypeBuilder<OfflineRequest> offlineRequest)
		{
			offlineRequest.HasIndex("CashboxId", "ExternalId", "Type");
		}

		private void MapEntity(EntityTypeBuilder<CashboxState> state)
		{
			state.HasOne((CashboxState x) => x.Cashbox).WithMany().IsRequired();
		}

		private void MapEntity(EntityTypeBuilder<User> user)
		{
			user.HasIndex((User x) => new { x.UserName }).IsUnique();
			user.HasIndex((User x) => new { x.CurrentToken, x.RealToken });
		}

		private void MapEntity(EntityTypeBuilder<Cashbox> cashbox)
		{
			string divider = "|";
			ValueConverter<byte[], string> converter = new ValueConverter<byte[], string>((byte[] v) => string.Join(divider, v), (string v) => v.Split(new string[1] { divider }, StringSplitOptions.RemoveEmptyEntries).Select(byte.Parse).ToArray());
			cashbox.HasIndex((Cashbox x) => x.UniqueNumber).IsUnique();
			cashbox.Property((Cashbox x) => x.OfdCode).HasDefaultValue(OfdEnum.KazakhTelecom);
			cashbox.Property((Cashbox x) => x.AllowedTaxValues).HasConversion(converter);
		}
	}
}
