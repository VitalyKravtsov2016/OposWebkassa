using System;
using System.Collections.Generic;

namespace WebCash.LocalServer.DAL.Entities
{
	public class CashboxState
	{
		public long Id { get; set; }

		public int DocumentsCount { get; set; }

		public long ShiftNumber { get; set; }

		public DateTime? ShiftOpened { get; set; }

		public DateTime? ShiftClosedOn { get; set; }

		public double CashDeposits { get; set; }

		public double CashWithdrawals { get; set; }

		public ISet<OperationSummary> OperationsSummary { get; protected set; }

		public DateTime? OfflineModeStart { get; set; }

		public Cashbox Cashbox { get; set; }

		public double SumInCashbox { get; set; }

		public double NNStartSell { get; set; }

		public double NNStartBuy { get; set; }

		public double NNStartReturnSell { get; set; }

		public double NNStartReturnBuy { get; set; }

		public CashboxState()
		{
			OperationsSummary = new HashSet<OperationSummary>();
		}
	}
}
