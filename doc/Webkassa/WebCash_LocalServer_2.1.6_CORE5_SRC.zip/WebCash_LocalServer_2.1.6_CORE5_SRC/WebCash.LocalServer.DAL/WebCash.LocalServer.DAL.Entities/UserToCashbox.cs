namespace WebCash.LocalServer.DAL.Entities
{
	public class UserToCashbox
	{
		public long CashboxId { get; set; }

		public Cashbox Cashbox { get; set; }

		public long UserId { get; set; }

		public User User { get; set; }
	}
}
