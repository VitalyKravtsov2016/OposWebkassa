using System;

namespace WebCash.LocalServer.DAL.Entities
{
	public class OfflineRequest
	{
		public long Id { get; set; }

		public RequestType Type { get; set; }

		public string Content { get; set; }

		public string ExternalId { get; set; }

		public DateTime Created { get; set; }

		public Cashbox Cashbox { get; set; }

		public OfflineRequest()
		{
			Created = DateTime.Now;
		}
	}
}
