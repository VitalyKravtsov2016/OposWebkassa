using WebCash.Constants.Enums;

namespace WebCash.LocalServer.DAL.Entities
{
	public class PaymentSummary
	{
		public long Id { get; set; }

		public PaymentTypeEnum Type { get; set; }

		public double Sum { get; set; }

		public OperationSummary OperationSummary { get; set; }
	}
}
