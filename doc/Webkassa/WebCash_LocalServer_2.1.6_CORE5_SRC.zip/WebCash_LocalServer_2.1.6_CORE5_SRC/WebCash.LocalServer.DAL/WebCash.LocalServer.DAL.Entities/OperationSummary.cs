using System.Collections.Generic;
using WebCash.Constants.Enums;

namespace WebCash.LocalServer.DAL.Entities
{
	public class OperationSummary
	{
		public long Id { get; set; }

		public OperationTypeEnum Type { get; set; }

		public int Count { get; set; }

		public double Taken { get; set; }

		public double Change { get; set; }

		public double Sum { get; set; }

		public ICollection<PaymentSummary> PaymentsSummary { get; protected set; }

		public double Tax { get; set; }

		public CashboxState State { get; set; }

		public double Discounts { get; set; }

		public double Markups { get; set; }

		public OperationSummary()
		{
			PaymentsSummary = new HashSet<PaymentSummary>();
		}
	}
}
