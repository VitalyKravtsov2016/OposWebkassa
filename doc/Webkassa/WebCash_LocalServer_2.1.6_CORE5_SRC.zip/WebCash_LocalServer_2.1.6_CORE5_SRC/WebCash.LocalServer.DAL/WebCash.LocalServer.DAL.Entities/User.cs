using System.Collections.Generic;

namespace WebCash.LocalServer.DAL.Entities
{
	public class User
	{
		public long Id { get; set; }

		public string UserName { get; set; }

		public string RealToken { get; set; }

		public string CurrentToken { get; set; }

		public string Password { get; set; }

		public string FullName { get; set; }

		public int Code { get; set; }

		public ICollection<UserToCashbox> Cashboxes { get; set; }

		public User()
		{
			Cashboxes = new HashSet<UserToCashbox>();
		}
	}
}
