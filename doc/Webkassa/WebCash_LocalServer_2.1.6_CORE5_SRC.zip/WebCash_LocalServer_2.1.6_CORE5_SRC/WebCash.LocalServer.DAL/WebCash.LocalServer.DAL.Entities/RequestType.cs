namespace WebCash.LocalServer.DAL.Entities
{
	public enum RequestType
	{
		Check,
		MoneyOperation,
		XZReport
	}
}
