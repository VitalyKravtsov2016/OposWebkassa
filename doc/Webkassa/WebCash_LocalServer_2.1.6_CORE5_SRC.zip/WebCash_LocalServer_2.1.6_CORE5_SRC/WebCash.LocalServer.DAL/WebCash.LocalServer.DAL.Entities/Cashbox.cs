using System.Collections.Generic;
using WebCash.Constants.Enums;

namespace WebCash.LocalServer.DAL.Entities
{
	public class Cashbox
	{
		public long Id { get; set; }

		public string UniqueNumber { get; set; }

		public virtual long IdentityNumber { get; set; }

		public virtual string RegistrationNumber { get; set; }

		public string Name { get; set; }

		public RoundTypeEnum RoundType { get; set; }

		public bool AutoWithdrawal { get; set; }

		public string OrganizationXin { get; set; }

		public string OrganizationFullName { get; set; }

		public string OrganizationVatSeria { get; set; }

		public string OrganizationVatNumber { get; set; }

		public bool OrganizationIsVatPayer { get; set; }

		public string Address { get; set; }

		public string OfdName { get; set; }

		public string OfdHost { get; set; }

		public ICollection<UserToCashbox> Users { get; set; }

		public OfdEnum OfdCode { get; set; }

		public byte[] AllowedTaxValues { get; set; }

		public OfflineSupportMode OfflineSupportMode { get; set; }

		public OfdProtocolVersion OfdProtocolVersion { get; set; }

		public Cashbox()
		{
			Users = new HashSet<UserToCashbox>();
			AllowedTaxValues = new byte[0];
		}
	}
}
