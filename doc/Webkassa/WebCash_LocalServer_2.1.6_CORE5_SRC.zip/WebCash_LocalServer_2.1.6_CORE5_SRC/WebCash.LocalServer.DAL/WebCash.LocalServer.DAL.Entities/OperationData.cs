using System;

namespace WebCash.LocalServer.DAL.Entities
{
	public class OperationData
	{
		public long Id { get; set; }

		public RequestType Type { get; set; }

		public string Request { get; set; }

		public string Response { get; set; }

		public string ExternalId { get; set; }

		public DateTime Date { get; set; }

		public Cashbox Cashbox { get; set; }

		public OperationData()
		{
			Date = DateTime.Now;
		}
	}
}
