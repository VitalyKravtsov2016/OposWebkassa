using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebCash.LocalServer.DAL.Migrations
{
	[DbContext(typeof(MainDbContext))]
	[Migration("20190405085152_AddCashboxAddress")]
	public class AddCashboxAddress : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.AddColumn<string>("Address", "Cashboxes", null, null, null, rowVersion: false, null, nullable: true);
		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.DropColumn("Address", "Cashboxes");
		}

		protected override void BuildTargetModel(ModelBuilder modelBuilder)
		{
			modelBuilder.HasAnnotation("ProductVersion", "2.1.1-rtm-30846");
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.Cashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<string>("Address");
				b.Property<bool>("AutoWithdrawal");
				b.Property<long>("IdentityNumber");
				b.Property<string>("Name");
				b.Property<string>("OrganizationFullName");
				b.Property<bool>("OrganizationIsVatPayer");
				b.Property<string>("OrganizationVatNumber");
				b.Property<string>("OrganizationVatSeria");
				b.Property<string>("OrganizationXin");
				b.Property<string>("RegistrationNumber");
				b.Property<int>("RoundType");
				b.Property<string>("UniqueNumber");
				b.HasKey("Id");
				b.HasIndex("UniqueNumber").IsUnique();
				b.ToTable("Cashboxes");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<double>("CashDeposits");
				b.Property<double>("CashWithdrawals");
				b.Property<long?>("CashboxId").IsRequired();
				b.Property<int>("DocumentsCount");
				b.Property<double>("NNStartBuy");
				b.Property<double>("NNStartReturnBuy");
				b.Property<double>("NNStartReturnSell");
				b.Property<double>("NNStartSell");
				b.Property<DateTime?>("OfflineModeStart");
				b.Property<DateTime?>("ShiftClosedOn");
				b.Property<long>("ShiftNumber");
				b.Property<DateTime?>("ShiftOpened");
				b.Property<double>("SumInCashbox");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("CashboxStates");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("CashboxId");
				b.Property<string>("Content");
				b.Property<DateTime>("Created");
				b.Property<string>("ExternalId");
				b.Property<int>("Type");
				b.HasKey("Id");
				b.HasIndex("CashboxId", "ExternalId", "Type");
				b.ToTable("OfflineRequests");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("CashboxId");
				b.Property<DateTime>("Date");
				b.Property<string>("ExternalId");
				b.Property<string>("Request");
				b.Property<string>("Response");
				b.Property<int>("Type");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("LastOperations");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<double>("Change");
				b.Property<int>("Count");
				b.Property<double>("Discounts");
				b.Property<double>("Markups");
				b.Property<long?>("StateId");
				b.Property<double>("Sum");
				b.Property<double>("Taken");
				b.Property<double>("Tax");
				b.Property<byte>("Type");
				b.HasKey("Id");
				b.HasIndex("StateId");
				b.ToTable("OperationSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("OperationSummaryId");
				b.Property<double>("Sum");
				b.Property<byte>("Type");
				b.HasKey("Id");
				b.HasIndex("OperationSummaryId");
				b.ToTable("PaymentSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.User", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<int>("Code");
				b.Property<string>("CurrentToken");
				b.Property<string>("FullName");
				b.Property<string>("Password");
				b.Property<string>("RealToken");
				b.Property<string>("UserName");
				b.HasKey("Id");
				b.HasIndex("UserName").IsUnique();
				b.ToTable("Users");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("UserId");
				b.Property<long>("CashboxId");
				b.HasKey("UserId", "CashboxId");
				b.HasIndex("CashboxId");
				b.ToTable("UserToCashbox");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade);
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.CashboxState", "State").WithMany("OperationsSummary").HasForeignKey("StateId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.OperationSummary", "OperationSummary").WithMany("PaymentsSummary").HasForeignKey("OperationSummaryId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany("Users").HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade);
				b.HasOne("WebCash.LocalServer.DAL.Entities.User", "User").WithMany("Cashboxes").HasForeignKey("UserId")
					.OnDelete(DeleteBehavior.Cascade);
			});
		}
	}
}
