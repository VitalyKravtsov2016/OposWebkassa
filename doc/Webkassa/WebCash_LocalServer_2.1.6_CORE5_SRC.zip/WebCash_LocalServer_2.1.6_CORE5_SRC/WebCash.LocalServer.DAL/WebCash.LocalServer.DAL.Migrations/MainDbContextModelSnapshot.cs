using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace WebCash.LocalServer.DAL.Migrations
{
	[DbContext(typeof(MainDbContext))]
	internal class MainDbContextModelSnapshot : ModelSnapshot
	{
		protected override void BuildModel(ModelBuilder modelBuilder)
		{
			modelBuilder.HasAnnotation("ProductVersion", "3.1.0");
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.Cashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<string>("Address").HasColumnType("TEXT");
				b.Property<string>("AllowedTaxValues").HasColumnType("TEXT");
				b.Property<bool>("AutoWithdrawal").HasColumnType("INTEGER");
				b.Property<long>("IdentityNumber").HasColumnType("INTEGER");
				b.Property<string>("Name").HasColumnType("TEXT");
				b.Property<int>("OfdCode").ValueGeneratedOnAdd().HasColumnType("INTEGER")
					.HasDefaultValue(1);
				b.Property<string>("OfdHost").HasColumnType("TEXT");
				b.Property<string>("OfdName").HasColumnType("TEXT");
				b.Property<int>("OfdProtocolVersion").HasColumnType("INTEGER");
				b.Property<byte>("OfflineSupportMode").HasColumnType("INTEGER");
				b.Property<string>("OrganizationFullName").HasColumnType("TEXT");
				b.Property<bool>("OrganizationIsVatPayer").HasColumnType("INTEGER");
				b.Property<string>("OrganizationVatNumber").HasColumnType("TEXT");
				b.Property<string>("OrganizationVatSeria").HasColumnType("TEXT");
				b.Property<string>("OrganizationXin").HasColumnType("TEXT");
				b.Property<string>("RegistrationNumber").HasColumnType("TEXT");
				b.Property<int>("RoundType").HasColumnType("INTEGER");
				b.Property<string>("UniqueNumber").HasColumnType("TEXT");
				b.HasKey("Id");
				b.HasIndex("UniqueNumber").IsUnique();
				b.ToTable("Cashboxes");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<double>("CashDeposits").HasColumnType("REAL");
				b.Property<double>("CashWithdrawals").HasColumnType("REAL");
				b.Property<long>("CashboxId").HasColumnType("INTEGER");
				b.Property<int>("DocumentsCount").HasColumnType("INTEGER");
				b.Property<double>("NNStartBuy").HasColumnType("REAL");
				b.Property<double>("NNStartReturnBuy").HasColumnType("REAL");
				b.Property<double>("NNStartReturnSell").HasColumnType("REAL");
				b.Property<double>("NNStartSell").HasColumnType("REAL");
				b.Property<DateTime?>("OfflineModeStart").HasColumnType("TEXT");
				b.Property<DateTime?>("ShiftClosedOn").HasColumnType("TEXT");
				b.Property<long>("ShiftNumber").HasColumnType("INTEGER");
				b.Property<DateTime?>("ShiftOpened").HasColumnType("TEXT");
				b.Property<double>("SumInCashbox").HasColumnType("REAL");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("CashboxStates");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<long?>("CashboxId").HasColumnType("INTEGER");
				b.Property<string>("Content").HasColumnType("TEXT");
				b.Property<DateTime>("Created").HasColumnType("TEXT");
				b.Property<string>("ExternalId").HasColumnType("TEXT");
				b.Property<int>("Type").HasColumnType("INTEGER");
				b.HasKey("Id");
				b.HasIndex("CashboxId", "ExternalId", "Type");
				b.ToTable("OfflineRequests");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<long?>("CashboxId").HasColumnType("INTEGER");
				b.Property<DateTime>("Date").HasColumnType("TEXT");
				b.Property<string>("ExternalId").HasColumnType("TEXT");
				b.Property<string>("Request").HasColumnType("TEXT");
				b.Property<string>("Response").HasColumnType("TEXT");
				b.Property<int>("Type").HasColumnType("INTEGER");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("LastOperations");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<double>("Change").HasColumnType("REAL");
				b.Property<int>("Count").HasColumnType("INTEGER");
				b.Property<double>("Discounts").HasColumnType("REAL");
				b.Property<double>("Markups").HasColumnType("REAL");
				b.Property<long?>("StateId").HasColumnType("INTEGER");
				b.Property<double>("Sum").HasColumnType("REAL");
				b.Property<double>("Taken").HasColumnType("REAL");
				b.Property<double>("Tax").HasColumnType("REAL");
				b.Property<byte>("Type").HasColumnType("INTEGER");
				b.HasKey("Id");
				b.HasIndex("StateId");
				b.ToTable("OperationSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<long?>("OperationSummaryId").HasColumnType("INTEGER");
				b.Property<double>("Sum").HasColumnType("REAL");
				b.Property<byte>("Type").HasColumnType("INTEGER");
				b.HasKey("Id");
				b.HasIndex("OperationSummaryId");
				b.ToTable("PaymentSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.User", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd().HasColumnType("INTEGER");
				b.Property<int>("Code").HasColumnType("INTEGER");
				b.Property<string>("CurrentToken").HasColumnType("TEXT");
				b.Property<string>("FullName").HasColumnType("TEXT");
				b.Property<string>("Password").HasColumnType("TEXT");
				b.Property<string>("RealToken").HasColumnType("TEXT");
				b.Property<string>("UserName").HasColumnType("TEXT");
				b.HasKey("Id");
				b.HasIndex("UserName").IsUnique();
				b.HasIndex("CurrentToken", "RealToken");
				b.ToTable("Users");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("UserId").HasColumnType("INTEGER");
				b.Property<long>("CashboxId").HasColumnType("INTEGER");
				b.HasKey("UserId", "CashboxId");
				b.HasIndex("CashboxId");
				b.ToTable("UserToCashbox");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade)
					.IsRequired();
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.CashboxState", "State").WithMany("OperationsSummary").HasForeignKey("StateId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.OperationSummary", "OperationSummary").WithMany("PaymentsSummary").HasForeignKey("OperationSummaryId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany("Users").HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade)
					.IsRequired();
				b.HasOne("WebCash.LocalServer.DAL.Entities.User", "User").WithMany("Cashboxes").HasForeignKey("UserId")
					.OnDelete(DeleteBehavior.Cascade)
					.IsRequired();
			});
		}
	}
}
