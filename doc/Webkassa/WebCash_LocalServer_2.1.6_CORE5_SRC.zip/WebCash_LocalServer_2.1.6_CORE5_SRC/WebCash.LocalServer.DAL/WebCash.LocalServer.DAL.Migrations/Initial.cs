using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Migrations.Operations.Builders;

namespace WebCash.LocalServer.DAL.Migrations
{
	[DbContext(typeof(MainDbContext))]
	[Migration("20180216084943_Initial")]
	public class Initial : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.CreateTable("Cashboxes", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				AutoWithdrawal = table.Column<bool>(),
				IdentityNumber = table.Column<long>(),
				Name = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				OrganizationFullName = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				OrganizationIsVatPayer = table.Column<bool>(),
				OrganizationVatNumber = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				OrganizationVatSeria = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				OrganizationXin = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				RegistrationNumber = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				RoundType = table.Column<int>(),
				UniqueNumber = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true)
			}, null, table =>
			{
				table.PrimaryKey("PK_Cashboxes", x => x.Id);
			});
			migrationBuilder.CreateTable("Users", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				Code = table.Column<int>(),
				FullName = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Password = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Token = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				UserName = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true)
			}, null, table =>
			{
				table.PrimaryKey("PK_Users", x => x.Id);
			});
			migrationBuilder.CreateTable("CashboxStates", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				CashDeposits = table.Column<double>(),
				CashWithdrawals = table.Column<double>(),
				CashboxId = table.Column<long>(),
				DocumentsCount = table.Column<int>(),
				NNStartBuy = table.Column<double>(),
				NNStartReturnBuy = table.Column<double>(),
				NNStartReturnSell = table.Column<double>(),
				NNStartSell = table.Column<double>(),
				OfflineModeStart = table.Column<DateTime>(null, null, null, rowVersion: false, null, nullable: true),
				ShiftClosedOn = table.Column<DateTime>(null, null, null, rowVersion: false, null, nullable: true),
				ShiftNumber = table.Column<long>(),
				ShiftOpened = table.Column<DateTime>(null, null, null, rowVersion: false, null, nullable: true),
				SumInCashbox = table.Column<double>()
			}, null, table =>
			{
				table.PrimaryKey("PK_CashboxStates", x => x.Id);
				table.ForeignKey("FK_CashboxStates_Cashboxes_CashboxId", x => x.CashboxId, "Cashboxes", "Id", null, ReferentialAction.NoAction, ReferentialAction.Cascade);
			});
			migrationBuilder.CreateTable("LastOperations", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				CashboxId = table.Column<long>(null, null, null, rowVersion: false, null, nullable: true),
				Date = table.Column<DateTime>(),
				ExternalId = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Request = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Response = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Type = table.Column<int>()
			}, null, table =>
			{
				table.PrimaryKey("PK_LastOperations", x => x.Id);
				table.ForeignKey("FK_LastOperations_Cashboxes_CashboxId", x => x.CashboxId, "Cashboxes", "Id", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			});
			migrationBuilder.CreateTable("OfflineRequests", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				CashboxId = table.Column<long>(null, null, null, rowVersion: false, null, nullable: true),
				Content = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Created = table.Column<DateTime>(),
				ExternalId = table.Column<string>(null, null, null, rowVersion: false, null, nullable: true),
				Type = table.Column<int>()
			}, null, table =>
			{
				table.PrimaryKey("PK_OfflineRequests", x => x.Id);
				table.ForeignKey("FK_OfflineRequests_Cashboxes_CashboxId", x => x.CashboxId, "Cashboxes", "Id", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			});
			migrationBuilder.CreateTable("UserToCashbox", (ColumnsBuilder table) => new
			{
				UserId = table.Column<long>(),
				CashboxId = table.Column<long>()
			}, null, table =>
			{
				table.PrimaryKey("PK_UserToCashbox", x => new { x.UserId, x.CashboxId });
				table.ForeignKey("FK_UserToCashbox_Cashboxes_CashboxId", x => x.CashboxId, "Cashboxes", "Id", null, ReferentialAction.NoAction, ReferentialAction.Cascade);
				table.ForeignKey("FK_UserToCashbox_Users_UserId", x => x.UserId, "Users", "Id", null, ReferentialAction.NoAction, ReferentialAction.Cascade);
			});
			migrationBuilder.CreateTable("OperationSummaries", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				Change = table.Column<double>(),
				Count = table.Column<int>(),
				Discounts = table.Column<double>(),
				Markups = table.Column<double>(),
				StateId = table.Column<long>(null, null, null, rowVersion: false, null, nullable: true),
				Sum = table.Column<double>(),
				Taken = table.Column<double>(),
				Tax = table.Column<double>(),
				Type = table.Column<byte>()
			}, null, table =>
			{
				table.PrimaryKey("PK_OperationSummaries", x => x.Id);
				table.ForeignKey("FK_OperationSummaries_CashboxStates_StateId", x => x.StateId, "CashboxStates", "Id", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			});
			migrationBuilder.CreateTable("PaymentSummaries", (ColumnsBuilder table) => new
			{
				Id = table.Column<long>().Annotation("Sqlite:Autoincrement", true),
				OperationSummaryId = table.Column<long>(null, null, null, rowVersion: false, null, nullable: true),
				Sum = table.Column<double>(),
				Type = table.Column<byte>()
			}, null, table =>
			{
				table.PrimaryKey("PK_PaymentSummaries", x => x.Id);
				table.ForeignKey("FK_PaymentSummaries_OperationSummaries_OperationSummaryId", x => x.OperationSummaryId, "OperationSummaries", "Id", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			});
			migrationBuilder.CreateIndex("IX_Cashboxes_UniqueNumber", "Cashboxes", "UniqueNumber", null, unique: true);
			migrationBuilder.CreateIndex("IX_CashboxStates_CashboxId", "CashboxStates", "CashboxId");
			migrationBuilder.CreateIndex("IX_LastOperations_CashboxId", "LastOperations", "CashboxId");
			migrationBuilder.CreateIndex("IX_OfflineRequests_CashboxId_ExternalId_Type", "OfflineRequests", new string[3] { "CashboxId", "ExternalId", "Type" });
			migrationBuilder.CreateIndex("IX_OperationSummaries_StateId", "OperationSummaries", "StateId");
			migrationBuilder.CreateIndex("IX_PaymentSummaries_OperationSummaryId", "PaymentSummaries", "OperationSummaryId");
			migrationBuilder.CreateIndex("IX_Users_UserName", "Users", "UserName", null, unique: true);
			migrationBuilder.CreateIndex("IX_UserToCashbox_CashboxId", "UserToCashbox", "CashboxId");
		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.DropTable("LastOperations");
			migrationBuilder.DropTable("OfflineRequests");
			migrationBuilder.DropTable("PaymentSummaries");
			migrationBuilder.DropTable("UserToCashbox");
			migrationBuilder.DropTable("OperationSummaries");
			migrationBuilder.DropTable("Users");
			migrationBuilder.DropTable("CashboxStates");
			migrationBuilder.DropTable("Cashboxes");
		}

		protected override void BuildTargetModel(ModelBuilder modelBuilder)
		{
			modelBuilder.HasAnnotation("ProductVersion", "2.0.1-rtm-125");
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.Cashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<bool>("AutoWithdrawal");
				b.Property<long>("IdentityNumber");
				b.Property<string>("Name");
				b.Property<string>("OrganizationFullName");
				b.Property<bool>("OrganizationIsVatPayer");
				b.Property<string>("OrganizationVatNumber");
				b.Property<string>("OrganizationVatSeria");
				b.Property<string>("OrganizationXin");
				b.Property<string>("RegistrationNumber");
				b.Property<int>("RoundType");
				b.Property<string>("UniqueNumber");
				b.HasKey("Id");
				b.HasIndex("UniqueNumber").IsUnique();
				b.ToTable("Cashboxes");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<double>("CashDeposits");
				b.Property<double>("CashWithdrawals");
				b.Property<long?>("CashboxId").IsRequired();
				b.Property<int>("DocumentsCount");
				b.Property<double>("NNStartBuy");
				b.Property<double>("NNStartReturnBuy");
				b.Property<double>("NNStartReturnSell");
				b.Property<double>("NNStartSell");
				b.Property<DateTime?>("OfflineModeStart");
				b.Property<DateTime?>("ShiftClosedOn");
				b.Property<long>("ShiftNumber");
				b.Property<DateTime?>("ShiftOpened");
				b.Property<double>("SumInCashbox");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("CashboxStates");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("CashboxId");
				b.Property<string>("Content");
				b.Property<DateTime>("Created");
				b.Property<string>("ExternalId");
				b.Property<int>("Type");
				b.HasKey("Id");
				b.HasIndex("CashboxId", "ExternalId", "Type");
				b.ToTable("OfflineRequests");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("CashboxId");
				b.Property<DateTime>("Date");
				b.Property<string>("ExternalId");
				b.Property<string>("Request");
				b.Property<string>("Response");
				b.Property<int>("Type");
				b.HasKey("Id");
				b.HasIndex("CashboxId");
				b.ToTable("LastOperations");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<double>("Change");
				b.Property<int>("Count");
				b.Property<double>("Discounts");
				b.Property<double>("Markups");
				b.Property<long?>("StateId");
				b.Property<double>("Sum");
				b.Property<double>("Taken");
				b.Property<double>("Tax");
				b.Property<byte>("Type");
				b.HasKey("Id");
				b.HasIndex("StateId");
				b.ToTable("OperationSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<long?>("OperationSummaryId");
				b.Property<double>("Sum");
				b.Property<byte>("Type");
				b.HasKey("Id");
				b.HasIndex("OperationSummaryId");
				b.ToTable("PaymentSummaries");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.User", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("Id").ValueGeneratedOnAdd();
				b.Property<int>("Code");
				b.Property<string>("FullName");
				b.Property<string>("Password");
				b.Property<string>("Token");
				b.Property<string>("UserName");
				b.HasKey("Id");
				b.HasIndex("UserName").IsUnique();
				b.ToTable("Users");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.Property<long>("UserId");
				b.Property<long>("CashboxId");
				b.HasKey("UserId", "CashboxId");
				b.HasIndex("CashboxId");
				b.ToTable("UserToCashbox");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.CashboxState", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade);
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OfflineRequest", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationData", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany().HasForeignKey("CashboxId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.OperationSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.CashboxState", "State").WithMany("OperationsSummary").HasForeignKey("StateId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.PaymentSummary", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.OperationSummary", "OperationSummary").WithMany("PaymentsSummary").HasForeignKey("OperationSummaryId");
			});
			modelBuilder.Entity("WebCash.LocalServer.DAL.Entities.UserToCashbox", delegate(EntityTypeBuilder b)
			{
				b.HasOne("WebCash.LocalServer.DAL.Entities.Cashbox", "Cashbox").WithMany("Users").HasForeignKey("CashboxId")
					.OnDelete(DeleteBehavior.Cascade);
				b.HasOne("WebCash.LocalServer.DAL.Entities.User", "User").WithMany("Cashboxes").HasForeignKey("UserId")
					.OnDelete(DeleteBehavior.Cascade);
			});
		}
	}
}
