using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("WebCash.LocalServer.DAL")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("WebCash.LocalServer.DAL")]
[assembly: AssemblyTitle("WebCash.LocalServer.DAL")]
[assembly: AssemblyVersion("1.0.0.0")]
