// Method Error Code flag
#define	LK_SUCCESS 		0
#define	LK_CREATE_ERROR 	1
#define	LK_NOT_OPENED 		2
#define	LK_OPEN_FAIL		-1

// Printer Status flag
#define	LK_STS_NORMAL 			0
#define	LK_STS_COVEROPEN 		1
#define	LK_STS_PAPERNEAREMPTY 		2
#define	LK_STS_PAPEREMPTY 		4
#define	LK_STS_POWEROFF 		8


// Cash Drawer Status flag
#define	LK_CD_STS_CLOSED 		0
#define	LK_CD_STS_OPENED 		1

// Cash Drawer Kick-out Connector Pin
#define	LK_CD_PIN_TWO 		2
#define	LK_CD_PIN_FIVE 		5

// Alignment Code
#define	LK_ALIGNMENT_LEFT 		0
#define	LK_ALIGNMENT_CENTER	 	1
#define	LK_ALIGNMENT_RIGHT 		2

// Bitmap Size
#define	LK_BITMAP_NORMAL 		0
#define	LK_BITMAP_WIDTH_DOUBLE 		1
#define	LK_BITMAP_HEIGHT_DOUBLE 	2
#define	LK_BITMAP_WIDTH_HEIGHT_DOUBLE 	3

// Bitmap Image Mode
#define LK_BITMAP_NO_DITHER			0
#define LK_BITMAP_ERROR_DIFFUSION	1


//Text Attribute
// 8 7 6 5 4 3  2      1
//             BOLD   FONT AorB
//Font Attribute default value : not Bold, FontA, not Underline, not reverse
#define	LK_FNT_DEFAULT 		0
#define	LK_FNT_FONTB 		1
#define	LK_FNT_BOLD 		8
#define	LK_FNT_UNDERLINE 	128

// Text Size Attribute
#define	LK_TXT_1WIDTH 		0
#define	LK_TXT_2WIDTH 		16
#define	LK_TXT_3WIDTH 		32
#define	LK_TXT_4WIDTH 		48
#define	LK_TXT_5WIDTH 		64
#define	LK_TXT_6WIDTH 		80
#define	LK_TXT_7WIDTH 		96
#define	LK_TXT_8WIDTH	 	112

#define	LK_TXT_1HEIGHT 		0
#define	LK_TXT_2HEIGHT 		1
#define	LK_TXT_3HEIGHT 		2
#define	LK_TXT_4HEIGHT 		3
#define	LK_TXT_5HEIGHT 		4
#define	LK_TXT_6HEIGHT 		5
#define	LK_TXT_7HEIGHT 		6
#define	LK_TXT_8HEIGHT	 	7

// Barcode
#define	LK_BCS_PDF417 		200
#define	LK_BCS_MAXICODE 	201
#define	LK_BCS_QRCODE 		202

#define	LK_BCS_UPCA 		101
#define	LK_BCS_UPCE 		102
#define	LK_BCS_EAN8 		103
#define	LK_BCS_EAN13 		104
#define	LK_BCS_JAN8	 	105
#define	LK_BCS_JAN13 		106
#define	LK_BCS_ITF 		107
#define	LK_BCS_Codabar 		108
#define	LK_BCS_Code39 		109
#define	LK_BCS_Code93 		110
#define	LK_BCS_Code128 		111

// Barcode text position
#define	LK_HRI_TEXT_NONE 		0
#define	LK_HRI_TEXT_ABOVE	 	1
#define	LK_HRI_TEXT_BELOW 		2

// True-Type Font Style
#define	LK_TTF_THIN		0
#define	LK_TTF_NORMAL		1
#define	LK_TTF_BOLD		2
#define	LK_TTF_ITALIC		0x10
#define	LK_TTF_UNDERLINE	0x20

// True-Type Font Reverse Print
#define	LK_TTF_REVERSE_NO	0
#define	LK_TTF_REVERSE_YES	1

// QRCode Error Correction Level.
#define	LK_QRCODE_EC_LEVEL_L	0
#define	LK_QRCODE_EC_LEVEL_M	1
#define	LK_QRCODE_EC_LEVEL_Q	2
#define	LK_QRCODE_EC_LEVEL_H	3

// QRCode mask pattern.
#define	LK_QRCODE_MASK_AUTO	-1
#define	LK_QRCODE_MASK_0	0
#define	LK_QRCODE_MASK_1	1
#define	LK_QRCODE_MASK_2	2
#define	LK_QRCODE_MASK_3	3
#define	LK_QRCODE_MASK_4	4
#define	LK_QRCODE_MASK_5	5
#define	LK_QRCODE_MASK_6	6
#define	LK_QRCODE_MASK_7	7

// QRCode Symbol version.
#define	LK_QRCODE_VERSION_00	0 // Auto.
#define	LK_QRCODE_VERSION_01	1 // Version 1
#define	LK_QRCODE_VERSION_02	2 // Version 2
#define	LK_QRCODE_VERSION_03	3 // Version 3
#define	LK_QRCODE_VERSION_04	4 // Version 4
#define	LK_QRCODE_VERSION_05	5 // Version 5
#define	LK_QRCODE_VERSION_06	6 // Version 6
#define	LK_QRCODE_VERSION_07	7 // Version 7
#define	LK_QRCODE_VERSION_08	8 // Version 8
#define	LK_QRCODE_VERSION_09	9 // Version 9
#define	LK_QRCODE_VERSION_10	10 // Version 10
#define	LK_QRCODE_VERSION_11	11 // Version 11
#define	LK_QRCODE_VERSION_12	12 // Version 12
#define	LK_QRCODE_VERSION_13	13 // Version 13
#define	LK_QRCODE_VERSION_14	14 // Version 14
#define	LK_QRCODE_VERSION_15	15 // Version 15
#define	LK_QRCODE_VERSION_16	16 // Version 16
#define	LK_QRCODE_VERSION_17	17 // Version 17
#define	LK_QRCODE_VERSION_18	18 // Version 18
#define	LK_QRCODE_VERSION_19	19 // Version 19
#define	LK_QRCODE_VERSION_20	20 // Version 20
#define	LK_QRCODE_VERSION_21	21 // Version 21
#define	LK_QRCODE_VERSION_22	22 // Version 22
#define	LK_QRCODE_VERSION_23	23 // Version 23
#define	LK_QRCODE_VERSION_24	24 // Version 24
#define	LK_QRCODE_VERSION_25	25 // Version 25
#define	LK_QRCODE_VERSION_26	26 // Version 26
#define	LK_QRCODE_VERSION_27	27 // Version 27
#define	LK_QRCODE_VERSION_28	28 // Version 28
#define	LK_QRCODE_VERSION_29	29 // Version 29
#define	LK_QRCODE_VERSION_30	30 // Version 30
#define	LK_QRCODE_VERSION_31	31 // Version 31
#define	LK_QRCODE_VERSION_32	32 // Version 32
#define	LK_QRCODE_VERSION_33	33 // Version 33
#define	LK_QRCODE_VERSION_34	34 // Version 34
#define	LK_QRCODE_VERSION_35	35 // Version 35
#define	LK_QRCODE_VERSION_36	36 // Version 36
#define	LK_QRCODE_VERSION_37	37 // Version 37
#define	LK_QRCODE_VERSION_38	38 // Version 38
#define	LK_QRCODE_VERSION_39	39 // Version 39
#define	LK_QRCODE_VERSION_40	40 // Version 40


////////////////////////////// Export Function //////////////////////////////
#pragma comment (lib, "LKPOSTOT.lib")	// Reference Library.
#define	LUKHAN_LIBRARY	extern "C" __declspec(dllimport)

LUKHAN_LIBRARY	long __stdcall OpenPort(LPCTSTR PortName, long BaudRate);
LUKHAN_LIBRARY	long __stdcall ClosePort();
LUKHAN_LIBRARY	long __stdcall PrintBitmap(LPCTSTR BitmapFile, long Alignment, long Options, long Brightness, long ImageMode);
LUKHAN_LIBRARY	long __stdcall PrintString(LPCTSTR Data);
LUKHAN_LIBRARY	long __stdcall PrintText(LPCTSTR Data, long Alignment, long Options, long TextSize);
LUKHAN_LIBRARY	long __stdcall PrintNormal(LPCTSTR Data);
LUKHAN_LIBRARY	long __stdcall PrintBarCode(LPCTSTR Data, long Symbology, long Height, long Width, long Alignment, long TextPosition);
LUKHAN_LIBRARY	long __stdcall PrinterSts();
LUKHAN_LIBRARY	long __stdcall OpenDrawer(long DrawerPinNum, long PulseOnTime, long PulseOffTime);
LUKHAN_LIBRARY	long __stdcall PrintText(LPCTSTR Data, long Alignment, long Options, long TextSize);
LUKHAN_LIBRARY	long __stdcall DrawerSts();
LUKHAN_LIBRARY	long __stdcall CutPaper();
LUKHAN_LIBRARY	long __stdcall PrintStart();
LUKHAN_LIBRARY	long __stdcall PrintStop();
LUKHAN_LIBRARY	long __stdcall PrintData(unsigned char * Data, int Size);

LUKHAN_LIBRARY	long __stdcall PrintText2Image(LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);
LUKHAN_LIBRARY	long __stdcall PrintText2ImageAlignment(LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint, long Alignment);
LUKHAN_LIBRARY	long __stdcall OutputCompletePrinting(long TimeDelay);
// Printing QRCode BarCode Function.
LUKHAN_LIBRARY	long __stdcall PrintQRCode(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Alignment);
LUKHAN_LIBRARY	long __stdcall MakeQRCodeBitmap(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern, LPCTSTR BitmapName);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeGenerator(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern, long Alignment);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeFromFile(LPCTSTR File4QR, long ModuleSize, long ECLevel, long Version, long MaskPattern, long Alignment);
// Printing PDF417 BarCode Function
LUKHAN_LIBRARY	long __stdcall PrintPDF417(LPCTSTR PdfData, long DataLength, long NumberOfColumns, long CellWidth, long Alignment);

// Page Mode Function.
LUKHAN_LIBRARY	long __stdcall SetPageMode(BOOL	IsPageMode);
LUKHAN_LIBRARY	long __stdcall SetPrintDirection(long pDirect);
LUKHAN_LIBRARY	long __stdcall SetPrintingArea(long PageHeight);
LUKHAN_LIBRARY	long __stdcall SetAbsoluteVertical(long AbsolutePosition);
LUKHAN_LIBRARY	long __stdcall SetRelativeVertical(long RelativePosition);

// NV Logo
LUKHAN_LIBRARY	long __stdcall SaveNVBitmap(LPCTSTR SaveBitmapNameList, long Brightness, long ImageMode);
LUKHAN_LIBRARY	long __stdcall PrintNVBitmap(long NVImageNumber);
LUKHAN_LIBRARY	long __stdcall DeleteNVBitmap();

// Black Mark paper.
LUKHAN_LIBRARY	long __stdcall BlackMarkON(long FeedValue);
LUKHAN_LIBRARY	long __stdcall BlackMarkSearch(long FeedValue);

LUKHAN_LIBRARY	long __stdcall SetMasterUnit(long UnitMeasure);
LUKHAN_LIBRARY	long __stdcall PrintingWidth(long pwidth);

LUKHAN_LIBRARY	long __stdcall SetLabelSize(long widthsize, long heightsize);
LUKHAN_LIBRARY	long __stdcall PrintLabel();

LUKHAN_LIBRARY	long __stdcall PrintTTFXY(long BaseUnitX, long BaseUnitY, LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);
LUKHAN_LIBRARY	long __stdcall PrintTTFAlign(long Alignment, long BaseUnitY, LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);

LUKHAN_LIBRARY	long __stdcall PrintBitmapXY(long BaseUnitX, long BaseUnitY, LPCTSTR BitmapFile);
LUKHAN_LIBRARY	long __stdcall PrintBitmapAlign(long Alignment, long BaseUnitY, LPCTSTR BitmapFile);

LUKHAN_LIBRARY	long __stdcall PrintQRCodeXY(long BaseUnitX, long BaseUnitY, unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeAlign(long Alignment, long BaseUnitY, unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern);
// adjust to printiong position
LUKHAN_LIBRARY	long __stdcall SEWOO_PrintTextLS(LPCTSTR Data, long Alignment, long Options, long TextSize, long LineSpacing);
LUKHAN_LIBRARY	long __stdcall FeedDot(long dotvalue);
// 1.40 added for powerbuilder application
LUKHAN_LIBRARY	long __stdcall SetAlignment(long Alignment);
LUKHAN_LIBRARY	long __stdcall SetMagnify(long WidthandHeight);
LUKHAN_LIBRARY	long __stdcall SetAttribute(long attribute);

LUKHAN_LIBRARY	long __stdcall GetUsbStatus();
LUKHAN_LIBRARY	BYTE* __stdcall PrintDirectCommand(LPSTR Data);

LUKHAN_LIBRARY	long __stdcall SetTransactionMode(BOOL IsMode);
LUKHAN_LIBRARY	long __stdcall PrintTransactionMode();

LUKHAN_LIBRARY	long __stdcall SetAbsoluteVertical2(long AbsolutePosition);
LUKHAN_LIBRARY	long __stdcall SetAbsoluteHorizontal2(long AbsolutePosition);
LUKHAN_LIBRARY	long __stdcall SetPageModeWidth(long widthDots);
LUKHAN_LIBRARY	long __stdcall SetPageModeDPI(long dpi);

LUKHAN_LIBRARY	long __stdcall SetReverseBitmap(BOOL Reverse);
LUKHAN_LIBRARY	long __stdcall LineFeed(long LFCount);
