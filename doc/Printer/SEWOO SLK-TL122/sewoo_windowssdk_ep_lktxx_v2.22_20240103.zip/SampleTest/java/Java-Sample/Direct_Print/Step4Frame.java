import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;
import com.sewoo.thermal.jni.LKPOSTOTConst;

public class Step4Frame extends JFrame
{

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_GetPrtStatus = new JButton();
	JButton jButton_Close = new JButton();

	LKPOSTOT SWLib = null;

	/**Constract "Frame"*/
//	public Step4Frame() {
	public Step4Frame(LKPOSTOT sewoolib) {
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			pack();
			setVisible(true);
			SWLib = sewoolib;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"Receipt");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 300));
		this.setTitle("Step 4  Get Printer Status");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);
		jButton_GetPrtStatus.setText("Get Printer Status");
		jButton_GetPrtStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_GetPrtStatus_actionPerformed(e);
			}
			});
		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});

		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
//			   ,GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(15, 0, 0, 0), 0, 0));
			   ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 20, 20));

		jPanel_Receipt.add(jButton_GetPrtStatus, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 130, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	void jButton_GetPrtStatus_actionPerformed(ActionEvent e) {
	        String ESC    = ((char) 0x1b) + "";
	        String LF     = ((char) 0x0a) + "";
	        String SPACES = "                                                                      ";

	        try{
		do
		{
			long lResult = SWLib.PrinterSts();
			switch((int)lResult)
			{
			case LKPOSTOTConst.LK_STS_NORMAL:
				MessageBox.ok("No Error(" + lResult + ")");
				break;
			case LKPOSTOTConst.LK_STS_COVEROPEN:
				MessageBox.ok("Cover Open(" + lResult + ")");
				break;
			case LKPOSTOTConst.LK_STS_PAPERNEAREMPTY:
				MessageBox.ok("Paper Near Empty(" + lResult + ")");
				break;
			case LKPOSTOTConst.LK_STS_PAPEREMPTY:
				MessageBox.ok("Paper Empty(" + lResult + ")");
				break;
			case LKPOSTOTConst.LK_STS_POWEROFF:
				MessageBox.ok("Power Off(" + lResult + ")");
				break;
			}
		// exit our printing loop
		} while (false);
	        }
	        catch(Exception ex)
	        {
			MessageBox.ok(ex.getMessage());
	        }
	        finally
	        {
	        }

	        return;
	}

	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		dispose();
	}
}
