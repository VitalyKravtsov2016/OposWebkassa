import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;
import java.lang.Thread;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;
import com.sewoo.thermal.jni.LKPOSTOTConst;

public class Step5Frame extends JFrame
{
	JPanel contentPane;
	JPanel jPanel1 = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_OpenDrawer = new JButton();
	JButton jButton_close = new JButton();

	LKPOSTOT SWLib = null;

	/**Constract "Frame"*/
//	public Step5Frame() {
	public Step5Frame(LKPOSTOT sewoolib) {
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			pack();
			setVisible(true);
			SWLib = sewoolib;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"Cash Drawer");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 300));
		this.setTitle("Step5 Open Drawer.");
		jPanel1.setBorder(titledBorder1);
		jPanel1.setLayout(gridBagLayout2);
		jButton_OpenDrawer.setText("Open Drawer");
		jButton_OpenDrawer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_OpenDrawer_actionPerformed(e);
			}
			});
		jButton_close.setText("Close");
		jButton_close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_close_actionPerformed(e);
			}
			});
		contentPane.add(jPanel1, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
				,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 20, 20));
		jPanel1.add(jButton_OpenDrawer, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
				 ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 130, 0));
		contentPane.add(jButton_close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
			  ,GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	void jButton_OpenDrawer_actionPerformed(ActionEvent e) {
	        try
	        {
	            do
	            {
		SWLib.OpenDrawer(LKPOSTOTConst.LK_CD_PIN_TWO, 400, 400);
	            // exit our printing loop
	            } while (false);
	        }
	        catch(Exception ex)
	        {
			MessageBox.ok(ex.getMessage());
	        }
	        finally
	        {
	        }

	        return;
	}

	void jButton_close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		dispose();
	}
}
