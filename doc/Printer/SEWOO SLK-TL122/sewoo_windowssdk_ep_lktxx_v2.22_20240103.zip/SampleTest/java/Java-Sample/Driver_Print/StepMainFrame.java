import javax.swing.UIManager;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;

public class StepMainFrame extends JFrame{
	String[] portStrings = { "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3", "USB", "TCP/IP" };
	String[] baudStrings = { "115200", "57600", "38400", "19200", "9600", "4800", "2400" };

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_PrintString = new JButton();
	JButton jButton_PrintNormal = new JButton();
	JButton jButton_PrintText = new JButton();
	JButton jButton_OpenDrawer = new JButton();
	JButton jButton_Printer2DBarcode = new JButton();
	JButton jButton_PrintLabel = new JButton();
	JButton jButton_Close = new JButton();

	JLabel lblDRIVER= new JLabel("Printer driver name: ");
	JTextField driverTextField = new JTextField();
    
	LKPOSTOT SWLib = null;

	/**Constract "Frame"*/
	public StepMainFrame()
	{
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			this.pack();
			this.setVisible(true);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"SEWOO TECH Receipt and Drawer");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 400));
		this.setTitle("Java Sample Printing");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);

		driverTextField.setText("LK-T210");

		jButton_PrintString.setText("Print String");
		jButton_PrintString.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintString_actionPerformed(e);
			}
			});
		jButton_PrintNormal.setText("Print Normal");
		jButton_PrintNormal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintNormal_actionPerformed(e);
			}
			});
		jButton_PrintText.setText("Print Text");
		jButton_PrintText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintText_actionPerformed(e);
			}
			});
		jButton_OpenDrawer.setText("Open Drawer");
		jButton_OpenDrawer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_OpenDrawer_actionPerformed(e);
			}
			});
		jButton_Printer2DBarcode.setText("Print 2D-Barcode");
		jButton_Printer2DBarcode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Printer2DBarcode_actionPerformed(e);
			}
			});
		jButton_PrintLabel.setText("Print Label");
		jButton_PrintLabel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintLabel_actionPerformed(e);
			}
			});

		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});


		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			   ,GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(15, 0, 0, 0), 0, 0));

		jPanel_Receipt.add(lblDRIVER, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 150, 0));

		jPanel_Receipt.add(driverTextField, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintString, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintNormal, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
			,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintText, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
			,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_OpenDrawer, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_Printer2DBarcode, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintLabel, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));

		SWLib = new LKPOSTOT();
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	//******************** Click the Print String ********************
	void jButton_PrintString_actionPerformed(ActionEvent e) {
		new Step1Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the Print Normal ********************
	void jButton_PrintNormal_actionPerformed(ActionEvent e) {
		new Step2Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the Print Text ********************
	void jButton_PrintText_actionPerformed(ActionEvent e) {
		new Step3Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the Open Drawer ********************
	void jButton_OpenDrawer_actionPerformed(ActionEvent e) {
		new Step4Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the 2D-Barcode ********************
	void jButton_Printer2DBarcode_actionPerformed(ActionEvent e) {
		new Step5Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the Print Label ********************
	void jButton_PrintLabel_actionPerformed(ActionEvent e) {
		new Step6Frame(SWLib, driverTextField.getText());
	}

	//******************** Click the Close Button ********************
	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		SWLib = null;
		System.exit(0);
	}
}
