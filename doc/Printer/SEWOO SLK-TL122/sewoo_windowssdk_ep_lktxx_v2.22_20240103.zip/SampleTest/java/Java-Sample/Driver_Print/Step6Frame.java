import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;
import com.sewoo.thermal.jni.LKPOSTOTConst;

public class Step6Frame extends JFrame {

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_PrintLabel = new JButton();
	JButton jButton_Close = new JButton();

	LKPOSTOT SWLib = null;
	String driverName;

	/**Constract "Frame"*/
	public Step6Frame(LKPOSTOT sewoolib, String drvName) {
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			pack();
			setVisible(true);
			SWLib = sewoolib;
			driverName = drvName;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"Receipt");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 300));
		this.setTitle("Step 6  Print Label");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);
		jButton_PrintLabel.setText("Print Label");
		jButton_PrintLabel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintLabel_actionPerformed(e);
			}
			});
		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});

		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			   ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 20, 20));

		jPanel_Receipt.add(jButton_PrintLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 130, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	void jButton_PrintLabel_actionPerformed(ActionEvent e) {
	        String ESC    = ((char) 0x1b) + "";
	        String LF     = ((char) 0x0a) + "";
	        String SPACES = "                                                                      ";

	        try {
	            do
	            {
	            	long lResult;

		lResult = SWLib.OpenPort(driverName, 1);
		if(lResult != 0)
		{
			MessageBox.ok("Open Port Failed(" + lResult + ")");
			return;
		}

		SWLib.PrintStart();

		SWLib.PrintingWidth(404); // 57mm = 404-dot

		SWLib.SetMasterUnit(0); // Dot units.
		// 7mm = (7 / 25.4) * 180 = 49.6
//		SWLib.SetLabelSize(512, 180); // height = 1-inch
//		SWLib.SetLabelSize(512, 318); // height = 45mm
		SWLib.SetLabelSize(404, 264); // height = 35mm = 248 + 16(QR Code Guard)
		SWLib.PrintTTFAlign(1, 0, "����", 2, 32, "Center Alignment", 0); // TTF, 32-dot. Center align
		SWLib.PrintTTFAlign(1, 50, "����", 1, 32, "101Ҵ01-02��TTF Font", 0); // TTF, 32-dot.
		SWLib.PrintTTFXY(0, 100, "����", 2, 32, "AB-45627120", 0); // TTF, 32-dot.
		SWLib.PrintTTFXY(0, 150, "����", 2, 24, "2012-02-03 00:00:04", 0); // TTF, 32-dot.
		SWLib.PrintTTFXY(0, 186, "����", 2, 24, "test : 9999", 0); // TTF, 32-dot.
		SWLib.PrintTTFXY(0, 222, "����", 2, 24, "���� : 20", 0); // TTF, 32-dot.
		SWLib.PrintQRCodeAlign(2, 150, "QRCode Test Right Alignment", 0, 4, 0, 0, -1); // auto version.
		SWLib.PrintLabel();
		SWLib.PrintBarCode("1234567890", 109, 50, 404, 1, 0);
		SWLib.PrintNormal("---------------------------------\n");
    
		SWLib.PrintNormal("Chicken                    $10.00\n");
		SWLib.PrintNormal("Hamburger                  $20.00\n");
		SWLib.PrintNormal("Pizza                      $30.00\n");
		SWLib.PrintNormal("Lemons                     $40.00\n");
		SWLib.PrintNormal("Drink                      $50.00\n\n");
		SWLib.PrintNormal("Excluded tax              $150.00\n");
		SWLib.PrintNormal(ESC + "|uCTax(5%)                     $7.50\n");
		SWLib.PrintNormal(ESC + "|bCTotal                     $157.50\n");

		SWLib.PrintNormal(ESC + "|fP");

		SWLib.PrintStop();

		lResult = SWLib.ClosePort();
		if(lResult != 0)
		{
			MessageBox.ok("Close Port Failed(" + lResult + ")");
		}
	            // exit our printing loop
	            } while (false);
	        }
	        catch(Exception ex)
	        {
			MessageBox.ok(ex.getMessage());
	        }
	        finally
	        {
	        }

	        return;
	}

	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		dispose();
	}
}
