﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.useDriverCheckBox = New System.Windows.Forms.CheckBox
        Me.portNameCBox = New System.Windows.Forms.ComboBox
        Me.baudRateCBox = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.closeButton = New System.Windows.Forms.Button
        Me.openButton = New System.Windows.Forms.Button
        Me.pDriverNameTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.printPDF417Button = New System.Windows.Forms.Button
        Me.printQRCodeFileButton = New System.Windows.Forms.Button
        Me.printQRCodeGenButton = New System.Windows.Forms.Button
        Me.saveQRCodeButton = New System.Windows.Forms.Button
        Me.printQRCodeCmdButton = New System.Windows.Forms.Button
        Me.getPrinterStatusButton = New System.Windows.Forms.Button
        Me.printSampleButton = New System.Windows.Forms.Button
        Me.printTextButton = New System.Windows.Forms.Button
        Me.printNormalButton = New System.Windows.Forms.Button
        Me.printStringButton = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.cashDrawerOpenButton = New System.Windows.Forms.Button
        Me.getCashDrawerStatusButton = New System.Windows.Forms.Button
        Me.exitButton = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtIP = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'useDriverCheckBox
        '
        Me.useDriverCheckBox.AutoSize = True
        Me.useDriverCheckBox.Location = New System.Drawing.Point(22, 14)
        Me.useDriverCheckBox.Name = "useDriverCheckBox"
        Me.useDriverCheckBox.Size = New System.Drawing.Size(151, 16)
        Me.useDriverCheckBox.TabIndex = 0
        Me.useDriverCheckBox.Text = "Using the printer driver"
        Me.useDriverCheckBox.UseVisualStyleBackColor = True
        '
        'portNameCBox
        '
        Me.portNameCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.portNameCBox.FormattingEnabled = True
        Me.portNameCBox.Location = New System.Drawing.Point(91, 37)
        Me.portNameCBox.Name = "portNameCBox"
        Me.portNameCBox.Size = New System.Drawing.Size(119, 20)
        Me.portNameCBox.TabIndex = 1
        '
        'baudRateCBox
        '
        Me.baudRateCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.baudRateCBox.FormattingEnabled = True
        Me.baudRateCBox.Location = New System.Drawing.Point(91, 68)
        Me.baudRateCBox.Name = "baudRateCBox"
        Me.baudRateCBox.Size = New System.Drawing.Size(119, 20)
        Me.baudRateCBox.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.closeButton)
        Me.GroupBox1.Controls.Add(Me.portNameCBox)
        Me.GroupBox1.Controls.Add(Me.openButton)
        Me.GroupBox1.Controls.Add(Me.baudRateCBox)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 42)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(218, 150)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Port Information"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 71)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 12)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "BaudRate :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 12)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Port Name :"
        '
        'closeButton
        '
        Me.closeButton.Location = New System.Drawing.Point(110, 104)
        Me.closeButton.Name = "closeButton"
        Me.closeButton.Size = New System.Drawing.Size(100, 36)
        Me.closeButton.TabIndex = 9
        Me.closeButton.Text = "Close"
        Me.closeButton.UseVisualStyleBackColor = True
        '
        'openButton
        '
        Me.openButton.Location = New System.Drawing.Point(6, 104)
        Me.openButton.Name = "openButton"
        Me.openButton.Size = New System.Drawing.Size(98, 36)
        Me.openButton.TabIndex = 8
        Me.openButton.Text = "Open"
        Me.openButton.UseVisualStyleBackColor = True
        '
        'pDriverNameTextBox
        '
        Me.pDriverNameTextBox.Location = New System.Drawing.Point(332, 15)
        Me.pDriverNameTextBox.Name = "pDriverNameTextBox"
        Me.pDriverNameTextBox.Size = New System.Drawing.Size(174, 21)
        Me.pDriverNameTextBox.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.printPDF417Button)
        Me.GroupBox2.Controls.Add(Me.printQRCodeFileButton)
        Me.GroupBox2.Controls.Add(Me.printQRCodeGenButton)
        Me.GroupBox2.Controls.Add(Me.saveQRCodeButton)
        Me.GroupBox2.Controls.Add(Me.printQRCodeCmdButton)
        Me.GroupBox2.Controls.Add(Me.getPrinterStatusButton)
        Me.GroupBox2.Controls.Add(Me.printSampleButton)
        Me.GroupBox2.Controls.Add(Me.printTextButton)
        Me.GroupBox2.Controls.Add(Me.printNormalButton)
        Me.GroupBox2.Controls.Add(Me.printStringButton)
        Me.GroupBox2.Location = New System.Drawing.Point(256, 42)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(250, 393)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "POS Printer"
        '
        'printPDF417Button
        '
        Me.printPDF417Button.Location = New System.Drawing.Point(4, 351)
        Me.printPDF417Button.Name = "printPDF417Button"
        Me.printPDF417Button.Size = New System.Drawing.Size(241, 36)
        Me.printPDF417Button.TabIndex = 21
        Me.printPDF417Button.Text = "Print PDF417"
        Me.printPDF417Button.UseVisualStyleBackColor = True
        '
        'printQRCodeFileButton
        '
        Me.printQRCodeFileButton.Location = New System.Drawing.Point(4, 308)
        Me.printQRCodeFileButton.Name = "printQRCodeFileButton"
        Me.printQRCodeFileButton.Size = New System.Drawing.Size(241, 36)
        Me.printQRCodeFileButton.TabIndex = 20
        Me.printQRCodeFileButton.Text = "Print QRCode from file(QR Generator)"
        Me.printQRCodeFileButton.UseVisualStyleBackColor = True
        '
        'printQRCodeGenButton
        '
        Me.printQRCodeGenButton.Location = New System.Drawing.Point(4, 273)
        Me.printQRCodeGenButton.Name = "printQRCodeGenButton"
        Me.printQRCodeGenButton.Size = New System.Drawing.Size(241, 36)
        Me.printQRCodeGenButton.TabIndex = 19
        Me.printQRCodeGenButton.Text = "Print QRCode(QR Generator)"
        Me.printQRCodeGenButton.UseVisualStyleBackColor = True
        '
        'saveQRCodeButton
        '
        Me.saveQRCodeButton.Location = New System.Drawing.Point(4, 238)
        Me.saveQRCodeButton.Name = "saveQRCodeButton"
        Me.saveQRCodeButton.Size = New System.Drawing.Size(241, 36)
        Me.saveQRCodeButton.TabIndex = 18
        Me.saveQRCodeButton.Text = "Save QRCode(QR Generator)"
        Me.saveQRCodeButton.UseVisualStyleBackColor = True
        '
        'printQRCodeCmdButton
        '
        Me.printQRCodeCmdButton.Location = New System.Drawing.Point(4, 203)
        Me.printQRCodeCmdButton.Name = "printQRCodeCmdButton"
        Me.printQRCodeCmdButton.Size = New System.Drawing.Size(241, 36)
        Me.printQRCodeCmdButton.TabIndex = 17
        Me.printQRCodeCmdButton.Text = "Print QRCode(Command)"
        Me.printQRCodeCmdButton.UseVisualStyleBackColor = True
        '
        'getPrinterStatusButton
        '
        Me.getPrinterStatusButton.Location = New System.Drawing.Point(4, 161)
        Me.getPrinterStatusButton.Name = "getPrinterStatusButton"
        Me.getPrinterStatusButton.Size = New System.Drawing.Size(241, 36)
        Me.getPrinterStatusButton.TabIndex = 16
        Me.getPrinterStatusButton.Text = "Get Printer Status"
        Me.getPrinterStatusButton.UseVisualStyleBackColor = True
        '
        'printSampleButton
        '
        Me.printSampleButton.Location = New System.Drawing.Point(4, 126)
        Me.printSampleButton.Name = "printSampleButton"
        Me.printSampleButton.Size = New System.Drawing.Size(241, 36)
        Me.printSampleButton.TabIndex = 15
        Me.printSampleButton.Text = "Print 1D-BarCode"
        Me.printSampleButton.UseVisualStyleBackColor = True
        '
        'printTextButton
        '
        Me.printTextButton.Location = New System.Drawing.Point(4, 91)
        Me.printTextButton.Name = "printTextButton"
        Me.printTextButton.Size = New System.Drawing.Size(241, 36)
        Me.printTextButton.TabIndex = 14
        Me.printTextButton.Text = "Print Text"
        Me.printTextButton.UseVisualStyleBackColor = True
        '
        'printNormalButton
        '
        Me.printNormalButton.Location = New System.Drawing.Point(4, 56)
        Me.printNormalButton.Name = "printNormalButton"
        Me.printNormalButton.Size = New System.Drawing.Size(241, 36)
        Me.printNormalButton.TabIndex = 13
        Me.printNormalButton.Text = "Print Normal"
        Me.printNormalButton.UseVisualStyleBackColor = True
        '
        'printStringButton
        '
        Me.printStringButton.Location = New System.Drawing.Point(4, 21)
        Me.printStringButton.Name = "printStringButton"
        Me.printStringButton.Size = New System.Drawing.Size(241, 36)
        Me.printStringButton.TabIndex = 12
        Me.printStringButton.Text = "Print String"
        Me.printStringButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cashDrawerOpenButton)
        Me.GroupBox3.Controls.Add(Me.getCashDrawerStatusButton)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 269)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(218, 106)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Cash Drawer"
        '
        'cashDrawerOpenButton
        '
        Me.cashDrawerOpenButton.Location = New System.Drawing.Point(12, 20)
        Me.cashDrawerOpenButton.Name = "cashDrawerOpenButton"
        Me.cashDrawerOpenButton.Size = New System.Drawing.Size(197, 36)
        Me.cashDrawerOpenButton.TabIndex = 10
        Me.cashDrawerOpenButton.Text = "Cash Drawer Open"
        Me.cashDrawerOpenButton.UseVisualStyleBackColor = True
        '
        'getCashDrawerStatusButton
        '
        Me.getCashDrawerStatusButton.Location = New System.Drawing.Point(12, 62)
        Me.getCashDrawerStatusButton.Name = "getCashDrawerStatusButton"
        Me.getCashDrawerStatusButton.Size = New System.Drawing.Size(197, 36)
        Me.getCashDrawerStatusButton.TabIndex = 11
        Me.getCashDrawerStatusButton.Text = "Get Cash Drawer  Status"
        Me.getCashDrawerStatusButton.UseVisualStyleBackColor = True
        '
        'exitButton
        '
        Me.exitButton.Location = New System.Drawing.Point(18, 384)
        Me.exitButton.Name = "exitButton"
        Me.exitButton.Size = New System.Drawing.Size(216, 48)
        Me.exitButton.TabIndex = 7
        Me.exitButton.Text = "E&xit"
        Me.exitButton.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.GroupBox4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.exitButton)
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.pDriverNameTextBox)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.useDriverCheckBox)
        Me.Panel1.Location = New System.Drawing.Point(2, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(526, 454)
        Me.Panel1.TabIndex = 8
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtIP)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Location = New System.Drawing.Point(17, 202)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(216, 58)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Ethernet"
        '
        'txtIP
        '
        Me.txtIP.Location = New System.Drawing.Point(50, 21)
        Me.txtIP.Name = "txtIP"
        Me.txtIP.Size = New System.Drawing.Size(159, 21)
        Me.txtIP.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(15, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 12)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "IP : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(206, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 12)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Printer driver name :"
        '
        'Form1
        '
        Me.ClientSize = New System.Drawing.Size(534, 457)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "POS Printer Test Program (VB.NET)"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents useDriverCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents portNameCBox As System.Windows.Forms.ComboBox
    Friend WithEvents baudRateCBox As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents pDriverNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents closeButton As System.Windows.Forms.Button
    Friend WithEvents openButton As System.Windows.Forms.Button
    Friend WithEvents printTextButton As System.Windows.Forms.Button
    Friend WithEvents printNormalButton As System.Windows.Forms.Button
    Friend WithEvents printStringButton As System.Windows.Forms.Button
    Friend WithEvents cashDrawerOpenButton As System.Windows.Forms.Button
    Friend WithEvents getCashDrawerStatusButton As System.Windows.Forms.Button
    Friend WithEvents exitButton As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents printQRCodeFileButton As System.Windows.Forms.Button
    Friend WithEvents printQRCodeGenButton As System.Windows.Forms.Button
    Friend WithEvents saveQRCodeButton As System.Windows.Forms.Button
    Friend WithEvents printQRCodeCmdButton As System.Windows.Forms.Button
    Friend WithEvents getPrinterStatusButton As System.Windows.Forms.Button
    Friend WithEvents printSampleButton As System.Windows.Forms.Button
    Friend WithEvents printPDF417Button As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtIP As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
