// LKVCTESTDlg.h : header file
//

#if !defined(AFX_LKVCTESTDLG_H__47B302C8_FC94_4F0E_9F04_5BFC1B74DFEF__INCLUDED_)
#define AFX_LKVCTESTDLG_H__47B302C8_FC94_4F0E_9F04_5BFC1B74DFEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CLKVCTESTDlg dialog

class CLKVCTESTDlg : public CDialog
{
// Construction
public:
	CLKVCTESTDlg(CWnd* pParent = NULL);	// standard constructor
	BOOL m_bMode;

// Dialog Data
	//{{AFX_DATA(CLKVCTESTDlg)
	enum { IDD = IDD_LKVCTEST_DIALOG };
	CIPAddressCtrl	m_PrinterIP;
	CEdit	m_PRINTER;
	CButton	m_chkUsingDriver;
	CComboBox	m_cboBaudRate;
	CComboBox	m_cboPortName;
	CString	m_strPrinter;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLKVCTESTDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLKVCTESTDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonOpen();
	afx_msg void OnButtonClose();
	afx_msg void OnButtonPrintNormal();
	afx_msg void OnDestroy();
	afx_msg void OnButtonPrintString();
	afx_msg void OnButtonPrintText();
	afx_msg void OnButtonPrinterStatus();
	afx_msg void OnButtonOpenDrawer();
	afx_msg void OnButtonDrawerStatus();
	afx_msg void OnButtonPrintSample();
	afx_msg void OnCheck1();
	afx_msg void OnButtonPrintCmdqr();
	afx_msg void OnButtonPrintDcqr();
	afx_msg void OnButtonPrintSaveqr();
	afx_msg void OnButtonPrintFileqr();
	afx_msg void OnButtonPrintPdf417();
	afx_msg void OnSelchangeComboPortname();
	afx_msg void OnButtonPrintLabel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int	useprinterdriver;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LKVCTESTDLG_H__47B302C8_FC94_4F0E_9F04_5BFC1B74DFEF__INCLUDED_)
