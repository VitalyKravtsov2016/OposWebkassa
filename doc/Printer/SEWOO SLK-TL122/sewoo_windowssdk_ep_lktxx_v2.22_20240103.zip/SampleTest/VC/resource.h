//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LKVCTEST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LKVCTEST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_OPEN                 1000
#define IDC_BUTTON_CLOSE                1001
#define IDC_BUTTON_PRINT_NORMAL         1002
#define IDC_BUTTON_TCP_OPEN             1003
#define IDC_BUTTON_TCP_CLOSE            1004
#define IDC_COMBO_PORTNAME              1005
#define IDC_COMBO_PORTNUM               1006
#define IDC_EDIT_IP                     1007
#define IDC_EDIT_PORT                   1008
#define IDC_BUTTON_PRINT_STRING         1009
#define IDC_BUTTON_PRINT_TEXT           1010
#define IDC_BUTTON_PRINTER_STATUS       1011
#define IDC_BUTTON_OPEN_DRAWER          1012
#define IDC_BUTTON_DRAWER_STATUS        1013
#define IDC_BUTTON_PRINT_SAMPLE         1014
#define IDC_MSR_READ_START              1015
#define IDC_BUTTON_PRINT_CMDQR          1015
#define IDC_MSR_READ_CANCEL             1016
#define IDC_BUTTON_PRINT_DCQR           1016
#define IDC_BUTTON_PRINT_SAVEQR         1017
#define IDC_MSR_DATA                    1018
#define IDC_MSR_DATA1                   1018
#define IDC_BUTTON_PRINT_FILEQR         1018
#define IDC_MSR_DATA2                   1019
#define IDC_BUTTON_PRINT_PDF417         1019
#define IDC_MSR_DATA3                   1020
#define IDC_BUTTON_PRINT_LABEL          1020
#define IDC_BUTTON1                     1021
#define IDC_BUTTON_CONTROL              1021
#define IDC_CHECK1                      1022
#define IDC_BUTTON_PRINTER_PAPER        1023
#define IDC_EDIT_DRIVER_NAME            1024
#define IDC_IPADDRESS1                  1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
