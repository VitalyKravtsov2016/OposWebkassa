// LKVCTESTDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LKVCTEST.h"
#include "LKVCTESTDlg.h"

#include "LKPOSTOT.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLKVCTESTDlg dialog

CLKVCTESTDlg::CLKVCTESTDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLKVCTESTDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLKVCTESTDlg)
	m_strPrinter = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLKVCTESTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLKVCTESTDlg)
	DDX_Control(pDX, IDC_IPADDRESS1, m_PrinterIP);
	DDX_Control(pDX, IDC_EDIT_DRIVER_NAME, m_PRINTER);
	DDX_Control(pDX, IDC_CHECK1, m_chkUsingDriver);
	DDX_Control(pDX, IDC_COMBO_PORTNUM, m_cboBaudRate);
	DDX_Control(pDX, IDC_COMBO_PORTNAME, m_cboPortName);
	DDX_Text(pDX, IDC_EDIT_DRIVER_NAME, m_strPrinter);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLKVCTESTDlg, CDialog)
	//{{AFX_MSG_MAP(CLKVCTESTDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_NORMAL, OnButtonPrintNormal)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_PRINT_STRING, OnButtonPrintString)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_TEXT, OnButtonPrintText)
	ON_BN_CLICKED(IDC_BUTTON_PRINTER_STATUS, OnButtonPrinterStatus)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_DRAWER, OnButtonOpenDrawer)
	ON_BN_CLICKED(IDC_BUTTON_DRAWER_STATUS, OnButtonDrawerStatus)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_SAMPLE, OnButtonPrintSample)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_CMDQR, OnButtonPrintCmdqr)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_DCQR, OnButtonPrintDcqr)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_SAVEQR, OnButtonPrintSaveqr)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_FILEQR, OnButtonPrintFileqr)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_PDF417, OnButtonPrintPdf417)
	ON_CBN_SELCHANGE(IDC_COMBO_PORTNAME, OnSelchangeComboPortname)
	ON_BN_CLICKED(IDC_BUTTON_PRINT_LABEL, OnButtonPrintLabel)
	ON_BN_CLICKED(IDC_BUTTON_PRINTER_PAPER, OnButtonPrinterPaper)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLKVCTESTDlg message handlers

BOOL CLKVCTESTDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	for(int i = 1; i < 5; i++)
	{
		CString strPort;
		strPort.Format("COM%d",i);
		m_cboPortName.AddString(strPort);
	}

	for(i = 1; i < 4; i++)
	{
		CString strPort;
		strPort.Format("LPT%d",i);
		m_cboPortName.AddString(strPort);
	}	

	CString strPort;
	strPort.Format("USB");
	m_cboPortName.AddString(strPort);
	strPort.Format("TCP/IP");
	m_cboPortName.AddString(strPort);

	m_cboPortName.SetCurSel(0);

	strPort.Format("115200");
	m_cboBaudRate.AddString(strPort);
	strPort.Format("57600");
	m_cboBaudRate.AddString(strPort);

	strPort.Format("38400");
	m_cboBaudRate.AddString(strPort);
	strPort.Format("19200");
	m_cboBaudRate.AddString(strPort);
	strPort.Format("9600");
	m_cboBaudRate.AddString(strPort);
	strPort.Format("4800");
	m_cboBaudRate.AddString(strPort);

	m_cboBaudRate.SetCurSel(2);
	

	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_STRING)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_NORMAL)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_TEXT)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_SAMPLE)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINTER_STATUS)->EnableWindow(false);

	GetDlgItem(IDC_BUTTON_OPEN_DRAWER)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_DRAWER_STATUS)->EnableWindow(false);

	GetDlgItem(IDC_EDIT_DRIVER_NAME)->EnableWindow(false);

	GetDlgItem(IDC_BUTTON_PRINT_CMDQR)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_SAVEQR)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_DCQR)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_FILEQR)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_PDF417)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_PRINT_LABEL)->EnableWindow(false);

	GetDlgItem(IDC_IPADDRESS1)->EnableWindow(false);
	m_PrinterIP.SetAddress(192, 168, 1, 192);

	GetDlgItem(IDC_BUTTON_PRINTER_PAPER)->EnableWindow(false);

	m_strPrinter = "VENDOR THERMAL PRINTER";
	m_chkUsingDriver.SetCheck(FALSE);
	useprinterdriver = 0;

	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLKVCTESTDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLKVCTESTDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLKVCTESTDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLKVCTESTDlg::OnDestroy() 
{
	CDialog::OnDestroy();

	ClosePort();	

	// TODO: Add your message handler code here
	
}

void CLKVCTESTDlg::OnButtonOpen() 
{
	// TODO: Add your control notification handler code here
	long	portnum, lResult;
	CString strPort, strBaud;
	BYTE	nField0, nField1, nField2, nField3;
	char	MyIP[128];

	int idx = m_cboPortName.GetCurSel();
	if(idx == 8)
	{
		if(m_PrinterIP.IsBlank())
		{
			AfxMessageBox ("Please Type the IP Address");
			return;
		}
		memset(MyIP, 0, sizeof(MyIP));
		m_PrinterIP.GetAddress(nField0, nField1, nField2, nField3);
		wsprintf(MyIP, "%d.%d.%d.%d", nField0, nField1, nField2, nField3);
		lResult = OpenPort(MyIP, 9100);
	} else {
		m_cboPortName.GetLBText(m_cboPortName.GetCurSel(),strPort);
		m_cboBaudRate.GetLBText(m_cboBaudRate.GetCurSel(),strBaud);
		portnum = atoi(strBaud);
		lResult = OpenPort(strPort, portnum);
	}

	if(lResult != 0)
	{
		AfxMessageBox("Open Port Failed");		
		return ;
	}

	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(true);

	GetDlgItem(IDC_BUTTON_PRINT_STRING)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_NORMAL)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_TEXT)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_SAMPLE)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINTER_STATUS)->EnableWindow(true);

	GetDlgItem(IDC_BUTTON_OPEN_DRAWER)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_DRAWER_STATUS)->EnableWindow(true);

	GetDlgItem(IDC_BUTTON_PRINT_CMDQR)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_SAVEQR)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_DCQR)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_FILEQR)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_PDF417)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINT_LABEL)->EnableWindow(true);
	GetDlgItem(IDC_BUTTON_PRINTER_PAPER)->EnableWindow(true);
}

void CLKVCTESTDlg::OnButtonClose() 
{
	// TODO: Add your control notification handler code here
	long lResult = ClosePort();
	if(lResult != 0) {
		MessageBox("Close Port Failed!!!", "Error", MB_OK);
	} else {
		GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(false);

		GetDlgItem(IDC_BUTTON_PRINT_STRING)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_NORMAL)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_TEXT)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_SAMPLE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINTER_STATUS)->EnableWindow(false);

		GetDlgItem(IDC_BUTTON_OPEN_DRAWER)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_DRAWER_STATUS)->EnableWindow(false);

		GetDlgItem(IDC_BUTTON_PRINT_CMDQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_SAVEQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_DCQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_FILEQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_PDF417)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_LABEL)->EnableWindow(false);
	}
}

void CLKVCTESTDlg::OnButtonPrintString() 
{
	// TODO: Add your control notification handler code here
    CString	TempStr;
	CString strCenter = "\x1B\x61\x31"; // �߾�����
    unsigned char strLeftPrintData[10] = "\x1B\x61\x00"; // ��������
    CString strLeft = "\x1B\x61\x30"; // ��������
    CString strRight = "\x1B\x61\x32"; // ����������

    CString strDouble = "\x1B\x21\x20"; // Horizontal Double
    CString strUnderline = "\x1B\x21\x80"; // underline
    CString strDoubleBold = "\x1B\x21\x28"; // Emphasize
    CString strNormal = "\x1B\x21\x02"; // �߾�����
    CString PatialCut = "\x1D\x56\x42\x01"; // Partial Cut.

    
    CString BarCodeHeight = "\x1D\x68\x50"; // ���ڵ� ����
    CString BarCodeWidth = "\x1D\x77\x02"; // ���ڵ� ��
    CString SetHRI = "\x1D\x48\x02"; // HRI���� �μ���ġ �Ʒ��μ�����
    CString SetCode128B = "\x1D\x6B\x49"; // Code128

	long lResult;

    TempStr = "";
    TempStr = TempStr + strDouble;
    TempStr = TempStr + strCenter;
    TempStr = TempStr + "Receipt List\r\n\r\n\r\n";
    TempStr = TempStr + strNormal;
    TempStr = TempStr + strRight;
    TempStr = TempStr + "Right Alignment\r\n";
    TempStr = TempStr + strCenter;
    TempStr = TempStr + "Thank you for coming to our shop!\r\n";
    TempStr = TempStr + "==========================================\r\n";
    TempStr = TempStr + "Chicken                             $10.00\r\n";
    TempStr = TempStr + "Hamburger                           $20.00\r\n";
    TempStr = TempStr + "Pizza                               $30.00\r\n";
    TempStr = TempStr + "Lemons                              $40.00\r\n";
    TempStr = TempStr + "Drink                               $50.00\r\n\r\n";
    TempStr = TempStr + "Excluded tax                       $150.00\r\n";
    TempStr = TempStr + strUnderline;
    TempStr = TempStr + "Tax(5%)                              $7.50\r\n";
    TempStr = TempStr + strDoubleBold;
    TempStr = TempStr + "Total         $157.50\r\n\r\n";
    TempStr = TempStr + strNormal;
    TempStr = TempStr + "Payment                            $200.00\r\n";
    TempStr = TempStr + "Change                              $42.50\r\n\r\n";
    TempStr = TempStr + "==========================================\r\n";
    TempStr = TempStr + strNormal + strCenter;
    TempStr = TempStr + BarCodeHeight; // ���ڵ� ����
    TempStr = TempStr + BarCodeWidth; // ���ڵ� ��
    TempStr = TempStr + SetHRI; // HRI���� �μ���ġ �Ʒ��μ�����
    
//    TempStr = TempStr + SetCode128B + "\x0e" + "\x7B\x42"; //14 => �μ��� ���ڵ� �ڸ��� + Code128b����
    TempStr = TempStr + SetCode128B + "\x12" + "\x7B\x42"; //14 => �μ��� ���ڵ� �ڸ��� + Code128b����
      TempStr = TempStr + "abc4567890123456" + "\x0A"; // �μ��� ���ڵ� ����Ÿ

    if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();
    
    PrintString(TempStr);
    PrintBitmap(".\\SEWOO.bmp", LK_ALIGNMENT_CENTER, 0, 5, 0);

//    PrintString(strCenter + "Test for PrintData Function\n");
//    PrintData(strLeftPrintData, 3);
//    PrintString("Test for PrintData Function\n");

	PrintString(PatialCut);
    
    PrintStop();

    if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintNormal() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

//	PrintBitmap(".\\SEWOO.bmp", 1, 0, 5, 0); // Print Bitmap
	PrintBitmap(".\\����.bmp", 1, 0, 5, 0); // Print Bitmap

	PrintNormal("\x1b|rATEL (123)-456-7890\n\n\n");
	PrintNormal("\x1b|cAThank you for coming to our shop!\n");
	PrintNormal("\x1b|cADate\n\n");
	PrintNormal("Chicken                             $10.00\n");
	PrintNormal("Hamburger                           $20.00\n");
	PrintNormal("Pizza                               $30.00\n");
	PrintNormal("Lemons                              $40.00\n");
	PrintNormal("Drink                               $50.00\n");
	PrintNormal("Excluded tax                       $150.00\n");
	PrintNormal("\x1b|uCTax(5%)                              $7.50\n");
	PrintNormal("\x1b|bC\x1b|2CTotal         $157.50\n\n");
	PrintNormal("Payment                            $200.00\n");
	PrintNormal("Change                              $42.50\n\n");
	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // Print Barcode

//	PrintBitmap(".\\SEWOO.bmp", 1, 0, 5, 1); // Print Bitmap
	PrintBitmap(".\\����.bmp", 1, 0, 5, 1); // Print Bitmap

	PrintNormal("\x1b|fP"); // Partial Cut.

	PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintText() 
{
	// TODO: Add your control notification handler code here
	CString	BarData = "0123456789";
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("Open Port Failed");		
			return;
		}
	}

	PrintStart();
    
	PrintText("Receipt\r\n\r\n\r\n", LK_ALIGNMENT_CENTER, LK_FNT_DEFAULT, LK_TXT_2WIDTH);
    PrintText("TEL (123)-456-7890\r\n", LK_ALIGNMENT_RIGHT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Thank you for coming to our shop!\r\n", LK_ALIGNMENT_CENTER, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Chicken                             $10.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Hamburger                           $20.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Pizza                               $30.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Lemons                              $40.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Drink                               $50.00\r\n\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Excluded tax                       $150.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Tax(5%)                              $7.50\r\n", LK_ALIGNMENT_LEFT, LK_FNT_UNDERLINE, LK_TXT_1WIDTH);
    PrintText("Total         $157.50\r\n\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_2WIDTH);
    PrintText("Payment                            $200.00\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintText("Change                              $42.50\r\n\r\n", LK_ALIGNMENT_LEFT, LK_FNT_DEFAULT, LK_TXT_1WIDTH);
    PrintBarCode(BarData, LK_BCS_Code39, 40, 512, LK_ALIGNMENT_CENTER, LK_HRI_TEXT_BELOW);
    PrintBitmap(".\\SEWOO.bmp", LK_ALIGNMENT_RIGHT, LK_BITMAP_NORMAL, 5, 1);
    PrintNormal("\x1b|fP"); // Partial Cut.
    
    PrintStop();
	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrinterStatus() 
{
	// TODO: Add your control notification handler code here
    long lResult = PrinterSts();
    switch(lResult)
	{
    case LK_STS_NORMAL:
        MessageBox("No Error", "OK", MB_OK);
		break;
    case LK_STS_COVEROPEN:
        MessageBox("Cover Open", "ERROR", MB_OK);
		break;
    case LK_STS_PAPERNEAREMPTY:
        MessageBox("Paper Near Empty", "ERROR", MB_OK);
		break;
    case LK_STS_PAPEREMPTY:
        MessageBox("Paper Empty", "ERROR", MB_OK);
		break;
    case LK_STS_POWEROFF:
        MessageBox("Power Off", "ERROR", MB_OK);
		break;
	}
}

void CLKVCTESTDlg::OnButtonOpenDrawer() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	OpenDrawer(LK_CD_PIN_TWO, 400, 400);

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonDrawerStatus() 
{
	// TODO: Add your control notification handler code here
    long lResult = DrawerSts();
    switch(lResult)
	{
    case LK_CD_STS_CLOSED:
        MessageBox("Cash Drawer Closed", "Cash Drawer Status", MB_OK);
		break;
    case LK_CD_STS_OPENED:
        MessageBox("Cash Drawer Opened", "Cash Drawer Status", MB_OK);
		break;
	}

}

void CLKVCTESTDlg::OnButtonPrintSample() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

	PrintNormal("\x1b|cA\x1b|bC\x1b|2CLUKHAN\n");
	PrintNormal("Homepage : http://www.miniprinter.com\n");
	PrintNormal("==========================================\n");
	PrintNormal("Chicken                             $10.00\n");
	PrintNormal("Hamburger                           $20.00\n");
	PrintNormal("Pizza                               $30.00\n");
	PrintNormal("Lemons                              $40.00\n");
	PrintNormal("Drink                               $50.00\n");
	PrintNormal("Excluded tax                       $150.00\n");
	PrintNormal("\x1b|uCTax(5%)                              $7.50\n");
	PrintNormal("\x1b|bC\x1b|2CTotal         $157.50\n\n");
	PrintNormal("Payment                            $200.00\n");
	PrintNormal("Change                              $42.50\n\n");
	PrintNormal("------------------------------------------\n");
	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintBitmap(".\\SEWOO.bmp", 1, 0, 5, 1);

	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}


void CLKVCTESTDlg::OnCheck1() 
{
	// TODO: Add your control notification handler code here
	useprinterdriver = m_chkUsingDriver.GetCheck();
	if(useprinterdriver)
	{
		GetDlgItem(IDC_EDIT_DRIVER_NAME)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINTER_STATUS)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_DRAWER_STATUS)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_PORTNAME)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(false);

		GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_STRING)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_NORMAL)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_TEXT)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_SAMPLE)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_OPEN_DRAWER)->EnableWindow(true);

		GetDlgItem(IDC_BUTTON_PRINT_CMDQR)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_SAVEQR)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_DCQR)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_FILEQR)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_PRINT_PDF417)->EnableWindow(true);

		GetDlgItem(IDC_IPADDRESS1)->EnableWindow(false);
	} else {
		GetDlgItem(IDC_EDIT_DRIVER_NAME)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINTER_STATUS)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_DRAWER_STATUS)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_PORTNAME)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(true);

		GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_STRING)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_NORMAL)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_TEXT)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_SAMPLE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_OPEN_DRAWER)->EnableWindow(false);

		GetDlgItem(IDC_BUTTON_PRINT_CMDQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_SAVEQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_DCQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_FILEQR)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_PRINT_PDF417)->EnableWindow(false);

		int idx = m_cboPortName.GetCurSel();
		if(idx == 8)
		{
			GetDlgItem(IDC_IPADDRESS1)->EnableWindow(true);
			GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(false);
		} else {
			GetDlgItem(IDC_IPADDRESS1)->EnableWindow(false);
			GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(true);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintCmdqr() 
{
	// TODO: Add your control notification handler code here
	long lResult;
    unsigned char strQRCodeLeft[64] = "QRCode Test Left Alignment";
    unsigned char strQRCodeCenter[64] = "QRCode Test Center Alignment";
    unsigned char strQRCodeRight[64] = "QRCode Test Right Alignment";

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

    PrintQRCode(strQRCodeLeft, 0, 3, 0, LK_ALIGNMENT_LEFT);
    PrintQRCode(strQRCodeCenter, 0, 3, 0, LK_ALIGNMENT_CENTER);
    PrintQRCode((unsigned char *)"QRCode Test Right Alignment", 0, 3, 0, LK_ALIGNMENT_RIGHT);

	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintSaveqr() 
{
	// TODO: Add your control notification handler code here
	long lResult;
    unsigned char strQRCodeLeft[64] = "QRCode Test Left Alignment";
    unsigned char strQRCodeCenter[64] = "QRCode Test Center Alignment";
    unsigned char strQRCodeRight[64] = "QRCode Test Right Alignment";

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

    MakeQRCodeBitmap(strQRCodeLeft, 0, 3, 0, 0, -1, ".\\Left.bmp");
    MakeQRCodeBitmap(strQRCodeCenter, 0, 3, 0, 0, -1, ".\\Center.bmp");
    MakeQRCodeBitmap((unsigned char *)"QRCode Test Right Alignment", 0, 3, 0, 0, -1, ".\\Right.bmp");

	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintDcqr() 
{
	// TODO: Add your control notification handler code here
	long lResult;
//    unsigned char strQRCodeLeft[64] = "QRCode Test Left Alignment";
    unsigned char strQRCodeURL[64] = "http://naver.com";
//    unsigned char strQRCodeCenter[64] = "QRCode Test Center Alignment";
//    unsigned char strQRCodeRight[64] = "QRCode Test Right Alignment";

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

//    PrintQRCodeGenerator(strQRCodeLeft, 0, 3, 0, 0, -1, LK_ALIGNMENT_LEFT);
//    PrintQRCodeGenerator(strQRCodeURL, 0, 3, 0, 0, -1, LK_ALIGNMENT_CENTER);
    PrintQRCodeGenerator((unsigned char *)"http://naver.com", 0, 3, 0, 0, -1, LK_ALIGNMENT_CENTER);
//    PrintQRCodeGenerator((unsigned char *)"http://naver.com", 16, 1, 0, 1, 0, LK_ALIGNMENT_CENTER);
//    PrintQRCodeGenerator(strQRCodeCenter, 0, 3, 0, 0, -1, LK_ALIGNMENT_CENTER);
//    PrintQRCodeGenerator((unsigned char *)"QRCode Test Right Alignment", 0, 3, 0, 0, -1, LK_ALIGNMENT_RIGHT);
//    PrintQRCodeGenerator((unsigned char *)"SEWOO TECH CO.,LTD%0D%0AR & D Department / Senior Engineer%0D%0AJimmy Oh", 0, 3, 0, 0, -1, LK_ALIGNMENT_CENTER);

//	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}


void CLKVCTESTDlg::OnButtonPrintFileqr() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

    PrintQRCodeFromFile(".\\Email.txt", 3, 0, 0, -1, LK_ALIGNMENT_CENTER);

	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrintPdf417() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

    PrintString("PDF417 Column=8, Cell Width=2\n");
    PrintPDF417("0123456789", 0, 8, 2, 1);
    PrintString("PDF417 Column=8, Cell Width=3\n");
    PrintPDF417("0123456789", 0, 8, 3, 1);
    PrintString("PDF417 Column=4, Cell Width=2\n");
    PrintPDF417("0123456789", 0, 4, 2, 2);
    PrintString("PDF417 Column=4, Cell Width=3\n");
    PrintPDF417("0123456789", 0, 4, 3, 2);

	PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
	PrintNormal("\x1b|fP");

    PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnSelchangeComboPortname() 
{
	// TODO: Add your control notification handler code here
	int idx = m_cboPortName.GetCurSel();
	if(idx == 8)
	{
		GetDlgItem(IDC_IPADDRESS1)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(false);
	} else {
		GetDlgItem(IDC_IPADDRESS1)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_PORTNUM)->EnableWindow(true);
	}
}

void CLKVCTESTDlg::OnButtonPrintLabel() 
{
	// TODO: Add your control notification handler code here
	long lResult;

	if(useprinterdriver)
	{
		m_PRINTER.GetWindowText(m_strPrinter);

		lResult = OpenPort(m_strPrinter, 1);
		if(lResult != 0)
		{
			AfxMessageBox("OpenPrinter Failed");		
			return;
		}
	}

	PrintStart();

	PrintNormal("Chicken                             $10.00\n");
	PrintNormal("Hamburger                           $20.00\n");
	PrintNormal("Pizza                               $30.00\n");
	PrintNormal("Lemons                              $40.00\n");
	PrintNormal("Drink                               $50.00\n");
	PrintNormal("Excluded tax                       $150.00\n");
	PrintNormal("\x1b|uCTax(5%)                              $7.50\n");
	PrintNormal("\x1b|bC\x1b|2CTotal         $157.50\n\n");
	PrintNormal("Payment                            $200.00\n");
	PrintNormal("Change                              $42.50\n\n");

	PrintingWidth(404); // 57mm = 404-dot

	SetMasterUnit(0); // Dot units.
	// 7mm = (7 / 25.4) * 180 = 49.6
//	SetLabelSize(512, 180); // height = 1-inch
//	SetLabelSize(512, 318); // height = 45mm
	SetLabelSize(404, 264); // height = 35mm = 248 + 16(QR Code Guard)
	PrintTTFAlign(1, 0, "Arial", 2, 32, "Center Alignment", 0); // TTF, 32-dot. Center align
	PrintTTFAlign(1, 50, "Arial", 1, 32, "101-01-02��TTF Font", 0); // TTF, 32-dot.
	PrintTTFXY(0, 100, "Arial", 2, 32, "AB-45627120", 0); // TTF, 32-dot.
	PrintTTFXY(0, 150, "Arial", 2, 24, "2012-02-03 00:00:04", 0); // TTF, 32-dot.
	PrintTTFXY(0, 186, "Arial", 2, 24, "test : 9999", 0); // TTF, 32-dot.
	PrintTTFXY(0, 222, "Arial", 2, 24, "Qty : 20", 0); // TTF, 32-dot.
	PrintQRCodeAlign(2, 150, (unsigned char *)"QRCode Test Right Alignment", 0, 4, 0, 0, -1); // auto version.
	PrintLabel();
	PrintBarCode("1234567890", 109, 50, 404, 1, 0);
	PrintNormal("---------------------------------\n");
    
	PrintingWidth(512); // 72mm = 512-dot

	PrintNormal("\x1b|fP");

	PrintStop();

	if(useprinterdriver)
	{
		lResult = ClosePort();
		if(lResult != 0)
		{
			MessageBox("ClosePrinter Failed!!!", "Error", MB_OK);
		}
	}
}

void CLKVCTESTDlg::OnButtonPrinterPaper() 
{
	// TODO: Add your control notification handler code here
	BYTE* buf;
	CString str = "Normal Status";
	
	while(true)
	{
		buf = PrintDirectCommand("\x10\x04\x04");

		if(buf[0] == -1)
		{
			AfxMessageBox("Not response");
			return;
		}
		else if(buf[0] == 0)
		{
		}
		else
			break;
	}

	if((buf[0] & 0x0C) == 0x0C)
		str = "Paper Near End";

	if((buf[0] & 0x60) == 0x60)
		str = "Paper Empty";

	AfxMessageBox(str);
	
}
