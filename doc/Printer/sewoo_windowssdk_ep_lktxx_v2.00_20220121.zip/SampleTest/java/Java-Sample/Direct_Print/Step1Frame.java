import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;
import com.sewoo.thermal.jni.LKPOSTOTConst;

public class Step1Frame extends JFrame {

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_PrintString = new JButton();
	JButton jButton_Close = new JButton();

	LKPOSTOT SWLib = null;

	/**Constract "Frame"*/
//	public Step1Frame() {
	public Step1Frame(LKPOSTOT sewoolib) {
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			pack();
			setVisible(true);
			SWLib = sewoolib;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"Receipt");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 300));
		this.setTitle("Step 1  Print String");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);
		jButton_PrintString.setText("Print String");
		jButton_PrintString.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintString_actionPerformed(e);
			}
			});
		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});

		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			   ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 20, 20));

		jPanel_Receipt.add(jButton_PrintString, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 130, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));
	}

	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	//*************************************Button***********************************
	/**
	 * Outline      A method "Print" calls some another method.
	 *             They are method for printing.
	 */
	void jButton_PrintString_actionPerformed(ActionEvent e) {
	        String ESC    = ((char) 0x1b) + "";
	        String LF     = ((char) 0x0a) + "";
	        String SPACES = "                                                                      ";

	        try
	        {
	            do
	            {
		long lResult;

		SWLib.PrintStart();
    
		SWLib.PrintString("Chicken                             $10.00\n");
		SWLib.PrintString("Hamburger                           $20.00\n");
		SWLib.PrintString("Pizza                               $30.00\n");
		SWLib.PrintString("Lemons                              $40.00\n");
		SWLib.PrintString("Drink                               $50.00\n");
		SWLib.PrintString("Excluded tax                       $150.00\n");

		// �̹��� �μ�.
		String bitmapFile = "Logo.bmp";
		File imgFile = new File(bitmapFile);
		if( imgFile.exists() && imgFile.isFile() )
		{
			SWLib.PrintBitmap(bitmapFile, LKPOSTOTConst.LK_ALIGNMENT_CENTER, 0, 5, 0);
		}
		imgFile = null;

		SWLib.PrintNormal(ESC + "|fP"); // Partial Cut.

		SWLib.PrintStop();

	                // exit our printing loop
	            } while (false);
	        }
	        catch(Exception ex)
	        {
			MessageBox.ok(ex.getMessage());
	        }
	        finally
	        {
	        }

	        return;
	}

	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		dispose();
	}
}
