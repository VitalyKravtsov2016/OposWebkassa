import javax.swing.UIManager;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;

public class StepMainFrame extends JFrame{
	String[] portStrings = { "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3", "USB", "TCP/IP" };
	String[] baudStrings = { "115200", "57600", "38400", "19200", "9600", "4800", "2400" };

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_OpenPort = new JButton();
	JButton jButton_ClosePort = new JButton();
	JButton jButton_PrintString = new JButton();
	JButton jButton_PrintNormal = new JButton();
	JButton jButton_PrintText = new JButton();
	JButton jButton_GetPrtStatus = new JButton();
	JButton jButton_OpenDrawer = new JButton();
	JButton jButton_GetDrawerStatus = new JButton();
	JButton jButton_Printer2DBarcode = new JButton();
	JButton jButton_PrintLabel = new JButton();
	JButton jButton_Close = new JButton();

	JLabel lblPORT= new JLabel("Port Name : ");
	JComboBox portList = new JComboBox(portStrings);
	JLabel lblBAUD= new JLabel("BaudRate : ");
	JComboBox baudList = new JComboBox(baudStrings);
	JLabel lblTCP= new JLabel("Printer's IP : ");
	JTextField ipTextField = new JTextField();
    
	LKPOSTOT SWLib = null;

	/**Constract "Frame"*/
	public StepMainFrame()
	{
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			this.pack();
			this.setVisible(true);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"SEWOO TECH Receipt and Drawer");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 400));
		this.setTitle("Java Sample Printing");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);

		portList.setSelectedIndex(7);
		portList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jCombo_PORT_actionPerformed(e);
			}
			});

		baudList.setSelectedIndex(2);
		baudList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jCombo_BAUD_actionPerformed(e);
			}
			});

		ipTextField.setText("Input printer's IP");

		jButton_OpenPort.setText("Open Port");
		jButton_OpenPort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_OpenPort_actionPerformed(e);
			}
			});

		jButton_ClosePort.setText("Close Port");
		jButton_ClosePort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_ClosePort_actionPerformed(e);
			}
			});

		jButton_PrintString.setText("Print String");
		jButton_PrintString.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintString_actionPerformed(e);
			}
			});
		jButton_PrintNormal.setText("Print Normal");
		jButton_PrintNormal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintNormal_actionPerformed(e);
			}
			});
		jButton_PrintText.setText("Print Text");
		jButton_PrintText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintText_actionPerformed(e);
			}
			});
		jButton_GetPrtStatus.setText("Get Printer Status");
		jButton_GetPrtStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_GetPrtStatus_actionPerformed(e);
			}
			});
		jButton_OpenDrawer.setText("Open Drawer");
		jButton_OpenDrawer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_OpenDrawer_actionPerformed(e);
			}
			});
		jButton_GetDrawerStatus.setText("Get Drawer Status");
		jButton_GetDrawerStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_GetDrawerStatus_actionPerformed(e);
			}
			});
		jButton_Printer2DBarcode.setText("Print 2D-Barcode");
		jButton_Printer2DBarcode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Printer2DBarcode_actionPerformed(e);
			}
			});
		jButton_PrintLabel.setText("Print Label");
		jButton_PrintLabel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_PrintLabel_actionPerformed(e);
			}
			});

		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});


		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			   ,GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(15, 0, 0, 0), 0, 0));

		jPanel_Receipt.add(lblPORT, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 150, 0));

		jPanel_Receipt.add(portList, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(lblBAUD, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(baudList, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(lblTCP, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));
		jPanel_Receipt.add(ipTextField, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_OpenPort, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));
		jPanel_Receipt.add(jButton_ClosePort, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintString, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintNormal, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
			,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintText, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
			,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_GetPrtStatus, new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_OpenDrawer, new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_GetDrawerStatus, new GridBagConstraints(0, 9, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_Printer2DBarcode, new GridBagConstraints(0, 10, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		jPanel_Receipt.add(jButton_PrintLabel, new GridBagConstraints(0, 11, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 0, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));

		jButton_OpenPort.setEnabled(true);
		jButton_ClosePort.setEnabled(false);
		jButton_PrintString.setEnabled(false);
		jButton_PrintNormal.setEnabled(false);
		jButton_PrintText.setEnabled(false);
		jButton_GetPrtStatus.setEnabled(false);
		jButton_OpenDrawer.setEnabled(false);
		jButton_GetDrawerStatus.setEnabled(false);
		jButton_Printer2DBarcode.setEnabled(false);
		jButton_PrintLabel.setEnabled(false);

		portList.setEnabled(true);
		baudList.setEnabled(true);
		ipTextField.setEnabled(false);
		
		SWLib = new LKPOSTOT();
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	void jCombo_PORT_actionPerformed(ActionEvent e) {
		int selindex;
		String portName;

		selindex = portList.getSelectedIndex();
		portName = portStrings[selindex];
		if(portName.startsWith("TCP"))
		{
			ipTextField.setEnabled(true);
		} else {
			ipTextField.setEnabled(false);
		}
	}

	void jCombo_BAUD_actionPerformed(ActionEvent e) {
	}

	//******************** Click the Open Port ********************
	void jButton_OpenPort_actionPerformed(ActionEvent e) {
		long lResult, baudrate;
		int selindex;
		String portName, baudName;

		selindex = portList.getSelectedIndex();
		portName = portStrings[selindex];

		selindex = baudList.getSelectedIndex();
		baudName = baudStrings[selindex];

		baudrate = Long.parseLong(baudName);
		
		if (portName.equals("TCP/IP")) {
			lResult = SWLib.OpenPort(ipTextField.getText(), 9100);
		}
		else
		{
			lResult = SWLib.OpenPort(portName, baudrate);
		}
			
		if(lResult != 0)
		{
			MessageBox.ok("Open Port Failed(" + lResult + ")");
			return;
		} else {
			jButton_OpenPort.setEnabled(false);
			jButton_ClosePort.setEnabled(true);
			jButton_PrintString.setEnabled(true);
			jButton_PrintNormal.setEnabled(true);
			jButton_PrintText.setEnabled(true);
			jButton_GetPrtStatus.setEnabled(true);
			jButton_OpenDrawer.setEnabled(true);
			jButton_GetDrawerStatus.setEnabled(true);
			jButton_Printer2DBarcode.setEnabled(true);
			jButton_PrintLabel.setEnabled(true);

			portList.setEnabled(false);
			baudList.setEnabled(false);
			ipTextField.setEnabled(false);
		}
	}

	//******************** Click the Close Port ********************
	void jButton_ClosePort_actionPerformed(ActionEvent e) {
		int selindex;
		String portName;

		long lResult = SWLib.ClosePort();
		if(lResult != 0)
		{
			MessageBox.ok("Close Port Failed(" + lResult + ")");
		} else {
			jButton_OpenPort.setEnabled(true);
			jButton_ClosePort.setEnabled(false);
			jButton_PrintString.setEnabled(false);
			jButton_PrintNormal.setEnabled(false);
			jButton_PrintText.setEnabled(false);
			jButton_GetPrtStatus.setEnabled(false);
			jButton_OpenDrawer.setEnabled(false);
			jButton_GetDrawerStatus.setEnabled(false);
			jButton_Printer2DBarcode.setEnabled(false);
			jButton_PrintLabel.setEnabled(false);

			portList.setEnabled(true);
			baudList.setEnabled(true);

			selindex = portList.getSelectedIndex();
			portName = portStrings[selindex];
			if(portName.startsWith("TCP"))
			{
				ipTextField.setEnabled(true);
			} else {
				ipTextField.setEnabled(false);
			}
		}
	}

	//******************** Click the Print String ********************
	void jButton_PrintString_actionPerformed(ActionEvent e) {
		new Step1Frame(SWLib);
	}

	//******************** Click the Print Normal ********************
	void jButton_PrintNormal_actionPerformed(ActionEvent e) {
		new Step2Frame(SWLib);
	}

	//******************** Click the Print Text ********************
	void jButton_PrintText_actionPerformed(ActionEvent e) {
		new Step3Frame(SWLib);
	}

	//******************** Click the Printer Status ********************
	void jButton_GetPrtStatus_actionPerformed(ActionEvent e) {
		new Step4Frame(SWLib);
	}

	//******************** Click the Open Drawer ********************
	void jButton_OpenDrawer_actionPerformed(ActionEvent e) {
		new Step5Frame(SWLib);
	}

	//******************** Click the Drawer Status ********************
	void jButton_GetDrawerStatus_actionPerformed(ActionEvent e) {
		new Step6Frame(SWLib);
	}

	//******************** Click the 2D-Barcode ********************
	void jButton_Printer2DBarcode_actionPerformed(ActionEvent e) {
		new Step7Frame(SWLib);
	}

	//******************** Click the Print Label ********************
	void jButton_PrintLabel_actionPerformed(ActionEvent e) {
		new Step8Frame(SWLib);
	}

	//******************** Click the Close Button ********************
	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		SWLib = null;
		System.exit(0);
	}
}
