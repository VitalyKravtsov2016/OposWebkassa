import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.sql.Time;

// SEWOO TECH POS PRINTER
import com.sewoo.thermal.jni.LKPOSTOT;
import com.sewoo.thermal.jni.LKPOSTOTConst;

public class Step5Frame extends JFrame {

	JPanel contentPane;
	JPanel jPanel_Receipt = new JPanel();
	TitledBorder titledBorder1;
	GridBagLayout gridBagLayout1 = new GridBagLayout();
	GridBagLayout gridBagLayout2 = new GridBagLayout();
	JButton jButton_Printer2DBarcode = new JButton();
	JButton jButton_Close = new JButton();

	LKPOSTOT SWLib = null;
	String driverName;

	/**Constract "Frame"*/
	public Step5Frame(LKPOSTOT sewoolib, String drvName) {
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		try {
			jbInit();
			pack();
			setVisible(true);
			SWLib = sewoolib;
			driverName = drvName;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**Form the conponent*/
	private void jbInit() throws Exception  {
		contentPane = (JPanel) this.getContentPane();
		titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134)),"Receipt");
		contentPane.setLayout(gridBagLayout1);
		this.setSize(new Dimension(300, 300));
		this.setTitle("Step 5  Print 2D-BarCode");
		jPanel_Receipt.setLayout(gridBagLayout2);
		jPanel_Receipt.setBorder(titledBorder1);
		jButton_Printer2DBarcode.setText("Print 2D-Barcode");
		jButton_Printer2DBarcode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Printer2DBarcode_actionPerformed(e);
			}
			});
		jButton_Close.setText("Close");
		jButton_Close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			jButton_Close_actionPerformed(e);
			}
			});

		contentPane.add(jPanel_Receipt, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			   ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 20, 20));

		jPanel_Receipt.add(jButton_Printer2DBarcode, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
			 ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 10, 5, 10), 130, 0));

		contentPane.add(jButton_Close, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
		  ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));
	}

	/**When the window was closed*/
	protected void processWindowEvent(WindowEvent e){
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING){
			this.closing();
		}
		/**When the window was opened*/
		else if (e.getID() == WindowEvent.WINDOW_OPENED)
		{
		}
	}

	void jButton_Printer2DBarcode_actionPerformed(ActionEvent e) {
	        String ESC    = ((char) 0x1b) + "";
	        String LF     = ((char) 0x0a) + "";
	        String SPACES = "                                                                      ";

	        String strQRCodeLeft = "QRCode Test Left Alignment";
	        String strQRCodeCenter = "QRCode Test Center Alignment";
	        String strQRCodeRight = "QRCode Test Right Alignment";

	        try {
	            do
	            {
	            	long lResult;

		lResult = SWLib.OpenPort(driverName, 1);
		if(lResult != 0)
		{
			MessageBox.ok("Open Port Failed(" + lResult + ")");
			return;
		}

		SWLib.PrintStart();

		SWLib.PrintString("PDF417 Column=8, Cell Width=2\n");
		SWLib.PrintPDF417("0123456789", 0, 8, 2, 1);
		SWLib.PrintString("PDF417 Column=8, Cell Width=3\n");
		SWLib.PrintPDF417("0123456789", 0, 8, 3, 1);
		SWLib.PrintString("PDF417 Column=4, Cell Width=2\n");
		SWLib.PrintPDF417("0123456789", 0, 4, 2, 2);
		SWLib.PrintString("PDF417 Column=4, Cell Width=3\n");
		SWLib.PrintPDF417("0123456789", 0, 4, 3, 2);

		SWLib.PrintQRCode(strQRCodeLeft, 0, 3, 0, LKPOSTOTConst.LK_ALIGNMENT_LEFT);
		SWLib.PrintQRCode(strQRCodeCenter, 0, 3, 0, LKPOSTOTConst.LK_ALIGNMENT_CENTER);
		SWLib.PrintQRCode("QRCode Test Right Alignment", 0, 3, 0, LKPOSTOTConst.LK_ALIGNMENT_RIGHT);

		SWLib.PrintBarCode("1234567890", 109, 40, 512, 1, 2); // POSPrinter
		SWLib.PrintNormal(ESC + "|fP");

		SWLib.PrintStop();

		lResult = SWLib.ClosePort();
		if(lResult != 0)
		{
			MessageBox.ok("Close Port Failed(" + lResult + ")");
		}
	            // exit our printing loop
	            } while (false);
	        }
	        catch(Exception ex)
	        {
			MessageBox.ok(ex.getMessage());
	        }
	        finally
	        {
	        }

	        return;
	}

	void jButton_Close_actionPerformed(ActionEvent e) {
		this.closing();
	}

	void closing()
	{
		dispose();
	}
}
