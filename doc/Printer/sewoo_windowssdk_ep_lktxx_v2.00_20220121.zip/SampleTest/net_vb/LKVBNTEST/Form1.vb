﻿Public Class Form1

    Private useprinterdriver As Boolean
    Private m_strPrinter As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' TODO: Add extra initialization here
        For i As Integer = 1 To 4
            portNameCBox.Items.Add("COM" & i)
        Next

        For i As Integer = 1 To 3
            portNameCBox.Items.Add("LPT" & i)
        Next

        portNameCBox.Items.Add("USB")
        portNameCBox.Items.Add("TCP/IP")
        portNameCBox.SelectedIndex = 0
        ' BaudRate
        baudRateCBox.Items.Add("115200")
        baudRateCBox.Items.Add("57600")
        baudRateCBox.Items.Add("38400")
        baudRateCBox.Items.Add("19200")
        baudRateCBox.Items.Add("9600")
        baudRateCBox.Items.Add("4800")
        baudRateCBox.SelectedIndex = 2

        useprinterdriver = False
        pDriverNameTextBox.Enabled = False
        closeButton.Enabled = False
        cashDrawerOpenButton.Enabled = False
        getCashDrawerStatusButton.Enabled = False
        printStringButton.Enabled = False
        printNormalButton.Enabled = False
        printTextButton.Enabled = False
        printSampleButton.Enabled = False
        getPrinterStatusButton.Enabled = False
        printQRCodeCmdButton.Enabled = False
        saveQRCodeButton.Enabled = False
        printQRCodeGenButton.Enabled = False
        printQRCodeFileButton.Enabled = False
        printPDF417Button.Enabled = False

        txtIP.Text = "192.168.1.192"
        txtIP.Enabled = False
    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles useDriverCheckBox.CheckedChanged
        If useDriverCheckBox.Checked Then
            useprinterdriver = True
            pDriverNameTextBox.Enabled = True
            portNameCBox.Enabled = False
            baudRateCBox.Enabled = False
            openButton.Enabled = False
            closeButton.Enabled = False
            cashDrawerOpenButton.Enabled = True
            getCashDrawerStatusButton.Enabled = False
            printStringButton.Enabled = True
            printNormalButton.Enabled = True
            printTextButton.Enabled = True
            printSampleButton.Enabled = True
            getPrinterStatusButton.Enabled = False
            printQRCodeCmdButton.Enabled = True
            saveQRCodeButton.Enabled = True
            printQRCodeGenButton.Enabled = True
            printQRCodeFileButton.Enabled = True
            printPDF417Button.Enabled = True

            txtIP.Enabled = False
        Else
            Dim sIndex As Integer = portNameCBox.SelectedIndex
            If sIndex = 8 Then
                baudRateCBox.Enabled = False
                txtIP.Enabled = True
            Else
                baudRateCBox.Enabled = True
                txtIP.Enabled = False
            End If

            useprinterdriver = False
            pDriverNameTextBox.Enabled = False
            portNameCBox.Enabled = True
            openButton.Enabled = True
            closeButton.Enabled = False
            cashDrawerOpenButton.Enabled = False
            getCashDrawerStatusButton.Enabled = False
            printStringButton.Enabled = False
            printNormalButton.Enabled = False
            printTextButton.Enabled = False
            printSampleButton.Enabled = False
            getPrinterStatusButton.Enabled = False
            printQRCodeCmdButton.Enabled = False
            saveQRCodeButton.Enabled = False
            printQRCodeGenButton.Enabled = False
            printQRCodeFileButton.Enabled = False
            printPDF417Button.Enabled = False
        End If
    End Sub

    Private Sub exitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitButton.Click
        LKPrint.ClosePort()
        Me.Close()
    End Sub

    Private Sub portNameCBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles portNameCBox.SelectedIndexChanged
        Dim sIndex As Integer = portNameCBox.SelectedIndex
        If sIndex = 8 Then
            baudRateCBox.Enabled = False
            txtIP.Enabled = True
        Else
            baudRateCBox.Enabled = True
            txtIP.Enabled = False
        End If
    End Sub

    Private Sub openButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openButton.Click

        Dim port As String
        Dim lResult As Long = 0
        Dim baudRate As Int32 = 0

        Dim sIndex As Integer = portNameCBox.SelectedIndex
        If sIndex = 8 Then
            lResult = LKPrint.OpenPort(txtIP.Text, 9100)
        Else
            port = portNameCBox.Text
            baudRate = Integer.Parse(baudRateCBox.SelectedItem)
            lResult = LKPrint.OpenPort(port, baudRate)
        End If

        If lResult <> 0 Then
            MessageBox.Show("Open Port Failed", "Error", MessageBoxButtons.OK)
            Return
        Else
            useDriverCheckBox.Enabled = False
            pDriverNameTextBox.Enabled = False
            portNameCBox.Enabled = False
            baudRateCBox.Enabled = False
            openButton.Enabled = False
            closeButton.Enabled = True
            cashDrawerOpenButton.Enabled = True
            getCashDrawerStatusButton.Enabled = True
            printStringButton.Enabled = True
            printNormalButton.Enabled = True
            printTextButton.Enabled = True
            printSampleButton.Enabled = True
            getPrinterStatusButton.Enabled = True
            printQRCodeCmdButton.Enabled = True
            saveQRCodeButton.Enabled = True
            printQRCodeGenButton.Enabled = True
            printQRCodeFileButton.Enabled = True
            printPDF417Button.Enabled = True
        End If

    End Sub

    Private Sub closeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeButton.Click
        Dim lResult As Long = LKPrint.ClosePort()
        If lResult <> 0 Then
            MessageBox.Show("Close Port Failed", "Error", MessageBoxButtons.OK)
        Else
            Dim sIndex As Integer = portNameCBox.SelectedIndex
            If sIndex > 8 Then
                baudRateCBox.Enabled = False
            Else
                baudRateCBox.Enabled = True
            End If
            useDriverCheckBox.Enabled = True
            pDriverNameTextBox.Enabled = True
            portNameCBox.Enabled = True
            openButton.Enabled = True
            closeButton.Enabled = False
            cashDrawerOpenButton.Enabled = False
            getCashDrawerStatusButton.Enabled = False
            printStringButton.Enabled = False
            printNormalButton.Enabled = False
            printTextButton.Enabled = False
            printSampleButton.Enabled = False
            getPrinterStatusButton.Enabled = False
            printQRCodeCmdButton.Enabled = False
            saveQRCodeButton.Enabled = False
            printQRCodeGenButton.Enabled = False
            printQRCodeFileButton.Enabled = False
            printPDF417Button.Enabled = False
        End If

    End Sub

    Private Sub cashDrawerOpenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cashDrawerOpenButton.Click
        Dim lResult As Long
        If useprinterdriver Then
            ' Text Box 로 부터 받음
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.OpenDrawer(LKPrint.LK_CD_PIN_TWO, 400, 400)

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub getCashDrawerStatusButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles getCashDrawerStatusButton.Click
        Dim lResult As Long = LKPrint.DrawerSts()
        Select Case lResult
            Case LKPrint.LK_CD_STS_CLOSED
                MessageBox.Show("Cash Drawer Closed", "Cash Drawer Status", MessageBoxButtons.OK)
                Exit Select
            Case LKPrint.LK_CD_STS_OPENED
                MessageBox.Show("Cash Drawer Opened", "Cash Drawer Status", MessageBoxButtons.OK)
                Exit Select
        End Select
    End Sub

    Private Sub printStringButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printStringButton.Click
        ' TODO: Add your control notification handler code here
        Dim TempStr As String
        Dim strCenter As String = ChrW(27) & "a1"
        ' 중앙정렬
        'unsigned char strLeftPrintData[10] = "\x1B\x61\x00"; // 왼쪽정렬
        'string strLeftPrintData = "\x1B\x61\x00"; // 왼쪽정렬
        Dim strLeft As String = ChrW(27) & "a0"
        ' 왼쪽정렬
        Dim strRight As String = ChrW(27) & "a2"
        ' 오른쪽정렬
        Dim strDouble As String = ChrW(27) & "! "
        ' Horizontal Double
        Dim strUnderline As String = ChrW(27) & "!" & ChrW(128)
        ' underline
        Dim strDoubleBold As String = ChrW(27) & "!("
        ' Emphasize
        Dim strNormal As String = ChrW(27) & "!" & ChrW(2)
        ' 중앙정렬
        Dim PartialCut As String = ChrW(29) & "VB" & ChrW(1)
        ' Partial Cut.

        Dim BarCodeHeight As String = ChrW(29) & "hP"
        ' 바코드 높이
        Dim BarCodeWidth As String = ChrW(29) & "w" & ChrW(2)
        ' 바코드 폭
        Dim SetHRI As String = ChrW(29) & "H" & ChrW(2)
        ' HRI문자 인쇄위치 아래인쇄지정
        Dim SetCode128B As String = ChrW(29) & "kI"
        ' Code128
        Dim lResult As Long

        TempStr = ""
        TempStr = TempStr + strDouble
        TempStr = TempStr + strCenter
        TempStr = TempStr & "Receipt List" & vbCr & vbLf & vbCr & vbLf & vbCr & vbLf
        TempStr = TempStr + strNormal
        TempStr = TempStr + strRight
        TempStr = TempStr & "Right Alignment" & vbCr & vbLf
        TempStr = TempStr + strCenter
        TempStr = TempStr & "Thank you for coming to our shop!" & vbCr & vbLf
        TempStr = TempStr & "==========================================" & vbCr & vbLf
        TempStr = TempStr & "Chicken                             $10.00" & vbCr & vbLf
        TempStr = TempStr & "Hamburger                           $20.00" & vbCr & vbLf
        TempStr = TempStr & "Pizza                               $30.00" & vbCr & vbLf
        TempStr = TempStr & "Lemons                              $40.00" & vbCr & vbLf
        TempStr = TempStr & "Drink                               $50.00" & vbCr & vbLf & vbCr & vbLf
        TempStr = TempStr & "Excluded tax                       $150.00" & vbCr & vbLf
        TempStr = TempStr + strUnderline
        TempStr = TempStr & "Tax(5%)                              $7.50" & vbCr & vbLf
        TempStr = TempStr + strDoubleBold
        TempStr = TempStr & "Total         $157.50" & vbCr & vbLf & vbCr & vbLf
        TempStr = TempStr + strNormal
        TempStr = TempStr & "Payment                            $200.00" & vbCr & vbLf
        TempStr = TempStr & "Change                              $42.50" & vbCr & vbLf & vbCr & vbLf
        TempStr = TempStr & "==========================================" & vbCr & vbLf
        TempStr = TempStr + strNormal + strCenter
        TempStr = TempStr + BarCodeHeight
        ' 바코드 높이
        TempStr = TempStr + BarCodeWidth
        ' 바코드 폭
        TempStr = TempStr + SetHRI
        ' HRI문자 인쇄위치 아래인쇄지정
        TempStr = TempStr + SetCode128B & ChrW(14) & "{B"
        '14 => 인쇄할 바코드 자리수 + Code128b선택
        TempStr = TempStr & "abc456789012" & vbLf
        ' 인쇄할 바코드 데이타

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()
        LKPrint.PrintString(TempStr)
        LKPrint.PrintBitmap(".\Logo.bmp", LKPrint.LK_ALIGNMENT_CENTER, 0, 5, 0)

        '    PrintString(strCenter + "Test for PrintData Function\n");
        '    PrintData(strLeftPrintData, 3);
        '    PrintString("Test for PrintData Function\n");

        LKPrint.PrintString(PartialCut)

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printNormalButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printNormalButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintBitmap(".\Logo.bmp", 1, 0, 5, 0)
        ' Print Bitmap
        LKPrint.PrintNormal(ChrW(27) & "|rATEL (123)-456-7890" & vbLf & vbLf & vbLf)
        LKPrint.PrintNormal(ChrW(27) & "|cAThank you for coming to our shop!" & vbLf)
        LKPrint.PrintNormal(ChrW(27) & "|cADate" & vbLf & vbLf)
        LKPrint.PrintNormal("Chicken                             $10.00" & vbLf)
        LKPrint.PrintNormal("Hamburger                           $20.00" & vbLf)
        LKPrint.PrintNormal("Pizza                               $30.00" & vbLf)
        LKPrint.PrintNormal("Lemons                              $40.00" & vbLf)
        LKPrint.PrintNormal("Drink                               $50.00" & vbLf)
        LKPrint.PrintNormal("Excluded tax                       $150.00" & vbLf)
        LKPrint.PrintNormal(ChrW(27) & "|uCTax(5%)                              $7.50" & vbLf)
        LKPrint.PrintNormal(ChrW(27) & "|bC" & ChrW(27) & "|2CTotal         $157.50" & vbLf & vbLf)
        LKPrint.PrintNormal("Payment                            $200.00" & vbLf)
        LKPrint.PrintNormal("Change                              $42.50" & vbLf & vbLf)
        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' Print Barcode
        LKPrint.PrintBitmap(".\LUKHAN-logo.bmp", 1, 0, 5, 1)
        ' Print Bitmap
        LKPrint.PrintNormal(ChrW(27) & "|fP")
        ' Partial Cut.
        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printTextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printTextButton.Click
        ' TODO: Add your control notification handler code here
        Dim BarData As String = "0123456789"
        Dim lResult As Long

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("Open Port Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintText("Receipt" & vbCr & vbLf & vbCr & vbLf & vbCr & vbLf, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH)
        LKPrint.PrintText("TEL (123)-456-7890" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_RIGHT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Thank you for coming to our shop!" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Chicken                             $10.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Hamburger                           $20.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Pizza                               $30.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Lemons                              $40.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Drink                               $50.00" & vbCr & vbLf & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Excluded tax                       $150.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Tax(5%)                              $7.50" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_UNDERLINE, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Total         $157.50" & vbCr & vbLf & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH)
        LKPrint.PrintText("Payment                            $200.00" & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintText("Change                              $42.50" & vbCr & vbLf & vbCr & vbLf, LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH)
        LKPrint.PrintBarCode(BarData, LKPrint.LK_BCS_Code39, 40, 512, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW)
        LKPrint.PrintBitmap(".\Logo.bmp", LKPrint.LK_ALIGNMENT_RIGHT, LKPrint.LK_BITMAP_NORMAL, 5, 1)
        LKPrint.CutPaper()

        LKPrint.PrintStop()
        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printSampleButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printSampleButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintNormal("EAN13 barcode" & vbCrLf)
        LKPrint.PrintBarCode("9788989975939", LKPrint.LK_BCS_EAN13, 40, 512, 1, 2)
        LKPrint.PrintNormal("EAN8 barcode" & vbCrLf)
        LKPrint.PrintBarCode("88017075", LKPrint.LK_BCS_EAN8, 40, 512, 1, 2)
        LKPrint.PrintNormal("3 of 9 barcode" & vbCrLf)
        LKPrint.PrintBarCode("1234567890", LKPrint.LK_BCS_Code39, 40, 512, 1, 2)
        LKPrint.PrintNormal("Code 93 barcode" & vbCrLf)
        LKPrint.PrintBarCode("0123498765", LKPrint.LK_BCS_Code93, 40, 512, 1, 2)
        LKPrint.PrintNormal("Interleaved 2 of 5 barcode" & vbCrLf)
        LKPrint.PrintBarCode("0987654321", LKPrint.LK_BCS_ITF, 40, 512, 1, 2)
        LKPrint.PrintNormal("Code 128 A barcode" & vbCrLf)
        LKPrint.PrintBarCode("{ACODE 128", LKPrint.LK_BCS_Code128, 40, 512, 1, 2)
        LKPrint.PrintNormal("Code 128 B barcode" & vbCrLf)
        LKPrint.PrintBarCode("{BCode 128", LKPrint.LK_BCS_Code128, 40, 512, 1, 2)
        LKPrint.PrintNormal("Code 128 C barcode" & vbCrLf)
        LKPrint.PrintBarCode("{C12345", LKPrint.LK_BCS_Code128, 40, 512, 1, 2)
        LKPrint.PrintNormal("Codabar barcode" & vbCrLf)
        LKPrint.PrintBarCode("A1029384756A", LKPrint.LK_BCS_Codabar, 40, 512, 1, 2)

        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub getPrinterStatusButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles getPrinterStatusButton.Click
        Dim lResult As Long = LKPrint.PrinterSts()
        Select Case lResult
            Case LKPrint.LK_STS_NORMAL
                MessageBox.Show("No Error", "OK", MessageBoxButtons.OK)
                Exit Select
            Case LKPrint.LK_STS_COVEROPEN
                MessageBox.Show("Cover Open", "ERROR", MessageBoxButtons.OK)
                Exit Select
            Case LKPrint.LK_STS_PAPERNEAREMPTY
                MessageBox.Show("Paper Near Empty", "ERROR", MessageBoxButtons.OK)
                Exit Select
            Case LKPrint.LK_STS_PAPEREMPTY
                MessageBox.Show("Paper Empty", "ERROR", MessageBoxButtons.OK)
                Exit Select
            Case LKPrint.LK_STS_POWEROFF
                MessageBox.Show("Power Off", "ERROR", MessageBoxButtons.OK)
                Exit Select
        End Select

    End Sub

    Private Sub printQRCodeCmdButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printQRCodeCmdButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long
        Dim strQRCodeLeft As String = "QRCode Test Left Alignment"
        Dim strQRCodeCenter As String = "QRCode Test Center Alignment"
        Dim strQRCodeRight As String = "QRCode Test Right Alignment"

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintQRCode(strQRCodeLeft, 0, 3, 0, LKPrint.LK_ALIGNMENT_LEFT)
        LKPrint.PrintQRCode(strQRCodeCenter, 0, 3, 0, LKPrint.LK_ALIGNMENT_CENTER)
        LKPrint.PrintQRCode(strQRCodeRight, 0, 3, 0, LKPrint.LK_ALIGNMENT_RIGHT)

        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' POSPrinter
        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub saveQRCodeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saveQRCodeButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long
        Dim strQRCodeLeft As String = "QRCode Test Left Alignment"
        Dim strQRCodeCenter As String = "QRCode Test Center Alignment"
        Dim strQRCodeRight As String = "QRCode Test Right Alignment"


        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.MakeQRCodeBitmap(strQRCodeLeft, 0, 3, 0, 0, -1, _
         ".\Left.bmp")
        LKPrint.MakeQRCodeBitmap(strQRCodeCenter, 0, 3, 0, 0, -1, _
         ".\Center.bmp")
        LKPrint.MakeQRCodeBitmap(strQRCodeRight, 0, 3, 0, 0, -1, _
         ".\Right.bmp")

        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' POSPrinter
        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()


        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printQRCodeGenButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printQRCodeGenButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long
        Dim strQRCodeLeft As String = "QRCode Test Left Alignment"
        Dim strQRCodeCenter As String = "QRCode Test Center Alignment"
        Dim strQRCodeRight As String = "QRCode Test Right Alignment"


        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintQRCodeGenerator(strQRCodeLeft, 0, 3, 0, 0, -1, _
         LKPrint.LK_ALIGNMENT_LEFT)
        LKPrint.PrintQRCodeGenerator(strQRCodeCenter, 0, 3, 0, 0, -1, _
         LKPrint.LK_ALIGNMENT_CENTER)
        LKPrint.PrintQRCodeGenerator("QRCode Test Right Alignment", 0, 3, 0, 0, -1, _
         LKPrint.LK_ALIGNMENT_RIGHT)
        LKPrint.PrintQRCodeGenerator("SEWOO TECH CO.,LTD%0D%0AR & D Department / Senior Engineer%0D%0AJimmy Oh", 0, 3, 0, 0, -1, _
         LKPrint.LK_ALIGNMENT_CENTER)

        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' POSPrinter
        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printQRCodeFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printQRCodeFileButton.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintQRCodeFromFile(".\Email.txt", 3, 0, 0, -1, LKPrint.LK_ALIGNMENT_CENTER)

        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' POSPrinter
        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    Private Sub printPDF417Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPDF417Button.Click
        ' TODO: Add your control notification handler code here
        Dim lResult As Long

        If useprinterdriver Then
            m_strPrinter = pDriverNameTextBox.Text.ToString()
            lResult = LKPrint.OpenPort(m_strPrinter, 1)
            If lResult <> 0 Then
                MessageBox.Show("OpenPrinter Failed", "Error", MessageBoxButtons.OK)
                Return
            End If
        End If

        LKPrint.PrintStart()

        LKPrint.PrintString("PDF417 Column=8, Cell Width=2" & vbLf)
        LKPrint.PrintPDF417("0123456789", 0, 8, 2, 1)
        LKPrint.PrintString("PDF417 Column=8, Cell Width=3" & vbLf)
        LKPrint.PrintPDF417("0123456789", 0, 8, 3, 1)
        LKPrint.PrintString("PDF417 Column=4, Cell Width=2" & vbLf)
        LKPrint.PrintPDF417("0123456789", 0, 4, 2, 2)
        LKPrint.PrintString("PDF417 Column=4, Cell Width=3" & vbLf)
        LKPrint.PrintPDF417("0123456789", 0, 4, 3, 2)

        LKPrint.PrintBarCode("1234567890", 109, 40, 512, 1, 2)
        ' POSPrinter
        LKPrint.PrintNormal(ChrW(27) & "|fP")

        LKPrint.PrintStop()

        If useprinterdriver Then
            lResult = LKPrint.ClosePort()
            If lResult <> 0 Then
                MessageBox.Show("ClosePrinter Failed!!!", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

End Class