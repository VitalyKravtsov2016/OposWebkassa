﻿Imports System
Imports System.Runtime.InteropServices
Imports Microsoft.VisualBasic

Module LKPrint

    ' Dll file name.
    Public Const SEWOODIR As String = "LKPOSTOT.dll"

    <DllImport(SEWOODIR, EntryPoint:="OpenPort")> _
        Public Function OpenPort(ByVal PortName As String, ByVal BaudRate As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="ClosePort")> _
    Public Function ClosePort() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintBitmap")> _
       Public Function PrintBitmap(ByVal BitmapFile As String, ByVal Alignment As Int32, ByVal Options As Int32, ByVal Brightness As Int32, ByVal ImageMode As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintString")> _
        Public Function PrintString(ByVal Data As String) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintText")> _
        Public Function PrintText(ByVal Data As String, ByVal Alignment As Int32, ByVal Options As Int32, ByVal TextSize As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintNormal")> _
        Public Function PrintNormal(ByVal Data As String) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintBarCode")> _
        Public Function PrintBarCode(ByVal Data As String, ByVal Symbology As Int32, ByVal Height As Int32, ByVal Width As Int32, ByVal Alignment As Int32, ByVal TextPosition As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrinterSts")> _
    Public Function PrinterSts() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="OpenDrawer")> _
        Public Function OpenDrawer(ByVal DrawerPinNum As Int32, ByVal PulseOnTime As Int32, ByVal PulseOffTime As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="DrawerSts")> _
    Public Function DrawerSts() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="CutPaper")> _
    Public Function CutPaper() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintStart")> _
    Public Function PrintStart() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintStop")> _
    Public Function PrintStop() As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintData")> _
        Public Function PrintData(ByVal Data As String, ByVal Size As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintText2Image")> _
        Public Function PrintText2Image(ByVal FontName As String, ByVal FontStyle As Int32, ByVal FontDotSize As Int32, ByVal TextData As String, ByVal ReversePrint As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintText2ImageAlignment")> _
        Public Function PrintText2ImageAlignment(ByVal FontName As String, ByVal FontStyle As Int32, ByVal FontDotSize As Int32, ByVal TextData As String, ByVal ReversePrint As Int32, ByVal Alignment As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="OutputCompletePrinting")> _
        Public Function OutputCompletePrinting(ByVal TimeDelay As Int32) As Int32
    End Function
    ' Printing QRCode BarCode Function.
    <DllImport(SEWOODIR, EntryPoint:="PrintQRCode")> _
        Public Function PrintQRCode(ByVal Data As String, ByVal Size As Int32, ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Alignment As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="MakeQRCodeBitmap")> _
        Public Function MakeQRCodeBitmap(ByVal Data As String, ByVal Size As Int32, ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Version As Int32, ByVal MaskPattern As Int32, ByVal BitmapName As String) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintQRCodeGenerator")> _
        Public Function PrintQRCodeGenerator(ByVal Data As String, ByVal Size As Int32, ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Version As Int32, ByVal MaskPattern As Int32, ByVal Alignment As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintQRCodeFromFile")> _
        Public Function PrintQRCodeFromFile(ByVal File As String, ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Version As Int32, ByVal MaskPattern As Int32, ByVal Alignment As Int32) As Int32
    End Function
    ' Printing PDF417 BarCode Function
    <DllImport(SEWOODIR, EntryPoint:="PrintPDF417")> _
        Public Function PrintPDF417(ByVal PdfData As String, ByVal DataLength As Int32, ByVal NumberOfColumns As Int32, ByVal CellWidth As Int32, ByVal Alignment As Int32) As Int32
    End Function
    ' Page Mode Function.
    <DllImport(SEWOODIR, EntryPoint:="SetPageMode")> _
        Public Function SetPageMode(ByVal IsPageMode As Boolean) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="SetPrintDirection")> _
        Public Function SetPrintDirection(ByVal pDirect As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="SetPrintingArea")>
    Public Function SetPrintingArea(ByVal PageHeight As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetAbsoluteVertical")>
    Public Function SetAbsoluteVertical(ByVal AbsolutePosition As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetRelativeVertical")>
    Public Function SetRelativeVertical(ByVal RelativePosition As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="LineFeed")>
    Public Function LineFeed(ByVal LFCount As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SaveNVBitmap")>
    Public Function SaveNVBitmap(ByVal SaveBitmapNameList As String, ByVal Brightness As Int32, ByVal ImageMode As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="DeleteNVBitmap")>
    Public Function DeleteNVBitmap() As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetMasterUnit")>
    Public Function SetMasterUnit(ByVal UnitMeasure As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintingWidth")>
    Public Function PrintingWidth(ByVal pwidth As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="BlackMarkON")>
    Public Function BlackMarkON(ByVal FeedValue As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="BlackMarkSearch")>
    Public Function BlackMarkSearch() As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetLabelSize")>
    Public Function SetLabelSize(ByVal widthsize As Int32, ByVal heightsize As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintLabel")>
    Public Function PrintLabel() As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintTTFXY")>
    Public Function PrintTTFXY(ByVal BaseUnitX As Int32, ByVal BaseUnitY As Int32,
                               ByVal FontName As String, ByVal FontStyle As Int32,
                               ByVal FontDotSize As Int32, ByVal TextData As String, ByVal ReversePrint As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintBitmapXY")>
    Public Function PrintBitmapXY(ByVal BaseUnitX As Int32, ByVal BaseUnitY As Int32, ByVal BitmapFile As String) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintQRCodeXY")>
    Public Function PrintQRCodeXY(ByVal BaseUnitX As Int32, ByVal BaseUnitY As Int32, ByVal Data As String, ByVal Size As Int32,
                                  ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Version As Int32, ByVal MaskPattern As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintTTFAlign")>
    Public Function PrintTTFAlign(ByVal Alignment As Int32, ByVal BaseUnitY As Int32, ByVal FontName As String, ByVal FontStyle As Int32,
                                  ByVal FontDotSize As Int32, ByVal TextData As String, ByVal ReversePrint As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintBitmapAlign")>
    Public Function PrintBitmapAlign(ByVal BaseUnitX As Int32, ByVal BaseUnitY As Int32, ByVal BitmapFile As String) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintQRCodeAlign")>
    Public Function PrintQRCodeAlign(ByVal Alignment As Int32, ByVal BaseUnitY As Int32, ByVal data As String, ByVal Size As Int32,
                                     ByVal ModuleSize As Int32, ByVal ECLevel As Int32, ByVal Version As Int32, ByVal MaskPattern As Int32) As Int32
    End Function
    <DllImport(SEWOODIR, EntryPoint:="PrintTextLS")>
    Public Function PrintTextLS(ByVal Data As String, ByVal Alignment As Int32, ByVal Options As Int32, ByVal TextSize As Int32,
                                ByVal LineSpacing As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="FeedDot")>
    Public Function FeedDot(ByVal dotvalue As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetAlignment")>
    Public Function SetAlignment(ByVal Alignment As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetMagnify")>
    Public Function SetMagnify(ByVal WidthandHeight As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetAttribute")>
    Public Function SetAttribute(ByVal WidthandHeight As Int32) As Int32
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SendCommand")>
    Public Function SendCommand(ByVal Cmd As IntPtr, ByVal size As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="ReadData")>
    Public Function ReadData(ByVal ReadBuf As String, ByVal millisecond As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetEncoding")>
    Public Function SetEncoding(ByVal iEncoding As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="Rotation")>
    Public Function Rotation(ByVal pRotate As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetAbsoluteHorizontal")>
    Public Function SetAbsoluteHorizontal(ByVal AbsolutePosition As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetMoveToXY")>
    Public Function SetMoveToXY(ByVal AbsoluteXPosition As Long, ByVal AbsoluteYPosition As Long) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="GetFeedStatus")>
    Public Function GetFeedStatus() As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintDirectCommand")>
    Public Function PrintDirectCommand(ByVal Data As String) As Byte()
    End Function

    <DllImport(SEWOODIR, EntryPoint:="SetTransactionMode")> _
    Public Function SetTransactionMode(ByVal IsMode As Boolean) As Long
    End Function

    <DllImport(SEWOODIR, EntryPoint:="PrintTransactionMode")>
    Public Function PrintTransactionMode() As Long
    End Function

    'Method return value
    Public Const LK_SUCCESS As Integer = 0
    Public Const LK_CREATE_ERROR As Integer = 1
    Public Const LK_NOT_OPENED As Integer = 2
    Public Const LK_TIMEOUT As Integer = -1

    ' Printer Status flag
    ' Printer Status flag
    Public Const LK_STS_NORMAL As Integer = 0
    Public Const LK_STS_COVEROPEN As Integer = 1
    Public Const LK_STS_PAPERNEAREMPTY As Integer = 2
    Public Const LK_STS_PAPEREMPTY As Integer = 4
    Public Const LK_STS_POWEROFF As Integer = 8

    ' Cash Drawer Status flag
    Public Const LK_CD_STS_CLOSED As Integer = 0
    Public Const LK_CD_STS_OPENED As Integer = 1

    ' Cash Drawer Kick-out Connector Pin
    Public Const LK_CD_PIN_TWO As Integer = 2
    Public Const LK_CD_PIN_FIVE As Integer = 5

    ' Alignment Code
    Public Const LK_ALIGNMENT_LEFT As Integer = 0
    Public Const LK_ALIGNMENT_CENTER As Integer = 1
    Public Const LK_ALIGNMENT_RIGHT As Integer = 2

    ' Bitmap Size
    Public Const LK_BITMAP_NORMAL As Integer = 0
    Public Const LK_BITMAP_WIDTH_DOUBLE As Integer = 1
    Public Const LK_BITMAP_HEIGHT_DOUBLE As Integer = 2
    Public Const LK_BITMAP_WIDTH_HEIGHT_DOUBLE As Integer = 3

    ' Bitmap Image Mode
    Public Const LK_BITMAP_NO_DITHER As Integer = 0
    Public Const LK_BITMAP_ERROR_DIFFUSION As Integer = 1
    Public Const LK_BITMAP_ORDERED_DITHER As Integer = 2

    'Text Attribute
    'Font Attribute default value : not Bold, FontA, not Underline, not reverse
    Public Const LK_FNT_DEFAULT As Integer = 0
    Public Const LK_FNT_FONTB As Integer = 1
    Public Const LK_FNT_BOLD As Integer = 8
    Public Const LK_FNT_UNDERLINE As Integer = 128

    ' Text Size Attribute
    Public Const LK_TXT_1WIDTH As Integer = 0
    Public Const LK_TXT_2WIDTH As Integer = 16
    Public Const LK_TXT_3WIDTH As Integer = 32
    Public Const LK_TXT_4WIDTH As Integer = 48
    Public Const LK_TXT_5WIDTH As Integer = 64
    Public Const LK_TXT_6WIDTH As Integer = 80
    Public Const LK_TXT_7WIDTH As Integer = 96
    Public Const LK_TXT_8WIDTH As Integer = 112

    Public Const LK_TXT_1HEIGHT As Integer = 0
    Public Const LK_TXT_2HEIGHT As Integer = 1
    Public Const LK_TXT_3HEIGHT As Integer = 2
    Public Const LK_TXT_4HEIGHT As Integer = 3
    Public Const LK_TXT_5HEIGHT As Integer = 4
    Public Const LK_TXT_6HEIGHT As Integer = 5
    Public Const LK_TXT_7HEIGHT As Integer = 6
    Public Const LK_TXT_8HEIGHT As Integer = 7

    ' Barcode
    Public Const LK_BCS_PDF417 As Integer = 200
    Public Const LK_BCS_MAXICODE As Integer = 201
    Public Const LK_BCS_QRCODE As Integer = 202

    Public Const LK_BCS_UPCA As Integer = 101
    Public Const LK_BCS_UPCE As Integer = 102
    Public Const LK_BCS_EAN8 As Integer = 103
    Public Const LK_BCS_EAN13 As Integer = 104
    Public Const LK_BCS_JAN8 As Integer = 105
    Public Const LK_BCS_JAN13 As Integer = 106
    Public Const LK_BCS_ITF As Integer = 107
    Public Const LK_BCS_Codabar As Integer = 108
    Public Const LK_BCS_Code39 As Integer = 109
    Public Const LK_BCS_Code93 As Integer = 110
    Public Const LK_BCS_Code128 As Integer = 111

    ' Barcode text position
    Public Const LK_HRI_TEXT_NONE As Integer = 0
    Public Const LK_HRI_TEXT_ABOVE As Integer = 1
    Public Const LK_HRI_TEXT_BELOW As Integer = 2

    ' True-Type Font Style
    Public Const LK_TTF_THIN As Integer = 0
    Public Const LK_TTF_NORMAL As Integer = 1
    Public Const LK_TTF_BOLD As Integer = 2
    Public Const LK_TTF_ITALIC As Integer = 16 '0x10
    Public Const LK_TTF_UNDERLINE As Integer = 32 '0x20

    ' True-Type Font Reverse Print
    Public Const LK_TTF_REVERSE_NO As Integer = 0
    Public Const LK_TTF_REVERSE_YES As Integer = 1

    ' QRCode Error Correction Level.
    Public Const LK_QRCODE_EC_LEVEL_L As Integer = 0
    Public Const LK_QRCODE_EC_LEVEL_M As Integer = 1
    Public Const LK_QRCODE_EC_LEVEL_Q As Integer = 2
    Public Const LK_QRCODE_EC_LEVEL_H As Integer = 3

    ' QRCode mask pattern.
    Public Const LK_QRCODE_MASK_AUTO As Integer = -1
    Public Const LK_QRCODE_MASK_0 As Integer = 0
    Public Const LK_QRCODE_MASK_1 As Integer = 1
    Public Const LK_QRCODE_MASK_2 As Integer = 2
    Public Const LK_QRCODE_MASK_3 As Integer = 3
    Public Const LK_QRCODE_MASK_4 As Integer = 4
    Public Const LK_QRCODE_MASK_5 As Integer = 5
    Public Const LK_QRCODE_MASK_6 As Integer = 6
    Public Const LK_QRCODE_MASK_7 As Integer = 7

    ' QRCode Symbol version.
    Public Const LK_QRCODE_VERSION_00 As Integer = 0 ' Auto.
    Public Const LK_QRCODE_VERSION_01 As Integer = 1 ' Version 1
    Public Const LK_QRCODE_VERSION_02 As Integer = 2 ' Version 2
    Public Const LK_QRCODE_VERSION_03 As Integer = 3 ' Version 3
    Public Const LK_QRCODE_VERSION_04 As Integer = 4 ' Version 4
    Public Const LK_QRCODE_VERSION_05 As Integer = 5 ' Version 5
    Public Const LK_QRCODE_VERSION_06 As Integer = 6 ' Version 6
    Public Const LK_QRCODE_VERSION_07 As Integer = 7 ' Version 7
    Public Const LK_QRCODE_VERSION_08 As Integer = 8 ' Version 8
    Public Const LK_QRCODE_VERSION_09 As Integer = 9 ' Version 9
    Public Const LK_QRCODE_VERSION_10 As Integer = 10 ' Version 10
    Public Const LK_QRCODE_VERSION_11 As Integer = 11 ' Version 11
    Public Const LK_QRCODE_VERSION_12 As Integer = 12 ' Version 12
    Public Const LK_QRCODE_VERSION_13 As Integer = 13 ' Version 13
    Public Const LK_QRCODE_VERSION_14 As Integer = 14 ' Version 14
    Public Const LK_QRCODE_VERSION_15 As Integer = 15 ' Version 15
    Public Const LK_QRCODE_VERSION_16 As Integer = 16 ' Version 16
    Public Const LK_QRCODE_VERSION_17 As Integer = 17 ' Version 17
    Public Const LK_QRCODE_VERSION_18 As Integer = 18 ' Version 18
    Public Const LK_QRCODE_VERSION_19 As Integer = 19 ' Version 19
    Public Const LK_QRCODE_VERSION_20 As Integer = 20 ' Version 20
    Public Const LK_QRCODE_VERSION_21 As Integer = 21 ' Version 21
    Public Const LK_QRCODE_VERSION_22 As Integer = 22 ' Version 22
    Public Const LK_QRCODE_VERSION_23 As Integer = 23 ' Version 23
    Public Const LK_QRCODE_VERSION_24 As Integer = 24 ' Version 24
    Public Const LK_QRCODE_VERSION_25 As Integer = 25 ' Version 25
    Public Const LK_QRCODE_VERSION_26 As Integer = 26 ' Version 26
    Public Const LK_QRCODE_VERSION_27 As Integer = 27 ' Version 27
    Public Const LK_QRCODE_VERSION_28 As Integer = 28 ' Version 28
    Public Const LK_QRCODE_VERSION_29 As Integer = 29 ' Version 29
    Public Const LK_QRCODE_VERSION_30 As Integer = 30 ' Version 30
    Public Const LK_QRCODE_VERSION_31 As Integer = 31 ' Version 31
    Public Const LK_QRCODE_VERSION_32 As Integer = 32 ' Version 32
    Public Const LK_QRCODE_VERSION_33 As Integer = 33 ' Version 33
    Public Const LK_QRCODE_VERSION_34 As Integer = 34 ' Version 34
    Public Const LK_QRCODE_VERSION_35 As Integer = 35 ' Version 35
    Public Const LK_QRCODE_VERSION_36 As Integer = 36 ' Version 36
    Public Const LK_QRCODE_VERSION_37 As Integer = 37 ' Version 37
    Public Const LK_QRCODE_VERSION_38 As Integer = 38 ' Version 38
    Public Const LK_QRCODE_VERSION_39 As Integer = 39 ' Version 39
    Public Const LK_QRCODE_VERSION_40 As Integer = 40 ' Version 40

End Module
