
#ifndef __SEWOO_ADK_HEADER__
#define __SEWOO_ADK_HEADER__

#include "lkadk_consts.h"
////////////////////////////// Export Function //////////////////////////////
#pragma comment (lib, "LKPOSTOT.lib")	// Reference Library.
#define	LUKHAN_LIBRARY	extern "C" __declspec(dllimport)

LUKHAN_LIBRARY	long __stdcall OpenPort(LPCTSTR PortName, long BaudRate);
LUKHAN_LIBRARY	long __stdcall ClosePort();
LUKHAN_LIBRARY	long __stdcall PrintBitmap(LPCTSTR BitmapFile, long Alignment, long Options, long Brightness, long ImageMode);
LUKHAN_LIBRARY	long __stdcall PrintString(LPCTSTR Data);
LUKHAN_LIBRARY	long __stdcall PrintText(LPCTSTR Data, long Alignment, long Options, long TextSize);
LUKHAN_LIBRARY	long __stdcall PrintNormal(LPCTSTR Data);
LUKHAN_LIBRARY	long __stdcall PrintBarCode(LPCTSTR Data, long Symbology, long Height, long Width, long Alignment, long TextPosition);
LUKHAN_LIBRARY	long __stdcall PrinterSts();
LUKHAN_LIBRARY	long __stdcall OpenDrawer(long DrawerPinNum, long PulseOnTime, long PulseOffTime);
LUKHAN_LIBRARY	long __stdcall DrawerSts();
LUKHAN_LIBRARY	long __stdcall CutPaper();
LUKHAN_LIBRARY	long __stdcall PrintStart();
LUKHAN_LIBRARY	long __stdcall PrintStop();
LUKHAN_LIBRARY	long __stdcall PrintData(unsigned char * Data, int Size);
LUKHAN_LIBRARY	long __stdcall LineFeed(long LFCount);

LUKHAN_LIBRARY	long __stdcall PrintText2Image(LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);
LUKHAN_LIBRARY	long __stdcall PrintText2ImageAlignment(LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint, long Alignment);
LUKHAN_LIBRARY	long __stdcall OutputCompletePrinting(long TimeDelay);
// Printing QRCode BarCode Function.
LUKHAN_LIBRARY	long __stdcall PrintQRCode(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Alignment);
LUKHAN_LIBRARY	long __stdcall MakeQRCodeBitmap(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern, LPCTSTR BitmapName);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeGenerator(unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern, long Alignment);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeFromFile(LPCTSTR File4QR, long ModuleSize, long ECLevel, long Version, long MaskPattern, long Alignment);
// Printing PDF417 BarCode Function
LUKHAN_LIBRARY	long __stdcall PrintPDF417(LPCTSTR PdfData, long DataLength, long NumberOfColumns, long CellWidth, long Alignment);

// Page Mode Function.
LUKHAN_LIBRARY	long __stdcall SetPageMode(BOOL	IsPageMode);
LUKHAN_LIBRARY	long __stdcall SetPrintDirection(long pDirect);
LUKHAN_LIBRARY	long __stdcall SetPrintingArea(long PageHeight);
LUKHAN_LIBRARY	long __stdcall SetAbsoluteVertical(long AbsolutePosition);
LUKHAN_LIBRARY	long __stdcall SetRelativeVertical(long RelativePosition);

// NV Logo
LUKHAN_LIBRARY	long __stdcall SaveNVBitmap(LPCTSTR SaveBitmapNameList, long Brightness, long ImageMode);
LUKHAN_LIBRARY	long __stdcall PrintNVBitmap(long NVImageNumber);
LUKHAN_LIBRARY	long __stdcall DeleteNVBitmap();

// Black Mark paper.
LUKHAN_LIBRARY	long __stdcall BlackMarkON(long FeedValue);
LUKHAN_LIBRARY	long __stdcall BlackMarkSearch(long FeedValue);

//
LUKHAN_LIBRARY	long __stdcall SetMasterUnit(long UnitMeasure);
LUKHAN_LIBRARY	long __stdcall PrintingWidth(long pwidth);

// Label Command using Memory Bitmap
LUKHAN_LIBRARY	long __stdcall SetLabelSize(long widthsize, long heightsize);
LUKHAN_LIBRARY	long __stdcall PrintLabel();
LUKHAN_LIBRARY	long __stdcall PrintTTFXY(long BaseUnitX, long BaseUnitY, LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);
LUKHAN_LIBRARY	long __stdcall PrintTTFAlign(long Alignment, long BaseUnitY, LPCTSTR FontName, long FontStyle, long FontDotSize, LPCTSTR TextData, long ReversePrint);
LUKHAN_LIBRARY	long __stdcall PrintBitmapXY(long BaseUnitX, long BaseUnitY, LPCTSTR BitmapFile);
LUKHAN_LIBRARY	long __stdcall PrintBitmapAlign(long Alignment, long BaseUnitY, LPCTSTR BitmapFile);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeXY(long BaseUnitX, long BaseUnitY, unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern);
LUKHAN_LIBRARY	long __stdcall PrintQRCodeAlign(long Alignment, long BaseUnitY, unsigned char * Data, long Size, long ModuleSize, long ECLevel, long Version, long MaskPattern);

// adjust to printiong position
LUKHAN_LIBRARY	long __stdcall PrintTextLS(LPCTSTR Data, long Alignment, long Options, long TextSize, long LineSpacing);
LUKHAN_LIBRARY	long __stdcall FeedDot(long dotvalue);

// 1.40 added for powerbuilder application
LUKHAN_LIBRARY	long __stdcall SetAlignment(long Alignment);
LUKHAN_LIBRARY	long __stdcall SetMagnify(long WidthandHeight);
LUKHAN_LIBRARY	long __stdcall SetAttribute(long attribute);

// 1.59
LUKHAN_LIBRARY	long __stdcall SendCommand(unsigned char * Cmd, int size);
LUKHAN_LIBRARY	long __stdcall ReadData(unsigned char * ReadBuf, long millisecond);
LUKHAN_LIBRARY	long __stdcall SetEncoding(long iEncoding);
LUKHAN_LIBRARY	long __stdcall Rotation(long pRotate);
LUKHAN_LIBRARY	long __stdcall SetAbsoluteHorizontal(long AbsolutePosition);
LUKHAN_LIBRARY	long __stdcall SetMoveToXY(long AbsoluteXPosition, long AbsoluteYPosition);
LUKHAN_LIBRARY	long __stdcall GetFeedStatus();

LUKHAN_LIBRARY	BYTE* __stdcall PrintDirectCommand(LPSTR Data);

#endif //__SEWOO_ADK_HEADER__
