package com.usb.epl.app.assist;

import com.sewoo.jpos.command.EPLConst;
import com.sewoo.jpos.printer.EPLPrinter;
import com.sewoo.port.android.DeviceConnection;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class Sample {

    // EPL
    protected EPLPrinter eplPrinter;
    private int paperType = EPLConst.LK_EPL_LABEL;

    public Sample(DeviceConnection connection)
    {
        eplPrinter = new EPLPrinter("EUC-KR", connection);
//		eplPrinter = new EPLPrinter(connection);
    }

    public void Print_Text() throws UnsupportedEncodingException
    {
        eplPrinter.setupPrinter("104", "152", paperType, "3", "0", 8, 6, 0);
        eplPrinter.printDeviceFont(400, 400, 0,   3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 90,  3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 180, 3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 270, 3, 1, 1, 0, "SEWOO Label Printer");

        eplPrinter.printDeviceFont(400, 960, 0,   8, 1, 1, 0, "한글 테스트 0도");
        eplPrinter.printDeviceFont(400, 960, 90,  8, 1, 1, 0, "한글 테스트 90도");
        eplPrinter.printDeviceFont(400, 960, 180, 8, 1, 1, 0, "한글 테스트 180도");
        eplPrinter.printDeviceFont(400, 960, 270, 8, 1, 1, 0, "한글 테스트 270도");

        eplPrinter.endPage(1);
    }

    public void Print_Barcode() throws UnsupportedEncodingException
    {
        String test_str = "Code128 Auto";
        String code_128a = "6015343013149";
        int barHeight = 12 * 8; // 12mm
        eplPrinter.setupPrinter("104", "152", paperType, "3", "0", 8, 6, 0);

        eplPrinter.printDeviceFont(80, 80, 0, 3, 1, 1, 0, test_str);
        eplPrinter.printBarCode(400, 480, 0,   EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(384, 480, 90,  EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(384, 464, 180, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(400, 464, 270, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // No readable.
        eplPrinter.printDeviceFont(80, 920, 0, 3, 1, 1, 0, "Human readable=No");
        eplPrinter.printBarCode(80, 960, 0, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // Readable
        eplPrinter.printDeviceFont(400, 920, 0, 3, 1, 1, 0, "Human readable=Yes");
        eplPrinter.printBarCode(400, 960, 0, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // QR Code
        eplPrinter.printQRCode(40, 800, 0, 4, 0, "QR Code print");
        // DataMatrix
        eplPrinter.printDataMatrix(400, 800, 0, 4, "DataMatrix print");
        // PDF417
        eplPrinter.printPDF417(40, 1100, 800, 600, 3, 9, "PDF417 Print");

        eplPrinter.endPage(1);
    }
    public void Print_Image() throws IOException
    {
        eplPrinter.setupPrinter("104", "152", paperType, "3", "0", 8, 6, 0);
        try
        {
            eplPrinter.printBitmap("//sdcard//temp//test//car_s.jpg", 10, 10);
            eplPrinter.printBitmap("//sdcard//temp//test//logo_s.jpg", 350, 10);

            eplPrinter.printBitmap("//sdcard//temp//test//danmark_windmill.jpg", 10, 600);
            eplPrinter.printBitmap("//sdcard//temp//test//logo_m.jpg", 350, 600);
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        eplPrinter.endPage(1);
    }
}
