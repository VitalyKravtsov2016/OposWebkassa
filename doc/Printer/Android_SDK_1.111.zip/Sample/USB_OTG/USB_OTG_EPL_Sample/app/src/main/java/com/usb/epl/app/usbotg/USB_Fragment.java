package com.usb.epl.app.usbotg;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.sewoo.port.android.USBPort;
import com.sewoo.port.android.USBPortConnection;
import com.usb.epl.app.assist.ConnectionInfo;
import com.usb.epl.app.assist.ResourceInstaller;
import com.usb.epl.app.assist.Sample;

import java.util.ArrayList;

public class USB_Fragment extends Fragment {

    private static final String TAG = "SEWOO USB";
    private static final String ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION";

    private Button button_open;
    private Button button_close;
    private ListView list_sample;

    private UsbManager mUsbManager;
    private USBPort port;
    private USBPortConnection connection;

    private Context context;
    private int printer_type = USBPort.LABEL_PRINTER;;

    private ArrayAdapter<String> adapter_sample;

    String[] str_sample = {
            "Text",
            "Barcode",
            "Image"
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.usb_flagment, container, false);

        button_open = (Button)view.findViewById(R.id.connect_button);
        button_close = (Button)view.findViewById(R.id.disconnect_button);
        list_sample = (ListView)view.findViewById(R.id.Sample_listView);

        context = container.getContext();
        mUsbManager = (UsbManager)context.getSystemService(Context.USB_SERVICE);
        port = new USBPort(mUsbManager, context);

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        context.registerReceiver(mUsbReceiver, filter);

        ArrayList<String> arr_sample = new ArrayList<String>();

        for(int i=0; i<str_sample.length; i++)
            arr_sample.add(str_sample[i]);

        adapter_sample = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, arr_sample){

            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                View view_v = super.getView(position, convertView, parent);

                TextView tv = (TextView)view_v.findViewById(android.R.id.text1);
                tv.setTextColor(Color.BLACK);

                return view_v;
            }
        };
        list_sample.setAdapter(adapter_sample);

        button_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ResourceInstaller ri = new ResourceInstaller();
                ri.copyAssets(context.getAssets(), "temp");

                // Retry
                for(int i=0;(i<10) && (connection == null);i++)
                {
                    connection = port.connect_device(printer_type);
                }
                if(connection != null)
                {
                    (ConnectionInfo.getInstance()).setConnection(connection);
                    button_open.setEnabled(false);
                    button_close.setEnabled(true);
                    list_sample.setEnabled(true);
                }
                else
                {
                    // Error
                    Toast toast = Toast.makeText(context, "Could not connect device.", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        button_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(connection != null)
                {
                    try
                    {
                        connection.close();
                        button_open.setEnabled(true);
                        button_close.setEnabled(false);
                        list_sample.setEnabled(false);
                        connection = null;
                        ConnectionInfo.getInstance().setConnection(null);
                    }
                    catch (InterruptedException e)
                    {
                        Toast toast = Toast.makeText(context, e.toString()+" : "+e.getMessage(), Toast.LENGTH_SHORT);
                        toast.show();
                        Log.e(TAG,e.getMessage(),e);
                    }
                }
            }
        });

        list_sample.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(ConnectionInfo.getInstance().getConnection() == null)
                    return;
                Sample sample = new Sample(ConnectionInfo.getInstance().getConnection());
                try
                {
                    switch(i)
                    {
                        case 0:
                            sample.Print_Text();
                            break;
                        case 1:
                            sample.Print_Barcode();
                            break;
                        case 2:
                            sample.Print_Image();
                            break;
                    }
                }
                catch(Exception e)
                {
                    Toast toast = Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT);
                    toast.show();
                    Log.e(TAG, e.getMessage(), e);
                }
            }
        });

        return view;
    }

    @Override
    public void onResume()
    {
        if(ConnectionInfo.getInstance().getConnection() == null)
        {
            button_open.setEnabled(true);
            button_close.setEnabled(false);
        }
        else
        {
            button_open.setEnabled(false);
            button_close.setEnabled(true);
        }
        super.onResume();
    }

    @Override
    public void onDestroy()
    {
        Log.d(TAG,"mytab usb destroy");
        if(connection != null)
        {
            try
            {
                connection.close();
            }
            catch (InterruptedException e)
            {
                Log.e(TAG,e.getMessage(),e);
            }
        }
        context.unregisterReceiver(mUsbReceiver);
        super.onDestroy();
    }

    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action))
            {
                synchronized (this)
                {
                    UsbDevice device = (UsbDevice) intent
                            .getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                    {
                        if (device != null)
                        {
                            // call method to set up device communication
                            Log.d(TAG,"connected "+ device);
                        }
                    }
                    else
                    {
                        Log.d(TAG, "permission denied for device " + device);
                    }
                }
            }
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action))
            {
                UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (device != null)
                {
                    // call your method that cleans up and closes communication with the device
                    Log.d(TAG,"disconnected "+ device);
                }
            }
        }
    };
}
