package com.usb.zpl.app.assist;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;

import com.sewoo.jpos.command.ZPLConst;
import com.sewoo.jpos.printer.ZPLPrinter;
import com.sewoo.port.android.DeviceConnection;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class Sample {

    // ZPL
    protected ZPLPrinter zplPrinter;
    private int paperType;

    public Sample(DeviceConnection connection)
    {
        zplPrinter = new ZPLPrinter(connection);
//		zplPrinter = new ZPLPrinter("EUC-KR", connection); // Korean.
//		zplPrinter = new ZPLPrinter("GB2312", connection); // Chinese.
//		zplPrinter = new ZPLPrinter("BIG5", connection); // Chinese.
    }

    public Sample(String charSet, DeviceConnection connection)
    {
        zplPrinter = new ZPLPrinter(charSet, connection);
    }

    public void Print_Text() throws UnsupportedEncodingException
    {
        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_GAP, 384, 480);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        zplPrinter.printText(ZPLConst.FONT_A, ZPLConst.ROTATION_0, 15, 12, 0, 0, "FontA 0123");
        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 15, 12, 0, 30, "FontB 0123");
        zplPrinter.printText(ZPLConst.FONT_C, ZPLConst.ROTATION_0, 15, 12, 0, 60, "FontC 0123");
        zplPrinter.printText(ZPLConst.FONT_D, ZPLConst.ROTATION_0, 15, 12, 0, 90, "FontD 0123");
        zplPrinter.printText(ZPLConst.FONT_E, ZPLConst.ROTATION_0, 15, 12, 0, 120, "FontE 0123");
        zplPrinter.printText(ZPLConst.FONT_F, ZPLConst.ROTATION_0, 15, 12, 0, 160, "FontF 0123");
        zplPrinter.printText(ZPLConst.FONT_G, ZPLConst.ROTATION_0, 15, 12, 0, 210, "FontG 01");
        zplPrinter.printText(ZPLConst.FONT_H, ZPLConst.ROTATION_0, 15, 12, 0, 300, "FontH 01234567");

        zplPrinter.endPage(1);
    }

    public void Print_Barcode() throws UnsupportedEncodingException
    {
        String data = "123456789012";
        ArrayList<String> byParam = new ArrayList<String>();
        byParam.add("2");
        byParam.add("3");
        byParam.add("20");

        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_GAP, 384, 1600);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        zplPrinter.setBarcodeField(byParam);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 70, "Code11");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Code11, null, 10, 10, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 150, "Code128");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Code128, null, 10, 100, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 250, "Code39");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Code39, null, 10, 200, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 350, "Code93");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Code93, null, 10, 300, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 450, "EAN13");
        zplPrinter.printBarcode(ZPLConst.BARCODE_EAN13, null, 10, 400, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 550, "EAN8");
        zplPrinter.printBarcode(ZPLConst.BARCODE_EAN8, null, 10, 500, "12345");

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 650, "Industrial 2OF5");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Industrial_2OF5, null, 10, 600, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 750, "Interleaved 2OF5");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Interleaved_2OF5, null, 10, 700, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 850, "LOGMARS");
        zplPrinter.printBarcode(ZPLConst.BARCODE_LOGMARS, null, 10, 800, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 950, "MSI");
        zplPrinter.printBarcode(ZPLConst.BARCODE_MSI, null, 10, 900, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1050, "PlanetCode");
        zplPrinter.printBarcode(ZPLConst.BARCODE_PlanetCode, null, 10, 1000, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1150, "Plessey");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Plessey, null, 10, 1100, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1250, "POSTNET");
        zplPrinter.printBarcode(ZPLConst.BARCODE_POSTNET, null, 10, 1200, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1350, "Standard 2OF5");
        zplPrinter.printBarcode(ZPLConst.BARCODE_Standard_2OF5, null, 10, 1300, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1450, "UPCA");
        zplPrinter.printBarcode(ZPLConst.BARCODE_UPCA, null, 10, 1400, data);

        zplPrinter.printText(ZPLConst.FONT_B, ZPLConst.ROTATION_0, 10, 10, 0, 1550, "UPCE");
        zplPrinter.printBarcode(ZPLConst.BARCODE_UPCE, null, 10, 1500, data);

        zplPrinter.endPage(1);

        /*// 2D-Barcode
        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_GAP, 384, 400);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        zplPrinter.printPDF417(40, 10, ZPLConst.ROTATION_0, 5, 5, 23, 'N', "ABCDEFGHIJKLMNOPQRSTUVWXTZ");
        zplPrinter.printQRCode(10, 180, 2, 5, 'L', "MM,AAC-42");
        zplPrinter.printDataMatrix(200, 180, ZPLConst.ROTATION_0, ZPLConst.DM_QUALITY_200, 5, "ABCDEFGHIJKLMNOPQRSTUVWXTZ");

        zplPrinter.endPage(1);*/

    }
    public void Print_Image() throws IOException
    {
        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_GAP, 384, 340);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        zplPrinter.printImage("//sdcard//temp//test//sample_4.jpg", 0, 0);
        zplPrinter.endPage(1);

        /*// Print image object.
        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_CONTINUOUS, 384, 340);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        Bitmap _bitmap = BitmapFactory.decodeFile("//sdcard//temp//test//sample_4.jpg");
        zplPrinter.printImage(_bitmap, 0, 0);
        zplPrinter.endPage(1);*/
    }

    public void Print_Geometry() throws UnsupportedEncodingException
    {
        zplPrinter.setupPrinter(ZPLConst.ROTATION_180, ZPLConst.SENSE_GAP, 384, 300);

        zplPrinter.startPage();
        zplPrinter.setInternationalFont(0);

        zplPrinter.printCircle(40,40, 70, 2, ZPLConst.LINE_COLOR_B);
        zplPrinter.printDiagonalLine(30, 30, 100, 100, 7, ZPLConst.LINE_COLOR_B, ZPLConst.DIAGONAL_L);
        zplPrinter.printEllipse(10, 10, 300, 200, 2, ZPLConst.LINE_COLOR_B);
        zplPrinter.printRectangle(120, 10, 120, 80, 10, ZPLConst.LINE_COLOR_B, 0);
        zplPrinter.printRectangle(120, 100, 120, 80, 10, ZPLConst.LINE_COLOR_B, 8);
        zplPrinter.endPage(1);
    }
}
