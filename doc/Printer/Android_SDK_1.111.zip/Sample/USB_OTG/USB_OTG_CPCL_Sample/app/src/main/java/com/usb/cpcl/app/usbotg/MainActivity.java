package com.usb.cpcl.app.usbotg;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.usb.cpcl.app.assist.ResourceInstaller;

public class MainActivity extends AppCompatActivity {

    private static final int TARGET_VERSION = 22;
    private static final int PERMISSIONS_REQUEST = 1;
    private static String[] PERMISSIONS_LIST =
            {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };

    public void SetCheckPermission()
    {
        int nVersion = android.os.Build.VERSION.SDK_INT;

        if(nVersion > TARGET_VERSION)
        {
            if(this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED)
            {
                this.requestPermissions(PERMISSIONS_LIST, PERMISSIONS_REQUEST);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SetCheckPermission();

        ActionBar ab = getSupportActionBar();
        ab.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        ActionBar.Tab tab = ab.newTab().setText("USB")
                .setTabListener(new MyTabListener(this, USB_Fragment.class.getName()));
        ab.addTab(tab);
    }

    private class MyTabListener implements ActionBar.TabListener
    {
        private static final String TAG = "MyTabListener";
        private Fragment mFragment;
        private final Activity mActivity;
        private final String mFragName;

        private MyTabListener(Activity activity, String fragName) {
            mActivity = activity;
            mFragName = fragName;
        }

        @Override
        public void onTabSelected(ActionBar.Tab tab, android.support.v4.app.FragmentTransaction fragmentTransaction) {
            if(mFragment == null)
            {
                mFragment = Fragment.instantiate(mActivity, mFragName);
                fragmentTransaction.add(android.R.id.content, mFragment);
            }
            else
            {
                fragmentTransaction.attach(mFragment);
            }
            Log.d(TAG,"mytab select");
        }

        @Override
        public void onTabUnselected(ActionBar.Tab tab, android.support.v4.app.FragmentTransaction fragmentTransaction) {
            Log.d(TAG,"mytab hide");
            if(mFragment != null)
                fragmentTransaction.detach(mFragment);
        }

        @Override
        public void onTabReselected(ActionBar.Tab tab, android.support.v4.app.FragmentTransaction fragmentTransaction) {
            // Do nothing
        }
    }
}
