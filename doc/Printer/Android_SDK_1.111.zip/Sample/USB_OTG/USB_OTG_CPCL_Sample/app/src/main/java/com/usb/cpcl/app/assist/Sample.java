package com.usb.cpcl.app.assist;

import com.sewoo.jpos.command.CPCLConst;
import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.CPCLPrinter;
import com.sewoo.jpos.printer.LKPrint;
import com.sewoo.port.android.DeviceConnection;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class Sample {

    protected CPCLPrinter cpclPrinter;
    //private int paperType = CPCLConst.LK_CPCL_LABEL; // Label with gap.
    //private int paperType = CPCLConst.LK_CPCL_BLACKMARK; // Label with black mark.
    private int paperType = CPCLConst.LK_CPCL_CONTINUOUS; // Continuous label.

    public Sample(DeviceConnection connection)
    {
        cpclPrinter = new CPCLPrinter(connection);
    }

    public Sample(String charSet, DeviceConnection connection)
    {
        cpclPrinter = new CPCLPrinter(charSet, connection);
    }

    public void Print_Text() throws UnsupportedEncodingException
    {
        cpclPrinter.setForm(0, 200, 200, 406, 1);
        cpclPrinter.setMedia(paperType);

        cpclPrinter.printCPCLText(0, 5, 1, 1, 1, "SEWOO TECH CO.,LTD.", 0);
        cpclPrinter.printCPCLText(0, 0, 2, 1, 70, "Global leader in the mini-printer industry.", 0);
        cpclPrinter.printCPCLText(0, 0, 2, 1, 110, "Total Printing Solution", 0);
        cpclPrinter.printCPCLText(0, 0, 2, 1, 150, "Diverse innovative and reliable products", 0);
        // Telephone
        cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 7, 0, 1, 200, "TEL : 82-31-459-8200", 0);
        // Homepage
        cpclPrinter.printCPCL2DBarCode(0, CPCLConst.LK_CPCL_BCS_QRCODE, 0, 250, 4, 0, 1, 0, "http://www.miniprinter.com");
        cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 7, 0, 130, 250, "www.miniprinter.com", 0);
        cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 1, 0, 130, 300, "<-- Check This.", 0);
        cpclPrinter.printForm();
    }

    public void Print_Barcode() throws UnsupportedEncodingException
    {
        cpclPrinter.setForm(0, 200, 200, 406, 1);
        cpclPrinter.setMedia(paperType);
//		cpclPrinter.userString("BACKFEED", true); // Back feed.

        // CODABAR
        cpclPrinter.setCPCLBarcode(0, 0, 0);
        cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_CODABAR, 2, CPCLConst.LK_CPCL_BCS_0RATIO, 30, 19, 45, "A37859B", 0);
        cpclPrinter.printCPCLText(0, 7, 0, 19, 18, "CODABAR", 0);
        // Code 39
        cpclPrinter.setCPCLBarcode(0, 0, 0);
        cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_39, 2, CPCLConst.LK_CPCL_BCS_1RATIO, 30, 19, 130, "0123456", 0);
        cpclPrinter.printCPCLText(0, 7, 0, 21, 103, "CODE 39", 0);
        // Code 93
        cpclPrinter.setCPCLBarcode(0, 0, 0);
        cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_93, 2, CPCLConst.LK_CPCL_BCS_1RATIO, 30, 19, 215, "0123456", 0);
        cpclPrinter.printCPCLText(0, 7, 0, 21, 180, "CODE 93", 0);
        // BARCODE 128 1 1 50 150 10 HORIZ.
        cpclPrinter.setCPCLBarcode(0, 0, 0);
        cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_128, 2, CPCLConst.LK_CPCL_BCS_1RATIO, 30, 19, 300, "A37859B", 0);
        cpclPrinter.printCPCLText(0, 7, 0, 21, 270, "CODE 128", 0);
        // Print
        cpclPrinter.printForm();

        cpclPrinter.setForm(0, 200, 200, 406, 1);
        cpclPrinter.setMedia(paperType);

        try {
            cpclPrinter.printBitmap("//sdcard//temp//test//logo_s.jpg", 1, 1);
            cpclPrinter.setCPCLBarcode(0, 0, 0);
            cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_128, 2, CPCLConst.LK_CPCL_BCS_1RATIO, 30, 19, 125, "12345690AB", 0);
            cpclPrinter.printCPCL2DBarCode(0, CPCLConst.LK_CPCL_BCS_PDF417, 80, 180, 2, 7, 2, 1, "SEWOO TECH\r\nLK-P11");
            cpclPrinter.printCPCL2DBarCode(0, CPCLConst.LK_CPCL_BCS_QRCODE, 30, 260, 4, 0, 1, 0, "LK-P11");
            cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 0, 2, 130, 280, "SEWOO TECH", 0);
            cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 0, 2, 130, 300, "LK-P11", 0);
            cpclPrinter.printForm();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public void Print_Image()throws IOException
    {
        cpclPrinter.setForm(0, 200, 200, 406, 1);
        cpclPrinter.setMedia(paperType);

        cpclPrinter.printBitmap("//sdcard//temp//test//danmark_windmill.jpg", 10, 10);
        cpclPrinter.printBitmap("//sdcard//temp//test//denmark_flag.jpg", 222, 55);
        cpclPrinter.setCPCLBarcode(0, 0, 0);
        cpclPrinter.printCPCLBarcode(CPCLConst.LK_CPCL_0_ROTATION, CPCLConst.LK_CPCL_BCS_128, 2, CPCLConst.LK_CPCL_BCS_1RATIO, 30, 19, 290, "0123456", 1);
        cpclPrinter.printCPCLText(0, 0, 1, 21, 345, "Quantity 001", 1);
        cpclPrinter.printForm();
    }

    public void Print_Multilingual() throws UnsupportedEncodingException
    {
        int nLineWidth = 384;
        String Koreandata = "영수증";
        String Turkishdata = "Turkish(İ,Ş,Ğ)";
        String Russiandata = "Получение";
        String Arabicdata = "الإيصال";
        String Greekdata = "Παραλαβή";
        String Japanesedata = "領収書";
        String GB2312data = "收据";
        String BIG5data = "收據";

        try
        {
            cpclPrinter.setForm(0, 200, 200, 1000, 1);
            cpclPrinter.setMedia(paperType);

            cpclPrinter.printAndroidFont("Korean Font", nLineWidth, 24, 0, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Korean 100-dot size font in android device.
            cpclPrinter.printAndroidFont(Koreandata, nLineWidth, 100, 30, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("Turkish Font", nLineWidth, 24, 140, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Turkish 50-dot size font in android device.
            cpclPrinter.printAndroidFont(Turkishdata, nLineWidth, 50, 170, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("Russian Font", nLineWidth, 24, 230, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Russian 60-dot size font in android device.
            cpclPrinter.printAndroidFont(Russiandata, nLineWidth, 60, 260, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("Arabic Font", nLineWidth, 24, 330, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Arabic 100-dot size font in android device.
            cpclPrinter.printAndroidFont(Arabicdata, nLineWidth, 100, 360, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("Greek Font", nLineWidth, 24, 470, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Greek 60-dot size font in android device.
            cpclPrinter.printAndroidFont(Greekdata, nLineWidth, 60, 500, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("Japanese Font", nLineWidth, 24, 570, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Japanese 100-dot size font in android device.
            cpclPrinter.printAndroidFont(Japanesedata, nLineWidth, 100, 600, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("GB2312 Font", nLineWidth, 24, 710, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // GB2312 100-dot size font in android device.
            cpclPrinter.printAndroidFont(GB2312data, nLineWidth, 100, 740, ESCPOSConst.LK_ALIGNMENT_CENTER);

            cpclPrinter.printAndroidFont("BIG5 Font", nLineWidth, 24, 850, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // BIG5 100-dot size font in android device.
            cpclPrinter.printAndroidFont(BIG5data, nLineWidth, 100, 880, ESCPOSConst.LK_ALIGNMENT_CENTER);

            // Print
            cpclPrinter.printForm();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
