package com.printer.app.assist;

import com.sewoo.port.android.DeviceConnection;
import com.sewoo.request.android.AndroidMSR;

public class ConnectionInfo {

    private static ConnectionInfo connectionInfo;
    private DeviceConnection connection;

    public static ConnectionInfo getInstance()
    {
        if(connectionInfo == null)
            connectionInfo = new ConnectionInfo();
        return connectionInfo;
    }

    private ConnectionInfo()
    {}

    public void setConnection(DeviceConnection connection)
    {
        this.connection = connection;
    }

    public DeviceConnection getConnection()
    {
        return connection;
    }

}
