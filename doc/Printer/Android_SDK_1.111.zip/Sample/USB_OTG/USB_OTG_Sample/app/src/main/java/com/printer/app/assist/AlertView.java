package com.printer.app.assist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.Collections;

public class AlertView {

    private static final String GAP = " ";

    public static void ShowAlertView(Context context, String title, String msg)
    {
        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        ArrayAdapter<String> alert_adapter = new ArrayAdapter<String>(context, android.R.layout.select_dialog_singlechoice, Collections.singletonList(msg))
        {
            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                View view_v = super.getView(position, convertView, parent);

                TextView tv = (TextView)view_v.findViewById(android.R.id.text1);

                tv.setTextColor(Color.BLACK);
                tv.setTextSize(17);

                return view_v;
            }
        };

        TextView text_title = new TextView(context);
        text_title.setText(GAP+title);
        text_title.setTextSize(16);
        text_title.setTextColor(Color.parseColor("#A6A6A6"));

        alert
                .setCustomTitle(text_title)
                .setAdapter(alert_adapter, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        dialog.dismiss();
                    }
                })
                .show();
    }
}
