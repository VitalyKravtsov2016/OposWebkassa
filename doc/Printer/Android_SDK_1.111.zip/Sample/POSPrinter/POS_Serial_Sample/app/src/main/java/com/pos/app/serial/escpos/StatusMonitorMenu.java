package com.pos.app.serial.escpos;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.pos.app.serial.assist.ESCPOSSample;
import com.pos.app.serial.assist.ResourceInstaller;
import com.pos.app.serial.assist.StatusChecker;
import com.sewoo.jpos.printer.LKPrint;
import com.sewoo.port.serial.jni.LKSerialPort;
import com.sewoo.port.serial.jni.LKSerialPortFinder;
import com.sewoo.request.android.RequestHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StatusMonitorMenu extends Activity implements Button.OnClickListener{

    private static final String key = "status";

    private Button button_open;
    private Button button_close;
    private Button button_cd_open;
    private Button button_sample;
    private Button button_barcode;
    private Button button_image;

    private Spinner spinner_port;
    private Spinner spinner_baudrate;

    private static CheckBox check_cd_open;
    private static CheckBox check_cover_open;
    private static CheckBox check_paper_near_end;
    private static CheckBox check_paper_empty;

    ToggleButton toggle_asb_mode;

    List<String> list_PortName;
    List<String> list_Baudrate;

    ArrayAdapter<String> adapter_PortName;
    ArrayAdapter<String> adapter_Baudrate;

    static LKSerialPort sPort;
    LKSerialPortFinder sPortFinder;

    String str_portName = "";
    int baudrate = 0;

    Thread hThread;
    ESCPOSSample sample;

    StatusChecker checker;

    static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitor);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        button_open = (Button)findViewById(R.id.button_asb_connect);
        button_close = (Button)findViewById(R.id.button_asb_disconnect);
        button_cd_open = (Button)findViewById(R.id.button_asb_cd_open);
        button_sample = (Button)findViewById(R.id.button_asb_sample);
        button_barcode = (Button)findViewById(R.id.button_asb_barcode);
        button_image = (Button)findViewById(R.id.button_asb_image);

        spinner_port = (Spinner)findViewById(R.id.spinner_asb_port_name);
        spinner_baudrate = (Spinner)findViewById(R.id.spinner_asb_baudrate);

        toggle_asb_mode = (ToggleButton)findViewById(R.id.toggle_asb_mode);

        check_cd_open = (CheckBox)findViewById(R.id.check_cd_open);
        check_cover_open = (CheckBox)findViewById(R.id.check_cover_open);
        check_paper_near_end = (CheckBox)findViewById(R.id.check_paper_near_end);
        check_paper_empty = (CheckBox)findViewById(R.id.check_paper_empty);

        button_cd_open.setOnClickListener(this);
        button_sample.setOnClickListener(this);
        button_barcode.setOnClickListener(this);
        button_image.setOnClickListener(this);

        setInit();

        toggle_asb_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // TODO Auto-generated method stub
                if(isChecked)
                {
                    checker = new StatusChecker();
                    checker.setHandler(statusHandler);
                    checker.start();
                    sample.SetASBMode(true);
                }
                else
                {
                    sample.SetASBMode(false);
                    // need a dummy status.
                    checker.stop();
                }
            }
        });

        button_open.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                str_portName = spinner_port.getSelectedItem().toString();
                baudrate = Integer.parseInt(spinner_baudrate.getSelectedItem().toString());

                try {
                    serialopen();

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        button_close.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                try {
                    sPort.disconnect();

                    if((hThread != null) && (hThread.isAlive()))
                        hThread.interrupt();

                    SetEnableItem(false);

                    Toast.makeText(getApplicationContext(), "Close Port", Toast.LENGTH_SHORT).show();

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public void setInit()
    {
        sample = new ESCPOSSample(StatusMonitorMenu.this);

        context = StatusMonitorMenu.this;

        list_PortName = new ArrayList<String>();
        list_Baudrate = new ArrayList<String>();

        adapter_PortName = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list_PortName);
        adapter_Baudrate = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list_Baudrate);

        sPort = new LKSerialPort();
        sPortFinder = new LKSerialPortFinder();

        String[] str_Devices = sPortFinder.getAllDevicesPath();

        for(int i=0; i<str_Devices.length; i++)
            list_PortName.add(str_Devices[i]);

        Collections.sort(list_PortName);

        list_Baudrate.add("9600");
        list_Baudrate.add("19200");
        list_Baudrate.add("38400");
        list_Baudrate.add("57600");
        list_Baudrate.add("115200");

        adapter_PortName.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter_Baudrate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_port.setAdapter(adapter_PortName);
        spinner_baudrate.setAdapter(adapter_Baudrate);

        spinner_port.setSelection(0);
        spinner_baudrate.setSelection(0);

        SetEnableItem(false);
    }

    public void SetEnableItem(boolean check)
    {
        button_open.setEnabled(!check);
        spinner_port.setEnabled(!check);
        spinner_baudrate.setEnabled(!check);

        button_close.setEnabled(check);
        button_cd_open.setEnabled(check);
        button_sample.setEnabled(check);
        button_barcode.setEnabled(check);
        button_image.setEnabled(check);

        toggle_asb_mode.setEnabled(check);
    }

    @Override
    public void onClick(View view) {
        // TODO Auto-generated method stub
        try {
            switch (view.getId()) {
                case R.id.button_asb_cd_open: sample.OpenCashDrawer(); break;
                case R.id.button_asb_sample: sample.Print_Sample_1(); break;
                case R.id.button_asb_barcode: sample.Print_1D_Barcode(); break;
                case R.id.button_asb_image: sample.Print_Image(); break;
            }
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy()
    {
        try
        {
            if(sPort.isConnected())
                sPort.disconnect();

            if((hThread != null) && (hThread.isAlive()))
            {
                hThread.interrupt();
                hThread = null;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        super.onDestroy();
    }

    private void serialopen() throws IOException
    {
        new connTask().execute();
    }

    private class connTask extends AsyncTask<Void, Void, Integer> {

        ProgressDialog asyncDialog = new ProgressDialog(StatusMonitorMenu.this);
        AlertDialog.Builder alert = new AlertDialog.Builder(StatusMonitorMenu.this);

        @Override
        protected void onPreExecute(){
            asyncDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            asyncDialog.setMessage("Connect to Printer...");
            asyncDialog.setCancelable(false);
            asyncDialog.show();
            super.onPreExecute();
        };

        @Override
        protected Integer doInBackground(Void... params) {
            // TODO Auto-generated method stub

            Integer retVal = null;
            try {

                long re_value = sPort.connect(str_portName, baudrate);

                if(re_value == LKPrint.LK_SUCCESS)
                {
                    RequestHandler rh = new RequestHandler();
                    hThread = new Thread(rh);
                    hThread.start();

                    retVal = new Integer(sample.checkValidPort());
                }
                else
                    retVal = new Integer(-10);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }

            return retVal;
        }

        @Override
        protected void onPostExecute(Integer result){

            if(asyncDialog.isShowing())
                asyncDialog.dismiss();

            if(result.intValue() == LKPrint.LK_SUCCESS)
            {
                SetEnableItem(true);
            }
            else
            {
                if(sPort.isConnected())
                {
                    try {
                        sPort.disconnect();

                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if((hThread != null) && (hThread.isAlive()))
                {
                    hThread.interrupt();
                    hThread = null;
                }
                alert
                        .setTitle("Error")
                        .setMessage("Open Failed")
                        .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }

            super.onPostExecute(result);
        };
    }

    public static final Handler statusHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == -1)	// 비정상적인 연결 종료 (abnormal disconnection)
            {
                if(sPort.isConnected())
                {
                    sPort.ClosePort();
                    Toast.makeText(context, "Serial Port Disconnected", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            Bundle bundle = msg.getData();
            byte [] sts = bundle.getByteArray(key);

            if(check_cd_open != null && check_paper_near_end != null &&
                    check_cover_open != null && check_paper_empty != null)
            {
                if((sts[0] & 0x04) > 0) // 금전등록기 열림(Cash Drawer Open).
                    check_cd_open.setChecked(false);
                else
                    check_cd_open.setChecked(true);

                if((sts[0] & 0x20) > 0) // 커버 열림(Cover Open).
                    check_cover_open.setChecked(true);
                else
                    check_cover_open.setChecked(false);

                if((sts[2] & 0x03) > 0) // 용지 적음 (Paper Near End)
                    check_paper_near_end.setChecked(true);
                else
                    check_paper_near_end.setChecked(false);

                if((sts[2] & 0x0C) > 0) // 용지 없음(Paper Empty).
                    check_paper_empty.setChecked(true);
                else
                    check_paper_empty.setChecked(false);
            }
        }
    };
}
