package com.pos.app.serial.escpos;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    private static final int TARGET_VERSION = 22;
    private static final int PERMISSIONS_REQUEST = 1;
    private static final String NORMAL_MODE = "Normal";
    private static final String ASB_MODE = "ASB";

    private static String[] PERMISSIONS_LIST =
            {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };

    private Button button_normal;
    private Button button_asb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SetCheckPermission();

        button_normal = (Button)findViewById(R.id.button_normal_mode);
        button_asb = (Button)findViewById(R.id.button_asb_mode);

        button_normal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                movetoMenu(NORMAL_MODE);
            }
        });

        button_asb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                movetoMenu(ASB_MODE);
            }
        });
    }

    public void movetoMenu(String type)
    {
        Intent in = new Intent();

        if(type.equals(NORMAL_MODE))
            in.setClass(this, ESCPOSMenu.class);
        else
            in.setClass(this, StatusMonitorMenu.class);

        startActivity(in);
    }

    public void SetCheckPermission()
    {
        int nVersion = android.os.Build.VERSION.SDK_INT;

        if(nVersion > TARGET_VERSION)
        {
            if(this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED)
            {
                this.requestPermissions(PERMISSIONS_LIST, PERMISSIONS_REQUEST);
            }
        }
    }
}
