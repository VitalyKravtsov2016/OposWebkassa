package com.pos.app.serial.escpos;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.pos.app.serial.assist.ESCPOSSample;
import com.pos.app.serial.assist.ResourceInstaller;
import com.sewoo.jpos.printer.LKPrint;
import com.sewoo.port.serial.jni.LKSerialPort;
import com.sewoo.port.serial.jni.LKSerialPortFinder;
import com.sewoo.request.android.RequestHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ESCPOSMenu extends Activity implements Button.OnClickListener{
    private Button button_open;
    private Button button_close;
    private Button button_sample;
    private Button button_barcode;
    private Button button_image;
    private Button button_androidfont;
    private Button button_pdffile;
    private Button button_status;

    private Spinner spinner_port;
    private Spinner spinner_baudrate;

    List<String> list_PortName;
    List<String> list_Baudrate;

    ArrayAdapter<String> adapter_PortName;
    ArrayAdapter<String> adapter_Baudrate;

    LKSerialPort sPort;
    LKSerialPortFinder sPortFinder;

    String str_portName = "";
    int baudrate = 0;

    Thread hThread;
    ESCPOSSample sample;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escp);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        button_open = (Button)findViewById(R.id.button_connect);
        button_close = (Button)findViewById(R.id.button_disconnect);
        button_sample = (Button)findViewById(R.id.button_sample);
        button_barcode = (Button)findViewById(R.id.button_barcode);
        button_image = (Button)findViewById(R.id.button_image);
        button_androidfont = (Button)findViewById(R.id.button_androidfont);
        button_pdffile = (Button)findViewById(R.id.button_pdffile);
        button_status = (Button)findViewById(R.id.button_status);

        spinner_port = (Spinner)findViewById(R.id.spinner_port_name);
        spinner_baudrate = (Spinner)findViewById(R.id.spinner_baudrate);

        setInit();

        button_sample.setOnClickListener(this);
        button_barcode.setOnClickListener(this);
        button_image.setOnClickListener(this);
        button_androidfont.setOnClickListener(this);
        button_pdffile.setOnClickListener(this);
        button_status.setOnClickListener(this);

        button_open.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                str_portName = spinner_port.getSelectedItem().toString();
                baudrate = Integer.parseInt(spinner_baudrate.getSelectedItem().toString());

                try {
                    serialopen();

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });

        button_close.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                try {
                    sPort.disconnect();

                    if((hThread != null) && (hThread.isAlive()))
                        hThread.interrupt();

                    SetEnableItem(false);

                    Toast.makeText(getApplicationContext(), "Close Port", Toast.LENGTH_SHORT).show();

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
    }

    public void setInit()
    {
        sample = new ESCPOSSample(ESCPOSMenu.this);

        list_PortName = new ArrayList<String>();
        list_Baudrate = new ArrayList<String>();

        adapter_PortName = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list_PortName);
        adapter_Baudrate = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list_Baudrate);

        sPort = new LKSerialPort();
        sPortFinder = new LKSerialPortFinder();

        String[] str_Devices = sPortFinder.getAllDevicesPath();

        for(int i=0; i<str_Devices.length; i++)
            list_PortName.add(str_Devices[i]);

        Collections.sort(list_PortName);

        list_Baudrate.add("9600");
        list_Baudrate.add("19200");
        list_Baudrate.add("38400");
        list_Baudrate.add("57600");
        list_Baudrate.add("115200");

        adapter_PortName.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter_Baudrate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_port.setAdapter(adapter_PortName);
        spinner_baudrate.setAdapter(adapter_Baudrate);

        spinner_port.setSelection(0);
        spinner_baudrate.setSelection(0);

        SetEnableItem(false);
    }

    public void SetEnableItem(boolean check)
    {
        button_open.setEnabled(!check);
        spinner_port.setEnabled(!check);
        spinner_baudrate.setEnabled(!check);

        button_close.setEnabled(check);
        button_sample.setEnabled(check);
        button_barcode.setEnabled(check);
        button_image.setEnabled(check);
        button_androidfont.setEnabled(check);
        button_pdffile.setEnabled(check);
        button_status.setEnabled(check);
    }

    @Override
    public void onClick(View view) {

        try {
            switch (view.getId()) {
                case R.id.button_sample: sample.Print_Sample_1();break;
                case R.id.button_barcode: sample.Print_1D_Barcode(); break;
                case R.id.button_image: sample.Print_Image(); break;
                case R.id.button_androidfont: sample.Print_Android_Font(); break;
                case R.id.button_pdffile: sample.Print_PDF(); break;
                case R.id.button_status: sample.Check_PrinterStatus(); break;
            }
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy()
    {
        try
        {
            if(sPort.isConnected())
                sPort.disconnect();

            if((hThread != null) && (hThread.isAlive()))
            {
                hThread.interrupt();
                hThread = null;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        super.onDestroy();
    }

    private void serialopen() throws IOException
    {
        new connTask().execute();
    }

    private class connTask extends AsyncTask<Void, Void, Integer> {

        ProgressDialog asyncDialog = new ProgressDialog(ESCPOSMenu.this);
        AlertDialog.Builder alert = new AlertDialog.Builder(ESCPOSMenu.this);

        @Override
        protected void onPreExecute(){
            asyncDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            asyncDialog.setMessage("Connect to Printer...");
            asyncDialog.setCancelable(false);
            asyncDialog.show();
            super.onPreExecute();
        };

        @Override
        protected Integer doInBackground(Void... params) {
            // TODO Auto-generated method stub

            Integer retVal = null;
            try {

                long re_value = sPort.connect(str_portName, baudrate);

                if(re_value == LKPrint.LK_SUCCESS)
                {
                    RequestHandler rh = new RequestHandler();
                    hThread = new Thread(rh);
                    hThread.start();

                    retVal = new Integer(sample.checkValidPort());
                }
                else
                    retVal = new Integer(-10);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }

            return retVal;
        }

        @Override
        protected void onPostExecute(Integer result){

            if(asyncDialog.isShowing())
                asyncDialog.dismiss();

            if(result.intValue() == LKPrint.LK_SUCCESS)
            {
                SetEnableItem(true);
            }
            else
            {
                if(sPort.isConnected())
                {
                    try {
                        sPort.disconnect();

                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if((hThread != null) && (hThread.isAlive()))
                {
                    hThread.interrupt();
                    hThread = null;
                }
                alert
                        .setTitle("Error")
                        .setMessage("Open Failed")
                        .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }

            super.onPostExecute(result);
        };
    }
}
