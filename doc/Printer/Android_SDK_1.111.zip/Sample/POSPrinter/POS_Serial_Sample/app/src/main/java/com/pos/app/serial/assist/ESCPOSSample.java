package com.pos.app.serial.assist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;

import com.sewoo.jpos.command.ESCPOS;
import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.ESCPOSPrinter;
import com.sewoo.jpos.printer.LKPrint;

import java.io.IOException;

public class ESCPOSSample {

    private final char ESC = ESCPOS.ESC;

    private ESCPOSPrinter escposPrinter;
    private Context context;

    public ESCPOSSample(Context con)
    {
        // escposPrinter = new ESCPOSPrinter("EUC-KR"); // Korean.
        // escposPrinter = new ESCPOSPrinter("BIG5"); // BIG5.
        // escposPrinter = new ESCPOSPrinter("GB2312"); // GB2312.
        // escposPrinter = new ESCPOSPrinter("Shift_JIS"); // Japanese.
        escposPrinter = new ESCPOSPrinter();
        context = con;
    }

    public void Print_Sample_1() throws InterruptedException
    {
        try
        {
/*
			escposPrinter.printNormal(ESC+"|bC"+ESC+"|1CNormal\n");
			escposPrinter.printNormal(ESC+"|bC"+ESC+"|2CDouble width\n");
			escposPrinter.printNormal(ESC+"|bC"+ESC+"|3CDouble height\n");
			escposPrinter.printNormal(ESC+"|bC"+ESC+"|4CDouble width/height\n");
*/
            escposPrinter.printNormal(ESC+"|cA"+ESC+"|2CReceipt\r\n\r\n\r\n");
            escposPrinter.printNormal(ESC+"|rATEL (123)-456-7890\n\n\n");
            escposPrinter.printNormal(ESC+"|cAThank you for coming to our shop!\n");
            escposPrinter.printNormal(ESC+"|cADate\n\n");
            escposPrinter.printNormal("Chicken                             $10.00\n");
            escposPrinter.printNormal("Hamburger                           $20.00\n");
            escposPrinter.printNormal("Pizza                               $30.00\n");
            escposPrinter.printNormal("Lemons                              $40.00\n");
            escposPrinter.printNormal("Drink                               $50.00\n");
            escposPrinter.printNormal("Excluded tax                       $150.00\n");
            escposPrinter.printNormal(ESC+"|uCTax(5%)                              $7.50\n");
            escposPrinter.printNormal(ESC+"|bC"+ESC+"|2CTotal         $157.50\n\n");
            escposPrinter.printNormal("Payment                            $200.00\n");
            escposPrinter.printNormal("Change                              $42.50\n\n");
            escposPrinter.printBarCode("{Babc456789012", LKPrint.LK_BCS_Code128, 40, 512, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW); // Print Barcode
            escposPrinter.lineFeed(4);
            escposPrinter.cutPaper();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void Print_Sample_2() throws InterruptedException
    {
        try
        {
            escposPrinter.printText("Receipt\r\n\r\n\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
            escposPrinter.printText("TEL (123)-456-7890\r\n", LKPrint.LK_ALIGNMENT_RIGHT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Thank you for coming to our shop!\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Chicken                             $10.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Hamburger                           $20.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Pizza                               $30.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Lemons                              $40.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Drink                               $50.00\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Excluded tax                       $150.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Tax(5%)                              $7.50\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_UNDERLINE, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Total         $157.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
            escposPrinter.printText("Payment                            $200.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printText("Change                              $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
            // Reverse print
            //posPtr.printText("Change                              $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT | LKPrint.LK_FNT_REVERSE, LKPrint.LK_TXT_1WIDTH);
            escposPrinter.printBarCode("{Babc456789012", LKPrint.LK_BCS_Code128, 40, 512, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW); // Print Barcode
            escposPrinter.lineFeed(4);
            escposPrinter.cutPaper();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void Print_Image() throws InterruptedException
    {
        try
        {
            escposPrinter.printBitmap("//sdcard//temp//test//car_s.jpg", LKPrint.LK_ALIGNMENT_CENTER);
            escposPrinter.printBitmap("//sdcard//temp//test//danmark_windmill.jpg", LKPrint.LK_ALIGNMENT_LEFT);
            escposPrinter.printBitmap("//sdcard//temp//test//denmark_flag.jpg", LKPrint.LK_ALIGNMENT_RIGHT);
            escposPrinter.lineFeed(4);
            escposPrinter.cutPaper();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void Print_1D_Barcode() throws InterruptedException
    {
        String barCodeData = "123456789012";
        String barCodeData_2D = "ABCDEFGHIJKLMN";

        try
        {
            escposPrinter.printString("UPCA\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_UPCA, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("UPCE\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_UPCE, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("EAN8\r\n");
            escposPrinter.printBarCode("1234567", ESCPOSConst.LK_BCS_EAN8, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("EAN13\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_EAN13, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("CODE39\r\n");
            escposPrinter.printBarCode("ABCDEFGHI", ESCPOSConst.LK_BCS_Code39, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("ITF\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_ITF, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("CODABAR\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_Codabar, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("CODE93\r\n");
            escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_Code93, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
            escposPrinter.printString("CODE128\r\n");
            escposPrinter.printBarCode("{BNo.{C4567890120", ESCPOSConst.LK_BCS_Code128, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);

            escposPrinter.lineFeed(2);
            escposPrinter.printString("PDF417\r\n");
            escposPrinter.printPDF417(barCodeData_2D, barCodeData_2D.length(), 0, 10, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printString("QRCode\r\n");
            escposPrinter.printQRCode(barCodeData_2D, barCodeData_2D.length(), 3, ESCPOSConst.LK_QRCODE_EC_LEVEL_L, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.lineFeed(4);
            escposPrinter.cutPaper();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void Print_Android_Font() throws InterruptedException
    {
        String data = "Receipt";
//    	String data = "영수증";
        String Koreandata = "영수증";
        String Turkishdata = "Turkish(İ,Ş,Ğ)";
        String Russiandata = "Получение";
        String Arabicdata = "الإيصال";
        String Greekdata = "Παραλαβή";
        String Japanesedata = "領収書";
        String GB2312data = "收据";
        String BIG5data = "收據";

        Typeface typeface = null;

        try
        {
            escposPrinter.printAndroidFont(data, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);
            escposPrinter.lineFeed(2);
            escposPrinter.printAndroidFont("Left Alignment", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont("Center Alignment", 512, 24, ESCPOSConst.LK_ALIGNMENT_CENTER);
            escposPrinter.printAndroidFont("Right Alignment", 512, 24, ESCPOSConst.LK_ALIGNMENT_RIGHT);

            escposPrinter.lineFeed(2);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, "SANS_SERIF : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(Typeface.SERIF, "SERIF : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(typeface.MONOSPACE, "MONOSPACE : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

            escposPrinter.lineFeed(2);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, "SANS : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, "SANS BOLD : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, false, true, "SANS ITALIC : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, true, "SANS BOLD ITALIC : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, true, true, "SANS B/I/U : 1234iwIW", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

            escposPrinter.lineFeed(2);
            escposPrinter.printAndroidFont("Korean Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Korean 100-dot size font in android device.
            escposPrinter.printAndroidFont(Koreandata, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("Turkish Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Turkish 50-dot size font in android device.
            escposPrinter.printAndroidFont(Turkishdata, 512, 50, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("Russian Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Russian 60-dot size font in android device.
            escposPrinter.printAndroidFont(Russiandata, 512, 60, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("Arabic Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Arabic 100-dot size font in android device.
            escposPrinter.printAndroidFont(Arabicdata, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("Greek Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Greek 60-dot size font in android device.
            escposPrinter.printAndroidFont(Greekdata, 512, 60, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("Japanese Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // Japanese 100-dot size font in android device.
            escposPrinter.printAndroidFont(Japanesedata, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("GB2312 Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // GB2312 100-dot size font in android device.
            escposPrinter.printAndroidFont(GB2312data, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.printAndroidFont("BIG5 Font", 512, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
            // BIG5 100-dot size font in android device.
            escposPrinter.printAndroidFont(BIG5data, 512, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

            escposPrinter.lineFeed(4);
            escposPrinter.cutPaper();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void Print_PDF() throws InterruptedException
    {
        try
        {
            escposPrinter.printPDFFile("//sdcard//temp//test//PDF_Sample.pdf", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_PAPER_POS_3INCH, 2);
            escposPrinter.lineFeed(3);
            escposPrinter.cutPaper();

            //escposPrinter.printPDFFile("//sdcard//temp//test//PDF_Sample.pdf", LKPrint.LK_ALIGNMENT_LEFT, 500, 2);  //custom size
            //escposPrinter.lineFeed(3);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void Check_PrinterStatus() throws InterruptedException
    {
        try
        {
            int rtn = escposPrinter.printerSts();

            String statusMsg;

            switch(rtn)
            {
                case ESCPOSConst.LK_STS_NORMAL: statusMsg = "Normal"; break;
                case ESCPOSConst.STS_PAPEREMPTY: statusMsg = "Paper Empty"; break;
                case ESCPOSConst.STS_COVEROPEN: statusMsg = "Cover Open"; break;
                case ESCPOSConst.STS_PAPERNEAREMPTY: statusMsg = "Paper Near Empty"; break;
                case ESCPOSConst.STS_PAPEREMPTY + ESCPOSConst.STS_PAPERNEAREMPTY: statusMsg = "Paper Empty"; break;
                case ESCPOSConst.STS_COVEROPEN + ESCPOSConst.STS_PAPEREMPTY + ESCPOSConst.STS_PAPERNEAREMPTY: statusMsg = "Cover Open"; break;
                case -1: statusMsg = "Printer OFF"; break;
                default: statusMsg = "Return value = "+rtn; break;
            }

            AlertDialog.Builder alert = new AlertDialog.Builder(context);
            alert.setTitle("Status")
                    .setMessage(statusMsg)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            dialog.dismiss();
                        }
                    })
                    .show();

        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void SetASBMode(boolean check)
    {
        if(check)
            escposPrinter.asbOn();
        else
            escposPrinter.asbOff();
    }

    public void OpenCashDrawer()
    {
        escposPrinter.openDrawer(ESCPOSConst.CD_PIN_TWO, 100, 200);
    }

    public int checkValidPort() throws IOException, InterruptedException
    {
        return escposPrinter.printerSts();
    }
}
