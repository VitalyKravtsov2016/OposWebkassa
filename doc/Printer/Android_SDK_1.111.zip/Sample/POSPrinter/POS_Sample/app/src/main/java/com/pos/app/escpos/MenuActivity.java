package com.pos.app.escpos;

import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TabHost;

import com.pos.app.assist.ResourceInstaller;

public class MenuActivity extends TabActivity {

    String con_type = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        Intent in = getIntent();
        con_type = in.getStringExtra("Connection");

        final TabHost tabHost = getTabHost();
        tabHost.getTabWidget().setDividerDrawable(null);

        tabHost.addTab(tabHost.newTabSpec("Sample")
                .setIndicator("Sample")
                .setContent(new Intent(this, Print_Activity.class).putExtra("Connection", con_type)));

        tabHost.addTab(tabHost.newTabSpec("Status")
                .setIndicator("Status")
                .setContent(new Intent(this, Status_Activity.class).putExtra("Connection", con_type)));

        tabHost.setCurrentTab(0);

        for(int i=0; i<tabHost.getTabWidget().getChildCount(); i++)
        {
            tabHost.getTabWidget().getChildAt(i)
                    .setBackgroundColor(Color.parseColor("#10000000"));
        }

        tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab())
                .setBackgroundColor(Color.parseColor("#ffffff"));

        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String s) {
                for(int i=0; i<tabHost.getTabWidget().getChildCount(); i++)
                {
                    tabHost.getTabWidget().getChildAt(i)
                            .setBackgroundColor(Color.parseColor("#10000000"));
                }

                tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab())
                        .setBackgroundColor(Color.parseColor("#ffffff"));
            }
        });
    }
}
