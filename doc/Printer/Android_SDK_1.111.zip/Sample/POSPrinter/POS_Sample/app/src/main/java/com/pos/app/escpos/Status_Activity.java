package com.pos.app.escpos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.pos.app.assist.Sample_Print;
import com.pos.app.assist.StatusChecker;
import com.sewoo.jpos.command.ESCPOS;
import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.ESCPOSPrinter;
import com.sewoo.jpos.printer.LKPrint;
import com.sewoo.port.android.BluetoothPort;

import java.io.UnsupportedEncodingException;

public class Status_Activity extends BaseActivity {

    private static final String TAG = "StatusMonitorMenu";
    private static final String key = "status";
    private final char ESC = ESCPOS.ESC;

    private ToggleButton toggle_asb;
    private Button button_cash_open;
    private Button button_text;
    private Button button_1d_bar;
    private Button button_2d_bar;
    private static CheckBox check_cash_open;
    private static CheckBox check_cover_open;
    private static CheckBox check_paper_near_end;
    private static CheckBox check_paper_empty;

    ESCPOSPrinter escposPrinter;
    StatusChecker checker;

    Sample_Print sample;

    String con_type = "";

    static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.status_layout);

        Intent in = getIntent();
        con_type = in.getStringExtra("Connection");

        if(con_type.equals("BlueTooth"))
            activity_list.add(Status_Activity.this);

        escposPrinter = new ESCPOSPrinter();

        sample = new Sample_Print();

        context = getApplicationContext();

        toggle_asb = (ToggleButton)findViewById(R.id.toggleButtonASB);
        button_cash_open = (Button)findViewById(R.id.ButtonStatusCashOpen);
        button_text = (Button)findViewById(R.id.ButtonStatusText);
        button_1d_bar = (Button)findViewById(R.id.ButtonStatus1DBar);
        button_2d_bar = (Button)findViewById(R.id.ButtonStatus2DBar);
        check_cash_open = (CheckBox)findViewById(R.id.checkCashDrawerOpen);
        check_cover_open = (CheckBox)findViewById(R.id.checkCoverOpen);
        check_paper_near_end = (CheckBox)findViewById(R.id.checkPaperNearEnd);
        check_paper_empty = (CheckBox)findViewById(R.id.checkPaperEmpty);

        toggle_asb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    checker = new StatusChecker();
                    checker.setHandler(statusHandler);
                    checker.start();
                    escposPrinter.asbOn();
                }
                else
                {
                    escposPrinter.asbOff();
                    // need a dummy status.
                    checker.stop();
                }
            }
        });

        button_cash_open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                escposPrinter.openDrawer(ESCPOSConst.CD_PIN_TWO, 100, 200);
            }
        });

        button_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    escposPrinter.printNormal(ESC+"|cA"+ESC+"|2CReceipt\r\n\r\n\r\n");
                    escposPrinter.printNormal(ESC+"|rATEL (123)-456-7890\n\n\n");
                    escposPrinter.printNormal(ESC+"|cAThank you for coming to our shop!\n");
                    escposPrinter.printNormal(ESC+"|cADate\n\n");
                    escposPrinter.printNormal("Chicken                             $10.00\n");
                    escposPrinter.printNormal("Hamburger                           $20.00\n");
                    escposPrinter.printNormal("Pizza                               $30.00\n");
                    escposPrinter.printNormal("Lemons                              $40.00\n");
                    escposPrinter.printNormal("Drink                               $50.00\n");
                    escposPrinter.printNormal("Excluded tax                       $150.00\n");
                    escposPrinter.printNormal(ESC+"|uCTax(5%)                              $7.50\n");
                    escposPrinter.printNormal(ESC+"|bC"+ESC+"|2CTotal         $157.50\n\n");
                    escposPrinter.printNormal("Payment                            $200.00\n");
                    escposPrinter.printNormal("Change                              $42.50\n\n");
                    escposPrinter.printBarCode("{Babc456789012", LKPrint.LK_BCS_Code128, 40, 512, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW); // Print Barcode
                    escposPrinter.lineFeed(4);
                    escposPrinter.cutPaper();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });

        button_1d_bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String barCodeData = "123456789012";

                    escposPrinter.printString("UPCA\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_UPCA, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("UPCE\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_UPCE, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("EAN8\r\n");
                    escposPrinter.printBarCode("1234567", ESCPOSConst.LK_BCS_EAN8, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("EAN13\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_EAN13, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("CODE39\r\n");
                    escposPrinter.printBarCode("ABCDEFGHI", ESCPOSConst.LK_BCS_Code39, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("ITF\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_ITF, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("CODABAR\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_Codabar, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("CODE93\r\n");
                    escposPrinter.printBarCode(barCodeData, ESCPOSConst.LK_BCS_Code93, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.printString("CODE128\r\n");
                    escposPrinter.printBarCode("{BNo.{C4567890120", ESCPOSConst.LK_BCS_Code128, 70, 3, ESCPOSConst.LK_ALIGNMENT_CENTER, ESCPOSConst.LK_HRI_TEXT_BELOW);
                    escposPrinter.lineFeed(4);
                    escposPrinter.cutPaper();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });

        button_2d_bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String data = "ABCDEFGHIJKLMN";
                    escposPrinter.printString("PDF417\r\n");
                    escposPrinter.printPDF417(data, data.length(), 0, 10, ESCPOSConst.LK_ALIGNMENT_LEFT);
                    escposPrinter.printString("QRCode\r\n");
                    escposPrinter.printQRCode(data, data.length(), 3, ESCPOSConst.LK_QRCODE_EC_LEVEL_L, ESCPOSConst.LK_ALIGNMENT_CENTER);
                    escposPrinter.lineFeed(4);
                    escposPrinter.cutPaper();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public static final Handler statusHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == -1)	// 비정상적인 연결 종료 (abnormal disconnection)
            {
                Toast.makeText(context, "BlueTooth DisConnect", Toast.LENGTH_SHORT).show();
                if(BluetoothPort.getInstance().isConnected())
                {
                    try
                    {
                        BluetoothPort.getInstance().disconnect();
                    }
                    catch (Exception e)
                    {
                        Log.e("StatusMonitor", e.getMessage());
                    }
                }
                Log.d("Status","disconnected");
                return;
            }

            Bundle bundle = msg.getData();
            byte [] sts = bundle.getByteArray(key);

            if( check_cash_open != null && check_paper_empty != null &&
                    check_cover_open != null && check_paper_near_end != null)
            {
                if((sts[0] & 0x04) > 0) // 금전등록기 열림(Cash Drawer Open).
                    check_cash_open.setChecked(false);
                else
                    check_cash_open.setChecked(true);

                if((sts[0] & 0x20) > 0) // 커버 열림(Cover Open).
                    check_cover_open.setChecked(true);
                else
                    check_cover_open.setChecked(false);

                if((sts[2] & 0x03) > 0) // 용지 적음 (Paper Near End)
                    check_paper_near_end.setChecked(true);
                else
                    check_paper_near_end.setChecked(false);

                if((sts[2] & 0x0C) > 0) // 용지 없음(Paper Empty).
                    check_paper_empty.setChecked(true);
                else
                    check_paper_empty.setChecked(false);
            }
        }
    };

    @Override
    protected void onDestroy()
    {
        if(checker != null)
            checker.stop();
        Log.d(TAG,"onDestroy()");
        super.onDestroy();
    }
}
