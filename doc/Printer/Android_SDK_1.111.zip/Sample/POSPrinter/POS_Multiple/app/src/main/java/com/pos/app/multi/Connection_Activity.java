package com.pos.app.multi;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.pos.app.assist.AddressRepo;
import com.pos.app.assist.ResourceInstaller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

public class Connection_Activity extends Activity {

    public static Vector<String> ipAddrVector;
    private static final String dir = Environment.getExternalStorageDirectory().getAbsolutePath() + "//temp";
    private static final String fileName = dir + "//WFPrinter";
    private static final String TAG = "WiFiConnectMenu";
    private final int sendRequestCode = 2345;

    private EditText edit_addressBT;
    private EditText edit_addressNetwork;
    private Button button_select;
    private Button button_clear;
    private Button button_add;
    private ListView list_address;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_addressBT = (EditText)findViewById(R.id.EditTextAddressBT);
        edit_addressNetwork = (EditText)findViewById(R.id.EditTextAddressNetwork);
        button_select = (Button)findViewById(R.id.ButtonSelectBT);
        button_clear = (Button)findViewById(R.id.ButtonClearBT);
        button_add = (Button)findViewById(R.id.ButtonAddNetwork);
        list_address = (ListView)findViewById(R.id.ListView01);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice);

        list_address.setAdapter(adapter);
        list_address.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        loadSettingFile();

        button_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Connection_Activity.this, Bluetooth_Activity.class);
                startActivityForResult(intent, sendRequestCode);
            }
        });

        button_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit_addressBT.setText("");
                AddressRepo.getInstance().setBluetoothAddress("");
            }
        });

        button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ip = edit_addressNetwork.getText().toString();
                addIpList(ip);

                saveSettingFile();
            }
        });

        list_address.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String ipAddr = (String) list_address.getItemAtPosition(i);
                boolean checked = list_address.isItemChecked(i);

                if(!checked)
                {
                    AddressRepo.getInstance().removeIP(ipAddr);
                }
                else
                {
                    AddressRepo.getInstance().addIP(ipAddr);
                }
            }
        });

        list_address.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            String ip;

            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                ip = ipAddrVector.elementAt(i);
                boolean checked = list_address.isItemChecked(i);

                if(!checked)
                {
                    new AlertDialog.Builder(Connection_Activity.this)
                            .setTitle("Wi-Fi connection history")
                            .setMessage("Delete '"+ip+"' ?")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick(DialogInterface dialog, int which)
                                {
                                    deleteIpList(ip);

                                    saveSettingFile();
                                }
                            })
                            .setNegativeButton("NO", new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick(DialogInterface dialog, int which)
                                {

                                }
                            })
                            .show();
                }

                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        Bundle b = new Bundle();
        if (requestCode == sendRequestCode)
        {
            if (resultCode == RESULT_OK)
            {
                b = data.getExtras();
                String arr = b.getString(Bluetooth_Activity.EXTRA_DEVICE_ADDRESS);
                // TODO Address saved.
                AddressRepo.getInstance().setBluetoothAddress(arr);
                edit_addressBT.setText(arr);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy()
    {
        //saveSettingFile();
        super.onDestroy();
    }

    private void saveSettingFile()
    {
        try
        {
            File tempDir = new File(dir);
            if(!tempDir.exists())
            {
                tempDir.mkdir();
            }
            BufferedWriter fWriter = new BufferedWriter(new FileWriter(fileName));
            Iterator<String> iter = ipAddrVector.iterator();
            while(iter.hasNext())
            {
                fWriter.write(iter.next());
                fWriter.newLine();
            }
            fWriter.close();
        }
        catch (FileNotFoundException e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
        catch (IOException e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    private void addIpList(String addr)
    {
        deleteIpList(addr);
        // UI
        ipAddrVector.insertElementAt(addr, 0);
        adapter.insert(addr, 0);
    }

    // Delete Wi-Fi connection.
    private void deleteIpList(String addr)
    {
        if(ipAddrVector.contains(addr))
        {
            ipAddrVector.remove(addr);
        }
        if(adapter.getPosition(addr) >= 0)
        {
            adapter.remove(addr);
        }
    }

    private void loadSettingFile()
    {
        String line;
        ipAddrVector = new Vector<String>();
        try
        {
            // Retrieve the connection history from the file.
            BufferedReader fReader = new BufferedReader(new FileReader(fileName));
            while((line = fReader.readLine()) != null)
            {
                ipAddrVector.addElement(line);
                adapter.add(line);
            }
            fReader.close();
        }
        catch (FileNotFoundException e)
        {
            Log.i(TAG, "Connection history not exists.");
        }
        catch (IOException e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

}
