package com.mobile.app.assist;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;

import com.sewoo.jpos.command.ESCPOS;
import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.ESCPOSPrinter;
import com.sewoo.jpos.printer.LKPrint;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class Sample_Print {

    private ESCPOSPrinter escposPrinter;

    private final char ESC = ESCPOS.ESC;
    private final char LF = ESCPOS.LF;

    private CheckPrinterStatus check_status;
    private int sts;

    public Sample_Print()
    {
        escposPrinter = new ESCPOSPrinter();    //Default = English.
        //escposPrinter = new ESCPOSPrinter("EUC-KR"); // Korean.
        //escposPrinter = new ESCPOSPrinter("GB2312"); //Chinese.
        check_status = new CheckPrinterStatus();
    }

    public int Print_Sample_2() throws UnsupportedEncodingException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printNormal(ESC + "|cA" + ESC + "|bC" + ESC + "|2C" + "Receipt" + LF + LF);
        escposPrinter.printNormal(ESC+"|rATEL (123)-456-7890\n\n\n");
        escposPrinter.printNormal(ESC+"|cAThank you!!!\n");
        escposPrinter.printNormal("Chicken                   $10.00\n");
        escposPrinter.printNormal("Hamburger                 $20.00\n");
        escposPrinter.printNormal("Pizza                     $30.00\n");
        escposPrinter.printNormal("Lemons                    $40.00\n");
        escposPrinter.printNormal("Drink                     $50.00\n");
        escposPrinter.printNormal("Excluded tax             $150.00\n");
        escposPrinter.printNormal(ESC+"|uCTax(5%)                    $7.50\n");
        escposPrinter.printNormal(ESC+"|bC"+ESC+"|2CTotal    $157.50\n\n");
        escposPrinter.printNormal("Payment                  $200.00\n");
        escposPrinter.printNormal("Change                    $42.50\n\n");
        escposPrinter.printBarCode("{Babc456789012", LKPrint.LK_BCS_Code128, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW); // Print Barcode

        return 0;
    }

    public int Print_Sample_3() throws UnsupportedEncodingException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printText("Receipt\r\n\r\n\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
        escposPrinter.printText("TEL (123)-456-7890\r\n", LKPrint.LK_ALIGNMENT_RIGHT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Thank you for coming to our shop!\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Chicken                                   $10.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Hamburger                                 $20.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Pizza                                     $30.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Lemons                                    $40.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Drink                                     $50.00\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Excluded tax                             $150.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Tax(5%)                                    $7.50\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_UNDERLINE, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Total            $157.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
        escposPrinter.printText("Payment                                  $200.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Change                                    $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        // Reverse print.
        escposPrinter.printText("Change                                    $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT | LKPrint.LK_FNT_REVERSE, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printBarCode("0123456789", LKPrint.LK_BCS_Code39, 60, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);

        return 0;
    }

    public int Print_Sample_3_korea() throws IOException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        String data = "QRCode Test Left Alignment";

        escposPrinter.printBitmap("//sdcard//temp//test//logo_m.jpg", LKPrint.LK_ALIGNMENT_CENTER);
        escposPrinter.lineFeed(1);
        escposPrinter.printQRCode(data, data.length(), 6, ESCPOSConst.LK_QRCODE_EC_LEVEL_L, ESCPOSConst.LK_ALIGNMENT_LEFT);

        escposPrinter.printText("Thermal Receipt print\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_BOLD, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_2HEIGHT);
        escposPrinter.printText("[영수증 출력]\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_BOLD, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_2HEIGHT);
        escposPrinter.lineFeed(1);

        escposPrinter.printText("SEWOO COFFEE SHOP\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_BOLD, LKPrint.LK_TXT_2WIDTH);
        escposPrinter.printText("사업장 : 경기도 오산시 가장산업동로 28-6\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("매출일 : 2020-05-30   19:25:36\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("영수증 : No. 20200530-01-0049\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.lineFeed(1);

        escposPrinter.printText("------------------------------------------------\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("상품명          단가     수량          금액 \r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_BOLD, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("------------------------------------------------\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("Choco Latte     5000       1           5000\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("Iced Coffee     3500       1           3500\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("녹차라떼        4500       2           9000\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("사이다          3500       2           7000\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("------------------------------------------------\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("합계 금액[Total Amount]               24,500\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_BOLD, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printText("------------------------------------------------\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH | LKPrint.LK_TXT_1HEIGHT);
        escposPrinter.printBarCode("{B1234567890", LKPrint.LK_BCS_Code128, 60, 512, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.lineFeed(4);

        return 0;
    }

    public int Print_Sample_4() throws UnsupportedEncodingException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printText("Receipt\r\n\r\n\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
        escposPrinter.printText("TEL (123)-456-7890\r\n", LKPrint.LK_ALIGNMENT_RIGHT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Thank you for coming to our shop!\r\n", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Chicken                                                        $10.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Hamburger                                                      $20.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Pizza                                                          $30.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Lemons                                                         $40.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Drink                                                          $50.00\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Excluded tax                                                  $150.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Tax(5%)                                                         $7.50\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_UNDERLINE, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Total                      $157.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_2WIDTH);
        escposPrinter.printText("Payment                                                       $200.00\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printText("Change                                                         $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT, LKPrint.LK_TXT_1WIDTH);
        // Reverse print.
        escposPrinter.printText("Change                                                         $42.50\r\n\r\n", LKPrint.LK_ALIGNMENT_LEFT, LKPrint.LK_FNT_DEFAULT | LKPrint.LK_FNT_REVERSE, LKPrint.LK_TXT_1WIDTH);
        escposPrinter.printBarCode("0123456789", LKPrint.LK_BCS_Code39, 80, 3, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);

        return 0;
    }

    public int Print_1D_Barcode() throws UnsupportedEncodingException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printBarCode("1234567890", LKPrint.LK_BCS_Code39, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("0123498765", LKPrint.LK_BCS_Code93, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("0987654321", LKPrint.LK_BCS_ITF, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("{ACODE 128", LKPrint.LK_BCS_Code128, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("{BCode 128", LKPrint.LK_BCS_Code128, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("{C12345", LKPrint.LK_BCS_Code128, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printBarCode("A1029384756A", LKPrint.LK_BCS_Codabar, 40, 2, LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_HRI_TEXT_BELOW);
        escposPrinter.printNormal(ESC + "|cA" + ESC + "|4C" + ESC + "|bC" + "Thank you" + LF);
        escposPrinter.lineFeed(3);

        return 0;
    }

    public int Print_2D_Barcode() throws UnsupportedEncodingException
    {
        String data = "ABCDEFGHIJKLMN";

        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printString("PDF417\r\n");
        escposPrinter.printPDF417(data, data.length(), 0, 10, ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.printPDF417(data, data.length(), 4, 3, ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.printString("QRCode\r\n");
        escposPrinter.printQRCode(data, data.length(), 3, ESCPOSConst.LK_QRCODE_EC_LEVEL_L, ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.printNormal(ESC + "|cA" + ESC + "|4C" + ESC + "|bC" + "Thank you" + LF);
        escposPrinter.lineFeed(4);

        return 0;
    }

    public int Print_Image() throws IOException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printBitmap("//sdcard//temp//test//logo_s.jpg", LKPrint.LK_ALIGNMENT_CENTER);
        escposPrinter.printBitmap("//sdcard//temp//test//sample_2.jpg", LKPrint.LK_ALIGNMENT_CENTER);
        escposPrinter.printBitmap("//sdcard//temp//test//sample_3.jpg", LKPrint.LK_ALIGNMENT_LEFT);
        escposPrinter.printBitmap("//sdcard//temp//test//sample_4.jpg", LKPrint.LK_ALIGNMENT_RIGHT);

        Bitmap _bitmap = BitmapFactory.decodeFile("//sdcard//temp//test//logo_s.jpg");
        escposPrinter.printBitmap(_bitmap, LKPrint.LK_ALIGNMENT_CENTER);
        escposPrinter.printBitmap(_bitmap, LKPrint.LK_ALIGNMENT_CENTER, 0, 1);

        escposPrinter.printBitmap(_bitmap, LKPrint.LK_ALIGNMENT_LEFT, 1);
        escposPrinter.printBitmap(_bitmap, LKPrint.LK_ALIGNMENT_LEFT, 2);
        escposPrinter.printBitmap(_bitmap, LKPrint.LK_ALIGNMENT_LEFT, 3);

        escposPrinter.lineFeed(1);

        escposPrinter.printString("<Using dithering>\r\n"); //Use Dithering when using alpha values(transparency).
        escposPrinter.setDithering(ESCPOSConst.LK_BITMAP_ORDERED_DITHER);
        escposPrinter.printBitmap("//sdcard//temp//test//parking.jpg", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_PAPER_2INCH);
        escposPrinter.lineFeed(1);
        escposPrinter.setDithering(ESCPOSConst.LK_BITMAP_ERROR_DIFFUSION);
        escposPrinter.printBitmap("//sdcard//temp//test//parking.jpg", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_PAPER_2INCH);

        escposPrinter.printNormal(ESC + "|cA" + ESC + "|bC" + ESC + "|4C" + "Thank you" + LF);
        escposPrinter.lineFeed(3);

        return 0;
    }

    public int Print_Android_Font() throws IOException
    {
        int nLineWidth = 384;

        String data = "Receipt";
        Typeface typeface = null;

        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printAndroidFont(data, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.lineFeed(2);
        escposPrinter.printAndroidFont("Left Alignment", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont("Center Alignment", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.printAndroidFont("Right Alignment", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_RIGHT);

        escposPrinter.lineFeed(2);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, "SANS_SERIF : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, "SERIF : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(typeface.MONOSPACE, "MONOSPACE : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

        escposPrinter.lineFeed(2);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, "SANS : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, "SANS BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, false, "SANS BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, false, true, "SANS ITALIC : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, true, "SANS BOLD ITALIC : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SANS_SERIF, true, true, true, "SANS B/I/U : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

        escposPrinter.lineFeed(2);
        escposPrinter.printAndroidFont(Typeface.SERIF, "SERIF : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, true, "SERIF BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, true, false, "SERIF BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, false, true, "SERIF ITALIC : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, true, true, "SERIF BOLD ITALIC : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.SERIF, true, true, true, "SERIF B/I/U : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

        escposPrinter.lineFeed(2);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, "MONOSPACE : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, true, "MONO BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, true, false, "MONO BOLD : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, false, true, "MONO ITALIC : 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, true, true, "MONO BOLD ITALIC: 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        escposPrinter.printAndroidFont(Typeface.MONOSPACE, true, true, true, "MONO B/I/U: 1234iwIW", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);

        escposPrinter.lineFeed(4);

        return 0;
    }

    public int Print_Multilingual() throws IOException
    {
        int nLineWidth = 384;
        String Koreandata = "영수증";
        String Turkishdata = "Turkish(İ,Ş,Ğ)";
        String Russiandata = "Получение";
        String Arabicdata = "الإيصال";
        String Greekdata = "Παραλαβή";
        String Japanesedata = "領収書";
        String GB2312data = "收据";
        String BIG5data = "收據";

        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printAndroidFont("Korean Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Korean 100-dot size font in android device.
        escposPrinter.printAndroidFont(Koreandata, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("Turkish Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Turkish 50-dot size font in android device.
        escposPrinter.printAndroidFont(Turkishdata, nLineWidth, 50, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("Russian Font", 384, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Russian 60-dot size font in android device.
        escposPrinter.printAndroidFont(Russiandata, nLineWidth, 60, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("Arabic Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Arabic 100-dot size font in android device.
        escposPrinter.printAndroidFont(Arabicdata, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("Greek Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Greek 60-dot size font in android device.
        escposPrinter.printAndroidFont(Greekdata, nLineWidth, 60, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("Japanese Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // Japanese 100-dot size font in android device.
        escposPrinter.printAndroidFont(Japanesedata, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("GB2312 Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // GB2312 100-dot size font in android device.
        escposPrinter.printAndroidFont(GB2312data, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.printAndroidFont("BIG5 Font", nLineWidth, 24, ESCPOSConst.LK_ALIGNMENT_LEFT);
        // BIG5 100-dot size font in android device.
        escposPrinter.printAndroidFont(BIG5data, nLineWidth, 100, ESCPOSConst.LK_ALIGNMENT_CENTER);

        escposPrinter.lineFeed(4);

        return 0;
    }

    public int Print_PDF() throws IOException
    {
        sts = check_status.PrinterStatus(escposPrinter);
        if(sts != ESCPOSConst.LK_SUCCESS) return sts;

        escposPrinter.printPDFFile("//sdcard//temp//test//PDF_Sample.pdf", LKPrint.LK_ALIGNMENT_CENTER, LKPrint.LK_PAPER_2INCH, 2);
        escposPrinter.lineFeed(3);

        escposPrinter.printPDFFile("//sdcard//temp//test//PDF_Sample.pdf", LKPrint.LK_ALIGNMENT_LEFT, 300, 2);  //custom size
        escposPrinter.lineFeed(3);

        return 0;
    }
}
