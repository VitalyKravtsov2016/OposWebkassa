package com.mobile.app.escpos;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.mobile.app.assist.ResourceInstaller;
import com.mobile.app.assist.Sample_Print;
import com.sewoo.jpos.command.ESCPOSConst;

public class Menu_Activity extends BaseActivity implements Button.OnClickListener{

    private Button button_sample2;
    private Button button_sample3;
    private Button button_sample3_k;
    private Button button_sample4;
    private Button button_bar_1d;
    private Button button_bar_2d;
    private Button button_image;
    private Button button_android_font;
    private Button button_multi;
    private Button button_pdf;

    Sample_Print sample;

    String con_type = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.menu_layout);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        Intent in = getIntent();
        con_type = in.getStringExtra("Connection");

        if(con_type.equals("BlueTooth"))
            activity_list.add(Menu_Activity.this);

        button_sample2 = (Button)findViewById(R.id.ButtonSample_2);
        button_sample3 = (Button)findViewById(R.id.ButtonSample_3);
        button_sample3_k = (Button)findViewById(R.id.ButtonSample_3_Korea);
        button_sample4 = (Button)findViewById(R.id.ButtonSample_4);
        button_bar_1d = (Button)findViewById(R.id.Button1DBarcode);
        button_bar_2d = (Button)findViewById(R.id.Button2DBarcode);
        button_image = (Button)findViewById(R.id.ButtonImage);
        button_android_font = (Button)findViewById(R.id.ButtonAndroidFont);
        button_multi = (Button)findViewById(R.id.ButtonMultilingual);
        button_pdf = (Button)findViewById(R.id.ButtonPDF);

        button_sample2.setOnClickListener(this);
        button_sample3.setOnClickListener(this);
        button_sample3_k.setOnClickListener(this);
        button_sample4.setOnClickListener(this);
        button_bar_1d.setOnClickListener(this);
        button_bar_2d.setOnClickListener(this);
        button_image.setOnClickListener(this);
        button_android_font.setOnClickListener(this);
        button_multi.setOnClickListener(this);
        button_pdf.setOnClickListener(this);

        sample = new Sample_Print();
    }

    @Override
    public void onClick(View view)
    {
        int re_val = 0;

        try {
            switch (view.getId()) {
                case R.id.ButtonSample_2:
                    re_val = sample.Print_Sample_2();
                    break;
                case R.id.ButtonSample_3:
                    re_val = sample.Print_Sample_3();
                    break;
                case R.id.ButtonSample_3_Korea:
                    re_val = sample.Print_Sample_3_korea();
                    break;
                case R.id.ButtonSample_4:
                    re_val = sample.Print_Sample_4();
                    break;
                case R.id.Button1DBarcode:
                    re_val = sample.Print_1D_Barcode();
                    break;
                case R.id.Button2DBarcode:
                    re_val = sample.Print_2D_Barcode();
                    break;
                case R.id.ButtonImage:
                    re_val = sample.Print_Image();
                    break;
                case R.id.ButtonAndroidFont:
                    re_val = sample.Print_Android_Font();
                    break;
                case R.id.ButtonMultilingual:
                    re_val = sample.Print_Multilingual();
                    break;
                case R.id.ButtonPDF:
                    re_val = sample.Print_PDF();
                    break;
            }

            String statusMsg;
            if (re_val == ESCPOSConst.LK_STS_NORMAL) {
                statusMsg = new String("Printing success");
                Toast toast = Toast.makeText(Menu_Activity.this, statusMsg, Toast.LENGTH_SHORT);
                toast.show();
            } else {
                statusMsg = new String();
                if ((re_val & ESCPOSConst.LK_STS_COVER_OPEN) > 0)
                    statusMsg = statusMsg + "Cover Open\r\n";
                if ((re_val & ESCPOSConst.LK_STS_PAPER_EMPTY) > 0)
                    statusMsg = statusMsg + "Paper Empty\r\n";
                if ((re_val & ESCPOSConst.LK_STS_BATTERY_LOW) > 0)
                    statusMsg = statusMsg + "Battery Low\r\n";
                if ((re_val & ESCPOSConst.LK_STS_PRINTEROFF) > 0)
                    statusMsg = statusMsg + "Printer Power OFF\r\nReconnect and print\r\n";
                if ((re_val & ESCPOSConst.LK_STS_TIMEOUT) > 0)
                    statusMsg = statusMsg + "Timeout error";

                AlertDialog.Builder alert = new AlertDialog.Builder(Menu_Activity.this);
                alert.setTitle("Error")
                        .setMessage(statusMsg)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        }
        catch(Exception e)
        {
            AlertDialog.Builder alert = new AlertDialog.Builder(Menu_Activity.this);
            alert.setTitle("Error")
                    .setMessage(e.toString())
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            dialog.dismiss();
                        }
                    })
                    .show();
        }
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub

        if (con_type.equals("BlueTooth")) {
            activity_list.remove(1);
            ((Bluetooth_Activity) activity_list.get(0)).ExcuteDisconnect();
        }
        else if(con_type.equals("WiFi")) {
            ((WiFi_Activity) activity_wifi).ExcuteDisconnect();
        }

        super.onDestroy();
    }
}
