package com.mobile.app.assist;

import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.ESCPOSPrinter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class ReceiptSample {

    private ESCPOSPrinter escposPrinter;
    private char ESC = 0x1B;
    private char LF = 0x0A;

    public ReceiptSample()
    {
        escposPrinter = new ESCPOSPrinter();
    }

    public void cardPrint(String trackData) throws IOException
    {
        String cardData;
        // Logo
        escposPrinter.lineFeed(1);
        escposPrinter.printBitmap("//sdcard//temp//test//logo_s.jpg", ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.lineFeed(2);
        // List
        receipt();
        // Card
        trackData = trackData.substring(0, 16);
        cardData = trackData.substring(0,4) +"-";
        cardData = cardData + trackData.substring(4,8)+"-****-";
        cardData = cardData + trackData.substring(12,16);
        escposPrinter.lineFeed(2);
        escposPrinter.printNormal("Card : "+cardData+ LF + LF);
        // sign
        escposPrinter.printNormal(ESC + "|cA" + ESC + "|bC" + "Signature :" + LF);
        escposPrinter.printBitmap("//sdcard//temp//test//card_sign.JPG", ESCPOSConst.LK_ALIGNMENT_CENTER);
        escposPrinter.lineFeed(3);
    }

    public void receipt() throws UnsupportedEncodingException
    {
        escposPrinter.printNormal(ESC + "|cA" + ESC + "|bC" + ESC + "|2C" + "Receipt" + LF + LF);
        escposPrinter.printNormal(ESC + "|rA" + ESC + "|bC" + "TEL (123)-456-7890" + LF);
        escposPrinter.printNormal(ESC + "|cA" + ESC + "|bC" + "Thank you for coming to our shop" + LF + LF);

        escposPrinter.printNormal("Chicken                   $10.00" + LF);
        escposPrinter.printNormal("Hamburger                 $20.00" + LF);
        escposPrinter.printNormal("Pizza                     $30.00" + LF);
        escposPrinter.printNormal("Lemons                    $40.00" + LF);
        escposPrinter.printNormal("Drink                     $50.00" + LF + LF);
        escposPrinter.printNormal("Excluded tax             $150.00" + LF);

        escposPrinter.printNormal( ESC + "|uC" + "Tax(5%)                    $7.50" + LF);
        escposPrinter.printNormal( ESC + "|bC" + ESC + "|2C" + "Total   $157.50" + LF + LF);
        escposPrinter.printNormal( ESC + "|bC" + "Payment                  $200.00" + LF);
        escposPrinter.printNormal( ESC + "|bC" + "Change                    $42.50" + LF);
    }
}
