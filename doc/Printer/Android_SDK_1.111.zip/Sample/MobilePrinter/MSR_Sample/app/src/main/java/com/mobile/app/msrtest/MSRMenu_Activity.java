package com.mobile.app.msrtest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.mobile.app.assist.ReceiptSample;
import com.mobile.app.assist.ResourceInstaller;
import com.sewoo.jpos.command.ESCPOSConst;
import com.sewoo.jpos.printer.LKPrint;
import com.sewoo.request.android.AndroidMSR;

import java.io.IOException;
import java.util.ArrayList;

import static android.support.constraint.Constraints.TAG;

public class MSRMenu_Activity extends BaseActivity {

    private static Button button_msr;
    private static Button button_payment;
    private static EditText edit_track1;
    private static EditText edit_track2;
    private static EditText edit_track3;
    private static Spinner spinner_track_type;

    private ArrayAdapter<String> adapter_track_type;

    AndroidMSR androidMSR;
    String con_type = "";
    int mode;
    String[] str_track_type = {"Track 1","Track 2","Track 1,2", "Track 3", "Track 2,3"};

    static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.msr_layout);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        Intent in = getIntent();
        con_type = in.getStringExtra("Connection");

        if (con_type.equals("BlueTooth"))
            activity_list.add(MSRMenu_Activity.this);

        context = getApplicationContext();

        button_msr = (Button)findViewById(R.id.ButtonMSR);
        button_payment = (Button)findViewById(R.id.ButtonPayment);
        edit_track1 = (EditText)findViewById(R.id.EditTextTrack1);
        edit_track2 = (EditText)findViewById(R.id.EditTextTrack2);
        edit_track3 = (EditText)findViewById(R.id.EditTextTrack3);
        spinner_track_type = (Spinner)findViewById(R.id.SpinnerTrackType);

        ArrayList<String> arr_track_type = new ArrayList<String>();

        for(int i=0; i<str_track_type.length; i++)
            arr_track_type.add(str_track_type[i]);

        adapter_track_type = new ArrayAdapter<String>(MSRMenu_Activity.this, android.R.layout.simple_spinner_dropdown_item, arr_track_type);

        spinner_track_type.setAdapter(adapter_track_type);
        spinner_track_type.setSelection(1);

        button_msr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (button_msr.getText().equals("Read MSR"))
                {
                    // MSR mode command.
                    mode = spinner_track_type.getSelectedItemPosition(); // + 49;
                    switch (mode)
                    {
                        case 0: // Track 1
                            mode = ESCPOSConst.LK_MSR_TRACK_1;
                            break;
                        case 1: // Track 2
                            mode = ESCPOSConst.LK_MSR_TRACK_2;
                            break;
                        case 2: // Track 12
                            mode = ESCPOSConst.LK_MSR_TRACK_12;
                            break;
                        case 3: // Track 3
                            mode = ESCPOSConst.LK_MSR_TRACK_3;
                            break;
                        case 4: // Track 23
                            mode = ESCPOSConst.LK_MSR_TRACK_23;
                            break;
                    }
                    androidMSR = AndroidMSR.getInstance();
                    androidMSR.setHandler(msrHandler);
                    try
                    {
                        if(androidMSR.readMSR(mode) == LKPrint.LK_STS_MSR_READ)
                        {
                            spinner_track_type.setEnabled(false);
                            button_payment.setEnabled(false);
                            button_msr.setText("Cancel MSR");
                            edit_track1.setText("");
                            edit_track2.setText("");
                            edit_track3.setText("");
                        }
                        else
                        {
                            AlertDialog.Builder alert = new AlertDialog.Builder(context);
                            alert.setTitle("Error")
                                    .setMessage("Fail to change MSR mode.")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            // TODO Auto-generated method stub
                                            dialog.dismiss();
                                        }
                                    })
                                    .show();
                        }
                    }
                    catch(InterruptedException e1)
                    {
                        Log.e(TAG, "msrTestListener "+e1.getMessage());
                    }
                    catch(IOException e2)
                    {
                        Log.e(TAG, "msrTestListener "+e2.getMessage());
                    }
                }
                else
                {
                    spinner_track_type.setEnabled(true);
                    button_payment.setEnabled(true);
                    button_msr.setText("Read MSR");
                    edit_track1.setText("");
                    edit_track2.setText("");
                    edit_track3.setText("");
                    // Normal mode restore command.
                    if (androidMSR != null)
                    {
                        try
                        {
                            androidMSR.cancelMSR();
                        }
                        catch (InterruptedException e)
                        {
                            Log.e(TAG, "msrTestListener "+e.getMessage());
                        }
                    }
                }
            }
        });

        button_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                androidMSR = AndroidMSR.getInstance();
                androidMSR.setHandler(paymentHandler);
                if(!button_payment.getText().equals("Cancel MSR"))
                {
                    try
                    {
                        if(androidMSR.readMSR(ESCPOSConst.LK_MSR_TRACK_2) == LKPrint.LK_STS_MSR_READ)
                        {
//						boolean s = androidMSR.isMSRStatus();
//						Log.d(TAG,"status "+s);

                            button_payment.setText("Cancel MSR");
                            button_msr.setEnabled(false);
                            spinner_track_type.setEnabled(false);
                        }
                        else
                        {
                            AlertDialog.Builder alert = new AlertDialog.Builder(context);
                            alert.setTitle("Error")
                                    .setMessage("Fail to change MSR mode.")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            // TODO Auto-generated method stub
                                            dialog.dismiss();
                                        }
                                    })
                                    .show();
                        }
                    }
                    catch(Exception e)
                    {
                        AlertDialog.Builder alert = new AlertDialog.Builder(context);
                        alert.setTitle("Error")
                                .setMessage(e.toString())
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub
                                        dialog.dismiss();
                                    }
                                })
                                .show();
                    }
                }
                else
                {
                    try
                    {
                        androidMSR.cancelMSR();
                    }
                    catch (Exception e)
                    {
                        Log.e(TAG,e.getMessage());
                    }
                    button_payment.setText("MSR Card");
                    button_msr.setEnabled(false);
                    spinner_track_type.setEnabled(false);
                }
            }
        });
    }

    protected void onDestroy() {
        // TODO Auto-generated method stub
        try
        {
            if(androidMSR != null)
                androidMSR.releaseInstance();
        }
        catch (InterruptedException e)
        {
            Log.e(TAG,e.getMessage(),e);
        }

        if (con_type.equals("BlueTooth")) {
            activity_list.remove(1);
            ((Bluetooth_Activity) activity_list.get(0)).ExcuteDisconnect();
        }
        else if(con_type.equals("WiFi")) {
            ((WiFi_Activity) activity_wifi).ExcuteDisconnect();
        }

        super.onDestroy();
    }

    final static Handler msrHandler = new MSRHandler();
    final static Handler paymentHandler = new PaymentHandler();

    static class PaymentHandler extends Handler
    {
        @Override
        public void handleMessage(Message msg)
        {
            Bundle bundle;
            super.handleMessage(msg);
            bundle = (Bundle) msg.obj;
            if (bundle.size() > 1)
            {
                byte [] rawData = bundle.getByteArray("RawData");
                Log.i(TAG,"RawDATA == "+ new String(rawData));
                String [] track = parsingMSRData(rawData);


                if (track.length >= 3)
                {
                    ReceiptSample msrSample = new ReceiptSample();
                    try
                    {
                        // Print track2
                        msrSample.cardPrint(track[1]);
                        edit_track2.setText(track[1]);
                        button_payment.setText("MSR Card");
                        spinner_track_type.setEnabled(true);
                        button_msr.setEnabled(true);
                    }
                    catch (Exception e)
                    {
                        Log.e(TAG, e.getMessage());

                        AlertDialog.Builder alert = new AlertDialog.Builder(context);
                        alert.setTitle("Error")
                                .setMessage(e.toString())
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub
                                        dialog.dismiss();
                                    }
                                })
                                .show();
                    }
                }
            }
            else
            {
                // Fail to read MSR.
                Log.e(TAG,"RawDATA == "+ new String(bundle.getByteArray("RawData")));

                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setTitle("Error")
                        .setMessage("Invalid MSR Data.")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        }
    }

    static class MSRHandler extends Handler
    {
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            Bundle bundle = (Bundle) msg.obj;

            if(bundle.size() > 1)
            {
                // rawData - MSR Data.
                byte [] rawData = bundle.getByteArray("RawData");
                int rawLength = bundle.getInt("RawDataSize");
                String [] track = parsingMSRData(rawData);
                if(track.length >= 3)
                {
                    edit_track1.setText(track[0]);
                    edit_track2.setText(track[1]);
                    edit_track3.setText(track[2]);
                }
                Log.i(TAG, "RawDATA == "+new String(rawData));
                Log.i(TAG, "RawDATA Buffer Size == "+rawData.length);
                Log.i(TAG, "RawDATA Size == "+ rawLength);
                Toast toast = Toast.makeText(context, "RawData Size : "+rawLength+"\r\n"
                        +new String(rawData,0,rawLength), Toast.LENGTH_SHORT);
                toast.show();
                spinner_track_type.setEnabled(true);
                button_payment.setEnabled(true);
                button_msr.setText("Read MSR");
            }
            else
            {
                // Fail to read MSR.
                Log.e(TAG,"RawDATA == "+new String(bundle.getByteArray("RawData")));

                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setTitle("Error")
                        .setMessage("Invalid MSR Data.")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        }
    }

    private static String[] parsingMSRData(byte[] rawData)
    {
        final byte[] FS = { (byte) 0x1C };
        final byte[] ETX = { (byte) 0x03 };

        String temp = new String(rawData);
        String trackData[] = new String[3];

        // ETX , FS
        String[] rData = temp.split(new String(ETX));
        temp = rData[0];
        String[] tData = temp.split(new String(FS));

        switch (tData.length)
        {
            case 1:
                break;
            case 2:
                trackData[0] = tData[1];
                break;
            case 3:
                trackData[0] = tData[1];
                trackData[1] = tData[2];
                break;
            case 4:
                trackData[0] = tData[1];
                trackData[1] = tData[2];
                trackData[2] = tData[3];
                break;
        }
        return trackData;
    }
}
