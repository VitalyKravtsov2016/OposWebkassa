package com.mobile.app.epl;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.mobile.app.assist.ResourceInstaller;
import com.mobile.app.assist.Sample;
import com.sewoo.jpos.command.EPLConst;

import java.util.ArrayList;

public class Menu_Activity extends BaseActivity implements Button.OnClickListener {

    private Spinner spinner_media_type;
    private Button button_text;
    private Button button_image;
    private Button button_barcode;

    private ArrayAdapter<String> adapter_media;

    Sample sample;
    int count = 1;
    int paper_type = EPLConst.LK_EPL_CONTINUOUS;

    String con_type = "";

    String[] str_media = {"Gap Paper","Black Mark Paper","Continuous Paper"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.menu_layout);

        ResourceInstaller ri = new ResourceInstaller();
        ri.copyAssets(getAssets(), "temp");

        Intent in = getIntent();
        con_type = in.getStringExtra("Connection");

        if(con_type.equals("BlueTooth"))
            activity_list.add(Menu_Activity.this);

        sample = new Sample();

        spinner_media_type = (Spinner)findViewById(R.id.SpinnerMediaType);
        button_text = (Button)findViewById(R.id.ButtonText);
        button_image = (Button)findViewById(R.id.ButtonImage);
        button_barcode = (Button)findViewById(R.id.ButtonBarcode);

        ArrayList<String> arr_media = new ArrayList<String>();

        for(int i=0; i<str_media.length; i++)
            arr_media.add(str_media[i]);

        adapter_media = new ArrayAdapter<String>(Menu_Activity.this, android.R.layout.simple_spinner_dropdown_item, arr_media);

        spinner_media_type.setAdapter(adapter_media);
        spinner_media_type.setSelection(2);

        spinner_media_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i)
                {
                    case 0 : paper_type = EPLConst.LK_EPL_LABEL; break;
                    case 1 : paper_type = EPLConst.LK_EPL_BLACKMARK; break;
                    case 2 : paper_type = EPLConst.LK_EPL_CONTINUOUS; break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        button_text.setOnClickListener(this);
        button_image.setOnClickListener(this);
        button_barcode.setOnClickListener(this);
    }

    public int check_data(String str)
    {
        int input_num;

        if(str.equals(""))
            input_num = 1;
        else
            input_num = Integer.parseInt(str);

        return input_num;
    }

    @Override
    public void onClick(View view) {

        final int view_num = view.getId();

        final LinearLayout linear_popup = (LinearLayout)View.inflate(Menu_Activity.this, R.layout.input_layout, null);
        final EditText edit_input = (EditText)linear_popup.findViewById(R.id.EditTextPopup);

        edit_input.setText(Integer.toString(count));

        AlertDialog.Builder alert_popup = new AlertDialog.Builder(Menu_Activity.this);

        alert_popup
                .setTitle("Input Number")
                .setView(linear_popup)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        String input_data = edit_input.getText().toString();
                        count = check_data(input_data);

                        try {
                            switch (view_num) {
                                case R.id.ButtonText:
                                    sample.Print_Text(count, paper_type);
                                    break;
                                case R.id.ButtonImage:
                                    sample.Print_Image(count, paper_type);
                                    break;
                                case R.id.ButtonBarcode:
                                    sample.Print_Barcode(count, paper_type);
                                    break;
                            }
                        }
                        catch(Exception e)
                        {
                            Log.e("NumberFormatException","Invalid Input Nubmer.",e);
                        }
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .show();
    }
    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub

        if (con_type.equals("BlueTooth")) {
            activity_list.remove(1);
            ((Bluetooth_Activity) activity_list.get(0)).ExcuteDisconnect();
        }
        else if(con_type.equals("WiFi")) {
            ((WiFi_Activity) activity_wifi).ExcuteDisconnect();
        }

        super.onDestroy();
    }

}
