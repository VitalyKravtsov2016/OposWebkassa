package com.mobile.app.assist;

import android.content.Context;
import android.webkit.WebView;

import com.sewoo.jpos.command.EPLConst;
import com.sewoo.jpos.command.ZPLConst;
import com.sewoo.jpos.printer.EPLPrinter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class Sample {

    private EPLPrinter eplPrinter;

    public Sample()
    {
        eplPrinter = new EPLPrinter();  //Default = English
        //eplPrinter = new EPLPrinter("EUC-KR"); // Korean.
        //eplPrinter = new EPLPrinter("GB2312"); //Chinese.
    }

    public void Print_Text(int count, int paper_type) throws UnsupportedEncodingException
    {
        eplPrinter.setupPrinter("104", "152", paper_type, "3", "0", 8, 6, 0);
        eplPrinter.printDeviceFont(400, 400, 0,   3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 90,  3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 180, 3, 1, 1, 0, "SEWOO Label Printer");
        eplPrinter.printDeviceFont(400, 400, 270, 3, 1, 1, 0, "SEWOO Label Printer");

        eplPrinter.endPage(count);
    }

    public void Print_Barcode(int count, int paper_type) throws IOException
    {
        String test_str = "Code128 Auto";
        String code_128a = "6015343013149";
        int barHeight = 12 * 8; // 12mm
        eplPrinter.setupPrinter("104", "152", paper_type, "3", "0", 8, 6, 0);

        eplPrinter.printDeviceFont(80, 80, 0, 3, 1, 1, 0, test_str);
        eplPrinter.printBarCode(400, 480, 0,   EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(384, 480, 90,  EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(384, 464, 180, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);
        eplPrinter.printBarCode(400, 464, 270, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // No readable.
        eplPrinter.printDeviceFont(80, 920, 0, 3, 1, 1, 0, "Human readable=No");
        eplPrinter.printBarCode(80, 960, 0, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // Readable
        eplPrinter.printDeviceFont(400, 920, 0, 3, 1, 1, 0, "Human readable=Yes");
        eplPrinter.printBarCode(400, 960, 0, EPLConst.LK_EPL_BCS_128AUTO, 2, 0, barHeight, 1, code_128a);

        // QR Code
        eplPrinter.printQRCode(40, 800, 0, 4, 0, "QR Code print");
        // DataMatrix
        eplPrinter.printDataMatrix(400, 800, 0, 4, "DataMatrix print");

        eplPrinter.endPage(count);
    }

    public void Print_Image(int count, int paper_type) throws UnsupportedEncodingException
    {
        eplPrinter.setupPrinter("104", "152", paper_type, "3", "0", 8, 6, 0);
        try
        {
            eplPrinter.printBitmap("//sdcard//temp//test//car_s.jpg", 10, 10);
            eplPrinter.printBitmap("//sdcard//temp//test//logo_s.jpg", 350, 10);

            eplPrinter.printBitmap("//sdcard//temp//test//danmark_windmill.jpg", 10, 600);
            eplPrinter.printBitmap("//sdcard//temp//test//logo_m.jpg", 350, 600);
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        eplPrinter.endPage(count);
    }
}
