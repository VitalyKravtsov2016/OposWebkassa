package com.mobile.sewoonfc.cpcl;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import com.sewoo.jpos.command.CPCLConst;
import com.sewoo.jpos.command.ESCPOS;
import com.sewoo.jpos.printer.CPCLPrinter;
import com.sewoo.jpos.printer.NFCPrinter;
import com.sewoo.port.android.BluetoothPort;
import com.sewoo.request.android.RequestHandler;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;

public class Bluetooth_Activity extends Activity {

    private static final String TAG = "BluetoothConnectMenu";
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int BT_PRINTER = 1536;

    private EditText edit_btAddress;

    private BluetoothPort bluetoothPort;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothDevice connectedDevice;
    private NFCPrinter nfc;
    private CPCLPrinter cpclPrinter;
    private String nfcdata;
    private Thread hThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cpclPrinter = new CPCLPrinter();
        nfc = new NFCPrinter();

        edit_btAddress = (EditText)findViewById(R.id.EditText_BT_Address);

        bluetoothSetup();

        Init_NFC();
    }

    private void bluetoothSetup()
    {
        bluetoothPort = BluetoothPort.getInstance();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (mBluetoothAdapter == null)
        {
            // Device does not support Bluetooth
            return;
        }
        if (!mBluetoothAdapter.isEnabled())
        {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    private NdefMessage[] getNdefMessages(Intent intent) {
        // Parse the intent
        NdefMessage[] msgs = null;
        String action = intent.getAction();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action))
        {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

            if (rawMsgs != null) {

                msgs = new NdefMessage[rawMsgs.length];

                for (int i = 0; i < rawMsgs.length; i++)
                {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            }
        }
        return msgs;
    }

    public void Init_NFC()
    {
        Intent intent = getIntent();
        String action = intent.getAction();

        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action))
        {
            NdefMessage[] messages = getNdefMessages(getIntent());
            byte[] payload = messages[0].getRecords()[0].getPayload();

            nfcdata = new String(payload);
            CharSequence cs = nfcdata;

            if (nfcdata.matches ("^[\\da-fA-F]+$"))
            {
                // Valid Hexadecimal number
                Log.e(TAG, "[BT] Valid: " + nfcdata);
                nfcdata = nfc.getBT(nfcdata);
                edit_btAddress.setText(nfcdata);
            } else {
                // Invalid
                Log.e(TAG, "[BT] Invalid: " + nfcdata);
                Toast toast = Toast.makeText(getApplicationContext(), "Invalid address", Toast.LENGTH_SHORT);
                toast.show();
                return;
            }

            if( nfc.isBT(nfcdata) )
            {
                Log.e(TAG, "isBT is true");
                nfcdata = nfc.getBT(nfcdata);
                edit_btAddress.setText(nfcdata);
            } else {
                Log.e(TAG, "isBT is false");
                return;
            }

            try
            {
                Log.e(TAG, "start btConnNfc");

                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                connectedDevice = mBluetoothAdapter.getRemoteDevice(nfcdata);

                btConnNfc(nfcdata);
                Log.e(TAG, "End btConnNfc");
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private void btConnNfc(final String btDev) throws IOException
    {
        Log.e(TAG, "start connTaskNfc" + btDev);
        new connTaskNfc().execute(btDev);
    }

    // Nfc Bluetooth Connection Task.
    class connTaskNfc extends AsyncTask<String, Void, Integer>
    {
        private final ProgressDialog dialog = new ProgressDialog(Bluetooth_Activity.this);

        @Override
        protected void onPreExecute()
        {
            Log.e(TAG, "start onPreExecute");
            dialog.setTitle("Bluetooth");
            dialog.setMessage("Connecting");
            dialog.show();
            super.onPreExecute();
        }

        @Override
        protected Integer doInBackground(String... params)
        {
            Integer retVal = null;
            int retrycnt = 0;


            for(retrycnt=0; retrycnt < 4; retrycnt++)
            {
                try
                {
                    Log.e(TAG, "[BT] start connect=" + params[0]);
                    bluetoothPort.connect(params[0]);
                    Log.e(TAG, "[BT] end connect=" + params[0]);

                    retVal = Integer.valueOf(0);
                    return retVal;
                }
                catch (IOException e)
                {
                    retVal = new Integer(-1);
                    try
                    {
                        Thread.sleep(1000);
                    }
                    catch (InterruptedException e1)
                    {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                }
            }

            return retVal;
        }

        @Override
        protected void onPostExecute(Integer result)
        {
            if(result.intValue() == 0)	// Connection success.
            {
                RequestHandler rh = new RequestHandler();
                hThread = new Thread(rh);
                hThread.start();
                // UI
                if(dialog.isShowing())
                    dialog.dismiss();

                Log.e(TAG, "start CPCLPrinter");

                try
                {
                    //2-inch
                    cpclPrinter.setForm(0, 200, 200, 406, 384, 1);
                    cpclPrinter.setMedia(CPCLConst.LK_CPCL_CONTINUOUS);

                    cpclPrinter.printCPCLText(0, 5, 1, 1, 1, "SEWOO TECH CO.,LTD.", 0);
                    cpclPrinter.printCPCLText(0, 0, 2, 1, 70, "Global leader in the mini-printer industry.", 0);
                    cpclPrinter.printCPCLText(0, 0, 2, 1, 110, "Total Printing Solution", 0);
                    cpclPrinter.printCPCLText(0, 0, 2, 1, 150, "Diverse innovative and reliable products", 0);
                    // Telephone
                    cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 7, 0, 1, 200, "TEL : 82-31-459-8200", 0);
                    // Homepage
                    cpclPrinter.printCPCL2DBarCode(0, CPCLConst.LK_CPCL_BCS_QRCODE, 0, 250, 4, 0, 1, 0, "http://www.miniprinter.com");
                    cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 7, 0, 130, 250, "www.miniprinter.com", 0);
                    cpclPrinter.printCPCLText(CPCLConst.LK_CPCL_0_ROTATION, 1, 0, 130, 300, "<-- Check This.", 0);
                    cpclPrinter.printForm();
                }
                catch (UnsupportedEncodingException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                try
                {
                    Thread.sleep(2500);
                }
                catch (InterruptedException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                if(bluetoothPort.isConnected())
                {
                    try
                    {
                        bluetoothPort.disconnect();

                        try {
                            Method method = connectedDevice.getClass().getMethod("removeBond", (Class[]) null);
                            method.invoke(connectedDevice, (Object[]) null);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    catch (IOException e)
                    {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    catch (InterruptedException e)
                    {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                finish();
            }
            else	// Connection failed.
            {
                if(dialog.isShowing())
                    dialog.dismiss();

                AlertDialog.Builder alert = new AlertDialog.Builder(Bluetooth_Activity.this);

                alert
                        .setTitle("Error")
                        .setMessage("Connection failed.")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
            super.onPostExecute(result);
        }
    }

    @Override
    protected void onDestroy()
    {
        if((hThread != null) && (hThread.isAlive()))
        {
            hThread.interrupt();
            hThread = null;
        }

        super.onDestroy();
    }
}
