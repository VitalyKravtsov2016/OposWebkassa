package net.posprinter.asynncTask;

import android.os.AsyncTask;
import net.posprinter.posprinterface.BackgroundInit;
import net.posprinter.posprinterface.TaskCallback;

public class PosAsynncTask extends AsyncTask<Void, Void, Boolean> {
   TaskCallback callback;
   BackgroundInit init;

   public PosAsynncTask(TaskCallback callback, BackgroundInit init) {
      this.callback = callback;
      this.init = init;
   }

   protected Boolean doInBackground(Void... params) {
      boolean result = false;
      result = this.init.doinbackground();
      return result;
   }

   protected void onPostExecute(Boolean result) {
      super.onPostExecute(result);
      if (result) {
         this.callback.OnSucceed();
         this.cancel(true);
      } else {
         this.callback.OnFailed();
         this.cancel(true);
      }

   }
}
