package net.posprinter.utils;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import java.util.ArrayList;
import java.util.List;

public class BitmapProcess {
   public static Bitmap compressBmpByPrinterWidth(Bitmap bitmap, BitmapProcess.PrinterWidth printerWidth) {
      Bitmap resizedBitmap = null;
      int width = bitmap.getWidth();
      int height = bitmap.getHeight();
      short w;
      switch(printerWidth.ordinal()) {
      case 1:
         w = 576;
         break;
      case 2:
         w = 508;
         break;
      case 3:
         w = 384;
         break;
      default:
         w = 576;
      }

      if (width <= w) {
         return bitmap;
      } else {
         int newHeight = height * w / width;
         float scaleWidth = (float)w / (float)width;
         float scaleHeight = (float)newHeight / (float)height;
         Matrix matrix = new Matrix();
         matrix.postScale(scaleWidth, scaleHeight);
         resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
         return resizedBitmap;
      }
   }

   public static Bitmap compressBmpByYourWidth(Bitmap bitmap, int w) {
      Bitmap resizedBitmap = null;
      int width = bitmap.getWidth();
      int height = bitmap.getHeight();
      if (width <= w) {
         return bitmap;
      } else {
         int newHeight = height * w / width;
         float scaleWidth = (float)w / (float)width;
         float scaleHeight = (float)newHeight / (float)height;
         Matrix matrix = new Matrix();
         matrix.postScale(scaleWidth, scaleHeight);
         resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
         return resizedBitmap;
      }
   }

   public static Bitmap rotateBmp(Bitmap bitmap, BitmapProcess.RotateType rotateType) {
      Matrix matrix = new Matrix();
      float degrees = 0.0F;
      switch(rotateType.ordinal()) {
      case 1:
         degrees = 90.0F;
         break;
      case 2:
         degrees = 180.0F;
         break;
      case 3:
         degrees = 270.0F;
      }

      matrix.postRotate(degrees);
      Bitmap bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
      return bitmap2;
   }

   public static List<Bitmap> cutBitmap(int h, Bitmap bitmap) {
      int width = bitmap.getWidth();
      int height = bitmap.getHeight();
      boolean full = height % h == 0;
      int n = height % h == 0 ? height / h : height / h + 1;
      List<Bitmap> bitmaps = new ArrayList();

      for(int i = 0; i < n; ++i) {
         Bitmap b;
         if (full) {
            b = Bitmap.createBitmap(bitmap, 0, i * h, width, h);
         } else if (i == n - 1) {
            b = Bitmap.createBitmap(bitmap, 0, i * h, width, height - i * h);
         } else {
            b = Bitmap.createBitmap(bitmap, 0, i * h, width, h);
         }

         bitmaps.add(b);
      }

      return bitmaps;
   }

   public static Bitmap resizeImage(Bitmap bitmap, int w, boolean isOriginal) {
      Bitmap resizedBitmap = null;
      int width = bitmap.getWidth();
      int height = bitmap.getHeight();
      if (width <= w) {
         return bitmap;
      } else {
         if (!isOriginal) {
            int newHeight = height * w / width;
            float scaleWidth = (float)w / (float)width;
            float scaleHeight = (float)newHeight / (float)height;
            Matrix matrix = new Matrix();
            matrix.postScale(scaleWidth, scaleHeight);
            resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
         } else {
            resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, w, height);
         }

         return resizedBitmap;
      }
   }

   static enum RotateType {
      Rotate90,
      Rotate180,
      Rotate270;
   }

   static enum PrinterWidth {
      Pos80,
      Pos76,
      Pos58;
   }
}
