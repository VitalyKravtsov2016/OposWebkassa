package net.posprinter.utils;

import java.io.UnsupportedEncodingException;

public class StringUtils {
   public static byte[] strTobytes(String str) {
      byte[] data = null;

      try {
         byte[] b = str.getBytes("utf-8");
         data = (new String(b, "utf-8")).getBytes("gbk");
      } catch (UnsupportedEncodingException var3) {
         var3.printStackTrace();
      }

      return data;
   }

   public static byte[] byteMerger(byte[] byte_1, byte[] byte_2) {
      byte[] byte_3 = new byte[byte_1.length + byte_2.length];
      System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);
      System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);
      return byte_3;
   }

   public static byte[] strTobytes(String str, String charset) {
      byte[] data = null;

      try {
         byte[] b = str.getBytes("utf-8");
         data = (new String(b, "utf-8")).getBytes(charset);
      } catch (UnsupportedEncodingException var4) {
         var4.printStackTrace();
      }

      return data;
   }
}
