package net.posprinter.posprinterface;

public interface BackgroundInit {
   boolean doinbackground();
}
