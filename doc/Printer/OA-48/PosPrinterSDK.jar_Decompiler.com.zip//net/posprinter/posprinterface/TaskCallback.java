package net.posprinter.posprinterface;

public interface TaskCallback {
   void OnSucceed();

   void OnFailed();
}
