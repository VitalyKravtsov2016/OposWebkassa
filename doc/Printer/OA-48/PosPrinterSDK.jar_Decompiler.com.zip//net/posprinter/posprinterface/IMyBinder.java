package net.posprinter.posprinterface;

import android.content.Context;
import java.util.List;
import net.posprinter.utils.PosPrinterDev;
import net.posprinter.utils.RoundQueue;

public interface IMyBinder {
   void ConnectNetPort(String var1, int var2, TaskCallback var3);

   void ConnectBtPort(String var1, TaskCallback var2);

   void ConnectUsbPort(Context var1, String var2, TaskCallback var3);

   void DisconnectCurrentPort(TaskCallback var1);

   void Acceptdatafromprinter(TaskCallback var1, int var2);

   RoundQueue<byte[]> ReadBuffer();

   void ClearBuffer();

   void CheckLinkedState(TaskCallback var1);

   void Write(byte[] var1, TaskCallback var2);

   void WriteSendData(TaskCallback var1, ProcessData var2);

   void writeDataByUSB(TaskCallback var1, ProcessData var2);

   void DisconnetNetPort(TaskCallback var1);

   List<String> OnDiscovery(PosPrinterDev.PortType var1, Context var2);

   List<String> getBtAvailableDevice();
}
