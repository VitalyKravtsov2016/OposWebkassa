package net.posprinter.posprinterface;

import android.content.Context;
import net.posprinter.utils.RoundQueue;

public interface PrinterBinder {
   void connectBtPort(String var1, TaskCallback var2);

   void connectUsbPort(Context var1, String var2, TaskCallback var3);

   void connectNetPort(String var1, TaskCallback var2);

   void disconnectCurrentPort(String var1, TaskCallback var2);

   void disconnectAll(TaskCallback var1);

   void acceptdatafromprinter(String var1, TaskCallback var2);

   RoundQueue<byte[]> readBuffer(String var1);

   void clearBuffer(String var1);

   void checkLinkedState(String var1, TaskCallback var2);

   void write(String var1, byte[] var2, TaskCallback var3);

   void writeDataByYouself(String var1, TaskCallback var2, ProcessData var3);

   boolean isConnect(String var1);
}
