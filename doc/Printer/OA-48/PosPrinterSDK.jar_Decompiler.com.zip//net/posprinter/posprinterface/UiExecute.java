package net.posprinter.posprinterface;

public interface UiExecute {
   void onsucess();

   void onfailed();
}
