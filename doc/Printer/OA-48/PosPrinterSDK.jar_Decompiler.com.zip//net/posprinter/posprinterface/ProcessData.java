package net.posprinter.posprinterface;

import java.util.List;

public interface ProcessData {
   List<byte[]> processDataBeforeSend();
}
